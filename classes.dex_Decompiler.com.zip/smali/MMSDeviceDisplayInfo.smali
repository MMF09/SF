###### Class defpackage.MMSDeviceDisplayInfo (MMSDeviceDisplayInfo)
.class public final LMMSDeviceDisplayInfo;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LMMSDeviceDisplayInfo$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT_HDR_SUPPORT:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_REFRESH_RATE:Ljava/lang/Float;

.field public static final DEFAULT_RESOLUTION_HEIGHT:Ljava/lang/Integer;

.field public static final DEFAULT_RESOLUTION_WIDTH:Ljava/lang/Integer;

.field private static final serialVersionUID:J


# instance fields
.field public final hdr_support:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        tag = 0x4
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final refresh_rate:Ljava/lang/Float;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x3
        type = .enum Lcom/squareup/wire/Message$Datatype;->FLOAT:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final resolution_height:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x2
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final resolution_width:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x1
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, LMMSDeviceDisplayInfo;->DEFAULT_RESOLUTION_WIDTH:Ljava/lang/Integer;

    .line 7
    .line 8
    sput-object v0, LMMSDeviceDisplayInfo;->DEFAULT_RESOLUTION_HEIGHT:Ljava/lang/Integer;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sput-object v0, LMMSDeviceDisplayInfo;->DEFAULT_REFRESH_RATE:Ljava/lang/Float;

    .line 16
    .line 17
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    sput-object v0, LMMSDeviceDisplayInfo;->DEFAULT_HDR_SUPPORT:Ljava/util/List;

    .line 22
    .line 23
    return-void
.end method

.method private constructor <init>(LMMSDeviceDisplayInfo$Builder;)V
    .registers 6

    .line 7
    iget-object v0, p1, LMMSDeviceDisplayInfo$Builder;->resolution_width:Ljava/lang/Integer;

    iget-object v1, p1, LMMSDeviceDisplayInfo$Builder;->resolution_height:Ljava/lang/Integer;

    iget-object v2, p1, LMMSDeviceDisplayInfo$Builder;->refresh_rate:Ljava/lang/Float;

    iget-object v3, p1, LMMSDeviceDisplayInfo$Builder;->hdr_support:Ljava/util/List;

    invoke-direct {p0, v0, v1, v2, v3}, LMMSDeviceDisplayInfo;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Float;Ljava/util/List;)V

    .line 8
    invoke-virtual {p0, p1}, Lcom/squareup/wire/Message;->setBuilder(Lcom/squareup/wire/Message$Builder;)V

    return-void
.end method

.method public synthetic constructor <init>(LMMSDeviceDisplayInfo$Builder;LMMSDeviceDisplayInfo$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LMMSDeviceDisplayInfo;-><init>(LMMSDeviceDisplayInfo$Builder;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Float;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            "Ljava/lang/Float;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .line 2
    invoke-direct {p0}, Lcom/squareup/wire/Message;-><init>()V

    .line 3
    iput-object p1, p0, LMMSDeviceDisplayInfo;->resolution_width:Ljava/lang/Integer;

    .line 4
    iput-object p2, p0, LMMSDeviceDisplayInfo;->resolution_height:Ljava/lang/Integer;

    .line 5
    iput-object p3, p0, LMMSDeviceDisplayInfo;->refresh_rate:Ljava/lang/Float;

    .line 6
    invoke-static {p4}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceDisplayInfo;->hdr_support:Ljava/util/List;

    return-void
.end method

.method public static synthetic access$000(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LMMSDeviceDisplayInfo;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LMMSDeviceDisplayInfo;

    .line 12
    .line 13
    iget-object v1, p0, LMMSDeviceDisplayInfo;->resolution_width:Ljava/lang/Integer;

    .line 14
    .line 15
    iget-object v3, p1, LMMSDeviceDisplayInfo;->resolution_width:Ljava/lang/Integer;

    .line 16
    .line 17
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_35

    .line 22
    .line 23
    iget-object v1, p0, LMMSDeviceDisplayInfo;->resolution_height:Ljava/lang/Integer;

    .line 24
    .line 25
    iget-object v3, p1, LMMSDeviceDisplayInfo;->resolution_height:Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_35

    .line 32
    .line 33
    iget-object v1, p0, LMMSDeviceDisplayInfo;->refresh_rate:Ljava/lang/Float;

    .line 34
    .line 35
    iget-object v3, p1, LMMSDeviceDisplayInfo;->refresh_rate:Ljava/lang/Float;

    .line 36
    .line 37
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_35

    .line 42
    .line 43
    iget-object v1, p0, LMMSDeviceDisplayInfo;->hdr_support:Ljava/util/List;

    .line 44
    .line 45
    iget-object p1, p1, LMMSDeviceDisplayInfo;->hdr_support:Ljava/util/List;

    .line 46
    .line 47
    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    if-eqz p1, :cond_35

    .line 52
    .line 53
    goto :goto_36

    .line 54
    :cond_35
    const/4 v0, 0x0

    .line 55
    :goto_36
    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 2
    .line 3
    if-nez v0, :cond_36

    .line 4
    .line 5
    iget-object v0, p0, LMMSDeviceDisplayInfo;->resolution_width:Ljava/lang/Integer;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Integer;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    mul-int/lit8 v0, v0, 0x25

    .line 17
    .line 18
    iget-object v2, p0, LMMSDeviceDisplayInfo;->resolution_height:Ljava/lang/Integer;

    .line 19
    .line 20
    if-eqz v2, :cond_1a

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Integer;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x0

    .line 28
    :goto_1b
    add-int/2addr v0, v2

    .line 29
    mul-int/lit8 v0, v0, 0x25

    .line 30
    .line 31
    iget-object v2, p0, LMMSDeviceDisplayInfo;->refresh_rate:Ljava/lang/Float;

    .line 32
    .line 33
    if-eqz v2, :cond_26

    .line 34
    .line 35
    invoke-virtual {v2}, Ljava/lang/Float;->hashCode()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    :cond_26
    add-int/2addr v0, v1

    .line 40
    mul-int/lit8 v0, v0, 0x25

    .line 41
    .line 42
    iget-object v1, p0, LMMSDeviceDisplayInfo;->hdr_support:Ljava/util/List;

    .line 43
    .line 44
    if-eqz v1, :cond_32

    .line 45
    .line 46
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    goto :goto_33

    .line 51
    :cond_32
    const/4 v1, 0x1

    .line 52
    :goto_33
    add-int/2addr v0, v1

    .line 53
    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 54
    .line 55
    :cond_36
    return v0
.end method

###### Class MMSDeviceDisplayInfo.Builder (MMSDeviceDisplayInfo$Builder)
.class public final LMMSDeviceDisplayInfo$Builder;
.super Lcom/squareup/wire/Message$Builder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceDisplayInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/Message$Builder<",
        "LMMSDeviceDisplayInfo;",
        ">;"
    }
.end annotation


# instance fields
.field public hdr_support:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public refresh_rate:Ljava/lang/Float;

.field public resolution_height:Ljava/lang/Integer;

.field public resolution_width:Ljava/lang/Integer;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/squareup/wire/Message$Builder;-><init>()V

    return-void
.end method

.method public constructor <init>(LMMSDeviceDisplayInfo;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/squareup/wire/Message$Builder;-><init>(Lcom/squareup/wire/Message;)V

    if-nez p1, :cond_6

    return-void

    .line 3
    :cond_6
    iget-object v0, p1, LMMSDeviceDisplayInfo;->resolution_width:Ljava/lang/Integer;

    iput-object v0, p0, LMMSDeviceDisplayInfo$Builder;->resolution_width:Ljava/lang/Integer;

    .line 4
    iget-object v0, p1, LMMSDeviceDisplayInfo;->resolution_height:Ljava/lang/Integer;

    iput-object v0, p0, LMMSDeviceDisplayInfo$Builder;->resolution_height:Ljava/lang/Integer;

    .line 5
    iget-object v0, p1, LMMSDeviceDisplayInfo;->refresh_rate:Ljava/lang/Float;

    iput-object v0, p0, LMMSDeviceDisplayInfo$Builder;->refresh_rate:Ljava/lang/Float;

    .line 6
    iget-object p1, p1, LMMSDeviceDisplayInfo;->hdr_support:Ljava/util/List;

    invoke-static {p1}, LMMSDeviceDisplayInfo;->access$000(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceDisplayInfo$Builder;->hdr_support:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public build()LMMSDeviceDisplayInfo;
    .registers 3

    .line 2
    new-instance v0, LMMSDeviceDisplayInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, LMMSDeviceDisplayInfo;-><init>(LMMSDeviceDisplayInfo$Builder;LMMSDeviceDisplayInfo$a;)V

    return-object v0
.end method

.method public bridge synthetic build()Lcom/squareup/wire/Message;
    .registers 2

    .line 1
    invoke-virtual {p0}, LMMSDeviceDisplayInfo$Builder;->build()LMMSDeviceDisplayInfo;

    move-result-object v0

    return-object v0
.end method

.method public hdr_support(Ljava/util/List;)LMMSDeviceDisplayInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)",
            "LMMSDeviceDisplayInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceDisplayInfo$Builder;->hdr_support:Ljava/util/List;

    return-object p0
.end method

.method public refresh_rate(Ljava/lang/Float;)LMMSDeviceDisplayInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceDisplayInfo$Builder;->refresh_rate:Ljava/lang/Float;

    return-object p0
.end method

.method public resolution_height(Ljava/lang/Integer;)LMMSDeviceDisplayInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceDisplayInfo$Builder;->resolution_height:Ljava/lang/Integer;

    return-object p0
.end method

.method public resolution_width(Ljava/lang/Integer;)LMMSDeviceDisplayInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceDisplayInfo$Builder;->resolution_width:Ljava/lang/Integer;

    return-object p0
.end method

###### Class MMSDeviceDisplayInfo.a (MMSDeviceDisplayInfo$a)
.class public synthetic LMMSDeviceDisplayInfo$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceDisplayInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation
