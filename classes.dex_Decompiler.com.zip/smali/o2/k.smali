###### Class o2.k (o2.k)
.class public Lo2/k;
.super Lo2/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

.field public b:Lcom/google/android/gms/maps/model/TileOverlay;

.field public c:Lo2/j;

.field public d:Ljava/lang/String;

.field public e:F

.field public i:F

.field public j:F

.field public k:F

.field public l:Z

.field public m:F

.field public n:Z

.field public o:Ljava/lang/String;

.field public p:F

.field public q:Z

.field public r:F

.field public s:Landroid/content/Context;

.field public t:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x42c80000    # 100.0f

    .line 5
    .line 6
    iput v0, p0, Lo2/k;->j:F

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-boolean v0, p0, Lo2/k;->l:Z

    .line 10
    .line 11
    const/high16 v1, 0x43800000    # 256.0f

    .line 12
    .line 13
    iput v1, p0, Lo2/k;->m:F

    .line 14
    .line 15
    iput-boolean v0, p0, Lo2/k;->n:Z

    .line 16
    .line 17
    iput-boolean v0, p0, Lo2/k;->q:Z

    .line 18
    .line 19
    const/high16 v1, 0x3f800000    # 1.0f

    .line 20
    .line 21
    iput v1, p0, Lo2/k;->r:F

    .line 22
    .line 23
    iput-boolean v0, p0, Lo2/k;->t:Z

    .line 24
    .line 25
    iput-object p1, p0, Lo2/k;->s:Landroid/content/Context;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    invoke-virtual {p0}, Lo2/k;->getTileOverlayOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    move-result-object p1

    iput-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    return-void
.end method

.method public c()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v1, "urlTile "

    .line 4
    .line 5
    const-string v2, "creating TileProvider"

    .line 6
    .line 7
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 8
    .line 9
    .line 10
    new-instance v1, Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 11
    .line 12
    invoke-direct {v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;-><init>()V

    .line 13
    .line 14
    .line 15
    iget v2, v0, Lo2/k;->e:F

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->zIndex(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 18
    .line 19
    .line 20
    iget v2, v0, Lo2/k;->r:F

    .line 21
    .line 22
    const/high16 v3, 0x3f800000    # 1.0f

    .line 23
    .line 24
    sub-float/2addr v3, v2

    .line 25
    invoke-virtual {v1, v3}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->transparency(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 26
    .line 27
    .line 28
    new-instance v2, Lo2/j;

    .line 29
    .line 30
    iget v3, v0, Lo2/k;->m:F

    .line 31
    .line 32
    float-to-int v5, v3

    .line 33
    iget-boolean v6, v0, Lo2/k;->n:Z

    .line 34
    .line 35
    iget-object v7, v0, Lo2/k;->d:Ljava/lang/String;

    .line 36
    .line 37
    iget v3, v0, Lo2/k;->i:F

    .line 38
    .line 39
    float-to-int v8, v3

    .line 40
    iget v3, v0, Lo2/k;->j:F

    .line 41
    .line 42
    float-to-int v9, v3

    .line 43
    iget v3, v0, Lo2/k;->k:F

    .line 44
    .line 45
    float-to-int v10, v3

    .line 46
    iget-boolean v11, v0, Lo2/k;->l:Z

    .line 47
    .line 48
    iget-object v12, v0, Lo2/k;->o:Ljava/lang/String;

    .line 49
    .line 50
    iget v3, v0, Lo2/k;->p:F

    .line 51
    .line 52
    float-to-int v13, v3

    .line 53
    iget-boolean v14, v0, Lo2/k;->q:Z

    .line 54
    .line 55
    iget-object v15, v0, Lo2/k;->s:Landroid/content/Context;

    .line 56
    .line 57
    iget-boolean v3, v0, Lo2/k;->t:Z

    .line 58
    .line 59
    move-object v4, v2

    .line 60
    move/from16 v16, v3

    .line 61
    .line 62
    invoke-direct/range {v4 .. v16}, Lo2/j;-><init>(IZLjava/lang/String;IIIZLjava/lang/String;IZLandroid/content/Context;Z)V

    .line 63
    .line 64
    .line 65
    iput-object v2, v0, Lo2/k;->c:Lo2/j;

    .line 66
    .line 67
    invoke-virtual {v1, v2}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tileProvider(Lcom/google/android/gms/maps/model/TileProvider;)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 68
    .line 69
    .line 70
    return-object v1
.end method

.method public d()V
    .registers 3

    .line 1
    const-string v0, "urlTile "

    .line 2
    .line 3
    const-string v1, "creating new mode TileProvider"

    .line 4
    .line 5
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Lo2/k;->t:Z

    .line 10
    .line 11
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 12
    .line 13
    if-eqz v0, :cond_11

    .line 14
    .line 15
    invoke-virtual {v0}, Lo2/j;->k()V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    return-object v0
.end method

.method public getTileOverlayOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/k;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/k;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/k;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/k;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setDoubleTileSize(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/k;->n:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lo2/j;->l(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    invoke-virtual {p0}, Lo2/k;->d()V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 14
    .line 15
    if-eqz p1, :cond_13

    .line 16
    .line 17
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 18
    .line 19
    .line 20
    :cond_13
    return-void
.end method

.method public setFlipY(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/k;->l:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lo2/j;->m(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setMaximumNativeZ(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->j:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/j;->n(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    invoke-virtual {p0}, Lo2/k;->d()V

    .line 12
    .line 13
    .line 14
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 15
    .line 16
    if-eqz p1, :cond_14

    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public setMaximumZ(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->i:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/j;->o(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 12
    .line 13
    if-eqz p1, :cond_11

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setMinimumZ(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->k:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/j;->p(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 12
    .line 13
    if-eqz p1, :cond_11

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setOfflineMode(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/k;->q:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lo2/j;->q(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setOpacity(F)V
    .registers 4

    .line 1
    iput p1, p0, Lo2/k;->r:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_c

    .line 6
    .line 7
    const/high16 v1, 0x3f800000    # 1.0f

    .line 8
    .line 9
    sub-float/2addr v1, p1

    .line 10
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlay;->setTransparency(F)V

    .line 11
    .line 12
    .line 13
    :cond_c
    return-void
.end method

.method public setTileCacheMaxAge(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->p:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/j;->r(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 12
    .line 13
    if-eqz p1, :cond_11

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setTileCachePath(Ljava/lang/String;)V
    .registers 3

    .line 1
    if-eqz p1, :cond_29

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_9

    .line 8
    .line 9
    goto :goto_29

    .line 10
    :cond_9
    :try_start_9
    new-instance v0, Ljava/net/URL;

    .line 11
    .line 12
    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/net/URL;->getPath()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, Lo2/k;->o:Ljava/lang/String;
    :try_end_14
    .catch Ljava/net/MalformedURLException; {:try_start_9 .. :try_end_14} :catch_16
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    .line 20
    .line 21
    goto :goto_18

    .line 22
    :catch_15
    return-void

    .line 23
    :catch_16
    iput-object p1, p0, Lo2/k;->o:Ljava/lang/String;

    .line 24
    .line 25
    :goto_18
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 26
    .line 27
    if-eqz v0, :cond_1f

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Lo2/j;->s(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    :cond_1f
    invoke-virtual {p0}, Lo2/k;->d()V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 36
    .line 37
    if-eqz p1, :cond_29

    .line 38
    .line 39
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 40
    .line 41
    .line 42
    :cond_29
    :goto_29
    return-void
.end method

.method public setTileSize(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->m:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/j;->t(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 12
    .line 13
    if-eqz p1, :cond_11

    .line 14
    .line 15
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setUrlTemplate(Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/k;->d:Ljava/lang/String;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->c:Lo2/j;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lo2/j;->u(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/k;->e:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/k;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/TileOverlay;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method
