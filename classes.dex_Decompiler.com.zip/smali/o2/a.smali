###### Class o2.a (o2.a)
.class public Lo2/a;
.super Lcom/facebook/react/views/view/ReactViewGroup;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:I

.field public c:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/facebook/react/views/view/ReactViewGroup;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-boolean p1, p0, Lo2/a;->a:Z

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public getTooltip()Z
    .registers 2

    iget-boolean v0, p0, Lo2/a;->a:Z

    return v0
.end method

.method public setTooltip(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/a;->a:Z

    return-void
.end method
