###### Class o2.c (o2.c)
.class public abstract Lo2/c;
.super Lcom/facebook/react/views/view/ReactViewGroup;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/facebook/react/views/view/ReactViewGroup;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public abstract a(Lcom/google/android/gms/maps/GoogleMap;)V
.end method

.method public abstract getFeature()Ljava/lang/Object;
.end method
