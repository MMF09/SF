###### Class o2.m (o2.m)
.class public Lo2/m;
.super Lo2/k;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/m$a;
    }
.end annotation


# static fields
.field public static final v:[D


# instance fields
.field public u:Lo2/m$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x2

    new-array v0, v0, [D

    fill-array-data v0, :array_a

    sput-object v0, Lo2/m;->v:[D

    return-void

    nop

    :array_a
    .array-data 8
        -0x3e8ce407ba6f0856L    # -2.003750834789244E7
        0x41731bf84590f7aaL    # 2.003750834789244E7
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lo2/k;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public static synthetic e()[D
    .registers 1

    sget-object v0, Lo2/m;->v:[D

    return-object v0
.end method


# virtual methods
.method public c()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 16

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/TileOverlayOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Lo2/k;->e:F

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->zIndex(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 9
    .line 10
    .line 11
    iget v1, p0, Lo2/k;->r:F

    .line 12
    .line 13
    const/high16 v2, 0x3f800000    # 1.0f

    .line 14
    .line 15
    sub-float/2addr v2, v1

    .line 16
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->transparency(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 17
    .line 18
    .line 19
    new-instance v1, Lo2/m$a;

    .line 20
    .line 21
    iget v2, p0, Lo2/k;->m:F

    .line 22
    .line 23
    float-to-int v5, v2

    .line 24
    iget-object v6, p0, Lo2/k;->d:Ljava/lang/String;

    .line 25
    .line 26
    iget v2, p0, Lo2/k;->i:F

    .line 27
    .line 28
    float-to-int v7, v2

    .line 29
    iget v2, p0, Lo2/k;->j:F

    .line 30
    .line 31
    float-to-int v8, v2

    .line 32
    iget v2, p0, Lo2/k;->k:F

    .line 33
    .line 34
    float-to-int v9, v2

    .line 35
    iget-object v10, p0, Lo2/k;->o:Ljava/lang/String;

    .line 36
    .line 37
    iget v2, p0, Lo2/k;->p:F

    .line 38
    .line 39
    float-to-int v11, v2

    .line 40
    iget-boolean v12, p0, Lo2/k;->q:Z

    .line 41
    .line 42
    iget-object v13, p0, Lo2/k;->s:Landroid/content/Context;

    .line 43
    .line 44
    iget-boolean v14, p0, Lo2/k;->t:Z

    .line 45
    .line 46
    move-object v3, v1

    .line 47
    move-object v4, p0

    .line 48
    invoke-direct/range {v3 .. v14}, Lo2/m$a;-><init>(Lo2/m;ILjava/lang/String;IIILjava/lang/String;IZLandroid/content/Context;Z)V

    .line 49
    .line 50
    .line 51
    iput-object v1, p0, Lo2/m;->u:Lo2/m$a;

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tileProvider(Lcom/google/android/gms/maps/model/TileProvider;)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 54
    .line 55
    .line 56
    return-object v0
.end method

###### Class o2.m.a (o2.m$a)
.class public Lo2/m$a;
.super Lo2/j;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/m$a$a;
    }
.end annotation


# instance fields
.field public final synthetic n:Lo2/m;


# direct methods
.method public constructor <init>(Lo2/m;ILjava/lang/String;IIILjava/lang/String;IZLandroid/content/Context;Z)V
    .registers 26

    .line 1
    move-object v13, p0

    .line 2
    move-object v0, p1

    .line 3
    iput-object v0, v13, Lo2/m$a;->n:Lo2/m;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v7, 0x0

    .line 7
    move-object v0, p0

    .line 8
    move/from16 v1, p2

    .line 9
    .line 10
    move-object/from16 v3, p3

    .line 11
    .line 12
    move/from16 v4, p4

    .line 13
    .line 14
    move/from16 v5, p5

    .line 15
    .line 16
    move/from16 v6, p6

    .line 17
    .line 18
    move-object/from16 v8, p7

    .line 19
    .line 20
    move/from16 v9, p8

    .line 21
    .line 22
    move/from16 v10, p9

    .line 23
    .line 24
    move-object/from16 v11, p10

    .line 25
    .line 26
    move/from16 v12, p11

    .line 27
    .line 28
    invoke-direct/range {v0 .. v12}, Lo2/j;-><init>(IZLjava/lang/String;IIIZLjava/lang/String;IZLandroid/content/Context;Z)V

    .line 29
    .line 30
    .line 31
    new-instance v0, Lo2/m$a$a;

    .line 32
    .line 33
    move-object/from16 v2, p3

    .line 34
    .line 35
    invoke-direct {v0, p0, v1, v1, v2}, Lo2/m$a$a;-><init>(Lo2/m$a;IILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iput-object v0, v13, Lo2/j;->a:Lcom/google/android/gms/maps/model/UrlTileProvider;

    .line 39
    .line 40
    return-void
.end method

###### Class o2.m.a.C0057a (o2.m$a$a)
.class public Lo2/m$a$a;
.super Lcom/google/android/gms/maps/model/UrlTileProvider;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/m$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public final synthetic c:Lo2/m$a;


# direct methods
.method public constructor <init>(Lo2/m$a;IILjava/lang/String;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lo2/m$a$a;->c:Lo2/m$a;

    .line 2
    .line 3
    invoke-direct {p0, p2, p3}, Lcom/google/android/gms/maps/model/UrlTileProvider;-><init>(II)V

    .line 4
    .line 5
    .line 6
    iput-object p4, p0, Lo2/m$a$a;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput p2, p0, Lo2/m$a$a;->b:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(III)[D
    .registers 13

    .line 1
    int-to-double v0, p3

    .line 2
    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    .line 3
    .line 4
    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    .line 5
    .line 6
    .line 7
    move-result-wide v0

    .line 8
    const-wide v2, 0x41831bf84590f7aaL    # 4.007501669578488E7

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    div-double/2addr v2, v0

    .line 14
    const/4 p3, 0x4

    .line 15
    new-array p3, p3, [D

    .line 16
    .line 17
    invoke-static {}, Lo2/m;->e()[D

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    const/4 v1, 0x0

    .line 22
    aget-wide v4, v0, v1

    .line 23
    .line 24
    int-to-double v6, p1

    .line 25
    mul-double v6, v6, v2

    .line 26
    .line 27
    add-double/2addr v4, v6

    .line 28
    aput-wide v4, p3, v1

    .line 29
    .line 30
    invoke-static {}, Lo2/m;->e()[D

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v4, 0x1

    .line 35
    aget-wide v5, v0, v4

    .line 36
    .line 37
    add-int/lit8 v0, p2, 0x1

    .line 38
    .line 39
    int-to-double v7, v0

    .line 40
    mul-double v7, v7, v2

    .line 41
    .line 42
    sub-double/2addr v5, v7

    .line 43
    aput-wide v5, p3, v4

    .line 44
    .line 45
    invoke-static {}, Lo2/m;->e()[D

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    aget-wide v5, v0, v1

    .line 50
    .line 51
    add-int/2addr p1, v4

    .line 52
    int-to-double v0, p1

    .line 53
    mul-double v0, v0, v2

    .line 54
    .line 55
    add-double/2addr v5, v0

    .line 56
    const/4 p1, 0x2

    .line 57
    aput-wide v5, p3, p1

    .line 58
    .line 59
    invoke-static {}, Lo2/m;->e()[D

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    aget-wide v0, p1, v4

    .line 64
    .line 65
    int-to-double p1, p2

    .line 66
    mul-double p1, p1, v2

    .line 67
    .line 68
    sub-double/2addr v0, p1

    .line 69
    const/4 p1, 0x3

    .line 70
    aput-wide v0, p3, p1

    .line 71
    .line 72
    return-object p3
.end method

.method public getTileUrl(III)Ljava/net/URL;
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/m$a$a;->c:Lo2/m$a;

    .line 2
    .line 3
    iget-object v1, v0, Lo2/m$a;->n:Lo2/m;

    .line 4
    .line 5
    iget v2, v1, Lo2/k;->i:F

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x0

    .line 9
    cmpl-float v2, v2, v4

    .line 10
    .line 11
    if-lez v2, :cond_11

    .line 12
    .line 13
    iget v2, v0, Lo2/j;->e:I

    .line 14
    .line 15
    if-le p3, v2, :cond_11

    .line 16
    .line 17
    return-object v3

    .line 18
    :cond_11
    iget v1, v1, Lo2/k;->k:F

    .line 19
    .line 20
    cmpl-float v1, v1, v4

    .line 21
    .line 22
    if-lez v1, :cond_1c

    .line 23
    .line 24
    iget v0, v0, Lo2/j;->g:I

    .line 25
    .line 26
    if-ge p3, v0, :cond_1c

    .line 27
    .line 28
    return-object v3

    .line 29
    :cond_1c
    invoke-virtual {p0, p1, p2, p3}, Lo2/m$a$a;->a(III)[D

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iget-object p2, p0, Lo2/m$a$a;->a:Ljava/lang/String;

    .line 34
    .line 35
    const/4 p3, 0x0

    .line 36
    aget-wide v0, p1, p3

    .line 37
    .line 38
    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p3

    .line 42
    const-string v0, "{minX}"

    .line 43
    .line 44
    invoke-virtual {p2, v0, p3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    const/4 p3, 0x1

    .line 49
    aget-wide v0, p1, p3

    .line 50
    .line 51
    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p3

    .line 55
    const-string v0, "{minY}"

    .line 56
    .line 57
    invoke-virtual {p2, v0, p3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    const/4 p3, 0x2

    .line 62
    aget-wide v0, p1, p3

    .line 63
    .line 64
    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p3

    .line 68
    const-string v0, "{maxX}"

    .line 69
    .line 70
    invoke-virtual {p2, v0, p3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    const/4 p3, 0x3

    .line 75
    aget-wide v0, p1, p3

    .line 76
    .line 77
    invoke-static {v0, v1}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    const-string p3, "{maxY}"

    .line 82
    .line 83
    invoke-virtual {p2, p3, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    iget p2, p0, Lo2/m$a$a;->b:I

    .line 88
    .line 89
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p2

    .line 93
    const-string p3, "{width}"

    .line 94
    .line 95
    invoke-virtual {p1, p3, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    iget p2, p0, Lo2/m$a$a;->b:I

    .line 100
    .line 101
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p2

    .line 105
    const-string p3, "{height}"

    .line 106
    .line 107
    invoke-virtual {p1, p3, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    :try_start_6e
    new-instance p2, Ljava/net/URL;

    .line 112
    .line 113
    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_73
    .catch Ljava/net/MalformedURLException; {:try_start_6e .. :try_end_73} :catch_74

    .line 114
    .line 115
    .line 116
    return-object p2

    .line 117
    :catch_74
    move-exception p1

    .line 118
    new-instance p2, Ljava/lang/AssertionError;

    .line 119
    .line 120
    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    throw p2
.end method
