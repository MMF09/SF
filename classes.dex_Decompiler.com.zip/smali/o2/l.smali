###### Class o2.l (o2.l)
.class public Lo2/l;
.super Lcom/google/android/gms/maps/MapView;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$InfoWindowAdapter;
.implements Lcom/google/android/gms/maps/GoogleMap$OnMarkerDragListener;
.implements Lcom/google/android/gms/maps/OnMapReadyCallback;
.implements Lcom/google/android/gms/maps/GoogleMap$OnPoiClickListener;
.implements Lcom/google/android/gms/maps/GoogleMap$OnIndoorStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/l$r;
    }
.end annotation


# static fields
.field public static final b0:[Ljava/lang/String;


# instance fields
.field public final A:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/Marker;",
            "Lcom/airbnb/android/react/maps/a;",
            ">;"
        }
    .end annotation
.end field

.field public final B:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/Polyline;",
            "Lo2/i;",
            ">;"
        }
    .end annotation
.end field

.field public final C:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/Polygon;",
            "Lo2/h;",
            ">;"
        }
    .end annotation
.end field

.field public final D:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/GroundOverlay;",
            "Lo2/g;",
            ">;"
        }
    .end annotation
.end field

.field public final E:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/TileOverlay;",
            "Lo2/e;",
            ">;"
        }
    .end annotation
.end field

.field public final F:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/google/android/gms/maps/model/TileOverlay;",
            "Lo2/d;",
            ">;"
        }
    .end annotation
.end field

.field public final G:Landroidx/core/view/GestureDetectorCompat;

.field public final H:Lcom/airbnb/android/react/maps/AirMapManager;

.field public I:Lo2/l$r;

.field public J:Z

.field public K:Z

.field public final L:Lcom/facebook/react/uimanager/ThemedReactContext;

.field public final M:Lcom/facebook/react/uimanager/events/EventDispatcher;

.field public N:Lcom/google/android/gms/maps/LocationSource;

.field public O:Lo2/v;

.field public P:Lcom/google/android/gms/maps/model/LatLng;

.field public Q:J

.field public final R:Landroid/os/Handler;

.field public final S:Ljava/lang/Runnable;

.field public T:I

.field public U:I

.field public V:I

.field public W:I

.field public a:Lcom/google/android/gms/maps/GoogleMap;

.field public final a0:Ljava/lang/Runnable;

.field public b:Lde/f;

.field public c:Landroid/widget/ProgressBar;

.field public d:Landroid/widget/RelativeLayout;

.field public e:Landroid/widget/ImageView;

.field public i:Ljava/lang/Boolean;

.field public j:Ljava/lang/Integer;

.field public k:Ljava/lang/Integer;

.field public final l:I

.field public m:Lcom/google/android/gms/maps/model/LatLngBounds;

.field public n:Lcom/google/android/gms/maps/CameraUpdate;

.field public o:Z

.field public p:Z

.field public q:Z

.field public r:Z

.field public s:Lcom/facebook/react/bridge/ReadableMap;

.field public t:Lcom/facebook/react/bridge/ReadableMap;

.field public u:Ljava/lang/String;

.field public v:Z

.field public w:Z

.field public x:Lcom/google/android/gms/maps/model/LatLngBounds;

.field public y:I

.field public final z:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lo2/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lo2/l;->b0:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/bridge/ReactApplicationContext;Lcom/airbnb/android/react/maps/AirMapManager;Lcom/google/android/gms/maps/GoogleMapOptions;)V
    .registers 9

    .line 1
    invoke-static {p1, p2}, Lo2/l;->O(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/bridge/ReactApplicationContext;)Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    invoke-direct {p0, p2, p4}, Lcom/google/android/gms/maps/MapView;-><init>(Landroid/content/Context;Lcom/google/android/gms/maps/GoogleMapOptions;)V

    .line 6
    .line 7
    .line 8
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 9
    .line 10
    iput-object p2, p0, Lo2/l;->i:Ljava/lang/Boolean;

    .line 11
    .line 12
    const/4 p2, 0x0

    .line 13
    iput-object p2, p0, Lo2/l;->j:Ljava/lang/Integer;

    .line 14
    .line 15
    iput-object p2, p0, Lo2/l;->k:Ljava/lang/Integer;

    .line 16
    .line 17
    const/16 p4, 0x32

    .line 18
    .line 19
    iput p4, p0, Lo2/l;->l:I

    .line 20
    .line 21
    const/4 p4, 0x0

    .line 22
    iput-boolean p4, p0, Lo2/l;->o:Z

    .line 23
    .line 24
    iput-boolean p4, p0, Lo2/l;->p:Z

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    iput-boolean v0, p0, Lo2/l;->q:Z

    .line 28
    .line 29
    iput-boolean p4, p0, Lo2/l;->r:Z

    .line 30
    .line 31
    iput-boolean p4, p0, Lo2/l;->v:Z

    .line 32
    .line 33
    iput-boolean p4, p0, Lo2/l;->w:Z

    .line 34
    .line 35
    iput p4, p0, Lo2/l;->y:I

    .line 36
    .line 37
    new-instance v0, Ljava/util/ArrayList;

    .line 38
    .line 39
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 43
    .line 44
    new-instance v0, Ljava/util/HashMap;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, Lo2/l;->A:Ljava/util/Map;

    .line 50
    .line 51
    new-instance v0, Ljava/util/HashMap;

    .line 52
    .line 53
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object v0, p0, Lo2/l;->B:Ljava/util/Map;

    .line 57
    .line 58
    new-instance v0, Ljava/util/HashMap;

    .line 59
    .line 60
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 61
    .line 62
    .line 63
    iput-object v0, p0, Lo2/l;->C:Ljava/util/Map;

    .line 64
    .line 65
    new-instance v0, Ljava/util/HashMap;

    .line 66
    .line 67
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 68
    .line 69
    .line 70
    iput-object v0, p0, Lo2/l;->D:Ljava/util/Map;

    .line 71
    .line 72
    new-instance v0, Ljava/util/HashMap;

    .line 73
    .line 74
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 75
    .line 76
    .line 77
    iput-object v0, p0, Lo2/l;->E:Ljava/util/Map;

    .line 78
    .line 79
    new-instance v0, Ljava/util/HashMap;

    .line 80
    .line 81
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 82
    .line 83
    .line 84
    iput-object v0, p0, Lo2/l;->F:Ljava/util/Map;

    .line 85
    .line 86
    iput-boolean p4, p0, Lo2/l;->J:Z

    .line 87
    .line 88
    iput-boolean p4, p0, Lo2/l;->K:Z

    .line 89
    .line 90
    const-wide/16 v0, 0x0

    .line 91
    .line 92
    iput-wide v0, p0, Lo2/l;->Q:J

    .line 93
    .line 94
    new-instance v0, Landroid/os/Handler;

    .line 95
    .line 96
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 101
    .line 102
    .line 103
    iput-object v0, p0, Lo2/l;->R:Landroid/os/Handler;

    .line 104
    .line 105
    new-instance v1, Lo2/l$i;

    .line 106
    .line 107
    invoke-direct {v1, p0}, Lo2/l$i;-><init>(Lo2/l;)V

    .line 108
    .line 109
    .line 110
    iput-object v1, p0, Lo2/l;->S:Ljava/lang/Runnable;

    .line 111
    .line 112
    new-instance v2, Lo2/l$h;

    .line 113
    .line 114
    invoke-direct {v2, p0}, Lo2/l$h;-><init>(Lo2/l;)V

    .line 115
    .line 116
    .line 117
    iput-object v2, p0, Lo2/l;->a0:Ljava/lang/Runnable;

    .line 118
    .line 119
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 120
    .line 121
    .line 122
    move-result-wide v2

    .line 123
    iput-wide v2, p0, Lo2/l;->Q:J

    .line 124
    .line 125
    const-wide/16 v2, 0x7530

    .line 126
    .line 127
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 128
    .line 129
    .line 130
    iput-object p3, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 131
    .line 132
    iput-object p1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 133
    .line 134
    invoke-super {p0, p2}, Lcom/google/android/gms/maps/MapView;->onCreate(Landroid/os/Bundle;)V

    .line 135
    .line 136
    .line 137
    invoke-super {p0}, Lcom/google/android/gms/maps/MapView;->onResume()V

    .line 138
    .line 139
    .line 140
    invoke-super {p0, p0}, Lcom/google/android/gms/maps/MapView;->getMapAsync(Lcom/google/android/gms/maps/OnMapReadyCallback;)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {p0, p1}, Lo2/l;->G(Landroid/content/Context;)Lcom/google/android/gms/maps/LocationSource;

    .line 144
    .line 145
    .line 146
    move-result-object p2

    .line 147
    iput-object p2, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    .line 148
    .line 149
    new-instance p2, Landroidx/core/view/GestureDetectorCompat;

    .line 150
    .line 151
    new-instance p3, Lo2/l$j;

    .line 152
    .line 153
    invoke-direct {p3, p0}, Lo2/l$j;-><init>(Lo2/l;)V

    .line 154
    .line 155
    .line 156
    invoke-direct {p2, p1, p3}, Landroidx/core/view/GestureDetectorCompat;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    .line 157
    .line 158
    .line 159
    iput-object p2, p0, Lo2/l;->G:Landroidx/core/view/GestureDetectorCompat;

    .line 160
    .line 161
    new-instance p2, Lo2/l$k;

    .line 162
    .line 163
    invoke-direct {p2, p0}, Lo2/l$k;-><init>(Lo2/l;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {p0, p2}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    .line 167
    .line 168
    .line 169
    const-class p2, Lcom/facebook/react/uimanager/UIManagerModule;

    .line 170
    .line 171
    invoke-virtual {p1, p2}, Lcom/facebook/react/bridge/ReactContext;->getNativeModule(Ljava/lang/Class;)Lcom/facebook/react/bridge/NativeModule;

    .line 172
    .line 173
    .line 174
    move-result-object p2

    .line 175
    check-cast p2, Lcom/facebook/react/uimanager/UIManagerModule;

    .line 176
    .line 177
    invoke-virtual {p2}, Lcom/facebook/react/uimanager/UIManagerModule;->getEventDispatcher()Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 178
    .line 179
    .line 180
    move-result-object p2

    .line 181
    iput-object p2, p0, Lo2/l;->M:Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 182
    .line 183
    new-instance p2, Lo2/v;

    .line 184
    .line 185
    invoke-direct {p2, p1}, Lo2/v;-><init>(Landroid/content/Context;)V

    .line 186
    .line 187
    .line 188
    iput-object p2, p0, Lo2/l;->O:Lo2/v;

    .line 189
    .line 190
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    .line 191
    .line 192
    invoke-direct {p1, p4, p4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 193
    .line 194
    .line 195
    iput p4, p1, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 196
    .line 197
    iput p4, p1, Landroid/widget/FrameLayout$LayoutParams;->height:I

    .line 198
    .line 199
    const p2, 0x5f5e0ff

    .line 200
    .line 201
    .line 202
    iput p2, p1, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 203
    .line 204
    iput p2, p1, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 205
    .line 206
    iget-object p2, p0, Lo2/l;->O:Lo2/v;

    .line 207
    .line 208
    invoke-virtual {p2, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 209
    .line 210
    .line 211
    iget-object p1, p0, Lo2/l;->O:Lo2/v;

    .line 212
    .line 213
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 214
    .line 215
    .line 216
    return-void
.end method

.method public static O(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/bridge/ReactApplicationContext;)Landroid/content/Context;
    .registers 2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic a(Lo2/l;)Z
    .registers 1

    iget-boolean p0, p0, Lo2/l;->p:Z

    return p0
.end method

.method public static synthetic b(Lo2/l;)Z
    .registers 1

    iget-boolean p0, p0, Lo2/l;->J:Z

    return p0
.end method

.method public static synthetic c(Lo2/l;)Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lo2/l;->D:Ljava/util/Map;

    return-object p0
.end method

.method public static synthetic d(Lo2/l;Z)Z
    .registers 2

    iput-boolean p1, p0, Lo2/l;->J:Z

    return p1
.end method

.method public static synthetic e(Lo2/l;)I
    .registers 1

    iget p0, p0, Lo2/l;->y:I

    return p0
.end method

.method public static synthetic f(Lo2/l;I)I
    .registers 2

    iput p1, p0, Lo2/l;->y:I

    return p1
.end method

.method public static synthetic g(Lo2/l;)Lcom/google/android/gms/maps/model/LatLngBounds;
    .registers 1

    iget-object p0, p0, Lo2/l;->x:Lcom/google/android/gms/maps/model/LatLngBounds;

    return-object p0
.end method

.method private getCacheImageView()Landroid/widget/ImageView;
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 2
    .line 3
    if-nez v0, :cond_1e

    .line 4
    .line 5
    new-instance v0, Landroid/widget/ImageView;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 15
    .line 16
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    .line 17
    .line 18
    const/4 v2, -0x1

    .line 19
    invoke-direct {v1, v2, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 26
    .line 27
    const/4 v1, 0x4

    .line 28
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    :cond_1e
    iget-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 32
    .line 33
    return-object v0
.end method

.method private getMapLoadingLayoutView()Landroid/widget/RelativeLayout;
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 2
    .line 3
    if-nez v0, :cond_3a

    .line 4
    .line 5
    new-instance v0, Landroid/widget/RelativeLayout;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 15
    .line 16
    const v1, -0x333334

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 23
    .line 24
    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    .line 25
    .line 26
    const/4 v2, -0x1

    .line 27
    invoke-direct {v1, v2, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 31
    .line 32
    .line 33
    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    .line 34
    .line 35
    const/4 v1, -0x2

    .line 36
    invoke-direct {v0, v1, v1}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 37
    .line 38
    .line 39
    const/16 v1, 0xd

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 42
    .line 43
    .line 44
    iget-object v1, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 45
    .line 46
    invoke-direct {p0}, Lo2/l;->getMapLoadingProgressBar()Landroid/widget/ProgressBar;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v1, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 54
    .line 55
    const/4 v1, 0x4

    .line 56
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 57
    .line 58
    .line 59
    :cond_3a
    iget-object v0, p0, Lo2/l;->j:Ljava/lang/Integer;

    .line 60
    .line 61
    invoke-virtual {p0, v0}, Lo2/l;->setLoadingBackgroundColor(Ljava/lang/Integer;)V

    .line 62
    .line 63
    .line 64
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 65
    .line 66
    return-object v0
.end method

.method private getMapLoadingProgressBar()Landroid/widget/ProgressBar;
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 2
    .line 3
    if-nez v0, :cond_13

    .line 4
    .line 5
    new-instance v0, Landroid/widget/ProgressBar;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    invoke-direct {v0, v1}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 15
    .line 16
    const/4 v1, 0x1

    .line 17
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    .line 18
    .line 19
    .line 20
    :cond_13
    iget-object v0, p0, Lo2/l;->k:Ljava/lang/Integer;

    .line 21
    .line 22
    if-eqz v0, :cond_1a

    .line 23
    .line 24
    invoke-virtual {p0, v0}, Lo2/l;->setLoadingIndicatorColor(Ljava/lang/Integer;)V

    .line 25
    .line 26
    .line 27
    :cond_1a
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 28
    .line 29
    return-object v0
.end method

.method public static synthetic h(Lo2/l;Lcom/google/android/gms/maps/model/LatLngBounds;)Lcom/google/android/gms/maps/model/LatLngBounds;
    .registers 2

    iput-object p1, p0, Lo2/l;->x:Lcom/google/android/gms/maps/model/LatLngBounds;

    return-object p1
.end method

.method public static synthetic i(Lo2/l;)Lcom/facebook/react/uimanager/events/EventDispatcher;
    .registers 1

    iget-object p0, p0, Lo2/l;->M:Lcom/facebook/react/uimanager/events/EventDispatcher;

    return-object p0
.end method

.method public static synthetic j(Lo2/l;)J
    .registers 3

    iget-wide v0, p0, Lo2/l;->Q:J

    return-wide v0
.end method

.method public static synthetic k(Lo2/l;)Ljava/lang/Runnable;
    .registers 1

    iget-object p0, p0, Lo2/l;->S:Ljava/lang/Runnable;

    return-object p0
.end method

.method public static synthetic l(Lo2/l;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lo2/l;->R:Landroid/os/Handler;

    return-object p0
.end method

.method public static synthetic m(Lo2/l;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    .registers 2

    iput-object p1, p0, Lo2/l;->i:Ljava/lang/Boolean;

    return-object p1
.end method

.method public static synthetic n(Lo2/l;)Z
    .registers 1

    invoke-virtual {p0}, Lo2/l;->P()Z

    move-result p0

    return p0
.end method

.method public static synthetic o(Lo2/l;)V
    .registers 1

    invoke-virtual {p0}, Lo2/l;->F()V

    return-void
.end method

.method public static synthetic p(Lo2/l;)Z
    .registers 1

    iget-boolean p0, p0, Lo2/l;->o:Z

    return p0
.end method

.method public static synthetic q(Lo2/l;)Lcom/google/android/gms/maps/LocationSource;
    .registers 1

    iget-object p0, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    return-object p0
.end method

.method public static synthetic r(Lo2/l;)Z
    .registers 1

    iget-boolean p0, p0, Lo2/l;->K:Z

    return p0
.end method

.method public static synthetic s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;
    .registers 1

    iget-object p0, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    return-object p0
.end method

.method public static synthetic t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;
    .registers 1

    iget-object p0, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    return-object p0
.end method

.method public static synthetic u(Lo2/l;Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;
    .registers 2

    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic v(Lo2/l;)Z
    .registers 1

    iget-boolean p0, p0, Lo2/l;->q:Z

    return p0
.end method

.method public static synthetic w(Lo2/l;)Lcom/google/android/gms/maps/model/LatLng;
    .registers 1

    iget-object p0, p0, Lo2/l;->P:Lcom/google/android/gms/maps/model/LatLng;

    return-object p0
.end method

.method public static synthetic x(Lo2/l;)Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lo2/l;->C:Ljava/util/Map;

    return-object p0
.end method

.method public static synthetic y(Lo2/l;)Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lo2/l;->B:Ljava/util/Map;

    return-object p0
.end method


# virtual methods
.method public A(Lcom/facebook/react/bridge/ReadableMap;I)V
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v1, Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getCameraPosition()Lcom/google/android/gms/maps/model/CameraPosition;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-direct {v1, v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;-><init>(Lcom/google/android/gms/maps/model/CameraPosition;)V

    .line 13
    .line 14
    .line 15
    const-string v0, "zoom"

    .line 16
    .line 17
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-eqz v2, :cond_1e

    .line 22
    .line 23
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 24
    .line 25
    .line 26
    move-result-wide v2

    .line 27
    double-to-float v0, v2

    .line 28
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->zoom(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 29
    .line 30
    .line 31
    :cond_1e
    const-string v0, "heading"

    .line 32
    .line 33
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_2e

    .line 38
    .line 39
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 40
    .line 41
    .line 42
    move-result-wide v2

    .line 43
    double-to-float v0, v2

    .line 44
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->bearing(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 45
    .line 46
    .line 47
    :cond_2e
    const-string v0, "pitch"

    .line 48
    .line 49
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_3e

    .line 54
    .line 55
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 56
    .line 57
    .line 58
    move-result-wide v2

    .line 59
    double-to-float v0, v2

    .line 60
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->tilt(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 61
    .line 62
    .line 63
    :cond_3e
    const-string v0, "center"

    .line 64
    .line 65
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->hasKey(Ljava/lang/String;)Z

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    if-eqz v2, :cond_5e

    .line 70
    .line 71
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getMap(Ljava/lang/String;)Lcom/facebook/react/bridge/ReadableMap;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    new-instance v0, Lcom/google/android/gms/maps/model/LatLng;

    .line 76
    .line 77
    const-string v2, "latitude"

    .line 78
    .line 79
    invoke-interface {p1, v2}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 80
    .line 81
    .line 82
    move-result-wide v2

    .line 83
    const-string v4, "longitude"

    .line 84
    .line 85
    invoke-interface {p1, v4}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 86
    .line 87
    .line 88
    move-result-wide v4

    .line 89
    invoke-direct {v0, v2, v3, v4, v5}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->target(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 93
    .line 94
    .line 95
    :cond_5e
    invoke-virtual {v1}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->build()Lcom/google/android/gms/maps/model/CameraPosition;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    invoke-static {p1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newCameraPosition(Lcom/google/android/gms/maps/model/CameraPosition;)Lcom/google/android/gms/maps/CameraUpdate;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    if-gtz p2, :cond_6e

    .line 104
    .line 105
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 106
    .line 107
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 108
    .line 109
    .line 110
    goto :goto_74

    .line 111
    :cond_6e
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 112
    .line 113
    const/4 v1, 0x0

    .line 114
    invoke-virtual {v0, p1, p2, v1}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;ILcom/google/android/gms/maps/GoogleMap$CancelableCallback;)V

    .line 115
    .line 116
    .line 117
    :goto_74
    return-void
.end method

.method public B(Lcom/google/android/gms/maps/model/LatLngBounds;I)V
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v1, 0x0

    .line 7
    if-gtz p2, :cond_10

    .line 8
    .line 9
    invoke-static {p1, v1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 14
    .line 15
    .line 16
    goto :goto_18

    .line 17
    :cond_10
    invoke-static {p1, v1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {v0, p1, p2, v1}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;ILcom/google/android/gms/maps/GoogleMap$CancelableCallback;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    return-void
.end method

.method public final C(IIII)V
    .registers 9

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 10
    .line 11
    float-to-double v0, v0

    .line 12
    int-to-double v2, p1

    .line 13
    mul-double v2, v2, v0

    .line 14
    .line 15
    double-to-int p1, v2

    .line 16
    int-to-double v2, p2

    .line 17
    mul-double v2, v2, v0

    .line 18
    .line 19
    double-to-int p2, v2

    .line 20
    int-to-double v2, p3

    .line 21
    mul-double v2, v2, v0

    .line 22
    .line 23
    double-to-int p3, v2

    .line 24
    int-to-double v2, p4

    .line 25
    mul-double v2, v2, v0

    .line 26
    .line 27
    double-to-int p4, v2

    .line 28
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 29
    .line 30
    iget v1, p0, Lo2/l;->T:I

    .line 31
    .line 32
    add-int/2addr p1, v1

    .line 33
    iget v1, p0, Lo2/l;->V:I

    .line 34
    .line 35
    add-int/2addr p2, v1

    .line 36
    iget v1, p0, Lo2/l;->U:I

    .line 37
    .line 38
    add-int/2addr p3, v1

    .line 39
    iget v1, p0, Lo2/l;->W:I

    .line 40
    .line 41
    add-int/2addr p4, v1

    .line 42
    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/google/android/gms/maps/GoogleMap;->setPadding(IIII)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public D(IIII)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/google/android/gms/maps/GoogleMap;->setPadding(IIII)V

    .line 4
    .line 5
    .line 6
    iput p1, p0, Lo2/l;->T:I

    .line 7
    .line 8
    iput p3, p0, Lo2/l;->U:I

    .line 9
    .line 10
    iput p2, p0, Lo2/l;->V:I

    .line 11
    .line 12
    iput p4, p0, Lo2/l;->W:I

    .line 13
    .line 14
    return-void
.end method

.method public final E()V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->s:Lcom/facebook/react/bridge/ReadableMap;

    .line 2
    .line 3
    if-eqz v0, :cond_b

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Lo2/l;->R(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Lo2/l;->v:Z

    .line 10
    .line 11
    goto :goto_10

    .line 12
    :cond_b
    iget-object v0, p0, Lo2/l;->t:Lcom/facebook/react/bridge/ReadableMap;

    .line 13
    .line 14
    invoke-virtual {p0, v0}, Lo2/l;->R(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 15
    .line 16
    .line 17
    :goto_10
    iget-object v0, p0, Lo2/l;->u:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v0, :cond_20

    .line 20
    .line 21
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 22
    .line 23
    new-instance v1, Lcom/google/android/gms/maps/model/MapStyleOptions;

    .line 24
    .line 25
    iget-object v2, p0, Lo2/l;->u:Ljava/lang/String;

    .line 26
    .line 27
    invoke-direct {v1, v2}, Lcom/google/android/gms/maps/model/MapStyleOptions;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->setMapStyle(Lcom/google/android/gms/maps/model/MapStyleOptions;)Z

    .line 31
    .line 32
    .line 33
    :cond_20
    return-void
.end method

.method public final F()V
    .registers 5

    .line 1
    iget-boolean v0, p0, Lo2/l;->r:Z

    .line 2
    .line 3
    if-eqz v0, :cond_27

    .line 4
    .line 5
    invoke-direct {p0}, Lo2/l;->getCacheImageView()Landroid/widget/ImageView;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-direct {p0}, Lo2/l;->getMapLoadingLayoutView()Landroid/widget/RelativeLayout;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v2, 0x4

    .line 14
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 19
    .line 20
    .line 21
    iget-object v2, p0, Lo2/l;->i:Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-eqz v2, :cond_35

    .line 28
    .line 29
    iget-object v2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 30
    .line 31
    new-instance v3, Lo2/l$g;

    .line 32
    .line 33
    invoke-direct {v3, p0, v0, v1}, Lo2/l$g;-><init>(Lo2/l;Landroid/widget/ImageView;Landroid/widget/RelativeLayout;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/GoogleMap;->snapshot(Lcom/google/android/gms/maps/GoogleMap$SnapshotReadyCallback;)V

    .line 37
    .line 38
    .line 39
    goto :goto_35

    .line 40
    :cond_27
    invoke-virtual {p0}, Lo2/l;->V()V

    .line 41
    .line 42
    .line 43
    iget-object v0, p0, Lo2/l;->i:Ljava/lang/Boolean;

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_35

    .line 50
    .line 51
    invoke-virtual {p0}, Lo2/l;->X()V

    .line 52
    .line 53
    .line 54
    :cond_35
    :goto_35
    return-void
.end method

.method public final G(Landroid/content/Context;)Lcom/google/android/gms/maps/LocationSource;
    .registers 3

    .line 1
    sget-object v0, Lp2/b;->a:Lp2/b;

    .line 2
    .line 3
    invoke-virtual {v0}, Lp2/b;->a()Lp2/a;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_f

    .line 8
    .line 9
    invoke-virtual {v0}, Lp2/a;->a()Lcom/google/android/gms/maps/LocationSource;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_f
    new-instance v0, Lo2/o;

    .line 17
    .line 18
    invoke-direct {v0, p1}, Lo2/o;-><init>(Landroid/content/Context;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public declared-synchronized H()V
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-boolean v0, p0, Lo2/l;->K:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_3d

    .line 3
    .line 4
    if-eqz v0, :cond_7

    .line 5
    .line 6
    monitor-exit p0

    .line 7
    return-void

    .line 8
    :cond_7
    const/4 v0, 0x1

    .line 9
    :try_start_8
    iput-boolean v0, p0, Lo2/l;->K:Z

    .line 10
    .line 11
    iget-object v1, p0, Lo2/l;->I:Lo2/l$r;

    .line 12
    .line 13
    if-eqz v1, :cond_28

    .line 14
    .line 15
    iget-object v1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 16
    .line 17
    if-eqz v1, :cond_28

    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    instance-of v2, v1, Landroidx/lifecycle/LifecycleOwner;

    .line 24
    .line 25
    if-eqz v2, :cond_28

    .line 26
    .line 27
    check-cast v1, Landroidx/lifecycle/LifecycleOwner;

    .line 28
    .line 29
    invoke-interface {v1}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    iget-object v2, p0, Lo2/l;->I:Lo2/l$r;

    .line 34
    .line 35
    invoke-virtual {v1, v2}, Landroidx/lifecycle/Lifecycle;->removeObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 36
    .line 37
    .line 38
    const/4 v1, 0x0

    .line 39
    iput-object v1, p0, Lo2/l;->I:Lo2/l$r;

    .line 40
    .line 41
    :cond_28
    iget-boolean v1, p0, Lo2/l;->J:Z

    .line 42
    .line 43
    if-nez v1, :cond_31

    .line 44
    .line 45
    invoke-virtual {p0}, Lcom/google/android/gms/maps/MapView;->onPause()V

    .line 46
    .line 47
    .line 48
    iput-boolean v0, p0, Lo2/l;->J:Z

    .line 49
    .line 50
    :cond_31
    invoke-virtual {p0}, Lcom/google/android/gms/maps/MapView;->onDestroy()V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lo2/l;->R:Landroid/os/Handler;

    .line 54
    .line 55
    iget-object v1, p0, Lo2/l;->S:Ljava/lang/Runnable;

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    :try_end_3b
    .catchall {:try_start_8 .. :try_end_3b} :catchall_3d

    .line 58
    .line 59
    .line 60
    monitor-exit p0

    .line 61
    return-void

    .line 62
    :catchall_3d
    move-exception v0

    .line 63
    monitor-exit p0

    .line 64
    throw v0
.end method

.method public I(Z)V
    .registers 3

    .line 1
    if-eqz p1, :cond_12

    .line 2
    .line 3
    iget-object p1, p0, Lo2/l;->i:Ljava/lang/Boolean;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-nez p1, :cond_12

    .line 10
    .line 11
    invoke-direct {p0}, Lo2/l;->getMapLoadingLayoutView()Landroid/widget/RelativeLayout;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const/4 v0, 0x0

    .line 16
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 17
    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public J(Lcom/facebook/react/bridge/ReadableArray;Lcom/facebook/react/bridge/ReadableMap;Z)V
    .registers 11

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 7
    .line 8
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;-><init>()V

    .line 9
    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    :goto_b
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-ge v1, v2, :cond_3c

    .line 17
    .line 18
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    const-string v3, "latitude"

    .line 23
    .line 24
    invoke-interface {v2, v3}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 25
    .line 26
    .line 27
    move-result-wide v3

    .line 28
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    const-string v4, "longitude"

    .line 33
    .line 34
    invoke-interface {v2, v4}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 35
    .line 36
    .line 37
    move-result-wide v4

    .line 38
    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    new-instance v4, Lcom/google/android/gms/maps/model/LatLng;

    .line 43
    .line 44
    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    .line 45
    .line 46
    .line 47
    move-result-wide v5

    .line 48
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 49
    .line 50
    .line 51
    move-result-wide v2

    .line 52
    invoke-direct {v4, v5, v6, v2, v3}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0, v4}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 56
    .line 57
    .line 58
    add-int/lit8 v1, v1, 0x1

    .line 59
    .line 60
    goto :goto_b

    .line 61
    :cond_3c
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->build()Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    const/16 v0, 0x32

    .line 66
    .line 67
    invoke-static {p1, v0}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    if-eqz p2, :cond_63

    .line 72
    .line 73
    const-string v0, "left"

    .line 74
    .line 75
    invoke-interface {p2, v0}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    const-string v1, "top"

    .line 80
    .line 81
    invoke-interface {p2, v1}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 82
    .line 83
    .line 84
    move-result v1

    .line 85
    const-string v2, "right"

    .line 86
    .line 87
    invoke-interface {p2, v2}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    const-string v3, "bottom"

    .line 92
    .line 93
    invoke-interface {p2, v3}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 94
    .line 95
    .line 96
    move-result p2

    .line 97
    invoke-virtual {p0, v0, v1, v2, p2}, Lo2/l;->C(IIII)V

    .line 98
    .line 99
    .line 100
    :cond_63
    if-eqz p3, :cond_6b

    .line 101
    .line 102
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 103
    .line 104
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 105
    .line 106
    .line 107
    goto :goto_70

    .line 108
    :cond_6b
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 109
    .line 110
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 111
    .line 112
    .line 113
    :goto_70
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 114
    .line 115
    iget p2, p0, Lo2/l;->T:I

    .line 116
    .line 117
    iget p3, p0, Lo2/l;->V:I

    .line 118
    .line 119
    iget v0, p0, Lo2/l;->U:I

    .line 120
    .line 121
    iget v1, p0, Lo2/l;->W:I

    .line 122
    .line 123
    invoke-virtual {p1, p2, p3, v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->setPadding(IIII)V

    .line 124
    .line 125
    .line 126
    return-void
.end method

.method public K(Lcom/facebook/react/bridge/ReadableMap;Z)V
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 7
    .line 8
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;-><init>()V

    .line 9
    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    iget-object v2, p0, Lo2/l;->z:Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    :cond_11
    :goto_11
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    if-eqz v3, :cond_30

    .line 23
    .line 24
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    check-cast v3, Lo2/c;

    .line 29
    .line 30
    instance-of v4, v3, Lcom/airbnb/android/react/maps/a;

    .line 31
    .line 32
    if-eqz v4, :cond_11

    .line 33
    .line 34
    invoke-virtual {v3}, Lo2/c;->getFeature()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    check-cast v1, Lcom/google/android/gms/maps/model/Marker;

    .line 39
    .line 40
    invoke-virtual {v1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 45
    .line 46
    .line 47
    const/4 v1, 0x1

    .line 48
    goto :goto_11

    .line 49
    :cond_30
    if-eqz v1, :cond_68

    .line 50
    .line 51
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->build()Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    const/16 v1, 0x32

    .line 56
    .line 57
    invoke-static {v0, v1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz p1, :cond_5b

    .line 62
    .line 63
    iget-object v1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 64
    .line 65
    const-string v2, "left"

    .line 66
    .line 67
    invoke-interface {p1, v2}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    const-string v3, "top"

    .line 72
    .line 73
    invoke-interface {p1, v3}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    const-string v4, "right"

    .line 78
    .line 79
    invoke-interface {p1, v4}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    const-string v5, "bottom"

    .line 84
    .line 85
    invoke-interface {p1, v5}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 86
    .line 87
    .line 88
    move-result p1

    .line 89
    invoke-virtual {v1, v2, v3, v4, p1}, Lcom/google/android/gms/maps/GoogleMap;->setPadding(IIII)V

    .line 90
    .line 91
    .line 92
    :cond_5b
    if-eqz p2, :cond_63

    .line 93
    .line 94
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 97
    .line 98
    .line 99
    goto :goto_68

    .line 100
    :cond_63
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 101
    .line 102
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 103
    .line 104
    .line 105
    :cond_68
    :goto_68
    return-void
.end method

.method public L(Lcom/facebook/react/bridge/ReadableArray;Lcom/facebook/react/bridge/ReadableMap;Z)V
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 7
    .line 8
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    new-array v1, v1, [Ljava/lang/String;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    const/4 v3, 0x0

    .line 19
    :goto_12
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    if-ge v3, v4, :cond_21

    .line 24
    .line 25
    invoke-interface {p1, v3}, Lcom/facebook/react/bridge/ReadableArray;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    aput-object v4, v1, v3

    .line 30
    .line 31
    add-int/lit8 v3, v3, 0x1

    .line 32
    .line 33
    goto :goto_12

    .line 34
    :cond_21
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iget-object v1, p0, Lo2/l;->z:Ljava/util/List;

    .line 39
    .line 40
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    :cond_2b
    :goto_2b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    if-eqz v3, :cond_57

    .line 49
    .line 50
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, Lo2/c;

    .line 55
    .line 56
    instance-of v4, v3, Lcom/airbnb/android/react/maps/a;

    .line 57
    .line 58
    if-eqz v4, :cond_2b

    .line 59
    .line 60
    move-object v4, v3

    .line 61
    check-cast v4, Lcom/airbnb/android/react/maps/a;

    .line 62
    .line 63
    invoke-virtual {v4}, Lcom/airbnb/android/react/maps/a;->getIdentifier()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    invoke-virtual {v3}, Lo2/c;->getFeature()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v3

    .line 71
    check-cast v3, Lcom/google/android/gms/maps/model/Marker;

    .line 72
    .line 73
    invoke-interface {p1, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    if-eqz v4, :cond_2b

    .line 78
    .line 79
    invoke-virtual {v3}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 84
    .line 85
    .line 86
    const/4 v2, 0x1

    .line 87
    goto :goto_2b

    .line 88
    :cond_57
    if-eqz v2, :cond_8f

    .line 89
    .line 90
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->build()Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    const/16 v0, 0x32

    .line 95
    .line 96
    invoke-static {p1, v0}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    if-eqz p2, :cond_82

    .line 101
    .line 102
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 103
    .line 104
    const-string v1, "left"

    .line 105
    .line 106
    invoke-interface {p2, v1}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    const-string v2, "top"

    .line 111
    .line 112
    invoke-interface {p2, v2}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    const-string v3, "right"

    .line 117
    .line 118
    invoke-interface {p2, v3}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 119
    .line 120
    .line 121
    move-result v3

    .line 122
    const-string v4, "bottom"

    .line 123
    .line 124
    invoke-interface {p2, v4}, Lcom/facebook/react/bridge/ReadableMap;->getInt(Ljava/lang/String;)I

    .line 125
    .line 126
    .line 127
    move-result p2

    .line 128
    invoke-virtual {v0, v1, v2, v3, p2}, Lcom/google/android/gms/maps/GoogleMap;->setPadding(IIII)V

    .line 129
    .line 130
    .line 131
    :cond_82
    if-eqz p3, :cond_8a

    .line 132
    .line 133
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 134
    .line 135
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 136
    .line 137
    .line 138
    goto :goto_8f

    .line 139
    :cond_8a
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 140
    .line 141
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 142
    .line 143
    .line 144
    :cond_8f
    :goto_8f
    return-void
.end method

.method public M(I)Landroid/view/View;
    .registers 3

    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    return-object p1
.end method

.method public final N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;
    .registers 7

    .line 1
    iget-object v0, p0, Lo2/l;->A:Ljava/util/Map;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lcom/airbnb/android/react/maps/a;

    .line 8
    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_b
    iget-object v1, p0, Lo2/l;->A:Ljava/util/Map;

    .line 13
    .line 14
    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    :cond_15
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_50

    .line 27
    .line 28
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Ljava/util/Map$Entry;

    .line 33
    .line 34
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    check-cast v3, Lcom/google/android/gms/maps/model/Marker;

    .line 39
    .line 40
    invoke-virtual {v3}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 45
    .line 46
    .line 47
    move-result-object v4

    .line 48
    invoke-virtual {v3, v4}, Lcom/google/android/gms/maps/model/LatLng;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_15

    .line 53
    .line 54
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    check-cast v3, Lcom/google/android/gms/maps/model/Marker;

    .line 59
    .line 60
    invoke-virtual {v3}, Lcom/google/android/gms/maps/model/Marker;->getTitle()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v3

    .line 64
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getTitle()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-eqz v3, :cond_15

    .line 73
    .line 74
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    move-object v0, p1

    .line 79
    check-cast v0, Lcom/airbnb/android/react/maps/a;

    .line 80
    .line 81
    :cond_50
    return-object v0
.end method

.method public final P()Z
    .registers 5

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lo2/l;->b0:[Ljava/lang/String;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    aget-object v3, v1, v2

    .line 9
    .line 10
    invoke-static {v0, v3}, Landroidx/core/content/PermissionChecker;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v3, 0x1

    .line 15
    if-eqz v0, :cond_1c

    .line 16
    .line 17
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    aget-object v1, v1, v3

    .line 22
    .line 23
    invoke-static {v0, v1}, Landroidx/core/content/PermissionChecker;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-nez v0, :cond_1d

    .line 28
    .line 29
    :cond_1c
    const/4 v2, 0x1

    .line 30
    :cond_1d
    return v2
.end method

.method public Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;
    .registers 7

    .line 1
    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 7
    .line 8
    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-wide v2, p1, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 12
    .line 13
    const-string v4, "latitude"

    .line 14
    .line 15
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 16
    .line 17
    .line 18
    iget-wide v2, p1, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 19
    .line 20
    const-string v4, "longitude"

    .line 21
    .line 22
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 23
    .line 24
    .line 25
    const-string v2, "coordinate"

    .line 26
    .line 27
    invoke-interface {v0, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 28
    .line 29
    .line 30
    iget-object v1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 31
    .line 32
    invoke-virtual {v1}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v1, p1}, Lcom/google/android/gms/maps/Projection;->toScreenLocation(Lcom/google/android/gms/maps/model/LatLng;)Landroid/graphics/Point;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 41
    .line 42
    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 43
    .line 44
    .line 45
    iget v2, p1, Landroid/graphics/Point;->x:I

    .line 46
    .line 47
    int-to-double v2, v2

    .line 48
    const-string v4, "x"

    .line 49
    .line 50
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 51
    .line 52
    .line 53
    iget p1, p1, Landroid/graphics/Point;->y:I

    .line 54
    .line 55
    int-to-double v2, p1

    .line 56
    const-string p1, "y"

    .line 57
    .line 58
    invoke-interface {v1, p1, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 59
    .line 60
    .line 61
    const-string p1, "position"

    .line 62
    .line 63
    invoke-interface {v0, p1, v1}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 64
    .line 65
    .line 66
    return-object v0
.end method

.method public final R(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 15

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    const-string v0, "longitude"

    .line 5
    .line 6
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    const-string v2, "latitude"

    .line 11
    .line 12
    invoke-interface {p1, v2}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 13
    .line 14
    .line 15
    move-result-wide v2

    .line 16
    const-string v4, "longitudeDelta"

    .line 17
    .line 18
    invoke-interface {p1, v4}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 19
    .line 20
    .line 21
    move-result-wide v4

    .line 22
    const-string v6, "latitudeDelta"

    .line 23
    .line 24
    invoke-interface {p1, v6}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 25
    .line 26
    .line 27
    move-result-wide v6

    .line 28
    new-instance p1, Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 29
    .line 30
    new-instance v8, Lcom/google/android/gms/maps/model/LatLng;

    .line 31
    .line 32
    const-wide/high16 v9, 0x4000000000000000L    # 2.0

    .line 33
    .line 34
    div-double/2addr v6, v9

    .line 35
    sub-double v11, v2, v6

    .line 36
    .line 37
    div-double/2addr v4, v9

    .line 38
    sub-double v9, v0, v4

    .line 39
    .line 40
    invoke-direct {v8, v11, v12, v9, v10}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 41
    .line 42
    .line 43
    new-instance v9, Lcom/google/android/gms/maps/model/LatLng;

    .line 44
    .line 45
    add-double/2addr v6, v2

    .line 46
    add-double/2addr v4, v0

    .line 47
    invoke-direct {v9, v6, v7, v4, v5}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 48
    .line 49
    .line 50
    invoke-direct {p1, v8, v9}, Lcom/google/android/gms/maps/model/LatLngBounds;-><init>(Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;)V

    .line 51
    .line 52
    .line 53
    invoke-super {p0}, Landroid/widget/FrameLayout;->getHeight()I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-lez v4, :cond_4f

    .line 58
    .line 59
    invoke-super {p0}, Landroid/widget/FrameLayout;->getWidth()I

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    if-gtz v4, :cond_41

    .line 64
    .line 65
    goto :goto_4f

    .line 66
    :cond_41
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 67
    .line 68
    const/4 v1, 0x0

    .line 69
    invoke-static {p1, v1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 74
    .line 75
    .line 76
    const/4 p1, 0x0

    .line 77
    iput-object p1, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 78
    .line 79
    goto :goto_61

    .line 80
    :cond_4f
    :goto_4f
    iget-object v4, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 81
    .line 82
    new-instance v5, Lcom/google/android/gms/maps/model/LatLng;

    .line 83
    .line 84
    invoke-direct {v5, v2, v3, v0, v1}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 85
    .line 86
    .line 87
    const/high16 v0, 0x41200000    # 10.0f

    .line 88
    .line 89
    invoke-static {v5, v0}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngZoom(Lcom/google/android/gms/maps/model/LatLng;F)Lcom/google/android/gms/maps/CameraUpdate;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    invoke-virtual {v4, v0}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 94
    .line 95
    .line 96
    iput-object p1, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 97
    .line 98
    :goto_61
    return-void
.end method

.method public S(Landroid/view/MotionEvent;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Landroid/graphics/Point;

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    float-to-int v1, v1

    .line 13
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    float-to-int p1, p1

    .line 18
    invoke-direct {v0, v1, p1}, Landroid/graphics/Point;-><init>(II)V

    .line 19
    .line 20
    .line 21
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 22
    .line 23
    invoke-virtual {p1}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/Projection;->fromScreenLocation(Landroid/graphics/Point;)Lcom/google/android/gms/maps/model/LatLng;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    iget-object v0, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 36
    .line 37
    iget-object v1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 38
    .line 39
    const-string v2, "onDoublePress"

    .line 40
    .line 41
    invoke-virtual {v0, v1, p0, v2, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public T(Landroid/view/MotionEvent;)V
    .registers 5

    .line 1
    new-instance v0, Landroid/graphics/Point;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    float-to-int v1, v1

    .line 8
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    float-to-int p1, p1

    .line 13
    invoke-direct {v0, v1, p1}, Landroid/graphics/Point;-><init>(II)V

    .line 14
    .line 15
    .line 16
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/Projection;->fromScreenLocation(Landroid/graphics/Point;)Lcom/google/android/gms/maps/model/LatLng;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v0, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 31
    .line 32
    iget-object v1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 33
    .line 34
    const-string v2, "onPanDrag"

    .line 35
    .line 36
    invoke-virtual {v0, v1, p0, v2, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final U()V
    .registers 4

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Landroidx/lifecycle/LifecycleOwner;

    .line 6
    .line 7
    if-eqz v1, :cond_1b

    .line 8
    .line 9
    new-instance v1, Lo2/l$r;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-direct {v1, p0, v2}, Lo2/l$r;-><init>(Lo2/l;Lo2/l$i;)V

    .line 13
    .line 14
    .line 15
    iput-object v1, p0, Lo2/l;->I:Lo2/l$r;

    .line 16
    .line 17
    check-cast v0, Landroidx/lifecycle/LifecycleOwner;

    .line 18
    .line 19
    invoke-interface {v0}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-object v1, p0, Lo2/l;->I:Lo2/l$r;

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final V()V
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 2
    .line 3
    if-eqz v0, :cond_12

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/view/ViewGroup;

    .line 10
    .line 11
    iget-object v1, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Lo2/l;->e:Landroid/widget/ImageView;

    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public W(I)V
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lo2/c;

    .line 8
    .line 9
    instance-of v0, p1, Lcom/airbnb/android/react/maps/a;

    .line 10
    .line 11
    if-eqz v0, :cond_28

    .line 12
    .line 13
    move-object v0, p1

    .line 14
    check-cast v0, Lcom/airbnb/android/react/maps/a;

    .line 15
    .line 16
    iget-object v1, p0, Lo2/l;->A:Ljava/util/Map;

    .line 17
    .line 18
    invoke-virtual {p1}, Lo2/c;->getFeature()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    iget-object v1, p0, Lo2/l;->O:Lo2/v;

    .line 26
    .line 27
    if-eqz v1, :cond_35

    .line 28
    .line 29
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    iget-object v2, p0, Lo2/l;->O:Lo2/v;

    .line 34
    .line 35
    if-ne v1, v2, :cond_35

    .line 36
    .line 37
    :try_start_24
    invoke-virtual {v2, v0}, Lcom/facebook/react/views/view/ReactViewGroup;->removeView(Landroid/view/View;)V
    :try_end_27
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_27} :catch_35

    .line 38
    .line 39
    .line 40
    goto :goto_35

    .line 41
    :cond_28
    instance-of v0, p1, Lo2/e;

    .line 42
    .line 43
    if-eqz v0, :cond_35

    .line 44
    .line 45
    iget-object v0, p0, Lo2/l;->E:Ljava/util/Map;

    .line 46
    .line 47
    invoke-virtual {p1}, Lo2/c;->getFeature()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    :catch_35
    :cond_35
    :goto_35
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 55
    .line 56
    invoke-virtual {p1, v0}, Lo2/c;->a(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 57
    .line 58
    .line 59
    return-void
.end method

.method public final X()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/l;->Y()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 5
    .line 6
    if-eqz v0, :cond_15

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroid/view/ViewGroup;

    .line 13
    .line 14
    iget-object v1, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 21
    .line 22
    :cond_15
    return-void
.end method

.method public final Y()V
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 2
    .line 3
    if-eqz v0, :cond_12

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/view/ViewGroup;

    .line 10
    .line 11
    iget-object v1, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public Z(Lcom/facebook/react/bridge/ReadableMap;Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 12

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 7
    .line 8
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;-><init>()V

    .line 9
    .line 10
    .line 11
    const-string v1, "latitude"

    .line 12
    .line 13
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 14
    .line 15
    .line 16
    move-result-wide v2

    .line 17
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    const-string v3, "longitude"

    .line 22
    .line 23
    invoke-interface {p1, v3}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 24
    .line 25
    .line 26
    move-result-wide v4

    .line 27
    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    new-instance v4, Lcom/google/android/gms/maps/model/LatLng;

    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 34
    .line 35
    .line 36
    move-result-wide v5

    .line 37
    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    .line 38
    .line 39
    .line 40
    move-result-wide v7

    .line 41
    invoke-direct {v4, v5, v6, v7, v8}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0, v4}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 45
    .line 46
    .line 47
    invoke-interface {p2, v1}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 48
    .line 49
    .line 50
    move-result-wide v1

    .line 51
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-interface {p2, v3}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 56
    .line 57
    .line 58
    move-result-wide v1

    .line 59
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    new-instance v1, Lcom/google/android/gms/maps/model/LatLng;

    .line 64
    .line 65
    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    .line 66
    .line 67
    .line 68
    move-result-wide v2

    .line 69
    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    .line 70
    .line 71
    .line 72
    move-result-wide p1

    .line 73
    invoke-direct {v1, v2, v3, p1, p2}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->build()Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    iget-object p2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 84
    .line 85
    invoke-virtual {p2, p1}, Lcom/google/android/gms/maps/GoogleMap;->setLatLngBoundsForCameraTarget(Lcom/google/android/gms/maps/model/LatLngBounds;)V

    .line 86
    .line 87
    .line 88
    return-void
.end method

.method public a0(Ljava/lang/Object;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_51

    .line 5
    .line 6
    check-cast p1, Ljava/util/HashMap;

    .line 7
    .line 8
    const-string v0, "width"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    const/4 v3, 0x0

    .line 15
    if-nez v2, :cond_12

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    goto :goto_1c

    .line 19
    :cond_12
    invoke-virtual {p1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Ljava/lang/Float;

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/Float;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    :goto_1c
    const-string v2, "height"

    .line 30
    .line 31
    invoke-virtual {p1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    if-nez v4, :cond_26

    .line 36
    .line 37
    const/4 p1, 0x0

    .line 38
    goto :goto_30

    .line 39
    :cond_26
    invoke-virtual {p1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, Ljava/lang/Float;

    .line 44
    .line 45
    invoke-virtual {p1}, Ljava/lang/Float;->intValue()I

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    :goto_30
    if-lez v0, :cond_41

    .line 50
    .line 51
    if-gtz p1, :cond_35

    .line 52
    .line 53
    goto :goto_41

    .line 54
    :cond_35
    iget-object v2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 55
    .line 56
    iget-object v4, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 57
    .line 58
    invoke-static {v4, v0, p1, v3}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;III)Lcom/google/android/gms/maps/CameraUpdate;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    invoke-virtual {v2, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 63
    .line 64
    .line 65
    goto :goto_4c

    .line 66
    :cond_41
    :goto_41
    iget-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 67
    .line 68
    iget-object v0, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 69
    .line 70
    invoke-static {v0, v3}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 75
    .line 76
    .line 77
    :goto_4c
    iput-object v1, p0, Lo2/l;->m:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 78
    .line 79
    iput-object v1, p0, Lo2/l;->n:Lcom/google/android/gms/maps/CameraUpdate;

    .line 80
    .line 81
    goto :goto_5c

    .line 82
    :cond_51
    iget-object p1, p0, Lo2/l;->n:Lcom/google/android/gms/maps/CameraUpdate;

    .line 83
    .line 84
    if-eqz p1, :cond_5c

    .line 85
    .line 86
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 87
    .line 88
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 89
    .line 90
    .line 91
    iput-object v1, p0, Lo2/l;->n:Lcom/google/android/gms/maps/CameraUpdate;

    .line 92
    .line 93
    :cond_5c
    :goto_5c
    return-void
.end method

.method public dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l;->G:Landroidx/core/view/GestureDetectorCompat;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroidx/core/view/GestureDetectorCompat;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    float-to-int v0, v0

    .line 11
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    float-to-int v1, v1

    .line 16
    iget-object v2, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 17
    .line 18
    if-eqz v2, :cond_22

    .line 19
    .line 20
    invoke-virtual {v2}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    new-instance v3, Landroid/graphics/Point;

    .line 25
    .line 26
    invoke-direct {v3, v0, v1}, Landroid/graphics/Point;-><init>(II)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v2, v3}, Lcom/google/android/gms/maps/Projection;->fromScreenLocation(Landroid/graphics/Point;)Lcom/google/android/gms/maps/model/LatLng;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iput-object v0, p0, Lo2/l;->P:Lcom/google/android/gms/maps/model/LatLng;

    .line 34
    .line 35
    :cond_22
    invoke-static {p1}, Landroidx/core/view/MotionEventCompat;->getActionMasked(Landroid/view/MotionEvent;)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const/4 v1, 0x0

    .line 40
    const/4 v2, 0x1

    .line 41
    if-eqz v0, :cond_35

    .line 42
    .line 43
    if-eq v0, v2, :cond_2d

    .line 44
    .line 45
    goto :goto_4b

    .line 46
    :cond_2d
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 51
    .line 52
    .line 53
    goto :goto_4b

    .line 54
    :cond_35
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    iget-object v3, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 59
    .line 60
    if-eqz v3, :cond_48

    .line 61
    .line 62
    invoke-virtual {v3}, Lcom/google/android/gms/maps/GoogleMap;->getUiSettings()Lcom/google/android/gms/maps/UiSettings;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    invoke-virtual {v3}, Lcom/google/android/gms/maps/UiSettings;->isScrollGesturesEnabled()Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_48

    .line 71
    .line 72
    const/4 v1, 0x1

    .line 73
    :cond_48
    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 74
    .line 75
    .line 76
    :goto_4b
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    .line 77
    .line 78
    .line 79
    return v2
.end method

.method public getFeatureCount()I
    .registers 2

    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0
.end method

.method public getInfoContents(Lcom/google/android/gms/maps/model/Marker;)Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lcom/airbnb/android/react/maps/a;->getInfoContents()Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public getInfoWindow(Lcom/google/android/gms/maps/model/Marker;)Landroid/view/View;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Lcom/airbnb/android/react/maps/a;->getCallout()Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public getMapBoundaries()[[D
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lcom/google/android/gms/maps/Projection;->getVisibleRegion()Lcom/google/android/gms/maps/model/VisibleRegion;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v0, v0, Lcom/google/android/gms/maps/model/VisibleRegion;->latLngBounds:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 12
    .line 13
    iget-object v1, v0, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 14
    .line 15
    iget-object v0, v0, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 16
    .line 17
    const/4 v2, 0x2

    .line 18
    new-array v3, v2, [[D

    .line 19
    .line 20
    new-array v4, v2, [D

    .line 21
    .line 22
    iget-wide v5, v1, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 23
    .line 24
    const/4 v7, 0x0

    .line 25
    aput-wide v5, v4, v7

    .line 26
    .line 27
    iget-wide v5, v1, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    aput-wide v5, v4, v1

    .line 31
    .line 32
    aput-object v4, v3, v7

    .line 33
    .line 34
    new-array v2, v2, [D

    .line 35
    .line 36
    iget-wide v4, v0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 37
    .line 38
    aput-wide v4, v2, v7

    .line 39
    .line 40
    iget-wide v4, v0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 41
    .line 42
    aput-wide v4, v2, v1

    .line 43
    .line 44
    aput-object v2, v3, v1

    .line 45
    .line 46
    return-object v3
.end method

.method public onIndoorBuildingFocused()V
    .registers 14

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getFocusedBuilding()Lcom/google/android/gms/maps/model/IndoorBuilding;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "onIndoorBuildingFocused"

    .line 8
    .line 9
    const-string v2, "IndoorBuilding"

    .line 10
    .line 11
    const-string v3, "underground"

    .line 12
    .line 13
    const-string v4, "activeLevelIndex"

    .line 14
    .line 15
    const-string v5, "levels"

    .line 16
    .line 17
    const/4 v6, 0x0

    .line 18
    if-eqz v0, :cond_70

    .line 19
    .line 20
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getLevels()Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object v7

    .line 24
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createArray()Lcom/facebook/react/bridge/WritableArray;

    .line 25
    .line 26
    .line 27
    move-result-object v8

    .line 28
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 29
    .line 30
    .line 31
    move-result-object v7

    .line 32
    :goto_1f
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 33
    .line 34
    .line 35
    move-result v9

    .line 36
    if-eqz v9, :cond_4c

    .line 37
    .line 38
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v9

    .line 42
    check-cast v9, Lcom/google/android/gms/maps/model/IndoorLevel;

    .line 43
    .line 44
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 45
    .line 46
    .line 47
    move-result-object v10

    .line 48
    const-string v11, "index"

    .line 49
    .line 50
    invoke-interface {v10, v11, v6}, Lcom/facebook/react/bridge/WritableMap;->putInt(Ljava/lang/String;I)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v9}, Lcom/google/android/gms/maps/model/IndoorLevel;->getName()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v11

    .line 57
    const-string v12, "name"

    .line 58
    .line 59
    invoke-interface {v10, v12, v11}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v9}, Lcom/google/android/gms/maps/model/IndoorLevel;->getShortName()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v9

    .line 66
    const-string v11, "shortName"

    .line 67
    .line 68
    invoke-interface {v10, v11, v9}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-interface {v8, v10}, Lcom/facebook/react/bridge/WritableArray;->pushMap(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 72
    .line 73
    .line 74
    add-int/lit8 v6, v6, 0x1

    .line 75
    .line 76
    goto :goto_1f

    .line 77
    :cond_4c
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 82
    .line 83
    .line 84
    move-result-object v7

    .line 85
    invoke-interface {v7, v5, v8}, Lcom/facebook/react/bridge/WritableMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getActiveLevelIndex()I

    .line 89
    .line 90
    .line 91
    move-result v5

    .line 92
    invoke-interface {v7, v4, v5}, Lcom/facebook/react/bridge/WritableMap;->putInt(Ljava/lang/String;I)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/IndoorBuilding;->isUnderground()Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    invoke-interface {v7, v3, v0}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 100
    .line 101
    .line 102
    invoke-interface {v6, v2, v7}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 103
    .line 104
    .line 105
    iget-object v0, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 106
    .line 107
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 108
    .line 109
    invoke-virtual {v0, v2, p0, v1, v6}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 110
    .line 111
    .line 112
    goto :goto_8f

    .line 113
    :cond_70
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createArray()Lcom/facebook/react/bridge/WritableArray;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 122
    .line 123
    .line 124
    move-result-object v8

    .line 125
    invoke-interface {v8, v5, v7}, Lcom/facebook/react/bridge/WritableMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    .line 126
    .line 127
    .line 128
    invoke-interface {v8, v4, v6}, Lcom/facebook/react/bridge/WritableMap;->putInt(Ljava/lang/String;I)V

    .line 129
    .line 130
    .line 131
    invoke-interface {v8, v3, v6}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 132
    .line 133
    .line 134
    invoke-interface {v0, v2, v8}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 135
    .line 136
    .line 137
    iget-object v2, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 138
    .line 139
    iget-object v3, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 140
    .line 141
    invoke-virtual {v2, v3, p0, v1, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 142
    .line 143
    .line 144
    :goto_8f
    return-void
.end method

.method public onIndoorLevelActivated(Lcom/google/android/gms/maps/model/IndoorBuilding;)V
    .registers 6

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getActiveLevelIndex()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-ltz v0, :cond_4b

    .line 9
    .line 10
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getLevels()Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-lt v0, v1, :cond_14

    .line 19
    .line 20
    goto :goto_4b

    .line 21
    :cond_14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getLevels()Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, Lcom/google/android/gms/maps/model/IndoorLevel;

    .line 30
    .line 31
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {}, Lcom/facebook/react/bridge/Arguments;->createMap()Lcom/facebook/react/bridge/WritableMap;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    const-string v3, "activeLevelIndex"

    .line 40
    .line 41
    invoke-interface {v2, v3, v0}, Lcom/facebook/react/bridge/WritableMap;->putInt(Ljava/lang/String;I)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorLevel;->getName()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    const-string v3, "name"

    .line 49
    .line 50
    invoke-interface {v2, v3, v0}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorLevel;->getShortName()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    const-string v0, "shortName"

    .line 58
    .line 59
    invoke-interface {v2, v0, p1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    const-string p1, "IndoorLevel"

    .line 63
    .line 64
    invoke-interface {v1, p1, v2}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 65
    .line 66
    .line 67
    iget-object p1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 68
    .line 69
    iget-object v0, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 70
    .line 71
    const-string v2, "onIndoorLevelActivated"

    .line 72
    .line 73
    invoke-virtual {p1, v0, p0, v2, v1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 74
    .line 75
    .line 76
    :cond_4b
    :goto_4b
    return-void
.end method

.method public onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 7

    .line 1
    iget-boolean v0, p0, Lo2/l;->K:Z

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iget-wide v0, p0, Lo2/l;->Q:J

    .line 7
    .line 8
    const-wide/16 v2, 0x0

    .line 9
    .line 10
    cmp-long v4, v0, v2

    .line 11
    .line 12
    if-eqz v4, :cond_1a

    .line 13
    .line 14
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 15
    .line 16
    .line 17
    move-result-wide v0

    .line 18
    iget-wide v2, p0, Lo2/l;->Q:J

    .line 19
    .line 20
    sub-long/2addr v0, v2

    .line 21
    sget-object v2, Lp2/b;->a:Lp2/b;

    .line 22
    .line 23
    const/4 v3, 0x2

    .line 24
    invoke-virtual {v2, v3, v0, v1}, Lp2/b;->d(IJ)V

    .line 25
    .line 26
    .line 27
    :cond_1a
    iput-object p1, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 28
    .line 29
    invoke-virtual {p1, p0}, Lcom/google/android/gms/maps/GoogleMap;->setInfoWindowAdapter(Lcom/google/android/gms/maps/GoogleMap$InfoWindowAdapter;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 33
    .line 34
    invoke-virtual {v0, p0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMarkerDragListener(Lcom/google/android/gms/maps/GoogleMap$OnMarkerDragListener;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Lcom/google/android/gms/maps/GoogleMap;->setOnPoiClickListener(Lcom/google/android/gms/maps/GoogleMap$OnPoiClickListener;)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 43
    .line 44
    invoke-virtual {v0, p0}, Lcom/google/android/gms/maps/GoogleMap;->setOnIndoorStateChangeListener(Lcom/google/android/gms/maps/GoogleMap$OnIndoorStateChangeListener;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0}, Lo2/l;->E()V

    .line 48
    .line 49
    .line 50
    iget-object v0, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 51
    .line 52
    iget-object v1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 53
    .line 54
    new-instance v2, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 55
    .line 56
    invoke-direct {v2}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 57
    .line 58
    .line 59
    const-string v3, "onMapReady"

    .line 60
    .line 61
    invoke-virtual {v0, v1, p0, v3, v2}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 62
    .line 63
    .line 64
    new-instance v0, Lo2/l$l;

    .line 65
    .line 66
    invoke-direct {v0, p0, p0}, Lo2/l$l;-><init>(Lo2/l;Lo2/l;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMyLocationChangeListener(Lcom/google/android/gms/maps/GoogleMap$OnMyLocationChangeListener;)V

    .line 70
    .line 71
    .line 72
    new-instance v0, Lo2/l$m;

    .line 73
    .line 74
    invoke-direct {v0, p0, p0}, Lo2/l$m;-><init>(Lo2/l;Lo2/l;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMarkerClickListener(Lcom/google/android/gms/maps/GoogleMap$OnMarkerClickListener;)V

    .line 78
    .line 79
    .line 80
    new-instance v0, Lo2/l$n;

    .line 81
    .line 82
    invoke-direct {v0, p0}, Lo2/l$n;-><init>(Lo2/l;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnPolygonClickListener(Lcom/google/android/gms/maps/GoogleMap$OnPolygonClickListener;)V

    .line 86
    .line 87
    .line 88
    new-instance v0, Lo2/l$o;

    .line 89
    .line 90
    invoke-direct {v0, p0}, Lo2/l$o;-><init>(Lo2/l;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnPolylineClickListener(Lcom/google/android/gms/maps/GoogleMap$OnPolylineClickListener;)V

    .line 94
    .line 95
    .line 96
    new-instance v0, Lo2/l$p;

    .line 97
    .line 98
    invoke-direct {v0, p0, p0}, Lo2/l$p;-><init>(Lo2/l;Lo2/l;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnInfoWindowClickListener(Lcom/google/android/gms/maps/GoogleMap$OnInfoWindowClickListener;)V

    .line 102
    .line 103
    .line 104
    new-instance v0, Lo2/l$q;

    .line 105
    .line 106
    invoke-direct {v0, p0, p0}, Lo2/l$q;-><init>(Lo2/l;Lo2/l;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMapClickListener(Lcom/google/android/gms/maps/GoogleMap$OnMapClickListener;)V

    .line 110
    .line 111
    .line 112
    new-instance v0, Lo2/l$a;

    .line 113
    .line 114
    invoke-direct {v0, p0, p0}, Lo2/l$a;-><init>(Lo2/l;Lo2/l;)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMapLongClickListener(Lcom/google/android/gms/maps/GoogleMap$OnMapLongClickListener;)V

    .line 118
    .line 119
    .line 120
    new-instance v0, Lo2/l$b;

    .line 121
    .line 122
    invoke-direct {v0, p0}, Lo2/l$b;-><init>(Lo2/l;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnGroundOverlayClickListener(Lcom/google/android/gms/maps/GoogleMap$OnGroundOverlayClickListener;)V

    .line 126
    .line 127
    .line 128
    new-instance v0, Lo2/l$c;

    .line 129
    .line 130
    invoke-direct {v0, p0}, Lo2/l$c;-><init>(Lo2/l;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnCameraMoveStartedListener(Lcom/google/android/gms/maps/GoogleMap$OnCameraMoveStartedListener;)V

    .line 134
    .line 135
    .line 136
    new-instance v0, Lo2/l$d;

    .line 137
    .line 138
    invoke-direct {v0, p0, p1}, Lo2/l$d;-><init>(Lo2/l;Lcom/google/android/gms/maps/GoogleMap;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnCameraMoveListener(Lcom/google/android/gms/maps/GoogleMap$OnCameraMoveListener;)V

    .line 142
    .line 143
    .line 144
    new-instance v0, Lo2/l$e;

    .line 145
    .line 146
    invoke-direct {v0, p0, p1}, Lo2/l$e;-><init>(Lo2/l;Lcom/google/android/gms/maps/GoogleMap;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnCameraIdleListener(Lcom/google/android/gms/maps/GoogleMap$OnCameraIdleListener;)V

    .line 150
    .line 151
    .line 152
    new-instance v0, Lo2/l$f;

    .line 153
    .line 154
    invoke-direct {v0, p0, p0}, Lo2/l$f;-><init>(Lo2/l;Lo2/l;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setOnMapLoadedCallback(Lcom/google/android/gms/maps/GoogleMap$OnMapLoadedCallback;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {p0}, Lo2/l;->U()V

    .line 161
    .line 162
    .line 163
    return-void
.end method

.method public onMarkerDrag(Lcom/google/android/gms/maps/model/Marker;)V
    .registers 6

    .line 1
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 10
    .line 11
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 12
    .line 13
    const-string v3, "onMarkerDrag"

    .line 14
    .line 15
    invoke-virtual {v1, v2, p0, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 31
    .line 32
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 33
    .line 34
    const-string v3, "onDrag"

    .line 35
    .line 36
    invoke-virtual {v1, v2, v0, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public onMarkerDragEnd(Lcom/google/android/gms/maps/model/Marker;)V
    .registers 6

    .line 1
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 10
    .line 11
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 12
    .line 13
    const-string v3, "onMarkerDragEnd"

    .line 14
    .line 15
    invoke-virtual {v1, v2, p0, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 31
    .line 32
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 33
    .line 34
    const-string v3, "onDragEnd"

    .line 35
    .line 36
    invoke-virtual {v1, v2, v0, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public onMarkerDragStart(Lcom/google/android/gms/maps/model/Marker;)V
    .registers 6

    .line 1
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, v0}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 10
    .line 11
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 12
    .line 13
    const-string v3, "onMarkerDragStart"

    .line 14
    .line 15
    invoke-virtual {v1, v2, p0, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lo2/l;->N(Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 31
    .line 32
    iget-object v2, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 33
    .line 34
    const-string v3, "onDragStart"

    .line 35
    .line 36
    invoke-virtual {v1, v2, v0, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public onPoiClick(Lcom/google/android/gms/maps/model/PointOfInterest;)V
    .registers 5

    .line 1
    iget-object v0, p1, Lcom/google/android/gms/maps/model/PointOfInterest;->latLng:Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p1, Lcom/google/android/gms/maps/model/PointOfInterest;->placeId:Ljava/lang/String;

    .line 8
    .line 9
    const-string v2, "placeId"

    .line 10
    .line 11
    invoke-interface {v0, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object p1, p1, Lcom/google/android/gms/maps/model/PointOfInterest;->name:Ljava/lang/String;

    .line 15
    .line 16
    const-string v1, "name"

    .line 17
    .line 18
    invoke-interface {v0, v1, p1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object p1, p0, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 22
    .line 23
    iget-object v1, p0, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 24
    .line 25
    const-string v2, "onPoiClick"

    .line 26
    .line 27
    invoke-virtual {p1, v1, p0, v2, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public requestLayout()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/widget/FrameLayout;->requestLayout()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lo2/l;->a0:Ljava/lang/Runnable;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public setCacheEnabled(Z)V
    .registers 2

    .line 1
    iput-boolean p1, p0, Lo2/l;->r:Z

    .line 2
    .line 3
    invoke-virtual {p0}, Lo2/l;->F()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setCamera(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 8

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    new-instance v0, Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 5
    .line 6
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;-><init>()V

    .line 7
    .line 8
    .line 9
    const-string v1, "center"

    .line 10
    .line 11
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableMap;->getMap(Ljava/lang/String;)Lcom/facebook/react/bridge/ReadableMap;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz v1, :cond_34

    .line 16
    .line 17
    const-string v2, "longitude"

    .line 18
    .line 19
    invoke-interface {v1, v2}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 20
    .line 21
    .line 22
    move-result-wide v2

    .line 23
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    const-string v3, "latitude"

    .line 28
    .line 29
    invoke-interface {v1, v3}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 30
    .line 31
    .line 32
    move-result-wide v3

    .line 33
    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    new-instance v3, Lcom/google/android/gms/maps/model/LatLng;

    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 40
    .line 41
    .line 42
    move-result-wide v4

    .line 43
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 44
    .line 45
    .line 46
    move-result-wide v1

    .line 47
    invoke-direct {v3, v4, v5, v1, v2}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v0, v3}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->target(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 51
    .line 52
    .line 53
    :cond_34
    const-string v1, "pitch"

    .line 54
    .line 55
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 56
    .line 57
    .line 58
    move-result-wide v1

    .line 59
    double-to-float v1, v1

    .line 60
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->tilt(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 61
    .line 62
    .line 63
    const-string v1, "heading"

    .line 64
    .line 65
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 66
    .line 67
    .line 68
    move-result-wide v1

    .line 69
    double-to-float v1, v1

    .line 70
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->bearing(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 71
    .line 72
    .line 73
    const-string v1, "zoom"

    .line 74
    .line 75
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 76
    .line 77
    .line 78
    move-result-wide v1

    .line 79
    double-to-float p1, v1

    .line 80
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->zoom(F)Lcom/google/android/gms/maps/model/CameraPosition$Builder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/CameraPosition$Builder;->build()Lcom/google/android/gms/maps/model/CameraPosition;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-static {p1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newCameraPosition(Lcom/google/android/gms/maps/model/CameraPosition;)Lcom/google/android/gms/maps/CameraUpdate;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-super {p0}, Landroid/widget/FrameLayout;->getHeight()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-lez v0, :cond_70

    .line 96
    .line 97
    invoke-super {p0}, Landroid/widget/FrameLayout;->getWidth()I

    .line 98
    .line 99
    .line 100
    move-result v0

    .line 101
    if-gtz v0, :cond_67

    .line 102
    .line 103
    goto :goto_70

    .line 104
    :cond_67
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 105
    .line 106
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/GoogleMap;->moveCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 107
    .line 108
    .line 109
    const/4 p1, 0x0

    .line 110
    iput-object p1, p0, Lo2/l;->n:Lcom/google/android/gms/maps/CameraUpdate;

    .line 111
    .line 112
    goto :goto_72

    .line 113
    :cond_70
    :goto_70
    iput-object p1, p0, Lo2/l;->n:Lcom/google/android/gms/maps/CameraUpdate;

    .line 114
    .line 115
    :goto_72
    return-void
.end method

.method public setHandlePanDrag(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/l;->p:Z

    return-void
.end method

.method public setIndoorActiveLevelIndex(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getFocusedBuilding()Lcom/google/android/gms/maps/model/IndoorBuilding;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_23

    .line 8
    .line 9
    if-ltz p1, :cond_23

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getLevels()Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-ge p1, v1, :cond_23

    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/IndoorBuilding;->getLevels()Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, Lcom/google/android/gms/maps/model/IndoorLevel;

    .line 30
    .line 31
    if-eqz p1, :cond_23

    .line 32
    .line 33
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/IndoorLevel;->activate()V

    .line 34
    .line 35
    .line 36
    :cond_23
    return-void
.end method

.method public setInitialCamera(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 3

    .line 1
    iget-boolean v0, p0, Lo2/l;->w:Z

    .line 2
    .line 3
    if-nez v0, :cond_c

    .line 4
    .line 5
    if-eqz p1, :cond_c

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Lo2/l;->setCamera(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 8
    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    iput-boolean p1, p0, Lo2/l;->w:Z

    .line 12
    .line 13
    :cond_c
    return-void
.end method

.method public setInitialRegion(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/l;->s:Lcom/facebook/react/bridge/ReadableMap;

    .line 2
    .line 3
    iget-boolean v0, p0, Lo2/l;->v:Z

    .line 4
    .line 5
    if-nez v0, :cond_10

    .line 6
    .line 7
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 8
    .line 9
    if-eqz v0, :cond_10

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Lo2/l;->R(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 12
    .line 13
    .line 14
    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Lo2/l;->v:Z

    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setKmlSrc(Ljava/lang/String;)V
    .registers 19

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    const-string v0, "name"

    .line 4
    .line 5
    const-string v2, "description"

    .line 6
    .line 7
    :try_start_6
    new-instance v3, Lo2/n;

    .line 8
    .line 9
    iget-object v4, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 10
    .line 11
    invoke-direct {v3, v4}, Lo2/n;-><init>(Landroid/content/Context;)V

    .line 12
    .line 13
    .line 14
    const/4 v4, 0x1

    .line 15
    new-array v5, v4, [Ljava/lang/String;

    .line 16
    .line 17
    const/4 v6, 0x0

    .line 18
    aput-object p1, v5, v6

    .line 19
    .line 20
    invoke-virtual {v3, v5}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-virtual {v3}, Landroid/os/AsyncTask;->get()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    check-cast v3, Ljava/io/InputStream;

    .line 29
    .line 30
    if-nez v3, :cond_20

    .line 31
    .line 32
    return-void

    .line 33
    :cond_20
    new-instance v5, Lde/f;

    .line 34
    .line 35
    iget-object v7, v1, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 36
    .line 37
    iget-object v8, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 38
    .line 39
    invoke-direct {v5, v7, v3, v8}, Lde/f;-><init>(Lcom/google/android/gms/maps/GoogleMap;Ljava/io/InputStream;Landroid/content/Context;)V

    .line 40
    .line 41
    .line 42
    iput-object v5, v1, Lo2/l;->b:Lde/f;

    .line 43
    .line 44
    invoke-virtual {v5}, Lde/f;->d()V

    .line 45
    .line 46
    .line 47
    new-instance v3, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 48
    .line 49
    invoke-direct {v3}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 50
    .line 51
    .line 52
    new-instance v5, Lcom/facebook/react/bridge/WritableNativeArray;

    .line 53
    .line 54
    invoke-direct {v5}, Lcom/facebook/react/bridge/WritableNativeArray;-><init>()V

    .line 55
    .line 56
    .line 57
    iget-object v7, v1, Lo2/l;->b:Lde/f;

    .line 58
    .line 59
    invoke-virtual {v7}, Lde/f;->b()Ljava/lang/Iterable;

    .line 60
    .line 61
    .line 62
    move-result-object v7
    :try_end_3e
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_6 .. :try_end_3e} :catch_184
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_3e} :catch_17f
    .catch Ljava/lang/InterruptedException; {:try_start_6 .. :try_end_3e} :catch_17a
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_6 .. :try_end_3e} :catch_175

    .line 63
    const-string v8, "onKmlReady"

    .line 64
    .line 65
    if-nez v7, :cond_4a

    .line 66
    .line 67
    :try_start_42
    iget-object v0, v1, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 68
    .line 69
    iget-object v2, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 70
    .line 71
    invoke-virtual {v0, v2, v1, v8, v3}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :cond_4a
    iget-object v7, v1, Lo2/l;->b:Lde/f;

    .line 76
    .line 77
    invoke-virtual {v7}, Lde/f;->b()Ljava/lang/Iterable;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 82
    .line 83
    .line 84
    move-result-object v7

    .line 85
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v7

    .line 89
    check-cast v7, Lde/b;

    .line 90
    .line 91
    if-eqz v7, :cond_16d

    .line 92
    .line 93
    invoke-virtual {v7}, Lde/b;->a()Ljava/lang/Iterable;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    if-nez v9, :cond_64

    .line 98
    .line 99
    goto/16 :goto_16d

    .line 100
    .line 101
    :cond_64
    invoke-virtual {v7}, Lde/b;->a()Ljava/lang/Iterable;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 106
    .line 107
    .line 108
    move-result-object v9

    .line 109
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    if-eqz v9, :cond_80

    .line 114
    .line 115
    invoke-virtual {v7}, Lde/b;->a()Ljava/lang/Iterable;

    .line 116
    .line 117
    .line 118
    move-result-object v7

    .line 119
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 120
    .line 121
    .line 122
    move-result-object v7

    .line 123
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v7

    .line 127
    check-cast v7, Lde/b;

    .line 128
    .line 129
    :cond_80
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    invoke-virtual {v7}, Lde/b;->c()Ljava/lang/Iterable;

    .line 134
    .line 135
    .line 136
    move-result-object v9

    .line 137
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 138
    .line 139
    .line 140
    move-result-object v9

    .line 141
    :goto_8c
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 142
    .line 143
    .line 144
    move-result v10

    .line 145
    if-eqz v10, :cond_160

    .line 146
    .line 147
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v10

    .line 151
    check-cast v10, Lde/j;

    .line 152
    .line 153
    new-instance v11, Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 154
    .line 155
    invoke-direct {v11}, Lcom/google/android/gms/maps/model/MarkerOptions;-><init>()V

    .line 156
    .line 157
    .line 158
    invoke-virtual {v10}, Lde/j;->g()Lde/n;

    .line 159
    .line 160
    .line 161
    move-result-object v12

    .line 162
    if-eqz v12, :cond_a8

    .line 163
    .line 164
    invoke-virtual {v10}, Lde/j;->h()Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 165
    .line 166
    .line 167
    move-result-object v11

    .line 168
    goto :goto_af

    .line 169
    :cond_a8
    invoke-static {}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->defaultMarker()Lcom/google/android/gms/maps/model/BitmapDescriptor;

    .line 170
    .line 171
    .line 172
    move-result-object v12

    .line 173
    invoke-virtual {v11, v12}, Lcom/google/android/gms/maps/model/MarkerOptions;->icon(Lcom/google/android/gms/maps/model/BitmapDescriptor;)Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 174
    .line 175
    .line 176
    :goto_af
    invoke-virtual {v10}, Lbe/b;->a()Lbe/c;

    .line 177
    .line 178
    .line 179
    move-result-object v12

    .line 180
    invoke-interface {v12}, Lbe/c;->d()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v12

    .line 184
    check-cast v12, Lcom/google/android/gms/maps/model/LatLng;

    .line 185
    .line 186
    invoke-virtual {v10, v0}, Lbe/b;->f(Ljava/lang/String;)Z

    .line 187
    .line 188
    .line 189
    move-result v13
    :try_end_bd
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_42 .. :try_end_bd} :catch_184
    .catch Ljava/io/IOException; {:try_start_42 .. :try_end_bd} :catch_17f
    .catch Ljava/lang/InterruptedException; {:try_start_42 .. :try_end_bd} :catch_17a
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_42 .. :try_end_bd} :catch_175

    .line 190
    const-string v14, ""

    .line 191
    .line 192
    if-eqz v13, :cond_c6

    .line 193
    .line 194
    :try_start_c1
    invoke-virtual {v10, v0}, Lbe/b;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v13

    .line 198
    goto :goto_c7

    .line 199
    :cond_c6
    move-object v13, v14

    .line 200
    :goto_c7
    invoke-virtual {v10, v2}, Lbe/b;->f(Ljava/lang/String;)Z

    .line 201
    .line 202
    .line 203
    move-result v15

    .line 204
    if-eqz v15, :cond_d1

    .line 205
    .line 206
    invoke-virtual {v10, v2}, Lbe/b;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v14

    .line 210
    :cond_d1
    invoke-virtual {v11, v12}, Lcom/google/android/gms/maps/model/MarkerOptions;->position(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 211
    .line 212
    .line 213
    invoke-virtual {v11, v13}, Lcom/google/android/gms/maps/model/MarkerOptions;->title(Ljava/lang/String;)Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 214
    .line 215
    .line 216
    invoke-virtual {v11, v14}, Lcom/google/android/gms/maps/model/MarkerOptions;->snippet(Ljava/lang/String;)Lcom/google/android/gms/maps/model/MarkerOptions;

    .line 217
    .line 218
    .line 219
    new-instance v15, Lcom/airbnb/android/react/maps/a;

    .line 220
    .line 221
    iget-object v4, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 222
    .line 223
    move-object/from16 v16, v0

    .line 224
    .line 225
    iget-object v0, v1, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 226
    .line 227
    invoke-virtual {v0}, Lcom/airbnb/android/react/maps/AirMapManager;->getMarkerManager()Lcom/airbnb/android/react/maps/AirMapMarkerManager;

    .line 228
    .line 229
    .line 230
    move-result-object v0

    .line 231
    invoke-direct {v15, v4, v11, v0}, Lcom/airbnb/android/react/maps/a;-><init>(Landroid/content/Context;Lcom/google/android/gms/maps/model/MarkerOptions;Lcom/airbnb/android/react/maps/AirMapMarkerManager;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v10}, Lde/j;->g()Lde/n;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    if-eqz v0, :cond_105

    .line 239
    .line 240
    invoke-virtual {v10}, Lde/j;->g()Lde/n;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    invoke-virtual {v0}, Lde/n;->o()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    if-eqz v0, :cond_105

    .line 249
    .line 250
    invoke-virtual {v10}, Lde/j;->g()Lde/n;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-virtual {v0}, Lde/n;->o()Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object v0

    .line 258
    invoke-virtual {v15, v0}, Lcom/airbnb/android/react/maps/a;->setImage(Ljava/lang/String;)V

    .line 259
    .line 260
    .line 261
    goto :goto_11e

    .line 262
    :cond_105
    invoke-virtual {v10}, Lde/j;->k()Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v0

    .line 266
    invoke-virtual {v7, v0}, Lde/b;->f(Ljava/lang/String;)Lde/n;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    if-eqz v0, :cond_11e

    .line 271
    .line 272
    invoke-virtual {v10}, Lde/j;->k()Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    invoke-virtual {v7, v0}, Lde/b;->f(Ljava/lang/String;)Lde/n;

    .line 277
    .line 278
    .line 279
    move-result-object v0

    .line 280
    invoke-virtual {v0}, Lde/n;->o()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-virtual {v15, v0}, Lcom/airbnb/android/react/maps/a;->setImage(Ljava/lang/String;)V

    .line 285
    .line 286
    .line 287
    :cond_11e
    :goto_11e
    new-instance v0, Ljava/lang/StringBuilder;

    .line 288
    .line 289
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 290
    .line 291
    .line 292
    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 293
    .line 294
    .line 295
    const-string v4, " - "

    .line 296
    .line 297
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 298
    .line 299
    .line 300
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 301
    .line 302
    .line 303
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v0

    .line 307
    invoke-virtual {v15, v0}, Lcom/airbnb/android/react/maps/a;->setIdentifier(Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 311
    .line 312
    .line 313
    move-result v4

    .line 314
    const/4 v10, 0x1

    .line 315
    add-int/2addr v4, v10

    .line 316
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 317
    .line 318
    .line 319
    move-result-object v4

    .line 320
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 321
    .line 322
    .line 323
    move-result v6

    .line 324
    invoke-virtual {v1, v15, v6}, Lo2/l;->z(Landroid/view/View;I)V

    .line 325
    .line 326
    .line 327
    invoke-virtual {v1, v12}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 328
    .line 329
    .line 330
    move-result-object v6

    .line 331
    const-string v11, "id"

    .line 332
    .line 333
    invoke-interface {v6, v11, v0}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    const-string v0, "title"

    .line 337
    .line 338
    invoke-interface {v6, v0, v13}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    invoke-interface {v6, v2, v14}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    invoke-interface {v5, v6}, Lcom/facebook/react/bridge/WritableArray;->pushMap(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 345
    .line 346
    .line 347
    move-object v6, v4

    .line 348
    move-object/from16 v0, v16

    .line 349
    .line 350
    const/4 v4, 0x1

    .line 351
    goto/16 :goto_8c

    .line 352
    .line 353
    :cond_160
    const-string v0, "markers"

    .line 354
    .line 355
    invoke-interface {v3, v0, v5}, Lcom/facebook/react/bridge/WritableMap;->putArray(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableArray;)V

    .line 356
    .line 357
    .line 358
    iget-object v0, v1, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 359
    .line 360
    iget-object v2, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 361
    .line 362
    invoke-virtual {v0, v2, v1, v8, v3}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 363
    .line 364
    .line 365
    goto :goto_188

    .line 366
    :cond_16d
    :goto_16d
    iget-object v0, v1, Lo2/l;->H:Lcom/airbnb/android/react/maps/AirMapManager;

    .line 367
    .line 368
    iget-object v2, v1, Lo2/l;->L:Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 369
    .line 370
    invoke-virtual {v0, v2, v1, v8, v3}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V
    :try_end_174
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_c1 .. :try_end_174} :catch_184
    .catch Ljava/io/IOException; {:try_start_c1 .. :try_end_174} :catch_17f
    .catch Ljava/lang/InterruptedException; {:try_start_c1 .. :try_end_174} :catch_17a
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_c1 .. :try_end_174} :catch_175

    .line 371
    .line 372
    .line 373
    return-void

    .line 374
    :catch_175
    move-exception v0

    .line 375
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 376
    .line 377
    .line 378
    goto :goto_188

    .line 379
    :catch_17a
    move-exception v0

    .line 380
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 381
    .line 382
    .line 383
    goto :goto_188

    .line 384
    :catch_17f
    move-exception v0

    .line 385
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 386
    .line 387
    .line 388
    goto :goto_188

    .line 389
    :catch_184
    move-exception v0

    .line 390
    invoke-virtual {v0}, Lorg/xmlpull/v1/XmlPullParserException;->printStackTrace()V

    .line 391
    .line 392
    .line 393
    :goto_188
    return-void
.end method

.method public setLoadingBackgroundColor(Ljava/lang/Integer;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/l;->j:Ljava/lang/Integer;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/l;->d:Landroid/widget/RelativeLayout;

    .line 4
    .line 5
    if-eqz v0, :cond_14

    .line 6
    .line 7
    if-nez p1, :cond_d

    .line 8
    .line 9
    const/4 p1, -0x1

    .line 10
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 11
    .line 12
    .line 13
    goto :goto_14

    .line 14
    :cond_d
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 19
    .line 20
    .line 21
    :cond_14
    :goto_14
    return-void
.end method

.method public setLoadingIndicatorColor(Ljava/lang/Integer;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lo2/l;->k:Ljava/lang/Integer;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 4
    .line 5
    if-eqz v0, :cond_34

    .line 6
    .line 7
    if-nez p1, :cond_d

    .line 8
    .line 9
    const-string v0, "#606060"

    .line 10
    .line 11
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    :cond_d
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iget-object v2, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 39
    .line 40
    invoke-virtual {v2, v0}, Landroid/widget/ProgressBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 41
    .line 42
    .line 43
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setSecondaryProgressTintList(Landroid/content/res/ColorStateList;)V

    .line 46
    .line 47
    .line 48
    iget-object v0, p0, Lo2/l;->c:Landroid/widget/ProgressBar;

    .line 49
    .line 50
    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setIndeterminateTintList(Landroid/content/res/ColorStateList;)V

    .line 51
    .line 52
    .line 53
    :cond_34
    return-void
.end method

.method public setMapStyle(Ljava/lang/String;)V
    .registers 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    iput-object p1, p0, Lo2/l;->u:Ljava/lang/String;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 4
    .line 5
    if-eqz v0, :cond_10

    .line 6
    .line 7
    if-eqz p1, :cond_10

    .line 8
    .line 9
    new-instance v1, Lcom/google/android/gms/maps/model/MapStyleOptions;

    .line 10
    .line 11
    invoke-direct {v1, p1}, Lcom/google/android/gms/maps/model/MapStyleOptions;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->setMapStyle(Lcom/google/android/gms/maps/model/MapStyleOptions;)Z

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setMoveOnMarkerPress(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/l;->q:Z

    return-void
.end method

.method public setRegion(Lcom/facebook/react/bridge/ReadableMap;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/l;->t:Lcom/facebook/react/bridge/ReadableMap;

    .line 2
    .line 3
    if-eqz p1, :cond_b

    .line 4
    .line 5
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 6
    .line 7
    if-eqz v0, :cond_b

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lo2/l;->R(Lcom/facebook/react/bridge/ReadableMap;)V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public setShowsMyLocationButton(Z)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/l;->P()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    if-nez p1, :cond_11

    .line 8
    .line 9
    :cond_8
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getUiSettings()Lcom/google/android/gms/maps/UiSettings;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/UiSettings;->setMyLocationButtonEnabled(Z)V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setShowsUserLocation(Z)V
    .registers 4

    .line 1
    iput-boolean p1, p0, Lo2/l;->o:Z

    .line 2
    .line 3
    invoke-virtual {p0}, Lo2/l;->P()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_14

    .line 8
    .line 9
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 10
    .line 11
    iget-object v1, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->setLocationSource(Lcom/google/android/gms/maps/LocationSource;)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 17
    .line 18
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/GoogleMap;->setMyLocationEnabled(Z)V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public setToolbarEnabled(Z)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/l;->P()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    if-nez p1, :cond_11

    .line 8
    .line 9
    :cond_8
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 10
    .line 11
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getUiSettings()Lcom/google/android/gms/maps/UiSettings;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/UiSettings;->setMapToolbarEnabled(Z)V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public setUserLocationFastestInterval(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    .line 2
    .line 3
    instance-of v1, v0, Lo2/o;

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    check-cast v0, Lo2/o;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lo2/o;->a(I)V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public setUserLocationPriority(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    .line 2
    .line 3
    instance-of v1, v0, Lo2/o;

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    check-cast v0, Lo2/o;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lo2/o;->c(I)V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public setUserLocationUpdateInterval(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/l;->N:Lcom/google/android/gms/maps/LocationSource;

    .line 2
    .line 3
    instance-of v1, v0, Lo2/o;

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    check-cast v0, Lo2/o;

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Lo2/o;->b(I)V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public z(Landroid/view/View;I)V
    .registers 5

    .line 1
    instance-of v0, p1, Lcom/airbnb/android/react/maps/a;

    .line 2
    .line 3
    if-eqz v0, :cond_38

    .line 4
    .line 5
    check-cast p1, Lcom/airbnb/android/react/maps/a;

    .line 6
    .line 7
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 8
    .line 9
    invoke-virtual {p1, v0}, Lcom/airbnb/android/react/maps/a;->i(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 13
    .line 14
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    const/4 v0, 0x4

    .line 22
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Landroid/view/ViewGroup;

    .line 30
    .line 31
    if-eqz v0, :cond_23

    .line 32
    .line 33
    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    iget-object v0, p0, Lo2/l;->O:Lo2/v;

    .line 37
    .line 38
    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Lcom/airbnb/android/react/maps/a;->getFeature()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    check-cast p2, Lcom/google/android/gms/maps/model/Marker;

    .line 49
    .line 50
    iget-object v0, p0, Lo2/l;->A:Ljava/util/Map;

    .line 51
    .line 52
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    goto/16 :goto_127

    .line 56
    .line 57
    :cond_38
    instance-of v0, p1, Lo2/i;

    .line 58
    .line 59
    if-eqz v0, :cond_55

    .line 60
    .line 61
    check-cast p1, Lo2/i;

    .line 62
    .line 63
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 64
    .line 65
    invoke-virtual {p1, v0}, Lo2/i;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 69
    .line 70
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p1}, Lo2/i;->getFeature()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    check-cast p2, Lcom/google/android/gms/maps/model/Polyline;

    .line 78
    .line 79
    iget-object v0, p0, Lo2/l;->B:Ljava/util/Map;

    .line 80
    .line 81
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    goto/16 :goto_127

    .line 85
    .line 86
    :cond_55
    instance-of v0, p1, Lo2/d;

    .line 87
    .line 88
    if-eqz v0, :cond_72

    .line 89
    .line 90
    check-cast p1, Lo2/d;

    .line 91
    .line 92
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 93
    .line 94
    invoke-virtual {p1, v0}, Lo2/d;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 95
    .line 96
    .line 97
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 98
    .line 99
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {p1}, Lo2/d;->getFeature()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    check-cast p2, Lcom/google/android/gms/maps/model/TileOverlay;

    .line 107
    .line 108
    iget-object v0, p0, Lo2/l;->F:Ljava/util/Map;

    .line 109
    .line 110
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    goto/16 :goto_127

    .line 114
    .line 115
    :cond_72
    instance-of v0, p1, Lo2/h;

    .line 116
    .line 117
    if-eqz v0, :cond_8f

    .line 118
    .line 119
    check-cast p1, Lo2/h;

    .line 120
    .line 121
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 122
    .line 123
    invoke-virtual {p1, v0}, Lo2/h;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 124
    .line 125
    .line 126
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 127
    .line 128
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1}, Lo2/h;->getFeature()Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object p2

    .line 135
    check-cast p2, Lcom/google/android/gms/maps/model/Polygon;

    .line 136
    .line 137
    iget-object v0, p0, Lo2/l;->C:Ljava/util/Map;

    .line 138
    .line 139
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    goto/16 :goto_127

    .line 143
    .line 144
    :cond_8f
    instance-of v0, p1, Lo2/b;

    .line 145
    .line 146
    if-eqz v0, :cond_a1

    .line 147
    .line 148
    check-cast p1, Lo2/b;

    .line 149
    .line 150
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 151
    .line 152
    invoke-virtual {p1, v0}, Lo2/b;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 153
    .line 154
    .line 155
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 156
    .line 157
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    goto/16 :goto_127

    .line 161
    .line 162
    :cond_a1
    instance-of v0, p1, Lo2/k;

    .line 163
    .line 164
    if-eqz v0, :cond_b3

    .line 165
    .line 166
    check-cast p1, Lo2/k;

    .line 167
    .line 168
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 169
    .line 170
    invoke-virtual {p1, v0}, Lo2/k;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 171
    .line 172
    .line 173
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 174
    .line 175
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 176
    .line 177
    .line 178
    goto/16 :goto_127

    .line 179
    .line 180
    :cond_b3
    instance-of v0, p1, Lo2/m;

    .line 181
    .line 182
    if-eqz v0, :cond_c4

    .line 183
    .line 184
    check-cast p1, Lo2/m;

    .line 185
    .line 186
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 187
    .line 188
    invoke-virtual {p1, v0}, Lo2/k;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 189
    .line 190
    .line 191
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 192
    .line 193
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 194
    .line 195
    .line 196
    goto :goto_127

    .line 197
    :cond_c4
    instance-of v0, p1, Lo2/f;

    .line 198
    .line 199
    if-eqz v0, :cond_d5

    .line 200
    .line 201
    check-cast p1, Lo2/f;

    .line 202
    .line 203
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 204
    .line 205
    invoke-virtual {p1, v0}, Lo2/f;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 206
    .line 207
    .line 208
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 209
    .line 210
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    goto :goto_127

    .line 214
    :cond_d5
    instance-of v0, p1, Lo2/g;

    .line 215
    .line 216
    if-eqz v0, :cond_f1

    .line 217
    .line 218
    check-cast p1, Lo2/g;

    .line 219
    .line 220
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 221
    .line 222
    invoke-virtual {p1, v0}, Lo2/g;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 223
    .line 224
    .line 225
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 226
    .line 227
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {p1}, Lo2/g;->getFeature()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object p2

    .line 234
    check-cast p2, Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 235
    .line 236
    iget-object v0, p0, Lo2/l;->D:Ljava/util/Map;

    .line 237
    .line 238
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    goto :goto_127

    .line 242
    :cond_f1
    instance-of v0, p1, Lo2/e;

    .line 243
    .line 244
    if-eqz v0, :cond_10d

    .line 245
    .line 246
    check-cast p1, Lo2/e;

    .line 247
    .line 248
    iget-object v0, p0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 249
    .line 250
    invoke-virtual {p1, v0}, Lo2/e;->b(Lcom/google/android/gms/maps/GoogleMap;)V

    .line 251
    .line 252
    .line 253
    iget-object v0, p0, Lo2/l;->z:Ljava/util/List;

    .line 254
    .line 255
    invoke-interface {v0, p2, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {p1}, Lo2/e;->getFeature()Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object p2

    .line 262
    check-cast p2, Lcom/google/android/gms/maps/model/TileOverlay;

    .line 263
    .line 264
    iget-object v0, p0, Lo2/l;->E:Ljava/util/Map;

    .line 265
    .line 266
    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    goto :goto_127

    .line 270
    :cond_10d
    instance-of v0, p1, Landroid/view/ViewGroup;

    .line 271
    .line 272
    if-eqz v0, :cond_124

    .line 273
    .line 274
    check-cast p1, Landroid/view/ViewGroup;

    .line 275
    .line 276
    const/4 v0, 0x0

    .line 277
    :goto_114
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 278
    .line 279
    .line 280
    move-result v1

    .line 281
    if-ge v0, v1, :cond_127

    .line 282
    .line 283
    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 284
    .line 285
    .line 286
    move-result-object v1

    .line 287
    invoke-virtual {p0, v1, p2}, Lo2/l;->z(Landroid/view/View;I)V

    .line 288
    .line 289
    .line 290
    add-int/lit8 v0, v0, 0x1

    .line 291
    .line 292
    goto :goto_114

    .line 293
    :cond_124
    invoke-virtual {p0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 294
    .line 295
    .line 296
    :cond_127
    :goto_127
    return-void
.end method

###### Class o2.l.a (o2.l$a)
.class public Lo2/l$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnMapLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$a;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$a;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMapLongClick(Lcom/google/android/gms/maps/model/LatLng;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$a;->b:Lo2/l;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "action"

    .line 8
    .line 9
    const-string v2, "long-press"

    .line 10
    .line 11
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lo2/l$a;->b:Lo2/l;

    .line 15
    .line 16
    invoke-static {v0}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v1, p0, Lo2/l$a;->b:Lo2/l;

    .line 21
    .line 22
    invoke-static {v1}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    iget-object v2, p0, Lo2/l$a;->a:Lo2/l;

    .line 27
    .line 28
    iget-object v3, p0, Lo2/l$a;->b:Lo2/l;

    .line 29
    .line 30
    invoke-virtual {v3, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    const-string v3, "onLongPress"

    .line 35
    .line 36
    invoke-virtual {v0, v1, v2, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

###### Class o2.l.b (o2.l$b)
.class public Lo2/l$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnGroundOverlayClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$b;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGroundOverlayClick(Lcom/google/android/gms/maps/model/GroundOverlay;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$b;->a:Lo2/l;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v0, v1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "action"

    .line 12
    .line 13
    const-string v2, "overlay-press"

    .line 14
    .line 15
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lo2/l$b;->a:Lo2/l;

    .line 19
    .line 20
    invoke-static {v1}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget-object v2, p0, Lo2/l$b;->a:Lo2/l;

    .line 25
    .line 26
    invoke-static {v2}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    iget-object v3, p0, Lo2/l$b;->a:Lo2/l;

    .line 31
    .line 32
    invoke-static {v3}, Lo2/l;->c(Lo2/l;)Ljava/util/Map;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v3, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/view/View;

    .line 41
    .line 42
    const-string v3, "onPress"

    .line 43
    .line 44
    invoke-virtual {v1, v2, p1, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

###### Class o2.l.c (o2.l$c)
.class public Lo2/l$c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnCameraMoveStartedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$c;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCameraMoveStarted(I)V
    .registers 3

    iget-object v0, p0, Lo2/l$c;->a:Lo2/l;

    invoke-static {v0, p1}, Lo2/l;->f(Lo2/l;I)I

    return-void
.end method

###### Class o2.l.d (o2.l$d)
.class public Lo2/l$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnCameraMoveListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/google/android/gms/maps/GoogleMap;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    iput-object p1, p0, Lo2/l$d;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$d;->a:Lcom/google/android/gms/maps/GoogleMap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCameraMove()V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$d;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lcom/google/android/gms/maps/Projection;->getVisibleRegion()Lcom/google/android/gms/maps/model/VisibleRegion;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v0, v0, Lcom/google/android/gms/maps/model/VisibleRegion;->latLngBounds:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 12
    .line 13
    iget-object v1, p0, Lo2/l$d;->b:Lo2/l;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-static {v1, v2}, Lo2/l;->h(Lo2/l;Lcom/google/android/gms/maps/model/LatLngBounds;)Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lo2/l$d;->b:Lo2/l;

    .line 20
    .line 21
    invoke-static {v1}, Lo2/l;->e(Lo2/l;)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v2, 0x1

    .line 26
    if-ne v2, v1, :cond_1d

    .line 27
    .line 28
    const/4 v1, 0x1

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    const/4 v1, 0x0

    .line 31
    :goto_1e
    new-instance v3, Lo2/t;

    .line 32
    .line 33
    iget-object v4, p0, Lo2/l$d;->b:Lo2/l;

    .line 34
    .line 35
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    invoke-direct {v3, v4, v0, v2, v1}, Lo2/t;-><init>(ILcom/google/android/gms/maps/model/LatLngBounds;ZZ)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lo2/l$d;->b:Lo2/l;

    .line 43
    .line 44
    invoke-static {v0}, Lo2/l;->i(Lo2/l;)Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-virtual {v0, v3}, Lcom/facebook/react/uimanager/events/EventDispatcher;->dispatchEvent(Lcom/facebook/react/uimanager/events/Event;)V

    .line 49
    .line 50
    .line 51
    return-void
.end method

###### Class o2.l.e (o2.l$e)
.class public Lo2/l$e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnCameraIdleListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lcom/google/android/gms/maps/GoogleMap;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    iput-object p1, p0, Lo2/l$e;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$e;->a:Lcom/google/android/gms/maps/GoogleMap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCameraIdle()V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$e;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/gms/maps/GoogleMap;->getProjection()Lcom/google/android/gms/maps/Projection;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Lcom/google/android/gms/maps/Projection;->getVisibleRegion()Lcom/google/android/gms/maps/model/VisibleRegion;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iget-object v0, v0, Lcom/google/android/gms/maps/model/VisibleRegion;->latLngBounds:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 12
    .line 13
    iget-object v1, p0, Lo2/l$e;->b:Lo2/l;

    .line 14
    .line 15
    invoke-static {v1}, Lo2/l;->e(Lo2/l;)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_4d

    .line 20
    .line 21
    iget-object v1, p0, Lo2/l$e;->b:Lo2/l;

    .line 22
    .line 23
    invoke-static {v1}, Lo2/l;->g(Lo2/l;)Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    if-eqz v1, :cond_28

    .line 28
    .line 29
    iget-object v1, p0, Lo2/l$e;->b:Lo2/l;

    .line 30
    .line 31
    invoke-static {v1}, Lo2/l;->g(Lo2/l;)Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {v0, v1}, Lo2/r;->a(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_4d

    .line 40
    .line 41
    :cond_28
    iget-object v1, p0, Lo2/l$e;->b:Lo2/l;

    .line 42
    .line 43
    invoke-static {v1, v0}, Lo2/l;->h(Lo2/l;Lcom/google/android/gms/maps/model/LatLngBounds;)Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 44
    .line 45
    .line 46
    iget-object v1, p0, Lo2/l$e;->b:Lo2/l;

    .line 47
    .line 48
    invoke-static {v1}, Lo2/l;->e(Lo2/l;)I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    const/4 v2, 0x0

    .line 53
    const/4 v3, 0x1

    .line 54
    if-ne v3, v1, :cond_38

    .line 55
    .line 56
    goto :goto_39

    .line 57
    :cond_38
    const/4 v3, 0x0

    .line 58
    :goto_39
    new-instance v1, Lo2/t;

    .line 59
    .line 60
    iget-object v4, p0, Lo2/l$e;->b:Lo2/l;

    .line 61
    .line 62
    invoke-virtual {v4}, Landroid/view/View;->getId()I

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    invoke-direct {v1, v4, v0, v2, v3}, Lo2/t;-><init>(ILcom/google/android/gms/maps/model/LatLngBounds;ZZ)V

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Lo2/l$e;->b:Lo2/l;

    .line 70
    .line 71
    invoke-static {v0}, Lo2/l;->i(Lo2/l;)Lcom/facebook/react/uimanager/events/EventDispatcher;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v0, v1}, Lcom/facebook/react/uimanager/events/EventDispatcher;->dispatchEvent(Lcom/facebook/react/uimanager/events/Event;)V

    .line 76
    .line 77
    .line 78
    :cond_4d
    return-void
.end method

###### Class o2.l.f (o2.l$f)
.class public Lo2/l$f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnMapLoadedCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$f;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$f;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMapLoaded()V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$f;->b:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0}, Lo2/l;->j(Lo2/l;)J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    cmp-long v4, v0, v2

    .line 10
    .line 11
    if-eqz v4, :cond_1d

    .line 12
    .line 13
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 14
    .line 15
    .line 16
    move-result-wide v0

    .line 17
    iget-object v2, p0, Lo2/l$f;->b:Lo2/l;

    .line 18
    .line 19
    invoke-static {v2}, Lo2/l;->j(Lo2/l;)J

    .line 20
    .line 21
    .line 22
    move-result-wide v2

    .line 23
    sub-long/2addr v0, v2

    .line 24
    sget-object v2, Lp2/b;->a:Lp2/b;

    .line 25
    .line 26
    const/4 v3, 0x1

    .line 27
    invoke-virtual {v2, v3, v0, v1}, Lp2/b;->d(IJ)V

    .line 28
    .line 29
    .line 30
    :cond_1d
    sget-object v0, Lp2/b;->a:Lp2/b;

    .line 31
    .line 32
    const/4 v1, 0x3

    .line 33
    const-string v2, ""

    .line 34
    .line 35
    invoke-virtual {v0, v1, v2}, Lp2/b;->c(ILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lo2/l$f;->b:Lo2/l;

    .line 39
    .line 40
    invoke-static {v0}, Lo2/l;->l(Lo2/l;)Landroid/os/Handler;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    iget-object v1, p0, Lo2/l$f;->b:Lo2/l;

    .line 45
    .line 46
    invoke-static {v1}, Lo2/l;->k(Lo2/l;)Ljava/lang/Runnable;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Lo2/l$f;->b:Lo2/l;

    .line 54
    .line 55
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 56
    .line 57
    invoke-static {v0, v1}, Lo2/l;->m(Lo2/l;Ljava/lang/Boolean;)Ljava/lang/Boolean;

    .line 58
    .line 59
    .line 60
    iget-object v0, p0, Lo2/l$f;->b:Lo2/l;

    .line 61
    .line 62
    invoke-static {v0}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    iget-object v1, p0, Lo2/l$f;->b:Lo2/l;

    .line 67
    .line 68
    invoke-static {v1}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    iget-object v2, p0, Lo2/l$f;->a:Lo2/l;

    .line 73
    .line 74
    new-instance v3, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 75
    .line 76
    invoke-direct {v3}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 77
    .line 78
    .line 79
    const-string v4, "onMapLoaded"

    .line 80
    .line 81
    invoke-virtual {v0, v1, v2, v4, v3}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 82
    .line 83
    .line 84
    iget-object v0, p0, Lo2/l$f;->b:Lo2/l;

    .line 85
    .line 86
    invoke-static {v0}, Lo2/l;->o(Lo2/l;)V

    .line 87
    .line 88
    .line 89
    return-void
.end method

###### Class o2.l.g (o2.l$g)
.class public Lo2/l$g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$SnapshotReadyCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->F()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroid/widget/ImageView;

.field public final synthetic b:Landroid/widget/RelativeLayout;

.field public final synthetic c:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Landroid/widget/ImageView;Landroid/widget/RelativeLayout;)V
    .registers 4

    iput-object p1, p0, Lo2/l$g;->c:Lo2/l;

    iput-object p2, p0, Lo2/l$g;->a:Landroid/widget/ImageView;

    iput-object p3, p0, Lo2/l$g;->b:Landroid/widget/RelativeLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSnapshotReady(Landroid/graphics/Bitmap;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/l$g;->a:Landroid/widget/ImageView;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lo2/l$g;->a:Landroid/widget/ImageView;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Lo2/l$g;->b:Landroid/widget/RelativeLayout;

    .line 13
    .line 14
    const/4 v0, 0x4

    .line 15
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

###### Class o2.l.h (o2.l$h)
.class public Lo2/l$h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$h;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$h;->a:Lo2/l;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/high16 v2, 0x40000000    # 2.0f

    .line 8
    .line 9
    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    iget-object v3, p0, Lo2/l$h;->a:Lo2/l;

    .line 14
    .line 15
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-static {v3, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    invoke-virtual {v0, v1, v2}, Landroid/view/View;->measure(II)V

    .line 24
    .line 25
    .line 26
    iget-object v0, p0, Lo2/l$h;->a:Lo2/l;

    .line 27
    .line 28
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    iget-object v2, p0, Lo2/l$h;->a:Lo2/l;

    .line 33
    .line 34
    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    iget-object v3, p0, Lo2/l$h;->a:Lo2/l;

    .line 39
    .line 40
    invoke-virtual {v3}, Landroid/view/View;->getRight()I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    iget-object v4, p0, Lo2/l$h;->a:Lo2/l;

    .line 45
    .line 46
    invoke-virtual {v4}, Landroid/view/View;->getBottom()I

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/view/View;->layout(IIII)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

###### Class o2.l.i (o2.l$i)
.class public Lo2/l$i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$i;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    sget-object v0, Lp2/b;->a:Lp2/b;

    const/4 v1, 0x4

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lp2/b;->c(ILjava/lang/String;)V

    return-void
.end method

###### Class o2.l.j (o2.l$j)
.class public Lo2/l$j;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;-><init>(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/bridge/ReactApplicationContext;Lcom/airbnb/android/react/maps/AirMapManager;Lcom/google/android/gms/maps/GoogleMapOptions;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$j;->a:Lo2/l;

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onDoubleTap(Landroid/view/MotionEvent;)Z
    .registers 3

    iget-object v0, p0, Lo2/l$j;->a:Lo2/l;

    invoke-virtual {v0, p1}, Lo2/l;->S(Landroid/view/MotionEvent;)V

    const/4 p1, 0x0

    return p1
.end method

.method public onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 5

    .line 1
    iget-object p1, p0, Lo2/l$j;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {p1}, Lo2/l;->a(Lo2/l;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_d

    .line 8
    .line 9
    iget-object p1, p0, Lo2/l$j;->a:Lo2/l;

    .line 10
    .line 11
    invoke-virtual {p1, p2}, Lo2/l;->T(Landroid/view/MotionEvent;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    const/4 p1, 0x0

    .line 15
    return p1
.end method

###### Class o2.l.k (o2.l$k)
.class public Lo2/l$k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;-><init>(Lcom/facebook/react/uimanager/ThemedReactContext;Lcom/facebook/react/bridge/ReactApplicationContext;Lcom/airbnb/android/react/maps/AirMapManager;Lcom/google/android/gms/maps/GoogleMapOptions;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$k;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 10

    .line 1
    iget-object p1, p0, Lo2/l$k;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {p1}, Lo2/l;->b(Lo2/l;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-nez p1, :cond_d

    .line 8
    .line 9
    iget-object p1, p0, Lo2/l$k;->a:Lo2/l;

    .line 10
    .line 11
    invoke-static {p1}, Lo2/l;->o(Lo2/l;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void
.end method

###### Class o2.l.C0056l (o2.l$l)
.class public Lo2/l$l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnMyLocationChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$l;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$l;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMyLocationChange(Landroid/location/Location;)V
    .registers 7

    .line 1
    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 7
    .line 8
    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    .line 12
    .line 13
    .line 14
    move-result-wide v2

    .line 15
    const-string v4, "latitude"

    .line 16
    .line 17
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    .line 21
    .line 22
    .line 23
    move-result-wide v2

    .line 24
    const-string v4, "longitude"

    .line 25
    .line 26
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p1}, Landroid/location/Location;->getAltitude()D

    .line 30
    .line 31
    .line 32
    move-result-wide v2

    .line 33
    const-string v4, "altitude"

    .line 34
    .line 35
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p1}, Landroid/location/Location;->getTime()J

    .line 39
    .line 40
    .line 41
    move-result-wide v2

    .line 42
    long-to-double v2, v2

    .line 43
    const-string v4, "timestamp"

    .line 44
    .line 45
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1}, Landroid/location/Location;->getAccuracy()F

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    float-to-double v2, v2

    .line 53
    const-string v4, "accuracy"

    .line 54
    .line 55
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Landroid/location/Location;->getSpeed()F

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    float-to-double v2, v2

    .line 63
    const-string v4, "speed"

    .line 64
    .line 65
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p1}, Landroid/location/Location;->getBearing()F

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    float-to-double v2, v2

    .line 73
    const-string v4, "heading"

    .line 74
    .line 75
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p1}, Landroid/location/Location;->isFromMockProvider()Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    const-string v2, "isFromMockProvider"

    .line 83
    .line 84
    invoke-interface {v1, v2, p1}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 85
    .line 86
    .line 87
    const-string p1, "coordinate"

    .line 88
    .line 89
    invoke-interface {v0, p1, v1}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 90
    .line 91
    .line 92
    iget-object p1, p0, Lo2/l$l;->b:Lo2/l;

    .line 93
    .line 94
    invoke-static {p1}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    iget-object v1, p0, Lo2/l$l;->b:Lo2/l;

    .line 99
    .line 100
    invoke-static {v1}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    iget-object v2, p0, Lo2/l$l;->a:Lo2/l;

    .line 105
    .line 106
    const-string v3, "onUserLocationChange"

    .line 107
    .line 108
    invoke-virtual {p1, v1, v2, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 109
    .line 110
    .line 111
    return-void
.end method

###### Class o2.l.m (o2.l$m)
.class public Lo2/l$m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnMarkerClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$m;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$m;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMarkerClick(Lcom/google/android/gms/maps/model/Marker;)Z
    .registers 11

    .line 1
    iget-object v0, p0, Lo2/l$m;->b:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lo2/l;->u(Lo2/l;Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Lo2/l$m;->b:Lo2/l;

    .line 8
    .line 9
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-virtual {v1, v2}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const-string v2, "action"

    .line 18
    .line 19
    const-string v3, "marker-press"

    .line 20
    .line 21
    invoke-interface {v1, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Lcom/airbnb/android/react/maps/a;->getIdentifier()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    const-string v5, "id"

    .line 29
    .line 30
    invoke-interface {v1, v5, v4}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v4, p0, Lo2/l$m;->b:Lo2/l;

    .line 34
    .line 35
    invoke-static {v4}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    iget-object v6, p0, Lo2/l$m;->b:Lo2/l;

    .line 40
    .line 41
    invoke-static {v6}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    iget-object v7, p0, Lo2/l$m;->a:Lo2/l;

    .line 46
    .line 47
    const-string v8, "onMarkerPress"

    .line 48
    .line 49
    invoke-virtual {v4, v6, v7, v8, v1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 50
    .line 51
    .line 52
    iget-object v1, p0, Lo2/l$m;->b:Lo2/l;

    .line 53
    .line 54
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-virtual {v1, v4}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-interface {v1, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v0}, Lcom/airbnb/android/react/maps/a;->getIdentifier()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    invoke-interface {v1, v5, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    iget-object v2, p0, Lo2/l$m;->b:Lo2/l;

    .line 73
    .line 74
    invoke-static {v2}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    iget-object v3, p0, Lo2/l$m;->b:Lo2/l;

    .line 79
    .line 80
    invoke-static {v3}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    const-string v4, "onPress"

    .line 85
    .line 86
    invoke-virtual {v2, v3, v0, v4, v1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 87
    .line 88
    .line 89
    iget-object v0, p0, Lo2/l$m;->a:Lo2/l;

    .line 90
    .line 91
    invoke-static {v0}, Lo2/l;->v(Lo2/l;)Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_62

    .line 96
    .line 97
    const/4 p1, 0x0

    .line 98
    return p1

    .line 99
    :cond_62
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->showInfoWindow()V

    .line 100
    .line 101
    .line 102
    const/4 p1, 0x1

    .line 103
    return p1
.end method

###### Class o2.l.n (o2.l$n)
.class public Lo2/l$n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnPolygonClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$n;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPolygonClick(Lcom/google/android/gms/maps/model/Polygon;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$n;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0}, Lo2/l;->w(Lo2/l;)Lcom/google/android/gms/maps/model/LatLng;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v0, v1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "action"

    .line 12
    .line 13
    const-string v2, "polygon-press"

    .line 14
    .line 15
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lo2/l$n;->a:Lo2/l;

    .line 19
    .line 20
    invoke-static {v1}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget-object v2, p0, Lo2/l$n;->a:Lo2/l;

    .line 25
    .line 26
    invoke-static {v2}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    iget-object v3, p0, Lo2/l$n;->a:Lo2/l;

    .line 31
    .line 32
    invoke-static {v3}, Lo2/l;->x(Lo2/l;)Ljava/util/Map;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v3, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/view/View;

    .line 41
    .line 42
    const-string v3, "onPress"

    .line 43
    .line 44
    invoke-virtual {v1, v2, p1, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

###### Class o2.l.o (o2.l$o)
.class public Lo2/l$o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnPolylineClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    iput-object p1, p0, Lo2/l$o;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPolylineClick(Lcom/google/android/gms/maps/model/Polyline;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$o;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0}, Lo2/l;->w(Lo2/l;)Lcom/google/android/gms/maps/model/LatLng;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v0, v1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "action"

    .line 12
    .line 13
    const-string v2, "polyline-press"

    .line 14
    .line 15
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lo2/l$o;->a:Lo2/l;

    .line 19
    .line 20
    invoke-static {v1}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iget-object v2, p0, Lo2/l$o;->a:Lo2/l;

    .line 25
    .line 26
    invoke-static {v2}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    iget-object v3, p0, Lo2/l$o;->a:Lo2/l;

    .line 31
    .line 32
    invoke-static {v3}, Lo2/l;->y(Lo2/l;)Ljava/util/Map;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-interface {v3, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroid/view/View;

    .line 41
    .line 42
    const-string v3, "onPress"

    .line 43
    .line 44
    invoke-virtual {v1, v2, p1, v3, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

###### Class o2.l.p (o2.l$p)
.class public Lo2/l$p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnInfoWindowClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$p;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$p;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onInfoWindowClick(Lcom/google/android/gms/maps/model/Marker;)V
    .registers 9

    .line 1
    iget-object v0, p0, Lo2/l$p;->b:Lo2/l;

    .line 2
    .line 3
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-virtual {v0, v1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    const-string v1, "action"

    .line 12
    .line 13
    const-string v2, "callout-press"

    .line 14
    .line 15
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v3, p0, Lo2/l$p;->b:Lo2/l;

    .line 19
    .line 20
    invoke-static {v3}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    iget-object v4, p0, Lo2/l$p;->b:Lo2/l;

    .line 25
    .line 26
    invoke-static {v4}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    iget-object v5, p0, Lo2/l$p;->a:Lo2/l;

    .line 31
    .line 32
    const-string v6, "onCalloutPress"

    .line 33
    .line 34
    invoke-virtual {v3, v4, v5, v6, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lo2/l$p;->b:Lo2/l;

    .line 38
    .line 39
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    invoke-virtual {v0, v3}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-interface {v0, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    iget-object v3, p0, Lo2/l$p;->b:Lo2/l;

    .line 51
    .line 52
    invoke-static {v3, p1}, Lo2/l;->u(Lo2/l;Lcom/google/android/gms/maps/model/Marker;)Lcom/airbnb/android/react/maps/a;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    iget-object v4, p0, Lo2/l$p;->b:Lo2/l;

    .line 57
    .line 58
    invoke-static {v4}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    iget-object v5, p0, Lo2/l$p;->b:Lo2/l;

    .line 63
    .line 64
    invoke-static {v5}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 65
    .line 66
    .line 67
    move-result-object v5

    .line 68
    invoke-virtual {v4, v5, v3, v6, v0}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 69
    .line 70
    .line 71
    iget-object v0, p0, Lo2/l$p;->b:Lo2/l;

    .line 72
    .line 73
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-virtual {v0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    invoke-interface {p1, v1, v2}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v3}, Lcom/airbnb/android/react/maps/a;->getCalloutView()Lo2/a;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    if-eqz v0, :cond_6a

    .line 89
    .line 90
    iget-object v1, p0, Lo2/l$p;->b:Lo2/l;

    .line 91
    .line 92
    invoke-static {v1}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    iget-object v2, p0, Lo2/l$p;->b:Lo2/l;

    .line 97
    .line 98
    invoke-static {v2}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    const-string v3, "onPress"

    .line 103
    .line 104
    invoke-virtual {v1, v2, v0, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 105
    .line 106
    .line 107
    :cond_6a
    return-void
.end method

###### Class o2.l.q (o2.l$q)
.class public Lo2/l$q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/GoogleMap$OnMapClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/l;->onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;

.field public final synthetic b:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;Lo2/l;)V
    .registers 3

    iput-object p1, p0, Lo2/l$q;->b:Lo2/l;

    iput-object p2, p0, Lo2/l$q;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMapClick(Lcom/google/android/gms/maps/model/LatLng;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/l$q;->b:Lo2/l;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lo2/l;->Q(Lcom/google/android/gms/maps/model/LatLng;)Lcom/facebook/react/bridge/WritableMap;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const-string v0, "action"

    .line 8
    .line 9
    const-string v1, "press"

    .line 10
    .line 11
    invoke-interface {p1, v0, v1}, Lcom/facebook/react/bridge/WritableMap;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lo2/l$q;->b:Lo2/l;

    .line 15
    .line 16
    invoke-static {v0}, Lo2/l;->t(Lo2/l;)Lcom/airbnb/android/react/maps/AirMapManager;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iget-object v1, p0, Lo2/l$q;->b:Lo2/l;

    .line 21
    .line 22
    invoke-static {v1}, Lo2/l;->s(Lo2/l;)Lcom/facebook/react/uimanager/ThemedReactContext;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    iget-object v2, p0, Lo2/l$q;->a:Lo2/l;

    .line 27
    .line 28
    const-string v3, "onPress"

    .line 29
    .line 30
    invoke-virtual {v0, v1, v2, v3, p1}, Lcom/airbnb/android/react/maps/AirMapManager;->pushEvent(Lcom/facebook/react/uimanager/ThemedReactContext;Landroid/view/View;Ljava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

###### Class o2.l.r (o2.l$r)
.class public Lo2/l$r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/LifecycleObserver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "r"
.end annotation


# instance fields
.field public final synthetic a:Lo2/l;


# direct methods
.method public constructor <init>(Lo2/l;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lo2/l$r;->a:Lo2/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lo2/l;Lo2/l$i;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lo2/l$r;-><init>(Lo2/l;)V

    return-void
.end method


# virtual methods
.method public onHostDestroy()V
    .registers 2
    .annotation runtime Landroidx/lifecycle/OnLifecycleEvent;
        value = .enum Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;
    .end annotation

    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    invoke-virtual {v0}, Lo2/l;->H()V

    return-void
.end method

.method public onHostPause()V
    .registers 4
    .annotation runtime Landroidx/lifecycle/OnLifecycleEvent;
        value = .enum Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;
    .end annotation

    .line 1
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0}, Lo2/l;->n(Lo2/l;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_12

    .line 8
    .line 9
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 10
    .line 11
    iget-object v0, v0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 12
    .line 13
    if-eqz v0, :cond_12

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->setMyLocationEnabled(Z)V

    .line 17
    .line 18
    .line 19
    :cond_12
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 20
    .line 21
    monitor-enter v0

    .line 22
    :try_start_15
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 23
    .line 24
    invoke-static {v1}, Lo2/l;->r(Lo2/l;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_22

    .line 29
    .line 30
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 31
    .line 32
    invoke-virtual {v1}, Lcom/google/android/gms/maps/MapView;->onPause()V

    .line 33
    .line 34
    .line 35
    :cond_22
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 36
    .line 37
    const/4 v2, 0x1

    .line 38
    invoke-static {v1, v2}, Lo2/l;->d(Lo2/l;Z)Z

    .line 39
    .line 40
    .line 41
    monitor-exit v0

    .line 42
    return-void

    .line 43
    :catchall_2a
    move-exception v1

    .line 44
    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_15 .. :try_end_2c} :catchall_2a

    .line 45
    throw v1
.end method

.method public onHostResume()V
    .registers 4
    .annotation runtime Landroidx/lifecycle/OnLifecycleEvent;
        value = .enum Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;
    .end annotation

    .line 1
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 2
    .line 3
    invoke-static {v0}, Lo2/l;->n(Lo2/l;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_20

    .line 8
    .line 9
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 10
    .line 11
    iget-object v1, v0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 12
    .line 13
    if-eqz v1, :cond_20

    .line 14
    .line 15
    invoke-static {v0}, Lo2/l;->p(Lo2/l;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setMyLocationEnabled(Z)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 23
    .line 24
    iget-object v1, v0, Lo2/l;->a:Lcom/google/android/gms/maps/GoogleMap;

    .line 25
    .line 26
    invoke-static {v0}, Lo2/l;->q(Lo2/l;)Lcom/google/android/gms/maps/LocationSource;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/GoogleMap;->setLocationSource(Lcom/google/android/gms/maps/LocationSource;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    iget-object v0, p0, Lo2/l$r;->a:Lo2/l;

    .line 34
    .line 35
    monitor-enter v0

    .line 36
    :try_start_23
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 37
    .line 38
    invoke-static {v1}, Lo2/l;->r(Lo2/l;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_30

    .line 43
    .line 44
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 45
    .line 46
    invoke-virtual {v1}, Lcom/google/android/gms/maps/MapView;->onResume()V

    .line 47
    .line 48
    .line 49
    :cond_30
    iget-object v1, p0, Lo2/l$r;->a:Lo2/l;

    .line 50
    .line 51
    const/4 v2, 0x0

    .line 52
    invoke-static {v1, v2}, Lo2/l;->d(Lo2/l;Z)Z

    .line 53
    .line 54
    .line 55
    monitor-exit v0

    .line 56
    return-void

    .line 57
    :catchall_38
    move-exception v1

    .line 58
    monitor-exit v0
    :try_end_3a
    .catchall {:try_start_23 .. :try_end_3a} :catchall_38

    .line 59
    throw v1
.end method
