###### Class o2.s (o2.s)
.class public Lo2/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/facebook/react/ReactPackage;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createNativeModules(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/react/bridge/ReactApplicationContext;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/react/bridge/NativeModule;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x1

    new-array v0, v0, [Lcom/facebook/react/bridge/NativeModule;

    new-instance v1, Lcom/airbnb/android/react/maps/AirMapModule;

    invoke-direct {v1, p1}, Lcom/airbnb/android/react/maps/AirMapModule;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    const/4 p1, 0x0

    aput-object v1, v0, p1

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public createViewManagers(Lcom/facebook/react/bridge/ReactApplicationContext;)Ljava/util/List;
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/facebook/react/bridge/ReactApplicationContext;",
            ")",
            "Ljava/util/List<",
            "Lcom/facebook/react/uimanager/ViewManager;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/airbnb/android/react/maps/AirMapCalloutManager;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/airbnb/android/react/maps/AirMapCalloutManager;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lcom/airbnb/android/react/maps/AirMapMarkerManager;

    .line 7
    .line 8
    invoke-direct {v1}, Lcom/airbnb/android/react/maps/AirMapMarkerManager;-><init>()V

    .line 9
    .line 10
    .line 11
    new-instance v2, Lcom/airbnb/android/react/maps/AirMapPolylineManager;

    .line 12
    .line 13
    invoke-direct {v2, p1}, Lcom/airbnb/android/react/maps/AirMapPolylineManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 14
    .line 15
    .line 16
    new-instance v3, Lcom/airbnb/android/react/maps/AirMapGradientPolylineManager;

    .line 17
    .line 18
    invoke-direct {v3, p1}, Lcom/airbnb/android/react/maps/AirMapGradientPolylineManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 19
    .line 20
    .line 21
    new-instance v4, Lcom/airbnb/android/react/maps/AirMapPolygonManager;

    .line 22
    .line 23
    invoke-direct {v4, p1}, Lcom/airbnb/android/react/maps/AirMapPolygonManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 24
    .line 25
    .line 26
    new-instance v5, Lcom/airbnb/android/react/maps/AirMapCircleManager;

    .line 27
    .line 28
    invoke-direct {v5, p1}, Lcom/airbnb/android/react/maps/AirMapCircleManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 29
    .line 30
    .line 31
    new-instance v6, Lcom/airbnb/android/react/maps/AirMapManager;

    .line 32
    .line 33
    invoke-direct {v6, p1}, Lcom/airbnb/android/react/maps/AirMapManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 34
    .line 35
    .line 36
    new-instance v7, Lcom/airbnb/android/react/maps/AirMapLiteManager;

    .line 37
    .line 38
    invoke-direct {v7, p1}, Lcom/airbnb/android/react/maps/AirMapLiteManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 39
    .line 40
    .line 41
    new-instance v8, Lcom/airbnb/android/react/maps/AirMapUrlTileManager;

    .line 42
    .line 43
    invoke-direct {v8, p1}, Lcom/airbnb/android/react/maps/AirMapUrlTileManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 44
    .line 45
    .line 46
    new-instance v9, Lcom/airbnb/android/react/maps/AirMapWMSTileManager;

    .line 47
    .line 48
    invoke-direct {v9, p1}, Lcom/airbnb/android/react/maps/AirMapWMSTileManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 49
    .line 50
    .line 51
    new-instance v10, Lcom/airbnb/android/react/maps/AirMapLocalTileManager;

    .line 52
    .line 53
    invoke-direct {v10, p1}, Lcom/airbnb/android/react/maps/AirMapLocalTileManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 54
    .line 55
    .line 56
    new-instance v11, Lcom/airbnb/android/react/maps/AirMapOverlayManager;

    .line 57
    .line 58
    invoke-direct {v11, p1}, Lcom/airbnb/android/react/maps/AirMapOverlayManager;-><init>(Lcom/facebook/react/bridge/ReactApplicationContext;)V

    .line 59
    .line 60
    .line 61
    new-instance p1, Lcom/airbnb/android/react/maps/AirMapHeatmapManager;

    .line 62
    .line 63
    invoke-direct {p1}, Lcom/airbnb/android/react/maps/AirMapHeatmapManager;-><init>()V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v6, v1}, Lcom/airbnb/android/react/maps/AirMapManager;->setMarkerManager(Lcom/airbnb/android/react/maps/AirMapMarkerManager;)V

    .line 67
    .line 68
    .line 69
    const/16 v12, 0xd

    .line 70
    .line 71
    new-array v12, v12, [Lcom/facebook/react/uimanager/ViewManager;

    .line 72
    .line 73
    const/4 v13, 0x0

    .line 74
    aput-object v0, v12, v13

    .line 75
    .line 76
    const/4 v0, 0x1

    .line 77
    aput-object v1, v12, v0

    .line 78
    .line 79
    const/4 v0, 0x2

    .line 80
    aput-object v2, v12, v0

    .line 81
    .line 82
    const/4 v0, 0x3

    .line 83
    aput-object v3, v12, v0

    .line 84
    .line 85
    const/4 v0, 0x4

    .line 86
    aput-object v4, v12, v0

    .line 87
    .line 88
    const/4 v0, 0x5

    .line 89
    aput-object v5, v12, v0

    .line 90
    .line 91
    const/4 v0, 0x6

    .line 92
    aput-object v6, v12, v0

    .line 93
    .line 94
    const/4 v0, 0x7

    .line 95
    aput-object v7, v12, v0

    .line 96
    .line 97
    const/16 v0, 0x8

    .line 98
    .line 99
    aput-object v8, v12, v0

    .line 100
    .line 101
    const/16 v0, 0x9

    .line 102
    .line 103
    aput-object v9, v12, v0

    .line 104
    .line 105
    const/16 v0, 0xa

    .line 106
    .line 107
    aput-object v10, v12, v0

    .line 108
    .line 109
    const/16 v0, 0xb

    .line 110
    .line 111
    aput-object v11, v12, v0

    .line 112
    .line 113
    const/16 v0, 0xc

    .line 114
    .line 115
    aput-object p1, v12, v0

    .line 116
    .line 117
    invoke-static {v12}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    return-object p1
.end method
