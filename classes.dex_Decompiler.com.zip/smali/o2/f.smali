###### Class o2.f (o2.f)
.class public Lo2/f;
.super Lo2/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/f$a;
    }
.end annotation


# instance fields
.field public a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

.field public b:Lcom/google/android/gms/maps/model/TileOverlay;

.field public c:Lo2/f$a;

.field public d:Ljava/lang/String;

.field public e:F

.field public i:F

.field public j:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/f;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    invoke-virtual {p0}, Lo2/f;->getTileOverlayOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    move-result-object p1

    iput-object p1, p0, Lo2/f;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 6

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/TileOverlayOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Lo2/f;->i:F

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->zIndex(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 9
    .line 10
    .line 11
    new-instance v1, Lo2/f$a;

    .line 12
    .line 13
    iget v2, p0, Lo2/f;->e:F

    .line 14
    .line 15
    float-to-int v2, v2

    .line 16
    iget-object v3, p0, Lo2/f;->d:Ljava/lang/String;

    .line 17
    .line 18
    iget-boolean v4, p0, Lo2/f;->j:Z

    .line 19
    .line 20
    invoke-direct {v1, p0, v2, v3, v4}, Lo2/f$a;-><init>(Lo2/f;ILjava/lang/String;Z)V

    .line 21
    .line 22
    .line 23
    iput-object v1, p0, Lo2/f;->c:Lo2/f$a;

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tileProvider(Lcom/google/android/gms/maps/model/TileProvider;)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 26
    .line 27
    .line 28
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/f;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    return-object v0
.end method

.method public getTileOverlayOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/f;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/f;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/f;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/f;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setPathTemplate(Ljava/lang/String;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/f;->d:Ljava/lang/String;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/f;->c:Lo2/f$a;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lo2/f$a;->c(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/f;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setTileSize(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/f;->e:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/f;->c:Lo2/f$a;

    .line 4
    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    float-to-int p1, p1

    .line 8
    invoke-virtual {v0, p1}, Lo2/f$a;->d(I)V

    .line 9
    .line 10
    .line 11
    :cond_a
    return-void
.end method

.method public setUseAssets(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/f;->j:Z

    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/f;->i:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/f;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/TileOverlay;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

###### Class o2.f.a (o2.f$a)
.class public Lo2/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/model/TileProvider;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:Ljava/lang/String;

.field public c:Z

.field public final synthetic d:Lo2/f;


# direct methods
.method public constructor <init>(Lo2/f;ILjava/lang/String;Z)V
    .registers 5

    .line 1
    iput-object p1, p0, Lo2/f$a;->d:Lo2/f;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput p2, p0, Lo2/f$a;->a:I

    .line 7
    .line 8
    iput-object p3, p0, Lo2/f$a;->b:Ljava/lang/String;

    .line 9
    .line 10
    iput-boolean p4, p0, Lo2/f$a;->c:Z

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a(III)Ljava/lang/String;
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/f$a;->b:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    const-string v1, "{x}"

    .line 8
    .line 9
    invoke-virtual {v0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    const-string v0, "{y}"

    .line 18
    .line 19
    invoke-virtual {p1, v0, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    const-string p3, "{z}"

    .line 28
    .line 29
    invoke-virtual {p1, p3, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    return-object p1
.end method

.method public final b(III)[B
    .registers 10

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lo2/f$a;->a(III)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p2, 0x0

    .line 6
    :try_start_5
    iget-boolean p3, p0, Lo2/f$a;->c:Z

    .line 7
    .line 8
    if-eqz p3, :cond_18

    .line 9
    .line 10
    iget-object p3, p0, Lo2/f$a;->d:Lo2/f;

    .line 11
    .line 12
    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object p3

    .line 16
    invoke-virtual {p3}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 17
    .line 18
    .line 19
    move-result-object p3

    .line 20
    invoke-virtual {p3, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    goto :goto_1e

    .line 25
    :cond_18
    new-instance p3, Ljava/io/FileInputStream;

    .line 26
    .line 27
    invoke-direct {p3, p1}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_1d
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_1d} :catch_7b
    .catch Ljava/lang/OutOfMemoryError; {:try_start_5 .. :try_end_1d} :catch_68
    .catchall {:try_start_5 .. :try_end_1d} :catchall_65

    .line 28
    .line 29
    .line 30
    move-object p1, p3

    .line 31
    :goto_1e
    :try_start_1e
    new-instance p3, Ljava/io/ByteArrayOutputStream;

    .line 32
    .line 33
    invoke-direct {p3}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_23
    .catch Ljava/io/IOException; {:try_start_1e .. :try_end_23} :catch_5f
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1e .. :try_end_23} :catch_59
    .catchall {:try_start_1e .. :try_end_23} :catchall_53

    .line 34
    .line 35
    .line 36
    const/16 v0, 0x4000

    .line 37
    .line 38
    :try_start_25
    new-array v1, v0, [B

    .line 39
    .line 40
    :goto_27
    const/4 v2, 0x0

    .line 41
    invoke-virtual {p1, v1, v2, v0}, Ljava/io/InputStream;->read([BII)I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    const/4 v4, -0x1

    .line 46
    if-eq v3, v4, :cond_33

    .line 47
    .line 48
    invoke-virtual {p3, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 49
    .line 50
    .line 51
    goto :goto_27

    .line 52
    :cond_33
    invoke-virtual {p3}, Ljava/io/OutputStream;->flush()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 56
    .line 57
    .line 58
    move-result-object p2
    :try_end_3a
    .catch Ljava/io/IOException; {:try_start_25 .. :try_end_3a} :catch_4d
    .catch Ljava/lang/OutOfMemoryError; {:try_start_25 .. :try_end_3a} :catch_47
    .catchall {:try_start_25 .. :try_end_3a} :catchall_41

    .line 59
    :try_start_3a
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_3d
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_3d} :catch_3d

    .line 60
    .line 61
    .line 62
    :catch_3d
    :try_start_3d
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_40} :catch_40

    .line 63
    .line 64
    .line 65
    :catch_40
    return-object p2

    .line 66
    :catchall_41
    move-exception p2

    .line 67
    move-object v5, p2

    .line 68
    move-object p2, p1

    .line 69
    move-object p1, v5

    .line 70
    goto/16 :goto_91

    .line 71
    .line 72
    :catch_47
    move-exception v0

    .line 73
    move-object v5, p3

    .line 74
    move-object p3, p1

    .line 75
    move-object p1, v0

    .line 76
    move-object v0, v5

    .line 77
    goto :goto_6b

    .line 78
    :catch_4d
    move-exception v0

    .line 79
    move-object v5, p3

    .line 80
    move-object p3, p1

    .line 81
    move-object p1, v0

    .line 82
    move-object v0, v5

    .line 83
    goto :goto_7e

    .line 84
    :catchall_53
    move-exception p3

    .line 85
    move-object v5, p2

    .line 86
    move-object p2, p1

    .line 87
    move-object p1, p3

    .line 88
    move-object p3, v5

    .line 89
    goto :goto_91

    .line 90
    :catch_59
    move-exception p3

    .line 91
    move-object v0, p2

    .line 92
    move-object v5, p3

    .line 93
    move-object p3, p1

    .line 94
    move-object p1, v5

    .line 95
    goto :goto_6b

    .line 96
    :catch_5f
    move-exception p3

    .line 97
    move-object v0, p2

    .line 98
    move-object v5, p3

    .line 99
    move-object p3, p1

    .line 100
    move-object p1, v5

    .line 101
    goto :goto_7e

    .line 102
    :catchall_65
    move-exception p1

    .line 103
    move-object p3, p2

    .line 104
    goto :goto_91

    .line 105
    :catch_68
    move-exception p1

    .line 106
    move-object p3, p2

    .line 107
    move-object v0, p3

    .line 108
    :goto_6b
    :try_start_6b
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_6e
    .catchall {:try_start_6b .. :try_end_6e} :catchall_8e

    .line 109
    .line 110
    .line 111
    if-eqz p3, :cond_75

    .line 112
    .line 113
    :try_start_70
    invoke-virtual {p3}, Ljava/io/InputStream;->close()V
    :try_end_73
    .catch Ljava/lang/Exception; {:try_start_70 .. :try_end_73} :catch_74

    .line 114
    .line 115
    .line 116
    goto :goto_75

    .line 117
    :catch_74
    nop

    .line 118
    :cond_75
    :goto_75
    if-eqz v0, :cond_7a

    .line 119
    .line 120
    :try_start_77
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_77 .. :try_end_7a} :catch_7a

    .line 121
    .line 122
    .line 123
    :catch_7a
    :cond_7a
    return-object p2

    .line 124
    :catch_7b
    move-exception p1

    .line 125
    move-object p3, p2

    .line 126
    move-object v0, p3

    .line 127
    :goto_7e
    :try_start_7e
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_81
    .catchall {:try_start_7e .. :try_end_81} :catchall_8e

    .line 128
    .line 129
    .line 130
    if-eqz p3, :cond_88

    .line 131
    .line 132
    :try_start_83
    invoke-virtual {p3}, Ljava/io/InputStream;->close()V
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_83 .. :try_end_86} :catch_87

    .line 133
    .line 134
    .line 135
    goto :goto_88

    .line 136
    :catch_87
    nop

    .line 137
    :cond_88
    :goto_88
    if-eqz v0, :cond_8d

    .line 138
    .line 139
    :try_start_8a
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_8d
    .catch Ljava/lang/Exception; {:try_start_8a .. :try_end_8d} :catch_8d

    .line 140
    .line 141
    .line 142
    :catch_8d
    :cond_8d
    return-object p2

    .line 143
    :catchall_8e
    move-exception p1

    .line 144
    move-object p2, p3

    .line 145
    move-object p3, v0

    .line 146
    :goto_91
    if-eqz p2, :cond_98

    .line 147
    .line 148
    :try_start_93
    invoke-virtual {p2}, Ljava/io/InputStream;->close()V
    :try_end_96
    .catch Ljava/lang/Exception; {:try_start_93 .. :try_end_96} :catch_97

    .line 149
    .line 150
    .line 151
    goto :goto_98

    .line 152
    :catch_97
    nop

    .line 153
    :cond_98
    :goto_98
    if-eqz p3, :cond_9d

    .line 154
    .line 155
    :try_start_9a
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_9d
    .catch Ljava/lang/Exception; {:try_start_9a .. :try_end_9d} :catch_9d

    .line 156
    .line 157
    .line 158
    :catch_9d
    :cond_9d
    throw p1
.end method

.method public c(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lo2/f$a;->b:Ljava/lang/String;

    return-void
.end method

.method public d(I)V
    .registers 2

    iput p1, p0, Lo2/f$a;->a:I

    return-void
.end method

.method public getTile(III)Lcom/google/android/gms/maps/model/Tile;
    .registers 4

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lo2/f$a;->b(III)[B

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    if-nez p1, :cond_9

    .line 6
    .line 7
    sget-object p1, Lcom/google/android/gms/maps/model/TileProvider;->NO_TILE:Lcom/google/android/gms/maps/model/Tile;

    .line 8
    .line 9
    goto :goto_11

    .line 10
    :cond_9
    new-instance p2, Lcom/google/android/gms/maps/model/Tile;

    .line 11
    .line 12
    iget p3, p0, Lo2/f$a;->a:I

    .line 13
    .line 14
    invoke-direct {p2, p3, p3, p1}, Lcom/google/android/gms/maps/model/Tile;-><init>(II[B)V

    .line 15
    .line 16
    .line 17
    move-object p1, p2

    .line 18
    :goto_11
    return-object p1
.end method
