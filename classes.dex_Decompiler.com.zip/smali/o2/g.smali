###### Class o2.g (o2.g)
.class public Lo2/g;
.super Lo2/c;
.source "SourceFile"

# interfaces
.implements Lo2/p;


# instance fields
.field public a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

.field public b:Lcom/google/android/gms/maps/model/GroundOverlay;

.field public c:Lcom/google/android/gms/maps/model/LatLngBounds;

.field public d:F

.field public e:Lcom/google/android/gms/maps/model/BitmapDescriptor;

.field public i:Landroid/graphics/Bitmap;

.field public j:Z

.field public k:F

.field public l:F

.field public final m:Lo2/q;

.field public n:Lcom/google/android/gms/maps/GoogleMap;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lo2/q;

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, p1, v1, p0}, Lo2/q;-><init>(Landroid/content/Context;Landroid/content/res/Resources;Lo2/p;)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lo2/g;->m:Lo2/q;

    .line 14
    .line 15
    return-void
.end method

.method private getGroundOverlay()Lcom/google/android/gms/maps/model/GroundOverlay;
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    iget-object v0, p0, Lo2/g;->n:Lcom/google/android/gms/maps/GoogleMap;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    return-object v1

    .line 12
    :cond_b
    invoke-virtual {p0}, Lo2/g;->getGroundOverlayOptions()Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    if-eqz v0, :cond_18

    .line 17
    .line 18
    iget-object v1, p0, Lo2/g;->n:Lcom/google/android/gms/maps/GoogleMap;

    .line 19
    .line 20
    invoke-virtual {v1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addGroundOverlay(Lcom/google/android/gms/maps/model/GroundOverlayOptions;)Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0

    .line 25
    :cond_18
    return-object v1
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, Lo2/g;->n:Lcom/google/android/gms/maps/GoogleMap;

    .line 3
    .line 4
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 5
    .line 6
    if-eqz v0, :cond_e

    .line 7
    .line 8
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/GroundOverlay;->remove()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 12
    .line 13
    iput-object p1, p0, Lo2/g;->a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/g;->getGroundOverlayOptions()Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_12

    .line 6
    .line 7
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addGroundOverlay(Lcom/google/android/gms/maps/model/GroundOverlayOptions;)Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    iput-object p1, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 12
    .line 13
    iget-boolean v0, p0, Lo2/g;->j:Z

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/GroundOverlay;->setClickable(Z)V

    .line 16
    .line 17
    .line 18
    goto :goto_14

    .line 19
    :cond_12
    iput-object p1, p0, Lo2/g;->n:Lcom/google/android/gms/maps/GoogleMap;

    .line 20
    .line 21
    :goto_14
    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/GroundOverlayOptions;
    .registers 3

    .line 1
    iget-object v0, p0, Lo2/g;->a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    new-instance v0, Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 7
    .line 8
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;-><init>()V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Lo2/g;->e:Lcom/google/android/gms/maps/model/BitmapDescriptor;

    .line 12
    .line 13
    if-eqz v1, :cond_12

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->image(Lcom/google/android/gms/maps/model/BitmapDescriptor;)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 16
    .line 17
    .line 18
    goto :goto_1d

    .line 19
    :cond_12
    invoke-static {}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->defaultMarker()Lcom/google/android/gms/maps/model/BitmapDescriptor;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->image(Lcom/google/android/gms/maps/model/BitmapDescriptor;)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x0

    .line 27
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->visible(Z)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 28
    .line 29
    .line 30
    :goto_1d
    iget-object v1, p0, Lo2/g;->c:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->positionFromBounds(Lcom/google/android/gms/maps/model/LatLngBounds;)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 33
    .line 34
    .line 35
    iget v1, p0, Lo2/g;->k:F

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->zIndex(F)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 38
    .line 39
    .line 40
    iget v1, p0, Lo2/g;->d:F

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->bearing(F)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 43
    .line 44
    .line 45
    iget v1, p0, Lo2/g;->l:F

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlayOptions;->transparency(F)Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 48
    .line 49
    .line 50
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    return-object v0
.end method

.method public getGroundOverlayOptions()Lcom/google/android/gms/maps/model/GroundOverlayOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/g;->a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/g;->c()Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/g;->a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/g;->a:Lcom/google/android/gms/maps/model/GroundOverlayOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setBearing(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/g;->d:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setBearing(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setBounds(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 10

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    invoke-interface {v2, v1}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 9
    .line 10
    .line 11
    move-result-wide v2

    .line 12
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    const/4 v5, 0x1

    .line 17
    invoke-interface {v4, v5}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 18
    .line 19
    .line 20
    move-result-wide v6

    .line 21
    invoke-direct {v0, v2, v3, v6, v7}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 22
    .line 23
    .line 24
    new-instance v2, Lcom/google/android/gms/maps/model/LatLng;

    .line 25
    .line 26
    invoke-interface {p1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    invoke-interface {v3, v1}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 31
    .line 32
    .line 33
    move-result-wide v3

    .line 34
    invoke-interface {p1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-interface {p1, v5}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 39
    .line 40
    .line 41
    move-result-wide v5

    .line 42
    invoke-direct {v2, v3, v4, v5, v6}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 43
    .line 44
    .line 45
    new-instance p1, Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 46
    .line 47
    invoke-direct {p1, v0, v2}, Lcom/google/android/gms/maps/model/LatLngBounds;-><init>(Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;)V

    .line 48
    .line 49
    .line 50
    iput-object p1, p0, Lo2/g;->c:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 51
    .line 52
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 53
    .line 54
    if-eqz v0, :cond_3a

    .line 55
    .line 56
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setPositionFromBounds(Lcom/google/android/gms/maps/model/LatLngBounds;)V

    .line 57
    .line 58
    .line 59
    :cond_3a
    return-void
.end method

.method public setIconBitmap(Landroid/graphics/Bitmap;)V
    .registers 2

    iput-object p1, p0, Lo2/g;->i:Landroid/graphics/Bitmap;

    return-void
.end method

.method public setIconBitmapDescriptor(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V
    .registers 2

    iput-object p1, p0, Lo2/g;->e:Lcom/google/android/gms/maps/model/BitmapDescriptor;

    return-void
.end method

.method public setImage(Ljava/lang/String;)V
    .registers 3

    iget-object v0, p0, Lo2/g;->m:Lo2/q;

    invoke-virtual {v0, p1}, Lo2/q;->f(Ljava/lang/String;)V

    return-void
.end method

.method public setTappable(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/g;->j:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setClickable(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setTransparency(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/g;->l:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setTransparency(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/g;->k:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public update()V
    .registers 3

    .line 1
    invoke-direct {p0}, Lo2/g;->getGroundOverlay()Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iput-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 6
    .line 7
    if-eqz v0, :cond_21

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setVisible(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 14
    .line 15
    iget-object v1, p0, Lo2/g;->e:Lcom/google/android/gms/maps/model/BitmapDescriptor;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setImage(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V

    .line 18
    .line 19
    .line 20
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 21
    .line 22
    iget v1, p0, Lo2/g;->l:F

    .line 23
    .line 24
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setTransparency(F)V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Lo2/g;->b:Lcom/google/android/gms/maps/model/GroundOverlay;

    .line 28
    .line 29
    iget-boolean v1, p0, Lo2/g;->j:Z

    .line 30
    .line 31
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/GroundOverlay;->setClickable(Z)V

    .line 32
    .line 33
    .line 34
    :cond_21
    return-void
.end method
