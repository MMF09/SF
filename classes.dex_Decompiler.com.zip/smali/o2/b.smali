###### Class o2.b (o2.b)
.class public Lo2/b;
.super Lo2/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/google/android/gms/maps/model/CircleOptions;

.field public b:Lcom/google/android/gms/maps/model/Circle;

.field public c:Lcom/google/android/gms/maps/model/LatLng;

.field public d:D

.field public e:I

.field public i:I

.field public j:F

.field public k:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Circle;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    invoke-virtual {p0}, Lo2/b;->getCircleOptions()Lcom/google/android/gms/maps/model/CircleOptions;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addCircle(Lcom/google/android/gms/maps/model/CircleOptions;)Lcom/google/android/gms/maps/model/Circle;

    move-result-object p1

    iput-object p1, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/CircleOptions;
    .registers 4

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/CircleOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/CircleOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lo2/b;->c:Lcom/google/android/gms/maps/model/LatLng;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CircleOptions;->center(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 9
    .line 10
    .line 11
    iget-wide v1, p0, Lo2/b;->d:D

    .line 12
    .line 13
    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/maps/model/CircleOptions;->radius(D)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 14
    .line 15
    .line 16
    iget v1, p0, Lo2/b;->i:I

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CircleOptions;->fillColor(I)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 19
    .line 20
    .line 21
    iget v1, p0, Lo2/b;->e:I

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CircleOptions;->strokeColor(I)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 24
    .line 25
    .line 26
    iget v1, p0, Lo2/b;->j:F

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CircleOptions;->strokeWidth(F)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 29
    .line 30
    .line 31
    iget v1, p0, Lo2/b;->k:F

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/CircleOptions;->zIndex(F)Lcom/google/android/gms/maps/model/CircleOptions;

    .line 34
    .line 35
    .line 36
    return-object v0
.end method

.method public getCircleOptions()Lcom/google/android/gms/maps/model/CircleOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/b;->a:Lcom/google/android/gms/maps/model/CircleOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/b;->c()Lcom/google/android/gms/maps/model/CircleOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/b;->a:Lcom/google/android/gms/maps/model/CircleOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/b;->a:Lcom/google/android/gms/maps/model/CircleOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    return-object v0
.end method

.method public setCenter(Lcom/google/android/gms/maps/model/LatLng;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/b;->c:Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Circle;->setCenter(Lcom/google/android/gms/maps/model/LatLng;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setFillColor(I)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/b;->i:I

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Circle;->setFillColor(I)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setRadius(D)V
    .registers 4

    .line 1
    iput-wide p1, p0, Lo2/b;->d:D

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/maps/model/Circle;->setRadius(D)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setStrokeColor(I)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/b;->e:I

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Circle;->setStrokeColor(I)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setStrokeWidth(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/b;->j:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Circle;->setStrokeWidth(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/b;->k:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/b;->b:Lcom/google/android/gms/maps/model/Circle;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Circle;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method
