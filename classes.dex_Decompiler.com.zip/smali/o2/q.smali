###### Class o2.q (o2.q)
.class public Lo2/q;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lo2/p;

.field public final b:Landroid/content/Context;

.field public final c:Landroid/content/res/Resources;

.field public final d:Lcom/facebook/drawee/view/DraweeHolder;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/drawee/view/DraweeHolder<",
            "*>;"
        }
    .end annotation
.end field

.field public e:Lcom/facebook/datasource/DataSource;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/datasource/DataSource<",
            "Lcom/facebook/common/references/CloseableReference<",
            "Lcom/facebook/imagepipeline/image/CloseableImage;",
            ">;>;"
        }
    .end annotation
.end field

.field public final f:Lcom/facebook/drawee/controller/ControllerListener;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/facebook/drawee/controller/ControllerListener<",
            "Lcom/facebook/imagepipeline/image/ImageInfo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/content/res/Resources;Lo2/p;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lo2/q$a;

    .line 5
    .line 6
    invoke-direct {v0, p0}, Lo2/q$a;-><init>(Lo2/q;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lo2/q;->f:Lcom/facebook/drawee/controller/ControllerListener;

    .line 10
    .line 11
    iput-object p1, p0, Lo2/q;->b:Landroid/content/Context;

    .line 12
    .line 13
    iput-object p2, p0, Lo2/q;->c:Landroid/content/res/Resources;

    .line 14
    .line 15
    iput-object p3, p0, Lo2/q;->a:Lo2/p;

    .line 16
    .line 17
    invoke-virtual {p0, p2}, Lo2/q;->c(Landroid/content/res/Resources;)Lcom/facebook/drawee/generic/GenericDraweeHierarchy;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    invoke-static {p2, p1}, Lcom/facebook/drawee/view/DraweeHolder;->create(Lcom/facebook/drawee/interfaces/DraweeHierarchy;Landroid/content/Context;)Lcom/facebook/drawee/view/DraweeHolder;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, p0, Lo2/q;->d:Lcom/facebook/drawee/view/DraweeHolder;

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/facebook/drawee/view/DraweeHolder;->onAttach()V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public static synthetic a(Lo2/q;)Lcom/facebook/datasource/DataSource;
    .registers 1

    iget-object p0, p0, Lo2/q;->e:Lcom/facebook/datasource/DataSource;

    return-object p0
.end method

.method public static synthetic b(Lo2/q;)Lo2/p;
    .registers 1

    iget-object p0, p0, Lo2/q;->a:Lo2/p;

    return-object p0
.end method


# virtual methods
.method public final c(Landroid/content/res/Resources;)Lcom/facebook/drawee/generic/GenericDraweeHierarchy;
    .registers 3

    .line 1
    new-instance v0, Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;-><init>(Landroid/content/res/Resources;)V

    .line 4
    .line 5
    .line 6
    sget-object p1, Lcom/facebook/drawee/drawable/ScalingUtils$ScaleType;->FIT_CENTER:Lcom/facebook/drawee/drawable/ScalingUtils$ScaleType;

    .line 7
    .line 8
    invoke-virtual {v0, p1}, Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;->setActualImageScaleType(Lcom/facebook/drawee/drawable/ScalingUtils$ScaleType;)Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0}, Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;->setFadeDuration(I)Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p1}, Lcom/facebook/drawee/generic/GenericDraweeHierarchyBuilder;->build()Lcom/facebook/drawee/generic/GenericDraweeHierarchy;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    return-object p1
.end method

.method public final d(Ljava/lang/String;)Lcom/google/android/gms/maps/model/BitmapDescriptor;
    .registers 2

    invoke-virtual {p0, p1}, Lo2/q;->e(Ljava/lang/String;)I

    move-result p1

    invoke-static {p1}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->fromResource(I)Lcom/google/android/gms/maps/model/BitmapDescriptor;

    move-result-object p1

    return-object p1
.end method

.method public final e(Ljava/lang/String;)I
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/q;->c:Landroid/content/res/Resources;

    .line 2
    .line 3
    iget-object v1, p0, Lo2/q;->b:Landroid/content/Context;

    .line 4
    .line 5
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const-string v2, "drawable"

    .line 10
    .line 11
    invoke-virtual {v0, p1, v2, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    return p1
.end method

.method public f(Ljava/lang/String;)V
    .registers 4

    .line 1
    if-nez p1, :cond_f

    .line 2
    .line 3
    iget-object p1, p0, Lo2/q;->a:Lo2/p;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-interface {p1, v0}, Lo2/p;->setIconBitmapDescriptor(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Lo2/q;->a:Lo2/p;

    .line 10
    .line 11
    invoke-interface {p1}, Lo2/p;->update()V

    .line 12
    .line 13
    .line 14
    goto/16 :goto_95

    .line 15
    .line 16
    :cond_f
    const-string v0, "http://"

    .line 17
    .line 18
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_58

    .line 23
    .line 24
    const-string v0, "https://"

    .line 25
    .line 26
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_58

    .line 31
    .line 32
    const-string v0, "file://"

    .line 33
    .line 34
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_58

    .line 39
    .line 40
    const-string v0, "asset://"

    .line 41
    .line 42
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-nez v0, :cond_58

    .line 47
    .line 48
    const-string v0, "data:"

    .line 49
    .line 50
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-eqz v0, :cond_38

    .line 55
    .line 56
    goto :goto_58

    .line 57
    :cond_38
    invoke-virtual {p0, p1}, Lo2/q;->d(Ljava/lang/String;)Lcom/google/android/gms/maps/model/BitmapDescriptor;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    if-eqz v0, :cond_52

    .line 62
    .line 63
    iget-object v1, p0, Lo2/q;->a:Lo2/p;

    .line 64
    .line 65
    invoke-interface {v1, v0}, Lo2/p;->setIconBitmapDescriptor(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, Lo2/q;->a:Lo2/p;

    .line 69
    .line 70
    iget-object v1, p0, Lo2/q;->c:Landroid/content/res/Resources;

    .line 71
    .line 72
    invoke-virtual {p0, p1}, Lo2/q;->e(Ljava/lang/String;)I

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    invoke-static {v1, p1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    invoke-interface {v0, p1}, Lo2/p;->setIconBitmap(Landroid/graphics/Bitmap;)V

    .line 81
    .line 82
    .line 83
    :cond_52
    iget-object p1, p0, Lo2/q;->a:Lo2/p;

    .line 84
    .line 85
    invoke-interface {p1}, Lo2/p;->update()V

    .line 86
    .line 87
    .line 88
    goto :goto_95

    .line 89
    :cond_58
    :goto_58
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-static {p1}, Lcom/facebook/imagepipeline/request/ImageRequestBuilder;->newBuilderWithSource(Landroid/net/Uri;)Lcom/facebook/imagepipeline/request/ImageRequestBuilder;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/request/ImageRequestBuilder;->build()Lcom/facebook/imagepipeline/request/ImageRequest;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-static {}, Lcom/facebook/drawee/backends/pipeline/Fresco;->getImagePipeline()Lcom/facebook/imagepipeline/core/ImagePipeline;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-virtual {v0, p1, p0}, Lcom/facebook/imagepipeline/core/ImagePipeline;->fetchDecodedImage(Lcom/facebook/imagepipeline/request/ImageRequest;Ljava/lang/Object;)Lcom/facebook/datasource/DataSource;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    iput-object v0, p0, Lo2/q;->e:Lcom/facebook/datasource/DataSource;

    .line 110
    .line 111
    invoke-static {}, Lcom/facebook/drawee/backends/pipeline/Fresco;->newDraweeControllerBuilder()Lcom/facebook/drawee/backends/pipeline/PipelineDraweeControllerBuilder;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    invoke-virtual {v0, p1}, Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;->setImageRequest(Ljava/lang/Object;)Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    check-cast p1, Lcom/facebook/drawee/backends/pipeline/PipelineDraweeControllerBuilder;

    .line 120
    .line 121
    iget-object v0, p0, Lo2/q;->f:Lcom/facebook/drawee/controller/ControllerListener;

    .line 122
    .line 123
    invoke-virtual {p1, v0}, Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;->setControllerListener(Lcom/facebook/drawee/controller/ControllerListener;)Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    check-cast p1, Lcom/facebook/drawee/backends/pipeline/PipelineDraweeControllerBuilder;

    .line 128
    .line 129
    iget-object v0, p0, Lo2/q;->d:Lcom/facebook/drawee/view/DraweeHolder;

    .line 130
    .line 131
    invoke-virtual {v0}, Lcom/facebook/drawee/view/DraweeHolder;->getController()Lcom/facebook/drawee/interfaces/DraweeController;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    invoke-virtual {p1, v0}, Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;->setOldController(Lcom/facebook/drawee/interfaces/DraweeController;)Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    check-cast p1, Lcom/facebook/drawee/backends/pipeline/PipelineDraweeControllerBuilder;

    .line 140
    .line 141
    invoke-virtual {p1}, Lcom/facebook/drawee/controller/AbstractDraweeControllerBuilder;->build()Lcom/facebook/drawee/controller/AbstractDraweeController;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    iget-object v0, p0, Lo2/q;->d:Lcom/facebook/drawee/view/DraweeHolder;

    .line 146
    .line 147
    invoke-virtual {v0, p1}, Lcom/facebook/drawee/view/DraweeHolder;->setController(Lcom/facebook/drawee/interfaces/DraweeController;)V

    .line 148
    .line 149
    .line 150
    :goto_95
    return-void
.end method

###### Class o2.q.a (o2.q$a)
.class public Lo2/q$a;
.super Lcom/facebook/drawee/controller/BaseControllerListener;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/drawee/controller/BaseControllerListener<",
        "Lcom/facebook/imagepipeline/image/ImageInfo;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lo2/q;


# direct methods
.method public constructor <init>(Lo2/q;)V
    .registers 2

    iput-object p1, p0, Lo2/q$a;->a:Lo2/q;

    invoke-direct {p0}, Lcom/facebook/drawee/controller/BaseControllerListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onFinalImageSet(Ljava/lang/String;Lcom/facebook/imagepipeline/image/ImageInfo;Landroid/graphics/drawable/Animatable;)V
    .registers 6
    .param p2    # Lcom/facebook/imagepipeline/image/ImageInfo;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Animatable;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    const/4 p1, 0x0

    .line 2
    :try_start_1
    iget-object p2, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p2}, Lo2/q;->a(Lo2/q;)Lcom/facebook/datasource/DataSource;

    move-result-object p2

    invoke-interface {p2}, Lcom/facebook/datasource/DataSource;->getResult()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/facebook/common/references/CloseableReference;
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_5b

    if-eqz p2, :cond_43

    .line 3
    :try_start_f
    invoke-virtual {p2}, Lcom/facebook/common/references/CloseableReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/facebook/imagepipeline/image/CloseableImage;

    if-eqz p1, :cond_43

    .line 4
    instance-of p3, p1, Lcom/facebook/imagepipeline/image/CloseableStaticBitmap;

    if-eqz p3, :cond_43

    .line 5
    check-cast p1, Lcom/facebook/imagepipeline/image/CloseableStaticBitmap;

    .line 6
    invoke-virtual {p1}, Lcom/facebook/imagepipeline/image/CloseableStaticBitmap;->getUnderlyingBitmap()Landroid/graphics/Bitmap;

    move-result-object p1

    if-eqz p1, :cond_43

    .line 7
    sget-object p3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v0, 0x1

    invoke-virtual {p1, p3, v0}, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config;Z)Landroid/graphics/Bitmap;

    move-result-object p1

    .line 8
    iget-object p3, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p3}, Lo2/q;->b(Lo2/q;)Lo2/p;

    move-result-object p3

    invoke-interface {p3, p1}, Lo2/p;->setIconBitmap(Landroid/graphics/Bitmap;)V

    .line 9
    iget-object p3, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p3}, Lo2/q;->b(Lo2/q;)Lo2/p;

    move-result-object p3

    invoke-static {p1}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->fromBitmap(Landroid/graphics/Bitmap;)Lcom/google/android/gms/maps/model/BitmapDescriptor;

    move-result-object p1

    invoke-interface {p3, p1}, Lo2/p;->setIconBitmapDescriptor(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V
    :try_end_40
    .catchall {:try_start_f .. :try_end_40} :catchall_41

    goto :goto_43

    :catchall_41
    move-exception p1

    goto :goto_5f

    .line 10
    :cond_43
    :goto_43
    iget-object p1, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p1}, Lo2/q;->a(Lo2/q;)Lcom/facebook/datasource/DataSource;

    move-result-object p1

    invoke-interface {p1}, Lcom/facebook/datasource/DataSource;->close()Z

    if-eqz p2, :cond_51

    .line 11
    invoke-static {p2}, Lcom/facebook/common/references/CloseableReference;->closeSafely(Lcom/facebook/common/references/CloseableReference;)V

    .line 12
    :cond_51
    iget-object p1, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p1}, Lo2/q;->b(Lo2/q;)Lo2/p;

    move-result-object p1

    invoke-interface {p1}, Lo2/p;->update()V

    return-void

    :catchall_5b
    move-exception p2

    move-object v1, p2

    move-object p2, p1

    move-object p1, v1

    .line 13
    :goto_5f
    iget-object p3, p0, Lo2/q$a;->a:Lo2/q;

    invoke-static {p3}, Lo2/q;->a(Lo2/q;)Lcom/facebook/datasource/DataSource;

    move-result-object p3

    invoke-interface {p3}, Lcom/facebook/datasource/DataSource;->close()Z

    if-eqz p2, :cond_6d

    .line 14
    invoke-static {p2}, Lcom/facebook/common/references/CloseableReference;->closeSafely(Lcom/facebook/common/references/CloseableReference;)V

    .line 15
    :cond_6d
    throw p1
.end method

.method public bridge synthetic onFinalImageSet(Ljava/lang/String;Ljava/lang/Object;Landroid/graphics/drawable/Animatable;)V
    .registers 4
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/drawable/Animatable;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    check-cast p2, Lcom/facebook/imagepipeline/image/ImageInfo;

    invoke-virtual {p0, p1, p2, p3}, Lo2/q$a;->onFinalImageSet(Ljava/lang/String;Lcom/facebook/imagepipeline/image/ImageInfo;Landroid/graphics/drawable/Animatable;)V

    return-void
.end method
