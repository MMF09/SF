###### Class o2.j (o2.j)
.class public Lo2/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/model/TileProvider;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/j$a;
    }
.end annotation


# instance fields
.field public a:Lcom/google/android/gms/maps/model/UrlTileProvider;

.field public b:Ljava/lang/String;

.field public c:I

.field public d:Z

.field public e:I

.field public f:I

.field public g:I

.field public h:Z

.field public i:Ljava/lang/String;

.field public j:I

.field public k:Z

.field public l:Landroid/content/Context;

.field public m:Z


# direct methods
.method public constructor <init>(IZLjava/lang/String;IIIZLjava/lang/String;IZLandroid/content/Context;Z)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lo2/j$a;

    .line 5
    .line 6
    invoke-direct {v0, p0, p1, p1, p3}, Lo2/j$a;-><init>(Lo2/j;IILjava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lo2/j;->a:Lcom/google/android/gms/maps/model/UrlTileProvider;

    .line 10
    .line 11
    iput p1, p0, Lo2/j;->c:I

    .line 12
    .line 13
    iput-boolean p2, p0, Lo2/j;->d:Z

    .line 14
    .line 15
    iput-object p3, p0, Lo2/j;->b:Ljava/lang/String;

    .line 16
    .line 17
    iput p4, p0, Lo2/j;->e:I

    .line 18
    .line 19
    iput p5, p0, Lo2/j;->f:I

    .line 20
    .line 21
    iput p6, p0, Lo2/j;->g:I

    .line 22
    .line 23
    iput-boolean p7, p0, Lo2/j;->h:Z

    .line 24
    .line 25
    iput-object p8, p0, Lo2/j;->i:Ljava/lang/String;

    .line 26
    .line 27
    iput p9, p0, Lo2/j;->j:I

    .line 28
    .line 29
    iput-boolean p10, p0, Lo2/j;->k:Z

    .line 30
    .line 31
    iput-object p11, p0, Lo2/j;->l:Landroid/content/Context;

    .line 32
    .line 33
    iput-boolean p12, p0, Lo2/j;->m:Z

    .line 34
    .line 35
    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Bitmap;)[B
    .registers 5

    .line 1
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 7
    .line 8
    const/16 v2, 0x64

    .line 9
    .line 10
    invoke-virtual {p1, v1, v2, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :try_start_10
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_13} :catch_14

    .line 18
    .line 19
    .line 20
    goto :goto_18

    .line 21
    :catch_14
    move-exception v0

    .line 22
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 23
    .line 24
    .line 25
    :goto_18
    return-object p1
.end method

.method public b(III)V
    .registers 10

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->e(III)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Ljava/io/File;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/io/File;->lastModified()J

    .line 11
    .line 12
    .line 13
    move-result-wide v1

    .line 14
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 15
    .line 16
    .line 17
    move-result-wide v3

    .line 18
    sub-long/2addr v3, v1

    .line 19
    const-wide/16 v1, 0x3e8

    .line 20
    .line 21
    div-long/2addr v3, v1

    .line 22
    iget v1, p0, Lo2/j;->j:I

    .line 23
    .line 24
    int-to-long v1, v1

    .line 25
    cmp-long v5, v3, v1

    .line 26
    .line 27
    if-lez v5, :cond_87

    .line 28
    .line 29
    const-string v1, "urlTile"

    .line 30
    .line 31
    const-string v2, "Refreshing"

    .line 32
    .line 33
    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    new-instance v1, Landroidx/work/Constraints$Builder;

    .line 37
    .line 38
    invoke-direct {v1}, Landroidx/work/Constraints$Builder;-><init>()V

    .line 39
    .line 40
    .line 41
    sget-object v2, Landroidx/work/NetworkType;->CONNECTED:Landroidx/work/NetworkType;

    .line 42
    .line 43
    invoke-virtual {v1, v2}, Landroidx/work/Constraints$Builder;->setRequiredNetworkType(Landroidx/work/NetworkType;)Landroidx/work/Constraints$Builder;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    invoke-virtual {v1}, Landroidx/work/Constraints$Builder;->build()Landroidx/work/Constraints;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    new-instance v2, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 52
    .line 53
    const-class v3, Lcom/airbnb/android/react/maps/AirMapTileWorker;

    .line 54
    .line 55
    invoke-direct {v2, v3}, Landroidx/work/OneTimeWorkRequest$Builder;-><init>(Ljava/lang/Class;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v1}, Landroidx/work/WorkRequest$Builder;->setConstraints(Landroidx/work/Constraints;)Landroidx/work/WorkRequest$Builder;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    check-cast v1, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 63
    .line 64
    invoke-virtual {v1, v0}, Landroidx/work/WorkRequest$Builder;->addTag(Ljava/lang/String;)Landroidx/work/WorkRequest$Builder;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    check-cast v1, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 69
    .line 70
    new-instance v2, Landroidx/work/Data$Builder;

    .line 71
    .line 72
    invoke-direct {v2}, Landroidx/work/Data$Builder;-><init>()V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->g(III)Ljava/net/URL;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-virtual {p1}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    const-string p2, "url"

    .line 84
    .line 85
    invoke-virtual {v2, p2, p1}, Landroidx/work/Data$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroidx/work/Data$Builder;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    const-string p2, "filename"

    .line 90
    .line 91
    invoke-virtual {p1, p2, v0}, Landroidx/work/Data$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroidx/work/Data$Builder;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    iget p2, p0, Lo2/j;->j:I

    .line 96
    .line 97
    const-string p3, "maxAge"

    .line 98
    .line 99
    invoke-virtual {p1, p3, p2}, Landroidx/work/Data$Builder;->putInt(Ljava/lang/String;I)Landroidx/work/Data$Builder;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-virtual {p1}, Landroidx/work/Data$Builder;->build()Landroidx/work/Data;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    invoke-virtual {v1, p1}, Landroidx/work/WorkRequest$Builder;->setInputData(Landroidx/work/Data;)Landroidx/work/WorkRequest$Builder;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    check-cast p1, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 112
    .line 113
    invoke-virtual {p1}, Landroidx/work/WorkRequest$Builder;->build()Landroidx/work/WorkRequest;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    check-cast p1, Landroidx/work/OneTimeWorkRequest;

    .line 118
    .line 119
    if-eqz p1, :cond_87

    .line 120
    .line 121
    iget-object p2, p0, Lo2/j;->l:Landroid/content/Context;

    .line 122
    .line 123
    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 124
    .line 125
    .line 126
    move-result-object p2

    .line 127
    invoke-static {p2}, Landroidx/work/WorkManager;->getInstance(Landroid/content/Context;)Landroidx/work/WorkManager;

    .line 128
    .line 129
    .line 130
    move-result-object p2

    .line 131
    sget-object p3, Landroidx/work/ExistingWorkPolicy;->KEEP:Landroidx/work/ExistingWorkPolicy;

    .line 132
    .line 133
    invoke-virtual {p2, v0, p3, p1}, Landroidx/work/WorkManager;->enqueueUniqueWork(Ljava/lang/String;Landroidx/work/ExistingWorkPolicy;Landroidx/work/OneTimeWorkRequest;)Landroidx/work/Operation;

    .line 134
    .line 135
    .line 136
    :cond_87
    return-void
.end method

.method public c(III)[B
    .registers 10

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->g(III)Ljava/net/URL;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p2, 0x0

    .line 6
    :try_start_5
    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-virtual {p1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 11
    .line 12
    .line 13
    move-result-object p1
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_d} :catch_57
    .catch Ljava/lang/OutOfMemoryError; {:try_start_5 .. :try_end_d} :catch_44
    .catchall {:try_start_5 .. :try_end_d} :catchall_3f

    .line 14
    :try_start_d
    new-instance p3, Ljava/io/ByteArrayOutputStream;

    .line 15
    .line 16
    invoke-direct {p3}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_12
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_12} :catch_3c
    .catch Ljava/lang/OutOfMemoryError; {:try_start_d .. :try_end_12} :catch_39
    .catchall {:try_start_d .. :try_end_12} :catchall_34

    .line 17
    .line 18
    .line 19
    const/16 v0, 0x4000

    .line 20
    .line 21
    :try_start_14
    new-array v1, v0, [B

    .line 22
    .line 23
    :goto_16
    const/4 v2, 0x0

    .line 24
    invoke-virtual {p1, v1, v2, v0}, Ljava/io/InputStream;->read([BII)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    const/4 v4, -0x1

    .line 29
    if-eq v3, v4, :cond_22

    .line 30
    .line 31
    invoke-virtual {p3, v1, v2, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 32
    .line 33
    .line 34
    goto :goto_16

    .line 35
    :cond_22
    invoke-virtual {p3}, Ljava/io/OutputStream;->flush()V

    .line 36
    .line 37
    .line 38
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 39
    .line 40
    .line 41
    move-result-object p2
    :try_end_29
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_29} :catch_32
    .catch Ljava/lang/OutOfMemoryError; {:try_start_14 .. :try_end_29} :catch_30
    .catchall {:try_start_14 .. :try_end_29} :catchall_6a

    .line 42
    :try_start_29
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_2c} :catch_2c

    .line 43
    .line 44
    .line 45
    :catch_2c
    :try_start_2c
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_2f} :catch_2f

    .line 46
    .line 47
    .line 48
    :catch_2f
    return-object p2

    .line 49
    :catch_30
    move-exception v0

    .line 50
    goto :goto_47

    .line 51
    :catch_32
    move-exception v0

    .line 52
    goto :goto_5a

    .line 53
    :catchall_34
    move-exception p3

    .line 54
    move-object v5, p3

    .line 55
    move-object p3, p2

    .line 56
    move-object p2, v5

    .line 57
    goto :goto_6b

    .line 58
    :catch_39
    move-exception v0

    .line 59
    move-object p3, p2

    .line 60
    goto :goto_47

    .line 61
    :catch_3c
    move-exception v0

    .line 62
    move-object p3, p2

    .line 63
    goto :goto_5a

    .line 64
    :catchall_3f
    move-exception p1

    .line 65
    move-object p3, p2

    .line 66
    move-object p2, p1

    .line 67
    move-object p1, p3

    .line 68
    goto :goto_6b

    .line 69
    :catch_44
    move-exception v0

    .line 70
    move-object p1, p2

    .line 71
    move-object p3, p1

    .line 72
    :goto_47
    :try_start_47
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_4a
    .catchall {:try_start_47 .. :try_end_4a} :catchall_6a

    .line 73
    .line 74
    .line 75
    if-eqz p1, :cond_51

    .line 76
    .line 77
    :try_start_4c
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_4c .. :try_end_4f} :catch_50

    .line 78
    .line 79
    .line 80
    goto :goto_51

    .line 81
    :catch_50
    nop

    .line 82
    :cond_51
    :goto_51
    if-eqz p3, :cond_56

    .line 83
    .line 84
    :try_start_53
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_56
    .catch Ljava/lang/Exception; {:try_start_53 .. :try_end_56} :catch_56

    .line 85
    .line 86
    .line 87
    :catch_56
    :cond_56
    return-object p2

    .line 88
    :catch_57
    move-exception v0

    .line 89
    move-object p1, p2

    .line 90
    move-object p3, p1

    .line 91
    :goto_5a
    :try_start_5a
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_5d
    .catchall {:try_start_5a .. :try_end_5d} :catchall_6a

    .line 92
    .line 93
    .line 94
    if-eqz p1, :cond_64

    .line 95
    .line 96
    :try_start_5f
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_5f .. :try_end_62} :catch_63

    .line 97
    .line 98
    .line 99
    goto :goto_64

    .line 100
    :catch_63
    nop

    .line 101
    :cond_64
    :goto_64
    if-eqz p3, :cond_69

    .line 102
    .line 103
    :try_start_66
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_69
    .catch Ljava/lang/Exception; {:try_start_66 .. :try_end_69} :catch_69

    .line 104
    .line 105
    .line 106
    :catch_69
    :cond_69
    return-object p2

    .line 107
    :catchall_6a
    move-exception p2

    .line 108
    :goto_6b
    if-eqz p1, :cond_72

    .line 109
    .line 110
    :try_start_6d
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_70
    .catch Ljava/lang/Exception; {:try_start_6d .. :try_end_70} :catch_71

    .line 111
    .line 112
    .line 113
    goto :goto_72

    .line 114
    :catch_71
    nop

    .line 115
    :cond_72
    :goto_72
    if-eqz p3, :cond_77

    .line 116
    .line 117
    :try_start_74
    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_77
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_77} :catch_77

    .line 118
    .line 119
    .line 120
    :catch_77
    :cond_77
    throw p2
.end method

.method public d()Landroid/graphics/Bitmap;
    .registers 3

    .line 1
    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 2
    .line 3
    const/16 v1, 0x200

    .line 4
    .line 5
    invoke-static {v1, v1, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {v0, v1}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public e(III)Ljava/lang/String;
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/j;->i:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return-object p1

    .line 7
    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 10
    .line 11
    .line 12
    iget-object v1, p0, Lo2/j;->i:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const/16 v1, 0x2f

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p3

    .line 26
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string p3, "/"

    .line 30
    .line 31
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    return-object p1
.end method

.method public f(III)[B
    .registers 15

    .line 1
    iget-object v0, p0, Lo2/j;->i:Ljava/lang/String;

    .line 2
    .line 3
    const-string v1, "urlTile"

    .line 4
    .line 5
    const-string v2, "/"

    .line 6
    .line 7
    if-eqz v0, :cond_71

    .line 8
    .line 9
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->i(III)[B

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_3b

    .line 14
    .line 15
    new-instance v3, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 18
    .line 19
    .line 20
    const-string v4, "tile cache HIT for "

    .line 21
    .line 22
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    goto :goto_67

    .line 60
    :cond_3b
    new-instance v3, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 63
    .line 64
    .line 65
    const-string v4, "tile cache MISS for "

    .line 66
    .line 67
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 102
    .line 103
    .line 104
    :goto_67
    if-eqz v0, :cond_72

    .line 105
    .line 106
    iget-boolean v3, p0, Lo2/j;->k:Z

    .line 107
    .line 108
    if-nez v3, :cond_72

    .line 109
    .line 110
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->b(III)V

    .line 111
    .line 112
    .line 113
    goto :goto_72

    .line 114
    :cond_71
    const/4 v0, 0x0

    .line 115
    :cond_72
    :goto_72
    if-nez v0, :cond_177

    .line 116
    .line 117
    iget-boolean v3, p0, Lo2/j;->k:Z

    .line 118
    .line 119
    if-nez v3, :cond_177

    .line 120
    .line 121
    iget-object v3, p0, Lo2/j;->i:Ljava/lang/String;

    .line 122
    .line 123
    if-eqz v3, :cond_177

    .line 124
    .line 125
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->e(III)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    new-instance v4, Landroidx/work/Constraints$Builder;

    .line 130
    .line 131
    invoke-direct {v4}, Landroidx/work/Constraints$Builder;-><init>()V

    .line 132
    .line 133
    .line 134
    sget-object v5, Landroidx/work/NetworkType;->CONNECTED:Landroidx/work/NetworkType;

    .line 135
    .line 136
    invoke-virtual {v4, v5}, Landroidx/work/Constraints$Builder;->setRequiredNetworkType(Landroidx/work/NetworkType;)Landroidx/work/Constraints$Builder;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    invoke-virtual {v4}, Landroidx/work/Constraints$Builder;->build()Landroidx/work/Constraints;

    .line 141
    .line 142
    .line 143
    move-result-object v4

    .line 144
    new-instance v5, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 145
    .line 146
    const-class v6, Lcom/airbnb/android/react/maps/AirMapTileWorker;

    .line 147
    .line 148
    invoke-direct {v5, v6}, Landroidx/work/OneTimeWorkRequest$Builder;-><init>(Ljava/lang/Class;)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v5, v4}, Landroidx/work/WorkRequest$Builder;->setConstraints(Landroidx/work/Constraints;)Landroidx/work/WorkRequest$Builder;

    .line 152
    .line 153
    .line 154
    move-result-object v4

    .line 155
    check-cast v4, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 156
    .line 157
    invoke-virtual {v4, v3}, Landroidx/work/WorkRequest$Builder;->addTag(Ljava/lang/String;)Landroidx/work/WorkRequest$Builder;

    .line 158
    .line 159
    .line 160
    move-result-object v4

    .line 161
    check-cast v4, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 162
    .line 163
    new-instance v5, Landroidx/work/Data$Builder;

    .line 164
    .line 165
    invoke-direct {v5}, Landroidx/work/Data$Builder;-><init>()V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->g(III)Ljava/net/URL;

    .line 169
    .line 170
    .line 171
    move-result-object v6

    .line 172
    invoke-virtual {v6}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object v6

    .line 176
    const-string v7, "url"

    .line 177
    .line 178
    invoke-virtual {v5, v7, v6}, Landroidx/work/Data$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroidx/work/Data$Builder;

    .line 179
    .line 180
    .line 181
    move-result-object v5

    .line 182
    const-string v6, "filename"

    .line 183
    .line 184
    invoke-virtual {v5, v6, v3}, Landroidx/work/Data$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroidx/work/Data$Builder;

    .line 185
    .line 186
    .line 187
    move-result-object v5

    .line 188
    const/4 v6, -0x1

    .line 189
    const-string v7, "maxAge"

    .line 190
    .line 191
    invoke-virtual {v5, v7, v6}, Landroidx/work/Data$Builder;->putInt(Ljava/lang/String;I)Landroidx/work/Data$Builder;

    .line 192
    .line 193
    .line 194
    move-result-object v5

    .line 195
    invoke-virtual {v5}, Landroidx/work/Data$Builder;->build()Landroidx/work/Data;

    .line 196
    .line 197
    .line 198
    move-result-object v5

    .line 199
    invoke-virtual {v4, v5}, Landroidx/work/WorkRequest$Builder;->setInputData(Landroidx/work/Data;)Landroidx/work/WorkRequest$Builder;

    .line 200
    .line 201
    .line 202
    move-result-object v4

    .line 203
    check-cast v4, Landroidx/work/OneTimeWorkRequest$Builder;

    .line 204
    .line 205
    invoke-virtual {v4}, Landroidx/work/WorkRequest$Builder;->build()Landroidx/work/WorkRequest;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    check-cast v4, Landroidx/work/OneTimeWorkRequest;

    .line 210
    .line 211
    if-eqz v4, :cond_1b4

    .line 212
    .line 213
    iget-object v5, p0, Lo2/j;->l:Landroid/content/Context;

    .line 214
    .line 215
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 216
    .line 217
    .line 218
    move-result-object v5

    .line 219
    invoke-static {v5}, Landroidx/work/WorkManager;->getInstance(Landroid/content/Context;)Landroidx/work/WorkManager;

    .line 220
    .line 221
    .line 222
    move-result-object v5

    .line 223
    sget-object v6, Landroidx/work/ExistingWorkPolicy;->KEEP:Landroidx/work/ExistingWorkPolicy;

    .line 224
    .line 225
    invoke-virtual {v5, v3, v6, v4}, Landroidx/work/WorkManager;->enqueueUniqueWork(Ljava/lang/String;Landroidx/work/ExistingWorkPolicy;Landroidx/work/OneTimeWorkRequest;)Landroidx/work/Operation;

    .line 226
    .line 227
    .line 228
    move-result-object v4

    .line 229
    invoke-interface {v4}, Landroidx/work/Operation;->getResult()Lrb/i;

    .line 230
    .line 231
    .line 232
    move-result-object v4

    .line 233
    :try_start_e8
    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 234
    .line 235
    const-wide/16 v7, 0x1

    .line 236
    .line 237
    invoke-interface {v4, v7, v8, v6}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    const-wide/16 v9, 0x1f4

    .line 241
    .line 242
    invoke-static {v9, v10}, Ljava/lang/Thread;->sleep(J)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v5, v3}, Landroidx/work/WorkManager;->getWorkInfosByTag(Ljava/lang/String;)Lrb/i;

    .line 246
    .line 247
    .line 248
    move-result-object v3

    .line 249
    invoke-interface {v3, v7, v8, v6}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object v3

    .line 253
    check-cast v3, Ljava/util/List;

    .line 254
    .line 255
    const-string v4, "urlTile: "

    .line 256
    .line 257
    const/4 v5, 0x0

    .line 258
    invoke-interface {v3, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v3

    .line 262
    check-cast v3, Landroidx/work/WorkInfo;

    .line 263
    .line 264
    invoke-virtual {v3}, Landroidx/work/WorkInfo;->toString()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v3

    .line 268
    invoke-static {v4, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 269
    .line 270
    .line 271
    iget-object v3, p0, Lo2/j;->i:Ljava/lang/String;

    .line 272
    .line 273
    if-eqz v3, :cond_1b4

    .line 274
    .line 275
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->i(III)[B

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    if-eqz v0, :cond_145

    .line 280
    .line 281
    new-instance v3, Ljava/lang/StringBuilder;

    .line 282
    .line 283
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 284
    .line 285
    .line 286
    const-string v4, "tile cache fetch HIT for "

    .line 287
    .line 288
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 289
    .line 290
    .line 291
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 292
    .line 293
    .line 294
    move-result-object p3

    .line 295
    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 296
    .line 297
    .line 298
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 299
    .line 300
    .line 301
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 306
    .line 307
    .line 308
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 309
    .line 310
    .line 311
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 312
    .line 313
    .line 314
    move-result-object p1

    .line 315
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 316
    .line 317
    .line 318
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object p1

    .line 322
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 323
    .line 324
    .line 325
    goto :goto_1b4

    .line 326
    :cond_145
    new-instance v3, Ljava/lang/StringBuilder;

    .line 327
    .line 328
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 329
    .line 330
    .line 331
    const-string v4, "tile cache fetch MISS for "

    .line 332
    .line 333
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 334
    .line 335
    .line 336
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object p3

    .line 340
    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object p1

    .line 350
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 351
    .line 352
    .line 353
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 354
    .line 355
    .line 356
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object p1

    .line 360
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 361
    .line 362
    .line 363
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 364
    .line 365
    .line 366
    move-result-object p1

    .line 367
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_171
    .catch Ljava/lang/Exception; {:try_start_e8 .. :try_end_171} :catch_172

    .line 368
    .line 369
    .line 370
    goto :goto_1b4

    .line 371
    :catch_172
    move-exception p1

    .line 372
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 373
    .line 374
    .line 375
    goto :goto_1b4

    .line 376
    :cond_177
    if-nez v0, :cond_1b4

    .line 377
    .line 378
    iget-boolean v3, p0, Lo2/j;->k:Z

    .line 379
    .line 380
    if-nez v3, :cond_1b4

    .line 381
    .line 382
    const-string v0, "Normal fetch"

    .line 383
    .line 384
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 385
    .line 386
    .line 387
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->c(III)[B

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    if-nez v0, :cond_1b4

    .line 392
    .line 393
    new-instance v3, Ljava/lang/StringBuilder;

    .line 394
    .line 395
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 396
    .line 397
    .line 398
    const-string v4, "tile fetch TIMEOUT / FAIL for "

    .line 399
    .line 400
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 401
    .line 402
    .line 403
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 404
    .line 405
    .line 406
    move-result-object p3

    .line 407
    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 408
    .line 409
    .line 410
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 411
    .line 412
    .line 413
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 414
    .line 415
    .line 416
    move-result-object p1

    .line 417
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 418
    .line 419
    .line 420
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 421
    .line 422
    .line 423
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 424
    .line 425
    .line 426
    move-result-object p1

    .line 427
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 428
    .line 429
    .line 430
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object p1

    .line 434
    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 435
    .line 436
    .line 437
    :cond_1b4
    :goto_1b4
    return-object v0
.end method

.method public g(III)Ljava/net/URL;
    .registers 5

    iget-object v0, p0, Lo2/j;->a:Lcom/google/android/gms/maps/model/UrlTileProvider;

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/maps/model/UrlTileProvider;->getTileUrl(III)Ljava/net/URL;

    move-result-object p1

    return-object p1
.end method

.method public getTile(III)Lcom/google/android/gms/maps/model/Tile;
    .registers 9

    .line 1
    iget-boolean v0, p0, Lo2/j;->m:Z

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    iget-object v0, p0, Lo2/j;->a:Lcom/google/android/gms/maps/model/UrlTileProvider;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2, p3}, Lcom/google/android/gms/maps/model/UrlTileProvider;->getTile(III)Lcom/google/android/gms/maps/model/Tile;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    return-object p1

    .line 12
    :cond_b
    iget v0, p0, Lo2/j;->e:I

    .line 13
    .line 14
    if-lez v0, :cond_10

    .line 15
    .line 16
    goto :goto_13

    .line 17
    :cond_10
    const v0, 0x7fffffff

    .line 18
    .line 19
    .line 20
    :goto_13
    iget v1, p0, Lo2/j;->c:I

    .line 21
    .line 22
    const/16 v2, 0x100

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    const-string v4, "urlTile"

    .line 26
    .line 27
    if-ne v1, v2, :cond_32

    .line 28
    .line 29
    iget-boolean v1, p0, Lo2/j;->d:Z

    .line 30
    .line 31
    if-eqz v1, :cond_32

    .line 32
    .line 33
    add-int/lit8 v1, p3, 0x1

    .line 34
    .line 35
    iget v2, p0, Lo2/j;->f:I

    .line 36
    .line 37
    if-gt v1, v2, :cond_32

    .line 38
    .line 39
    if-gt v1, v0, :cond_32

    .line 40
    .line 41
    const-string v1, "pullTilesFromHigherZoom"

    .line 42
    .line 43
    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->h(III)[B

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    goto :goto_33

    .line 51
    :cond_32
    move-object v1, v3

    .line 52
    :goto_33
    iget v2, p0, Lo2/j;->f:I

    .line 53
    .line 54
    if-le p3, v2, :cond_42

    .line 55
    .line 56
    const-string v1, "scaleLowerZoomTile"

    .line 57
    .line 58
    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 59
    .line 60
    .line 61
    iget v1, p0, Lo2/j;->f:I

    .line 62
    .line 63
    invoke-virtual {p0, p1, p2, p3, v1}, Lo2/j;->j(IIII)[B

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    :cond_42
    if-nez v1, :cond_4f

    .line 68
    .line 69
    if-gt p3, v0, :cond_4f

    .line 70
    .line 71
    const-string v0, "getTileImage"

    .line 72
    .line 73
    invoke-static {v4, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->f(III)[B

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    :cond_4f
    if-nez v1, :cond_7b

    .line 81
    .line 82
    iget-object v0, p0, Lo2/j;->i:Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v0, :cond_7b

    .line 85
    .line 86
    iget-boolean v0, p0, Lo2/j;->k:Z

    .line 87
    .line 88
    if-eqz v0, :cond_7b

    .line 89
    .line 90
    const-string v0, "findLowerZoomTileForScaling"

    .line 91
    .line 92
    invoke-static {v4, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 93
    .line 94
    .line 95
    iget v0, p0, Lo2/j;->f:I

    .line 96
    .line 97
    if-le p3, v0, :cond_65

    .line 98
    .line 99
    add-int/lit8 v0, v0, -0x1

    .line 100
    .line 101
    goto :goto_67

    .line 102
    :cond_65
    add-int/lit8 v0, p3, -0x1

    .line 103
    .line 104
    :goto_67
    iget v2, p0, Lo2/j;->g:I

    .line 105
    .line 106
    add-int/lit8 v4, p3, -0x3

    .line 107
    .line 108
    if-lt v2, v4, :cond_6e

    .line 109
    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    move v2, v4

    .line 112
    :goto_6f
    if-lt v0, v2, :cond_7b

    .line 113
    .line 114
    invoke-virtual {p0, p1, p2, p3, v0}, Lo2/j;->j(IIII)[B

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    if-eqz v1, :cond_78

    .line 119
    .line 120
    goto :goto_7b

    .line 121
    :cond_78
    add-int/lit8 v0, v0, -0x1

    .line 122
    .line 123
    goto :goto_6f

    .line 124
    :cond_7b
    :goto_7b
    if-nez v1, :cond_7e

    .line 125
    .line 126
    goto :goto_85

    .line 127
    :cond_7e
    new-instance v3, Lcom/google/android/gms/maps/model/Tile;

    .line 128
    .line 129
    iget p1, p0, Lo2/j;->c:I

    .line 130
    .line 131
    invoke-direct {v3, p1, p1, v1}, Lcom/google/android/gms/maps/model/Tile;-><init>(II[B)V

    .line 132
    .line 133
    .line 134
    :goto_85
    return-object v3
.end method

.method public h(III)[B
    .registers 10

    .line 1
    invoke-virtual {p0}, Lo2/j;->d()Landroid/graphics/Bitmap;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Landroid/graphics/Canvas;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 8
    .line 9
    .line 10
    new-instance v2, Landroid/graphics/Paint;

    .line 11
    .line 12
    invoke-direct {v2}, Landroid/graphics/Paint;-><init>()V

    .line 13
    .line 14
    .line 15
    mul-int/lit8 p1, p1, 0x2

    .line 16
    .line 17
    mul-int/lit8 p2, p2, 0x2

    .line 18
    .line 19
    add-int/lit8 p3, p3, 0x1

    .line 20
    .line 21
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->f(III)[B

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    add-int/lit8 v4, p2, 0x1

    .line 26
    .line 27
    invoke-virtual {p0, p1, v4, p3}, Lo2/j;->f(III)[B

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    add-int/lit8 p1, p1, 0x1

    .line 32
    .line 33
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->f(III)[B

    .line 34
    .line 35
    .line 36
    move-result-object p2

    .line 37
    invoke-virtual {p0, p1, v4, p3}, Lo2/j;->f(III)[B

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    if-eqz v3, :cond_69

    .line 42
    .line 43
    if-eqz v5, :cond_69

    .line 44
    .line 45
    if-eqz p2, :cond_69

    .line 46
    .line 47
    if-nez p1, :cond_31

    .line 48
    .line 49
    goto :goto_69

    .line 50
    :cond_31
    array-length p3, v3

    .line 51
    const/4 v4, 0x0

    .line 52
    invoke-static {v3, v4, p3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 53
    .line 54
    .line 55
    move-result-object p3

    .line 56
    const/4 v3, 0x0

    .line 57
    invoke-virtual {v1, p3, v3, v3, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p3}, Landroid/graphics/Bitmap;->recycle()V

    .line 61
    .line 62
    .line 63
    array-length p3, v5

    .line 64
    invoke-static {v5, v4, p3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 65
    .line 66
    .line 67
    move-result-object p3

    .line 68
    const/high16 v5, 0x43800000    # 256.0f

    .line 69
    .line 70
    invoke-virtual {v1, p3, v3, v5, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p3}, Landroid/graphics/Bitmap;->recycle()V

    .line 74
    .line 75
    .line 76
    array-length p3, p2

    .line 77
    invoke-static {p2, v4, p3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 78
    .line 79
    .line 80
    move-result-object p2

    .line 81
    invoke-virtual {v1, p2, v5, v3, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->recycle()V

    .line 85
    .line 86
    .line 87
    array-length p2, p1

    .line 88
    invoke-static {p1, v4, p2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    invoke-virtual {v1, p1, v5, v5, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    .line 96
    .line 97
    .line 98
    invoke-virtual {p0, v0}, Lo2/j;->a(Landroid/graphics/Bitmap;)[B

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 103
    .line 104
    .line 105
    return-object p1

    .line 106
    :cond_69
    :goto_69
    const/4 p1, 0x0

    .line 107
    return-object p1
.end method

.method public i(III)[B
    .registers 10

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Lo2/j;->e(III)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p2, 0x0

    .line 6
    if-nez p1, :cond_8

    .line 7
    .line 8
    return-object p2

    .line 9
    :cond_8
    new-instance p3, Ljava/io/File;

    .line 10
    .line 11
    invoke-direct {p3, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    :try_start_d
    new-instance p1, Ljava/io/FileInputStream;

    .line 15
    .line 16
    invoke-direct {p1, p3}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_12
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_12} :catch_66
    .catch Ljava/lang/OutOfMemoryError; {:try_start_d .. :try_end_12} :catch_53
    .catchall {:try_start_d .. :try_end_12} :catchall_4e

    .line 17
    .line 18
    .line 19
    :try_start_12
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_17
    .catch Ljava/io/IOException; {:try_start_12 .. :try_end_17} :catch_4b
    .catch Ljava/lang/OutOfMemoryError; {:try_start_12 .. :try_end_17} :catch_48
    .catchall {:try_start_12 .. :try_end_17} :catchall_44

    .line 22
    .line 23
    .line 24
    const/16 v1, 0x4000

    .line 25
    .line 26
    :try_start_19
    new-array v2, v1, [B

    .line 27
    .line 28
    :goto_1b
    const/4 v3, 0x0

    .line 29
    invoke-virtual {p1, v2, v3, v1}, Ljava/io/InputStream;->read([BII)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    const/4 v5, -0x1

    .line 34
    if-eq v4, v5, :cond_27

    .line 35
    .line 36
    invoke-virtual {v0, v2, v3, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 37
    .line 38
    .line 39
    goto :goto_1b

    .line 40
    :cond_27
    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    .line 41
    .line 42
    .line 43
    iget v1, p0, Lo2/j;->j:I

    .line 44
    .line 45
    if-nez v1, :cond_35

    .line 46
    .line 47
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 48
    .line 49
    .line 50
    move-result-wide v1

    .line 51
    invoke-virtual {p3, v1, v2}, Ljava/io/File;->setLastModified(J)Z

    .line 52
    .line 53
    .line 54
    :cond_35
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 55
    .line 56
    .line 57
    move-result-object p2
    :try_end_39
    .catch Ljava/io/IOException; {:try_start_19 .. :try_end_39} :catch_42
    .catch Ljava/lang/OutOfMemoryError; {:try_start_19 .. :try_end_39} :catch_40
    .catchall {:try_start_19 .. :try_end_39} :catchall_79

    .line 58
    :try_start_39
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_3c
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_3c} :catch_3c

    .line 59
    .line 60
    .line 61
    :catch_3c
    :try_start_3c
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_3c .. :try_end_3f} :catch_3f

    .line 62
    .line 63
    .line 64
    :catch_3f
    return-object p2

    .line 65
    :catch_40
    move-exception p3

    .line 66
    goto :goto_56

    .line 67
    :catch_42
    move-exception p3

    .line 68
    goto :goto_69

    .line 69
    :catchall_44
    move-exception p3

    .line 70
    move-object v0, p2

    .line 71
    move-object p2, p3

    .line 72
    goto :goto_7a

    .line 73
    :catch_48
    move-exception p3

    .line 74
    move-object v0, p2

    .line 75
    goto :goto_56

    .line 76
    :catch_4b
    move-exception p3

    .line 77
    move-object v0, p2

    .line 78
    goto :goto_69

    .line 79
    :catchall_4e
    move-exception p1

    .line 80
    move-object v0, p2

    .line 81
    move-object p2, p1

    .line 82
    move-object p1, v0

    .line 83
    goto :goto_7a

    .line 84
    :catch_53
    move-exception p3

    .line 85
    move-object p1, p2

    .line 86
    move-object v0, p1

    .line 87
    :goto_56
    :try_start_56
    invoke-virtual {p3}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_59
    .catchall {:try_start_56 .. :try_end_59} :catchall_79

    .line 88
    .line 89
    .line 90
    if-eqz p1, :cond_60

    .line 91
    .line 92
    :try_start_5b
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_5e} :catch_5f

    .line 93
    .line 94
    .line 95
    goto :goto_60

    .line 96
    :catch_5f
    nop

    .line 97
    :cond_60
    :goto_60
    if-eqz v0, :cond_65

    .line 98
    .line 99
    :try_start_62
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_65
    .catch Ljava/lang/Exception; {:try_start_62 .. :try_end_65} :catch_65

    .line 100
    .line 101
    .line 102
    :catch_65
    :cond_65
    return-object p2

    .line 103
    :catch_66
    move-exception p3

    .line 104
    move-object p1, p2

    .line 105
    move-object v0, p1

    .line 106
    :goto_69
    :try_start_69
    invoke-virtual {p3}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_6c
    .catchall {:try_start_69 .. :try_end_6c} :catchall_79

    .line 107
    .line 108
    .line 109
    if-eqz p1, :cond_73

    .line 110
    .line 111
    :try_start_6e
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_71
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_71} :catch_72

    .line 112
    .line 113
    .line 114
    goto :goto_73

    .line 115
    :catch_72
    nop

    .line 116
    :cond_73
    :goto_73
    if-eqz v0, :cond_78

    .line 117
    .line 118
    :try_start_75
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_78
    .catch Ljava/lang/Exception; {:try_start_75 .. :try_end_78} :catch_78

    .line 119
    .line 120
    .line 121
    :catch_78
    :cond_78
    return-object p2

    .line 122
    :catchall_79
    move-exception p2

    .line 123
    :goto_7a
    if-eqz p1, :cond_81

    .line 124
    .line 125
    :try_start_7c
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_7f
    .catch Ljava/lang/Exception; {:try_start_7c .. :try_end_7f} :catch_80

    .line 126
    .line 127
    .line 128
    goto :goto_81

    .line 129
    :catch_80
    nop

    .line 130
    :cond_81
    :goto_81
    if-eqz v0, :cond_86

    .line 131
    .line 132
    :try_start_83
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_83 .. :try_end_86} :catch_86

    .line 133
    .line 134
    .line 135
    :catch_86
    :cond_86
    throw p2
.end method

.method public j(IIII)[B
    .registers 11

    .line 1
    sub-int p4, p3, p4

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    shl-int/2addr v0, p4

    .line 5
    shr-int v1, p1, p4

    .line 6
    .line 7
    shr-int v2, p2, p4

    .line 8
    .line 9
    sub-int/2addr p3, p4

    .line 10
    rem-int/2addr p1, v0

    .line 11
    rem-int/2addr p2, v0

    .line 12
    invoke-virtual {p0}, Lo2/j;->d()Landroid/graphics/Bitmap;

    .line 13
    .line 14
    .line 15
    move-result-object p4

    .line 16
    new-instance v3, Landroid/graphics/Canvas;

    .line 17
    .line 18
    invoke-direct {v3, p4}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 19
    .line 20
    .line 21
    new-instance v4, Landroid/graphics/Paint;

    .line 22
    .line 23
    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0, v1, v2, p3}, Lo2/j;->f(III)[B

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    if-nez p3, :cond_21

    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    return-object p1

    .line 34
    :cond_21
    array-length v1, p3

    .line 35
    const/4 v2, 0x0

    .line 36
    invoke-static {p3, v2, v1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 37
    .line 38
    .line 39
    move-result-object p3

    .line 40
    iget v1, p0, Lo2/j;->c:I

    .line 41
    .line 42
    div-int/2addr v1, v0

    .line 43
    new-instance v0, Landroid/graphics/Rect;

    .line 44
    .line 45
    mul-int p1, p1, v1

    .line 46
    .line 47
    mul-int p2, p2, v1

    .line 48
    .line 49
    add-int v5, p1, v1

    .line 50
    .line 51
    add-int/2addr v1, p2

    .line 52
    invoke-direct {v0, p1, p2, v5, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 53
    .line 54
    .line 55
    new-instance p1, Landroid/graphics/Rect;

    .line 56
    .line 57
    const/16 p2, 0x200

    .line 58
    .line 59
    invoke-direct {p1, v2, v2, p2, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v3, p3, v0, p1, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p3}, Landroid/graphics/Bitmap;->recycle()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0, p4}, Lo2/j;->a(Landroid/graphics/Bitmap;)[B

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    invoke-virtual {p4}, Landroid/graphics/Bitmap;->recycle()V

    .line 73
    .line 74
    .line 75
    return-object p1
.end method

.method public k()V
    .registers 2

    iget-boolean v0, p0, Lo2/j;->m:Z

    iput-boolean v0, p0, Lo2/j;->m:Z

    return-void
.end method

.method public l(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/j;->d:Z

    return-void
.end method

.method public m(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/j;->h:Z

    return-void
.end method

.method public n(I)V
    .registers 2

    iput p1, p0, Lo2/j;->f:I

    return-void
.end method

.method public o(I)V
    .registers 2

    iput p1, p0, Lo2/j;->e:I

    return-void
.end method

.method public p(I)V
    .registers 2

    iput p1, p0, Lo2/j;->g:I

    return-void
.end method

.method public q(Z)V
    .registers 2

    iput-boolean p1, p0, Lo2/j;->k:Z

    return-void
.end method

.method public r(I)V
    .registers 2

    iput p1, p0, Lo2/j;->j:I

    return-void
.end method

.method public s(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lo2/j;->i:Ljava/lang/String;

    return-void
.end method

.method public t(I)V
    .registers 4

    .line 1
    iget v0, p0, Lo2/j;->c:I

    .line 2
    .line 3
    if-eq v0, p1, :cond_d

    .line 4
    .line 5
    new-instance v0, Lo2/j$a;

    .line 6
    .line 7
    iget-object v1, p0, Lo2/j;->b:Ljava/lang/String;

    .line 8
    .line 9
    invoke-direct {v0, p0, p1, p1, v1}, Lo2/j$a;-><init>(Lo2/j;IILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lo2/j;->a:Lcom/google/android/gms/maps/model/UrlTileProvider;

    .line 13
    .line 14
    :cond_d
    iput p1, p0, Lo2/j;->c:I

    .line 15
    .line 16
    return-void
.end method

.method public u(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lo2/j;->b:Ljava/lang/String;

    return-void
.end method

###### Class o2.j.a (o2.j$a)
.class public Lo2/j$a;
.super Lcom/google/android/gms/maps/model/UrlTileProvider;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public final synthetic b:Lo2/j;


# direct methods
.method public constructor <init>(Lo2/j;IILjava/lang/String;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lo2/j$a;->b:Lo2/j;

    .line 2
    .line 3
    invoke-direct {p0, p2, p3}, Lcom/google/android/gms/maps/model/UrlTileProvider;-><init>(II)V

    .line 4
    .line 5
    .line 6
    iput-object p4, p0, Lo2/j$a;->a:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public getTileUrl(III)Ljava/net/URL;
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/j$a;->b:Lo2/j;

    .line 2
    .line 3
    iget-boolean v0, v0, Lo2/j;->h:Z

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne v0, v1, :cond_c

    .line 7
    .line 8
    shl-int v0, v1, p3

    .line 9
    .line 10
    sub-int/2addr v0, p2

    .line 11
    add-int/lit8 p2, v0, -0x1

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, Lo2/j$a;->a:Ljava/lang/String;

    .line 14
    .line 15
    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    const-string v1, "{x}"

    .line 20
    .line 21
    invoke-virtual {v0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    const-string v0, "{y}"

    .line 30
    .line 31
    invoke-virtual {p1, v0, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-static {p3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p2

    .line 39
    const-string v0, "{z}"

    .line 40
    .line 41
    invoke-virtual {p1, v0, p2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    const/4 p2, 0x0

    .line 46
    iget-object v0, p0, Lo2/j$a;->b:Lo2/j;

    .line 47
    .line 48
    iget v1, v0, Lo2/j;->e:I

    .line 49
    .line 50
    if-lez v1, :cond_36

    .line 51
    .line 52
    if-le p3, v1, :cond_36

    .line 53
    .line 54
    return-object p2

    .line 55
    :cond_36
    iget v0, v0, Lo2/j;->g:I

    .line 56
    .line 57
    if-lez v0, :cond_3d

    .line 58
    .line 59
    if-ge p3, v0, :cond_3d

    .line 60
    .line 61
    return-object p2

    .line 62
    :cond_3d
    :try_start_3d
    new-instance p2, Ljava/net/URL;

    .line 63
    .line 64
    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_42
    .catch Ljava/net/MalformedURLException; {:try_start_3d .. :try_end_42} :catch_43

    .line 65
    .line 66
    .line 67
    return-object p2

    .line 68
    :catch_43
    move-exception p1

    .line 69
    new-instance p2, Ljava/lang/AssertionError;

    .line 70
    .line 71
    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    throw p2
.end method
