###### Class o2.w (o2.w)
.class public Lo2/w;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static g:Lo2/w;


# instance fields
.field public a:Landroid/os/Handler;

.field public b:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Lcom/airbnb/android/react/maps/a;",
            ">;"
        }
    .end annotation
.end field

.field public c:Z

.field public d:Ljava/lang/Runnable;

.field public final e:J

.field public f:Ljava/util/LinkedList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedList<",
            "Lcom/airbnb/android/react/maps/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/LinkedList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lo2/w;->c:Z

    .line 13
    .line 14
    const-wide/16 v0, 0x28

    .line 15
    .line 16
    iput-wide v0, p0, Lo2/w;->e:J

    .line 17
    .line 18
    new-instance v0, Ljava/util/LinkedList;

    .line 19
    .line 20
    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Lo2/w;->f:Ljava/util/LinkedList;

    .line 24
    .line 25
    new-instance v0, Landroid/os/Handler;

    .line 26
    .line 27
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 32
    .line 33
    .line 34
    iput-object v0, p0, Lo2/w;->a:Landroid/os/Handler;

    .line 35
    .line 36
    new-instance v0, Lo2/w$a;

    .line 37
    .line 38
    invoke-direct {v0, p0}, Lo2/w$a;-><init>(Lo2/w;)V

    .line 39
    .line 40
    .line 41
    iput-object v0, p0, Lo2/w;->d:Ljava/lang/Runnable;

    .line 42
    .line 43
    return-void
.end method

.method public static synthetic a(Lo2/w;Z)Z
    .registers 2

    iput-boolean p1, p0, Lo2/w;->c:Z

    return p1
.end method

.method public static synthetic b(Lo2/w;)Ljava/util/LinkedList;
    .registers 1

    iget-object p0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    return-object p0
.end method

.method public static synthetic c(Lo2/w;)Ljava/lang/Runnable;
    .registers 1

    iget-object p0, p0, Lo2/w;->d:Ljava/lang/Runnable;

    return-object p0
.end method

.method public static synthetic d(Lo2/w;)Landroid/os/Handler;
    .registers 1

    iget-object p0, p0, Lo2/w;->a:Landroid/os/Handler;

    return-object p0
.end method

.method public static f()Lo2/w;
    .registers 2

    .line 1
    sget-object v0, Lo2/w;->g:Lo2/w;

    .line 2
    .line 3
    if-nez v0, :cond_13

    .line 4
    .line 5
    const-class v0, Lo2/w;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    new-instance v1, Lo2/w;

    .line 9
    .line 10
    invoke-direct {v1}, Lo2/w;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lo2/w;->g:Lo2/w;

    .line 14
    .line 15
    monitor-exit v0

    .line 16
    goto :goto_13

    .line 17
    :catchall_10
    move-exception v1

    .line 18
    monitor-exit v0
    :try_end_12
    .catchall {:try_start_7 .. :try_end_12} :catchall_10

    .line 19
    throw v1

    .line 20
    :cond_13
    :goto_13
    sget-object v0, Lo2/w;->g:Lo2/w;

    .line 21
    .line 22
    return-object v0
.end method


# virtual methods
.method public e(Lcom/airbnb/android/react/maps/a;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    iget-boolean p1, p0, Lo2/w;->c:Z

    .line 7
    .line 8
    if-nez p1, :cond_15

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    iput-boolean p1, p0, Lo2/w;->c:Z

    .line 12
    .line 13
    iget-object p1, p0, Lo2/w;->a:Landroid/os/Handler;

    .line 14
    .line 15
    iget-object v0, p0, Lo2/w;->d:Ljava/lang/Runnable;

    .line 16
    .line 17
    const-wide/16 v1, 0x28

    .line 18
    .line 19
    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 20
    .line 21
    .line 22
    :cond_15
    return-void
.end method

.method public g(Lcom/airbnb/android/react/maps/a;)V
    .registers 3

    iget-object v0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    invoke-virtual {v0, p1}, Ljava/util/LinkedList;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public h()V
    .registers 4

    .line 1
    iget-object v0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :cond_6
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_1e

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Lcom/airbnb/android/react/maps/a;

    .line 18
    .line 19
    invoke-virtual {v1}, Lcom/airbnb/android/react/maps/a;->w()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-nez v2, :cond_6

    .line 24
    .line 25
    iget-object v2, p0, Lo2/w;->f:Ljava/util/LinkedList;

    .line 26
    .line 27
    invoke-virtual {v2, v1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    goto :goto_6

    .line 31
    :cond_1e
    iget-object v0, p0, Lo2/w;->f:Ljava/util/LinkedList;

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/util/LinkedList;->size()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-lez v0, :cond_32

    .line 38
    .line 39
    iget-object v0, p0, Lo2/w;->b:Ljava/util/LinkedList;

    .line 40
    .line 41
    iget-object v1, p0, Lo2/w;->f:Ljava/util/LinkedList;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->removeAll(Ljava/util/Collection;)Z

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, Lo2/w;->f:Ljava/util/LinkedList;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/util/LinkedList;->clear()V

    .line 49
    .line 50
    .line 51
    :cond_32
    return-void
.end method

###### Class o2.w.a (o2.w$a)
.class public Lo2/w$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lo2/w;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Lo2/w;


# direct methods
.method public constructor <init>(Lo2/w;)V
    .registers 2

    iput-object p1, p0, Lo2/w$a;->a:Lo2/w;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1
    iget-object v0, p0, Lo2/w$a;->a:Lo2/w;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {v0, v1}, Lo2/w;->a(Lo2/w;Z)Z

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lo2/w$a;->a:Lo2/w;

    .line 8
    .line 9
    invoke-virtual {v0}, Lo2/w;->h()V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Lo2/w$a;->a:Lo2/w;

    .line 13
    .line 14
    invoke-static {v0}, Lo2/w;->b(Lo2/w;)Ljava/util/LinkedList;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/util/LinkedList;->size()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-lez v0, :cond_28

    .line 23
    .line 24
    iget-object v0, p0, Lo2/w$a;->a:Lo2/w;

    .line 25
    .line 26
    invoke-static {v0}, Lo2/w;->d(Lo2/w;)Landroid/os/Handler;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget-object v1, p0, Lo2/w$a;->a:Lo2/w;

    .line 31
    .line 32
    invoke-static {v1}, Lo2/w;->c(Lo2/w;)Ljava/lang/Runnable;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const-wide/16 v2, 0x28

    .line 37
    .line 38
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 39
    .line 40
    .line 41
    :cond_28
    return-void
.end method
