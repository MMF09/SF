###### Class o2.e (o2.e)
.class public Lo2/e;
.super Lo2/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

.field public b:Lcom/google/android/gms/maps/model/TileOverlay;

.field public c:Lfe/b;

.field public d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lfe/c;",
            ">;"
        }
    .end annotation
.end field

.field public e:Lfe/a;

.field public i:Ljava/lang/Double;

.field public j:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 4

    .line 1
    const-string v0, "AirMapHeatmap"

    .line 2
    .line 3
    const-string v1, "ADD TO MAP"

    .line 4
    .line 5
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Lo2/e;->getHeatmapOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 17
    .line 18
    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 5

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/TileOverlayOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lo2/e;->c:Lfe/b;

    .line 7
    .line 8
    if-nez v1, :cond_37

    .line 9
    .line 10
    new-instance v1, Lfe/b$b;

    .line 11
    .line 12
    invoke-direct {v1}, Lfe/b$b;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, Lo2/e;->d:Ljava/util/List;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Lfe/b$b;->i(Ljava/util/Collection;)Lfe/b$b;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    iget-object v2, p0, Lo2/e;->j:Ljava/lang/Integer;

    .line 22
    .line 23
    if-eqz v2, :cond_1f

    .line 24
    .line 25
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    invoke-virtual {v1, v2}, Lfe/b$b;->h(I)Lfe/b$b;

    .line 30
    .line 31
    .line 32
    :cond_1f
    iget-object v2, p0, Lo2/e;->i:Ljava/lang/Double;

    .line 33
    .line 34
    if-eqz v2, :cond_2a

    .line 35
    .line 36
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 37
    .line 38
    .line 39
    move-result-wide v2

    .line 40
    invoke-virtual {v1, v2, v3}, Lfe/b$b;->g(D)Lfe/b$b;

    .line 41
    .line 42
    .line 43
    :cond_2a
    iget-object v2, p0, Lo2/e;->e:Lfe/a;

    .line 44
    .line 45
    if-eqz v2, :cond_31

    .line 46
    .line 47
    invoke-virtual {v1, v2}, Lfe/b$b;->f(Lfe/a;)Lfe/b$b;

    .line 48
    .line 49
    .line 50
    :cond_31
    invoke-virtual {v1}, Lfe/b$b;->e()Lfe/b;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    iput-object v1, p0, Lo2/e;->c:Lfe/b;

    .line 55
    .line 56
    :cond_37
    iget-object v1, p0, Lo2/e;->c:Lfe/b;

    .line 57
    .line 58
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tileProvider(Lcom/google/android/gms/maps/model/TileProvider;)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 59
    .line 60
    .line 61
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    return-object v0
.end method

.method public getHeatmapOptions()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/e;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/e;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/e;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/e;->a:Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setGradient(Lfe/a;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/e;->e:Lfe/a;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/e;->c:Lfe/b;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lfe/b;->h(Lfe/a;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 11
    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public setOpacity(D)V
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/Double;

    .line 2
    .line 3
    invoke-direct {v0, p1, p2}, Ljava/lang/Double;-><init>(D)V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, Lo2/e;->i:Ljava/lang/Double;

    .line 7
    .line 8
    iget-object v0, p0, Lo2/e;->c:Lfe/b;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0, p1, p2}, Lfe/b;->i(D)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 16
    .line 17
    if-eqz p1, :cond_15

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 20
    .line 21
    .line 22
    :cond_15
    return-void
.end method

.method public setPoints([Lfe/c;)V
    .registers 3

    .line 1
    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iput-object p1, p0, Lo2/e;->d:Ljava/util/List;

    .line 6
    .line 7
    iget-object v0, p0, Lo2/e;->c:Lfe/b;

    .line 8
    .line 9
    if-eqz v0, :cond_d

    .line 10
    .line 11
    invoke-virtual {v0, p1}, Lfe/b;->k(Ljava/util/Collection;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    iget-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 15
    .line 16
    if-eqz p1, :cond_14

    .line 17
    .line 18
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public setRadius(I)V
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/Integer;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Ljava/lang/Integer;-><init>(I)V

    .line 4
    .line 5
    .line 6
    iput-object v0, p0, Lo2/e;->j:Ljava/lang/Integer;

    .line 7
    .line 8
    iget-object v0, p0, Lo2/e;->c:Lfe/b;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Lfe/b;->j(I)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object p1, p0, Lo2/e;->b:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 16
    .line 17
    if-eqz p1, :cond_15

    .line 18
    .line 19
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->clearTileCache()V

    .line 20
    .line 21
    .line 22
    :cond_15
    return-void
.end method
