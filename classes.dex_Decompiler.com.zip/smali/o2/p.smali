###### Class o2.p (o2.p)
.class public interface abstract Lo2/p;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract setIconBitmap(Landroid/graphics/Bitmap;)V
.end method

.method public abstract setIconBitmapDescriptor(Lcom/google/android/gms/maps/model/BitmapDescriptor;)V
.end method

.method public abstract update()V
.end method
