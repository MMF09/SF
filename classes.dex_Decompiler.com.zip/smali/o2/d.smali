###### Class o2.d (o2.d)
.class public Lo2/d;
.super Lo2/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lo2/d$b;,
        Lo2/d$a;
    }
.end annotation


# instance fields
.field public a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;"
        }
    .end annotation
.end field

.field public b:[I

.field public c:F

.field public d:F

.field public e:Lcom/google/android/gms/maps/GoogleMap;

.field public i:Lcom/google/android/gms/maps/model/TileOverlay;

.field public j:Lo2/d$a;

.field public final k:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lo2/d;->k:Landroid/content/Context;

    .line 5
    .line 6
    return-void
.end method

.method public static d([IF)I
    .registers 8

    .line 1
    array-length v0, p0

    .line 2
    add-int/lit8 v0, v0, -0x1

    .line 3
    .line 4
    int-to-float v0, v0

    .line 5
    mul-float p1, p1, v0

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x0

    .line 11
    :goto_a
    array-length v4, p0

    .line 12
    if-ge v0, v4, :cond_40

    .line 13
    .line 14
    const/high16 v4, 0x3f800000    # 1.0f

    .line 15
    .line 16
    int-to-float v5, v0

    .line 17
    sub-float v5, p1, v5

    .line 18
    .line 19
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    sub-float/2addr v4, v5

    .line 24
    const/4 v5, 0x0

    .line 25
    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    .line 26
    .line 27
    .line 28
    move-result v4

    .line 29
    aget v5, p0, v0

    .line 30
    .line 31
    invoke-static {v5}, Landroid/graphics/Color;->red(I)I

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    int-to-float v5, v5

    .line 36
    mul-float v5, v5, v4

    .line 37
    .line 38
    float-to-int v5, v5

    .line 39
    add-int/2addr v1, v5

    .line 40
    aget v5, p0, v0

    .line 41
    .line 42
    invoke-static {v5}, Landroid/graphics/Color;->green(I)I

    .line 43
    .line 44
    .line 45
    move-result v5

    .line 46
    int-to-float v5, v5

    .line 47
    mul-float v5, v5, v4

    .line 48
    .line 49
    float-to-int v5, v5

    .line 50
    add-int/2addr v2, v5

    .line 51
    aget v5, p0, v0

    .line 52
    .line 53
    invoke-static {v5}, Landroid/graphics/Color;->blue(I)I

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    int-to-float v5, v5

    .line 58
    mul-float v5, v5, v4

    .line 59
    .line 60
    float-to-int v4, v5

    .line 61
    add-int/2addr v3, v4

    .line 62
    add-int/lit8 v0, v0, 0x1

    .line 63
    .line 64
    goto :goto_a

    .line 65
    :cond_40
    invoke-static {v1, v2, v3}, Landroid/graphics/Color;->rgb(III)I

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    return p0
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 4

    .line 1
    const-string v0, "AirMapGradientPolyline"

    .line 2
    .line 3
    const-string v1, "ADDTOMAP"

    .line 4
    .line 5
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, Lo2/d;->e:Lcom/google/android/gms/maps/GoogleMap;

    .line 9
    .line 10
    invoke-virtual {p0}, Lo2/d;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 19
    .line 20
    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/TileOverlayOptions;
    .registers 9

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/TileOverlayOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget v1, p0, Lo2/d;->c:F

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->zIndex(F)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 9
    .line 10
    .line 11
    new-instance v1, Lo2/d$a;

    .line 12
    .line 13
    iget-object v4, p0, Lo2/d;->k:Landroid/content/Context;

    .line 14
    .line 15
    iget-object v5, p0, Lo2/d;->a:Ljava/util/List;

    .line 16
    .line 17
    iget-object v6, p0, Lo2/d;->b:[I

    .line 18
    .line 19
    iget v7, p0, Lo2/d;->d:F

    .line 20
    .line 21
    move-object v2, v1

    .line 22
    move-object v3, p0

    .line 23
    invoke-direct/range {v2 .. v7}, Lo2/d$a;-><init>(Lo2/d;Landroid/content/Context;Ljava/util/List;[IF)V

    .line 24
    .line 25
    .line 26
    iput-object v1, p0, Lo2/d;->j:Lo2/d$a;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/TileOverlayOptions;->tileProvider(Lcom/google/android/gms/maps/model/TileProvider;)Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 29
    .line 30
    .line 31
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    return-object v0
.end method

.method public setCoordinates(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lo2/d;->a:Ljava/util/List;

    .line 2
    .line 3
    iget-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz p1, :cond_9

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/d;->e:Lcom/google/android/gms/maps/GoogleMap;

    .line 11
    .line 12
    if-eqz p1, :cond_17

    .line 13
    .line 14
    invoke-virtual {p0}, Lo2/d;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public setStrokeColors([I)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/d;->b:[I

    .line 2
    .line 3
    iget-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz p1, :cond_9

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/d;->e:Lcom/google/android/gms/maps/GoogleMap;

    .line 11
    .line 12
    if-eqz p1, :cond_17

    .line 13
    .line 14
    invoke-virtual {p0}, Lo2/d;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public setWidth(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/d;->d:F

    .line 2
    .line 3
    iget-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz p1, :cond_9

    .line 6
    .line 7
    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/TileOverlay;->remove()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p1, p0, Lo2/d;->e:Lcom/google/android/gms/maps/GoogleMap;

    .line 11
    .line 12
    if-eqz p1, :cond_17

    .line 13
    .line 14
    invoke-virtual {p0}, Lo2/d;->c()Lcom/google/android/gms/maps/model/TileOverlayOptions;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addTileOverlay(Lcom/google/android/gms/maps/model/TileOverlayOptions;)Lcom/google/android/gms/maps/model/TileOverlay;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    iput-object p1, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/d;->c:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/d;->i:Lcom/google/android/gms/maps/model/TileOverlay;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/TileOverlay;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

###### Class o2.d.a (o2.d$a)
.class public Lo2/d$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/google/android/gms/maps/model/TileProvider;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;"
        }
    .end annotation
.end field

.field public final b:[I

.field public final c:F

.field public final d:F

.field public final e:I

.field public final f:Lge/b;

.field public g:[Lcom/google/android/gms/maps/model/LatLng;

.field public h:[Lee/b;

.field public i:[Lee/b;

.field public final synthetic j:Lo2/d;


# direct methods
.method public constructor <init>(Lo2/d;Landroid/content/Context;Ljava/util/List;[IF)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;[IF)V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lo2/d$a;->j:Lo2/d;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p3, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 7
    .line 8
    iput-object p4, p0, Lo2/d$a;->b:[I

    .line 9
    .line 10
    iput p5, p0, Lo2/d$a;->c:F

    .line 11
    .line 12
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    .line 21
    .line 22
    iput p1, p0, Lo2/d$a;->d:F

    .line 23
    .line 24
    const/high16 p2, 0x43800000    # 256.0f

    .line 25
    .line 26
    mul-float p1, p1, p2

    .line 27
    .line 28
    float-to-int p1, p1

    .line 29
    iput p1, p0, Lo2/d$a;->e:I

    .line 30
    .line 31
    new-instance p1, Lge/b;

    .line 32
    .line 33
    const-wide/high16 p2, 0x4070000000000000L    # 256.0

    .line 34
    .line 35
    invoke-direct {p1, p2, p3}, Lge/b;-><init>(D)V

    .line 36
    .line 37
    .line 38
    iput-object p1, p0, Lo2/d$a;->f:Lge/b;

    .line 39
    .line 40
    invoke-virtual {p0}, Lo2/d$a;->a()V

    .line 41
    .line 42
    .line 43
    return-void
.end method


# virtual methods
.method public a()V
    .registers 7

    .line 1
    iget-object v0, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    new-array v0, v0, [Lcom/google/android/gms/maps/model/LatLng;

    .line 8
    .line 9
    iput-object v0, p0, Lo2/d$a;->g:[Lcom/google/android/gms/maps/model/LatLng;

    .line 10
    .line 11
    iget-object v0, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    new-array v0, v0, [Lee/b;

    .line 18
    .line 19
    iput-object v0, p0, Lo2/d$a;->h:[Lee/b;

    .line 20
    .line 21
    iget-object v0, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    add-int/lit8 v0, v0, -0x1

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    new-array v0, v0, [Lee/b;

    .line 35
    .line 36
    iput-object v0, p0, Lo2/d$a;->i:[Lee/b;

    .line 37
    .line 38
    :goto_25
    iget-object v0, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 39
    .line 40
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-ge v1, v0, :cond_62

    .line 45
    .line 46
    iget-object v0, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 47
    .line 48
    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast v0, Lcom/google/android/gms/maps/model/LatLng;

    .line 53
    .line 54
    iget-object v2, p0, Lo2/d$a;->g:[Lcom/google/android/gms/maps/model/LatLng;

    .line 55
    .line 56
    aput-object v0, v2, v1

    .line 57
    .line 58
    iget-object v2, p0, Lo2/d$a;->h:[Lee/b;

    .line 59
    .line 60
    iget-object v3, p0, Lo2/d$a;->f:Lge/b;

    .line 61
    .line 62
    invoke-virtual {v3, v0}, Lge/b;->a(Lcom/google/android/gms/maps/model/LatLng;)Lge/a;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    aput-object v3, v2, v1

    .line 67
    .line 68
    if-lez v1, :cond_5f

    .line 69
    .line 70
    iget-object v2, p0, Lo2/d$a;->a:Ljava/util/List;

    .line 71
    .line 72
    add-int/lit8 v3, v1, -0x1

    .line 73
    .line 74
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    check-cast v2, Lcom/google/android/gms/maps/model/LatLng;

    .line 79
    .line 80
    const-wide/high16 v4, 0x3fe0000000000000L    # 0.5

    .line 81
    .line 82
    invoke-static {v2, v0, v4, v5}, Lae/d;->c(Lcom/google/android/gms/maps/model/LatLng;Lcom/google/android/gms/maps/model/LatLng;D)Lcom/google/android/gms/maps/model/LatLng;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    iget-object v2, p0, Lo2/d$a;->i:[Lee/b;

    .line 87
    .line 88
    iget-object v4, p0, Lo2/d$a;->f:Lge/b;

    .line 89
    .line 90
    invoke-virtual {v4, v0}, Lge/b;->a(Lcom/google/android/gms/maps/model/LatLng;)Lge/a;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    aput-object v0, v2, v3

    .line 95
    .line 96
    :cond_5f
    add-int/lit8 v1, v1, 0x1

    .line 97
    .line 98
    goto :goto_25

    .line 99
    :cond_62
    return-void
.end method

.method public b(Landroid/graphics/Canvas;Landroid/graphics/Matrix;Landroid/graphics/Paint;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;FF)V
    .registers 21

    .line 1
    move-object v0, p2

    .line 2
    move-object/from16 v3, p5

    .line 3
    .line 4
    move-object/from16 v4, p6

    .line 5
    .line 6
    move/from16 v5, p7

    .line 7
    .line 8
    cmpl-float v1, v5, p8

    .line 9
    .line 10
    if-nez v1, :cond_19

    .line 11
    .line 12
    move-object v0, p0

    .line 13
    move-object v1, p1

    .line 14
    move-object/from16 v2, p4

    .line 15
    .line 16
    move-object/from16 v3, p5

    .line 17
    .line 18
    move-object/from16 v4, p6

    .line 19
    .line 20
    move/from16 v5, p7

    .line 21
    .line 22
    invoke-virtual/range {v0 .. v5}, Lo2/d$a;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;F)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    invoke-virtual {p2}, Landroid/graphics/Matrix;->reset()V

    .line 27
    .line 28
    .line 29
    iget-wide v1, v4, Lo2/d$b;->b:D

    .line 30
    .line 31
    iget-wide v6, v3, Lo2/d$b;->b:D

    .line 32
    .line 33
    sub-double/2addr v1, v6

    .line 34
    iget-wide v6, v4, Lo2/d$b;->a:D

    .line 35
    .line 36
    iget-wide v8, v3, Lo2/d$b;->a:D

    .line 37
    .line 38
    sub-double/2addr v6, v8

    .line 39
    invoke-static {v1, v2, v6, v7}, Ljava/lang/Math;->atan2(DD)D

    .line 40
    .line 41
    .line 42
    move-result-wide v1

    .line 43
    invoke-static {v1, v2}, Ljava/lang/Math;->toDegrees(D)D

    .line 44
    .line 45
    .line 46
    move-result-wide v1

    .line 47
    double-to-float v1, v1

    .line 48
    iget-wide v6, v3, Lo2/d$b;->a:D

    .line 49
    .line 50
    double-to-float v2, v6

    .line 51
    iget-wide v6, v3, Lo2/d$b;->b:D

    .line 52
    .line 53
    double-to-float v6, v6

    .line 54
    invoke-virtual {p2, v1, v2, v6}, Landroid/graphics/Matrix;->preRotate(FFF)Z

    .line 55
    .line 56
    .line 57
    iget-wide v1, v3, Lo2/d$b;->a:D

    .line 58
    .line 59
    double-to-float v1, v1

    .line 60
    iget-wide v6, v3, Lo2/d$b;->b:D

    .line 61
    .line 62
    double-to-float v2, v6

    .line 63
    invoke-virtual {p2, v1, v2}, Landroid/graphics/Matrix;->preTranslate(FF)Z

    .line 64
    .line 65
    .line 66
    iget-wide v1, v4, Lo2/d$b;->a:D

    .line 67
    .line 68
    iget-wide v6, v3, Lo2/d$b;->a:D

    .line 69
    .line 70
    sub-double/2addr v1, v6

    .line 71
    const-wide/high16 v6, 0x4000000000000000L    # 2.0

    .line 72
    .line 73
    invoke-static {v1, v2, v6, v7}, Ljava/lang/Math;->pow(DD)D

    .line 74
    .line 75
    .line 76
    move-result-wide v1

    .line 77
    iget-wide v8, v4, Lo2/d$b;->b:D

    .line 78
    .line 79
    iget-wide v10, v3, Lo2/d$b;->b:D

    .line 80
    .line 81
    sub-double/2addr v8, v10

    .line 82
    invoke-static {v8, v9, v6, v7}, Ljava/lang/Math;->pow(DD)D

    .line 83
    .line 84
    .line 85
    move-result-wide v6

    .line 86
    add-double/2addr v1, v6

    .line 87
    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    .line 88
    .line 89
    .line 90
    move-result-wide v1

    .line 91
    double-to-float v1, v1

    .line 92
    invoke-virtual {p2, v1, v1}, Landroid/graphics/Matrix;->preScale(FF)Z

    .line 93
    .line 94
    .line 95
    const/high16 v1, 0x3f800000    # 1.0f

    .line 96
    .line 97
    sub-float v2, p8, v5

    .line 98
    .line 99
    div-float/2addr v1, v2

    .line 100
    invoke-virtual {p2, v1, v1}, Landroid/graphics/Matrix;->preScale(FF)Z

    .line 101
    .line 102
    .line 103
    neg-float v1, v5

    .line 104
    const/4 v2, 0x0

    .line 105
    invoke-virtual {p2, v1, v2}, Landroid/graphics/Matrix;->preTranslate(FF)Z

    .line 106
    .line 107
    .line 108
    invoke-virtual {p3}, Landroid/graphics/Paint;->getShader()Landroid/graphics/Shader;

    .line 109
    .line 110
    .line 111
    move-result-object v1

    .line 112
    invoke-virtual {v1, p2}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 113
    .line 114
    .line 115
    iget-wide v0, v3, Lo2/d$b;->a:D

    .line 116
    .line 117
    double-to-float v0, v0

    .line 118
    iget-wide v1, v3, Lo2/d$b;->b:D

    .line 119
    .line 120
    double-to-float v1, v1

    .line 121
    iget-wide v2, v4, Lo2/d$b;->a:D

    .line 122
    .line 123
    double-to-float v5, v2

    .line 124
    iget-wide v2, v4, Lo2/d$b;->b:D

    .line 125
    .line 126
    double-to-float v6, v2

    .line 127
    move-object v2, p1

    .line 128
    move v3, v0

    .line 129
    move v4, v1

    .line 130
    move-object v7, p3

    .line 131
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 132
    .line 133
    .line 134
    return-void
.end method

.method public c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;F)V
    .registers 14

    .line 1
    iget-object v0, p0, Lo2/d$a;->b:[I

    .line 2
    .line 3
    invoke-static {v0, p5}, Lo2/d;->d([IF)I

    .line 4
    .line 5
    .line 6
    move-result p5

    .line 7
    invoke-virtual {p2, p5}, Landroid/graphics/Paint;->setColor(I)V

    .line 8
    .line 9
    .line 10
    iget-wide v0, p3, Lo2/d$b;->a:D

    .line 11
    .line 12
    double-to-float v3, v0

    .line 13
    iget-wide v0, p3, Lo2/d$b;->b:D

    .line 14
    .line 15
    double-to-float v4, v0

    .line 16
    iget-wide v0, p4, Lo2/d$b;->a:D

    .line 17
    .line 18
    double-to-float v5, v0

    .line 19
    iget-wide p3, p4, Lo2/d$b;->b:D

    .line 20
    .line 21
    double-to-float v6, p3

    .line 22
    move-object v2, p1

    .line 23
    move-object v7, p2

    .line 24
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public d(Landroid/graphics/Canvas;Landroid/graphics/Matrix;Landroid/graphics/Paint;Landroid/graphics/Paint;FII)V
    .registers 30

    .line 1
    move-object/from16 v9, p0

    .line 2
    .line 3
    move-object/from16 v10, p1

    .line 4
    .line 5
    move-object/from16 v11, p4

    .line 6
    .line 7
    new-instance v12, Lo2/d$b;

    .line 8
    .line 9
    invoke-direct {v12}, Lo2/d$b;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance v13, Lo2/d$b;

    .line 13
    .line 14
    invoke-direct {v13}, Lo2/d$b;-><init>()V

    .line 15
    .line 16
    .line 17
    new-instance v14, Lo2/d$b;

    .line 18
    .line 19
    invoke-direct {v14}, Lo2/d$b;-><init>()V

    .line 20
    .line 21
    .line 22
    new-instance v15, Lo2/d$b;

    .line 23
    .line 24
    invoke-direct {v15}, Lo2/d$b;-><init>()V

    .line 25
    .line 26
    .line 27
    new-instance v16, Lo2/d$b;

    .line 28
    .line 29
    invoke-direct/range {v16 .. v16}, Lo2/d$b;-><init>()V

    .line 30
    .line 31
    .line 32
    iget-object v0, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 33
    .line 34
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    const/high16 v8, 0x3f800000    # 1.0f

    .line 39
    .line 40
    const/4 v1, 0x0

    .line 41
    const/high16 v17, 0x40000000    # 2.0f

    .line 42
    .line 43
    const/4 v7, 0x1

    .line 44
    if-ne v0, v7, :cond_60

    .line 45
    .line 46
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 47
    .line 48
    aget-object v1, v0, v1

    .line 49
    .line 50
    iget v5, v9, Lo2/d$a;->e:I

    .line 51
    .line 52
    move-object v0, v12

    .line 53
    move/from16 v2, p5

    .line 54
    .line 55
    move/from16 v3, p6

    .line 56
    .line 57
    move/from16 v4, p7

    .line 58
    .line 59
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 60
    .line 61
    .line 62
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 63
    .line 64
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 65
    .line 66
    .line 67
    iget-object v0, v9, Lo2/d$a;->b:[I

    .line 68
    .line 69
    invoke-static {v0, v8}, Lo2/d;->d([IF)I

    .line 70
    .line 71
    .line 72
    move-result v0

    .line 73
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 74
    .line 75
    .line 76
    iget-wide v0, v12, Lo2/d$b;->a:D

    .line 77
    .line 78
    double-to-float v0, v0

    .line 79
    iget-wide v1, v12, Lo2/d$b;->b:D

    .line 80
    .line 81
    double-to-float v1, v1

    .line 82
    invoke-virtual/range {p4 .. p4}, Landroid/graphics/Paint;->getStrokeWidth()F

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    div-float v2, v2, v17

    .line 87
    .line 88
    invoke-virtual {v10, v0, v1, v2, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 89
    .line 90
    .line 91
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 92
    .line 93
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :cond_60
    iget-object v0, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 98
    .line 99
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    const/4 v2, 0x2

    .line 104
    if-ne v0, v2, :cond_90

    .line 105
    .line 106
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 107
    .line 108
    aget-object v1, v0, v1

    .line 109
    .line 110
    iget v5, v9, Lo2/d$a;->e:I

    .line 111
    .line 112
    move-object v0, v12

    .line 113
    move/from16 v2, p5

    .line 114
    .line 115
    move/from16 v3, p6

    .line 116
    .line 117
    move/from16 v4, p7

    .line 118
    .line 119
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 120
    .line 121
    .line 122
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 123
    .line 124
    aget-object v1, v0, v7

    .line 125
    .line 126
    iget v5, v9, Lo2/d$a;->e:I

    .line 127
    .line 128
    move-object v0, v13

    .line 129
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 130
    .line 131
    .line 132
    const/4 v5, 0x0

    .line 133
    move-object/from16 v0, p0

    .line 134
    .line 135
    move-object/from16 v1, p1

    .line 136
    .line 137
    move-object/from16 v2, p4

    .line 138
    .line 139
    move-object v3, v12

    .line 140
    move-object v4, v13

    .line 141
    invoke-virtual/range {v0 .. v5}, Lo2/d$a;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;F)V

    .line 142
    .line 143
    .line 144
    return-void

    .line 145
    :cond_90
    const/4 v6, 0x2

    .line 146
    :goto_91
    iget-object v0, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 147
    .line 148
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-ge v6, v0, :cond_166

    .line 153
    .line 154
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 155
    .line 156
    add-int/lit8 v18, v6, -0x2

    .line 157
    .line 158
    aget-object v1, v0, v18

    .line 159
    .line 160
    iget v5, v9, Lo2/d$a;->e:I

    .line 161
    .line 162
    move-object v0, v12

    .line 163
    move/from16 v2, p5

    .line 164
    .line 165
    move/from16 v3, p6

    .line 166
    .line 167
    move/from16 v4, p7

    .line 168
    .line 169
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 170
    .line 171
    .line 172
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 173
    .line 174
    add-int/lit8 v19, v6, -0x1

    .line 175
    .line 176
    aget-object v1, v0, v19

    .line 177
    .line 178
    iget v5, v9, Lo2/d$a;->e:I

    .line 179
    .line 180
    move-object v0, v13

    .line 181
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 182
    .line 183
    .line 184
    iget-object v0, v9, Lo2/d$a;->h:[Lee/b;

    .line 185
    .line 186
    aget-object v1, v0, v6

    .line 187
    .line 188
    iget v5, v9, Lo2/d$a;->e:I

    .line 189
    .line 190
    move-object v0, v14

    .line 191
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 192
    .line 193
    .line 194
    iget-object v0, v9, Lo2/d$a;->i:[Lee/b;

    .line 195
    .line 196
    aget-object v1, v0, v18

    .line 197
    .line 198
    iget v5, v9, Lo2/d$a;->e:I

    .line 199
    .line 200
    move-object v0, v15

    .line 201
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 202
    .line 203
    .line 204
    iget-object v0, v9, Lo2/d$a;->i:[Lee/b;

    .line 205
    .line 206
    aget-object v1, v0, v19

    .line 207
    .line 208
    iget v5, v9, Lo2/d$a;->e:I

    .line 209
    .line 210
    move-object/from16 v0, v16

    .line 211
    .line 212
    invoke-virtual/range {v0 .. v5}, Lo2/d$b;->a(Lee/b;FIII)Lo2/d$b;

    .line 213
    .line 214
    .line 215
    int-to-float v0, v6

    .line 216
    sub-float v1, v0, v17

    .line 217
    .line 218
    iget-object v2, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 219
    .line 220
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 221
    .line 222
    .line 223
    move-result v2

    .line 224
    int-to-float v2, v2

    .line 225
    div-float v19, v1, v2

    .line 226
    .line 227
    sub-float/2addr v0, v8

    .line 228
    iget-object v1, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 229
    .line 230
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 231
    .line 232
    .line 233
    move-result v1

    .line 234
    int-to-float v1, v1

    .line 235
    div-float v20, v0, v1

    .line 236
    .line 237
    add-float v0, v19, v20

    .line 238
    .line 239
    div-float v5, v0, v17

    .line 240
    .line 241
    invoke-static {v5}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    const-string v1, "AirMapGradientPolyline"

    .line 246
    .line 247
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 248
    .line 249
    .line 250
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    .line 251
    .line 252
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 253
    .line 254
    .line 255
    iget-object v0, v9, Lo2/d$a;->b:[I

    .line 256
    .line 257
    invoke-static {v0, v5}, Lo2/d;->d([IF)I

    .line 258
    .line 259
    .line 260
    move-result v0

    .line 261
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 262
    .line 263
    .line 264
    iget-wide v0, v13, Lo2/d$b;->a:D

    .line 265
    .line 266
    double-to-float v0, v0

    .line 267
    iget-wide v1, v13, Lo2/d$b;->b:D

    .line 268
    .line 269
    double-to-float v1, v1

    .line 270
    invoke-virtual/range {p4 .. p4}, Landroid/graphics/Paint;->getStrokeWidth()F

    .line 271
    .line 272
    .line 273
    move-result v2

    .line 274
    div-float v2, v2, v17

    .line 275
    .line 276
    invoke-virtual {v10, v0, v1, v2, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 277
    .line 278
    .line 279
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 280
    .line 281
    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 282
    .line 283
    .line 284
    if-nez v18, :cond_120

    .line 285
    .line 286
    move-object/from16 v18, v12

    .line 287
    .line 288
    goto :goto_122

    .line 289
    :cond_120
    move-object/from16 v18, v15

    .line 290
    .line 291
    :goto_122
    move-object/from16 v0, p0

    .line 292
    .line 293
    move-object/from16 v1, p1

    .line 294
    .line 295
    move-object/from16 v2, p2

    .line 296
    .line 297
    move-object/from16 v3, p3

    .line 298
    .line 299
    move-object/from16 v4, p4

    .line 300
    .line 301
    move/from16 v21, v5

    .line 302
    .line 303
    move-object/from16 v5, v18

    .line 304
    .line 305
    move v10, v6

    .line 306
    move-object v6, v13

    .line 307
    const/16 v18, 0x1

    .line 308
    .line 309
    move/from16 v7, v19

    .line 310
    .line 311
    const/high16 v19, 0x3f800000    # 1.0f

    .line 312
    .line 313
    move/from16 v8, v21

    .line 314
    .line 315
    invoke-virtual/range {v0 .. v8}, Lo2/d$a;->b(Landroid/graphics/Canvas;Landroid/graphics/Matrix;Landroid/graphics/Paint;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;FF)V

    .line 316
    .line 317
    .line 318
    iget-object v0, v9, Lo2/d$a;->a:Ljava/util/List;

    .line 319
    .line 320
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 321
    .line 322
    .line 323
    move-result v0

    .line 324
    add-int/lit8 v0, v0, -0x1

    .line 325
    .line 326
    if-ne v10, v0, :cond_149

    .line 327
    .line 328
    move-object v6, v14

    .line 329
    goto :goto_14b

    .line 330
    :cond_149
    move-object/from16 v6, v16

    .line 331
    .line 332
    :goto_14b
    move-object/from16 v0, p0

    .line 333
    .line 334
    move-object/from16 v1, p1

    .line 335
    .line 336
    move-object/from16 v2, p2

    .line 337
    .line 338
    move-object/from16 v3, p3

    .line 339
    .line 340
    move-object/from16 v4, p4

    .line 341
    .line 342
    move-object v5, v13

    .line 343
    move/from16 v7, v21

    .line 344
    .line 345
    move/from16 v8, v20

    .line 346
    .line 347
    invoke-virtual/range {v0 .. v8}, Lo2/d$a;->b(Landroid/graphics/Canvas;Landroid/graphics/Matrix;Landroid/graphics/Paint;Landroid/graphics/Paint;Lo2/d$b;Lo2/d$b;FF)V

    .line 348
    .line 349
    .line 350
    add-int/lit8 v6, v10, 0x1

    .line 351
    .line 352
    move-object/from16 v10, p1

    .line 353
    .line 354
    const/4 v7, 0x1

    .line 355
    const/high16 v8, 0x3f800000    # 1.0f

    .line 356
    .line 357
    goto/16 :goto_91

    .line 358
    .line 359
    :cond_166
    return-void
.end method

.method public getTile(III)Lcom/google/android/gms/maps/model/Tile;
    .registers 22

    .line 1
    move-object/from16 v8, p0

    .line 2
    .line 3
    iget v0, v8, Lo2/d$a;->e:I

    .line 4
    .line 5
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 6
    .line 7
    invoke-static {v0, v0, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 8
    .line 9
    .line 10
    move-result-object v9

    .line 11
    new-instance v1, Landroid/graphics/Canvas;

    .line 12
    .line 13
    invoke-direct {v1, v9}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 14
    .line 15
    .line 16
    new-instance v2, Landroid/graphics/Matrix;

    .line 17
    .line 18
    invoke-direct {v2}, Landroid/graphics/Matrix;-><init>()V

    .line 19
    .line 20
    .line 21
    new-instance v3, Landroid/graphics/Paint;

    .line 22
    .line 23
    invoke-direct {v3}, Landroid/graphics/Paint;-><init>()V

    .line 24
    .line 25
    .line 26
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 27
    .line 28
    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 29
    .line 30
    .line 31
    iget v0, v8, Lo2/d$a;->c:F

    .line 32
    .line 33
    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 34
    .line 35
    .line 36
    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    .line 37
    .line 38
    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 39
    .line 40
    .line 41
    sget-object v0, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    .line 42
    .line 43
    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 44
    .line 45
    .line 46
    const/4 v0, 0x1

    .line 47
    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setFlags(I)V

    .line 48
    .line 49
    .line 50
    new-instance v4, Landroid/graphics/LinearGradient;

    .line 51
    .line 52
    iget-object v15, v8, Lo2/d$a;->b:[I

    .line 53
    .line 54
    sget-object v17, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 55
    .line 56
    const/4 v11, 0x0

    .line 57
    const/4 v12, 0x0

    .line 58
    const/high16 v13, 0x3f800000    # 1.0f

    .line 59
    .line 60
    const/4 v14, 0x0

    .line 61
    const/16 v16, 0x0

    .line 62
    .line 63
    move-object v10, v4

    .line 64
    invoke-direct/range {v10 .. v17}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 68
    .line 69
    .line 70
    invoke-virtual {v3}, Landroid/graphics/Paint;->getShader()Landroid/graphics/Shader;

    .line 71
    .line 72
    .line 73
    move-result-object v4

    .line 74
    invoke-virtual {v4, v2}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 75
    .line 76
    .line 77
    new-instance v4, Landroid/graphics/Paint;

    .line 78
    .line 79
    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    .line 80
    .line 81
    .line 82
    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 83
    .line 84
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 85
    .line 86
    .line 87
    iget v5, v8, Lo2/d$a;->c:F

    .line 88
    .line 89
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 90
    .line 91
    .line 92
    sget-object v5, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    .line 93
    .line 94
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 95
    .line 96
    .line 97
    sget-object v5, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    .line 98
    .line 99
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setFlags(I)V

    .line 103
    .line 104
    .line 105
    move/from16 v0, p3

    .line 106
    .line 107
    int-to-double v5, v0

    .line 108
    const-wide/high16 v10, 0x4000000000000000L    # 2.0

    .line 109
    .line 110
    invoke-static {v10, v11, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 111
    .line 112
    .line 113
    move-result-wide v5

    .line 114
    iget v0, v8, Lo2/d$a;->d:F

    .line 115
    .line 116
    float-to-double v10, v0

    .line 117
    mul-double v5, v5, v10

    .line 118
    .line 119
    double-to-float v5, v5

    .line 120
    move-object/from16 v0, p0

    .line 121
    .line 122
    move/from16 v6, p1

    .line 123
    .line 124
    move/from16 v7, p2

    .line 125
    .line 126
    invoke-virtual/range {v0 .. v7}, Lo2/d$a;->d(Landroid/graphics/Canvas;Landroid/graphics/Matrix;Landroid/graphics/Paint;Landroid/graphics/Paint;FII)V

    .line 127
    .line 128
    .line 129
    new-instance v0, Ljava/io/ByteArrayOutputStream;

    .line 130
    .line 131
    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 132
    .line 133
    .line 134
    sget-object v1, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 135
    .line 136
    const/16 v2, 0x64

    .line 137
    .line 138
    invoke-virtual {v9, v1, v2, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 139
    .line 140
    .line 141
    new-instance v1, Lcom/google/android/gms/maps/model/Tile;

    .line 142
    .line 143
    iget v2, v8, Lo2/d$a;->e:I

    .line 144
    .line 145
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 146
    .line 147
    .line 148
    move-result-object v0

    .line 149
    invoke-direct {v1, v2, v2, v0}, Lcom/google/android/gms/maps/model/Tile;-><init>(II[B)V

    .line 150
    .line 151
    .line 152
    return-object v1
.end method

###### Class o2.d.b (o2.d$b)
.class public Lo2/d$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lo2/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public a:D

.field public b:D


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lee/b;FIII)Lo2/d$b;
    .registers 10

    .line 1
    iget-wide v0, p1, Lee/b;->a:D

    .line 2
    .line 3
    float-to-double v2, p2

    .line 4
    mul-double v0, v0, v2

    .line 5
    .line 6
    mul-int p3, p3, p5

    .line 7
    .line 8
    int-to-double p2, p3

    .line 9
    sub-double/2addr v0, p2

    .line 10
    iput-wide v0, p0, Lo2/d$b;->a:D

    .line 11
    .line 12
    iget-wide p1, p1, Lee/b;->b:D

    .line 13
    .line 14
    mul-double p1, p1, v2

    .line 15
    .line 16
    mul-int p4, p4, p5

    .line 17
    .line 18
    int-to-double p3, p4

    .line 19
    sub-double/2addr p1, p3

    .line 20
    iput-wide p1, p0, Lo2/d$b;->b:D

    .line 21
    .line 22
    return-object p0
.end method
