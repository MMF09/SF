###### Class o2.i (o2.i)
.class public Lo2/i;
.super Lo2/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/google/android/gms/maps/model/PolylineOptions;

.field public b:Lcom/google/android/gms/maps/model/Polyline;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;"
        }
    .end annotation
.end field

.field public d:I

.field public e:F

.field public i:Z

.field public j:Z

.field public k:F

.field public l:Lcom/google/android/gms/maps/model/Cap;

.field public m:Lcom/facebook/react/bridge/ReadableArray;

.field public n:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/PatternItem;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Lcom/google/android/gms/maps/model/RoundCap;

    .line 5
    .line 6
    invoke-direct {p1}, Lcom/google/android/gms/maps/model/RoundCap;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lo2/i;->l:Lcom/google/android/gms/maps/model/Cap;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Polyline;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/i;->getPolylineOptions()Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addPolyline(Lcom/google/android/gms/maps/model/PolylineOptions;)Lcom/google/android/gms/maps/model/Polyline;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 10
    .line 11
    iget-boolean v0, p0, Lo2/i;->i:Z

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/Polyline;->setClickable(Z)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final c()V
    .registers 6

    .line 1
    iget-object v0, p0, Lo2/i;->m:Lcom/facebook/react/bridge/ReadableArray;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    new-instance v0, Ljava/util/ArrayList;

    .line 7
    .line 8
    iget-object v1, p0, Lo2/i;->m:Lcom/facebook/react/bridge/ReadableArray;

    .line 9
    .line 10
    invoke-interface {v1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lo2/i;->n:Ljava/util/List;

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    const/4 v1, 0x0

    .line 21
    :goto_14
    iget-object v2, p0, Lo2/i;->m:Lcom/facebook/react/bridge/ReadableArray;

    .line 22
    .line 23
    invoke-interface {v2}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-ge v1, v2, :cond_51

    .line 28
    .line 29
    iget-object v2, p0, Lo2/i;->m:Lcom/facebook/react/bridge/ReadableArray;

    .line 30
    .line 31
    invoke-interface {v2, v1}, Lcom/facebook/react/bridge/ReadableArray;->getDouble(I)D

    .line 32
    .line 33
    .line 34
    move-result-wide v2

    .line 35
    double-to-float v2, v2

    .line 36
    rem-int/lit8 v3, v1, 0x2

    .line 37
    .line 38
    if-eqz v3, :cond_29

    .line 39
    .line 40
    const/4 v3, 0x1

    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    const/4 v3, 0x0

    .line 43
    :goto_2a
    if-eqz v3, :cond_37

    .line 44
    .line 45
    iget-object v3, p0, Lo2/i;->n:Ljava/util/List;

    .line 46
    .line 47
    new-instance v4, Lcom/google/android/gms/maps/model/Gap;

    .line 48
    .line 49
    invoke-direct {v4, v2}, Lcom/google/android/gms/maps/model/Gap;-><init>(F)V

    .line 50
    .line 51
    .line 52
    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    goto :goto_4e

    .line 56
    :cond_37
    iget-object v3, p0, Lo2/i;->l:Lcom/google/android/gms/maps/model/Cap;

    .line 57
    .line 58
    instance-of v3, v3, Lcom/google/android/gms/maps/model/RoundCap;

    .line 59
    .line 60
    if-eqz v3, :cond_43

    .line 61
    .line 62
    new-instance v2, Lcom/google/android/gms/maps/model/Dot;

    .line 63
    .line 64
    invoke-direct {v2}, Lcom/google/android/gms/maps/model/Dot;-><init>()V

    .line 65
    .line 66
    .line 67
    goto :goto_49

    .line 68
    :cond_43
    new-instance v3, Lcom/google/android/gms/maps/model/Dash;

    .line 69
    .line 70
    invoke-direct {v3, v2}, Lcom/google/android/gms/maps/model/Dash;-><init>(F)V

    .line 71
    .line 72
    .line 73
    move-object v2, v3

    .line 74
    :goto_49
    iget-object v3, p0, Lo2/i;->n:Ljava/util/List;

    .line 75
    .line 76
    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    :goto_4e
    add-int/lit8 v1, v1, 0x1

    .line 80
    .line 81
    goto :goto_14

    .line 82
    :cond_51
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 83
    .line 84
    if-eqz v0, :cond_5a

    .line 85
    .line 86
    iget-object v1, p0, Lo2/i;->n:Ljava/util/List;

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/Polyline;->setPattern(Ljava/util/List;)V

    .line 89
    .line 90
    .line 91
    :cond_5a
    return-void
.end method

.method public final d()Lcom/google/android/gms/maps/model/PolylineOptions;
    .registers 3

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/PolylineOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lo2/i;->c:Ljava/util/List;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->addAll(Ljava/lang/Iterable;)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 9
    .line 10
    .line 11
    iget v1, p0, Lo2/i;->d:I

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->color(I)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 14
    .line 15
    .line 16
    iget v1, p0, Lo2/i;->e:F

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->width(F)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 19
    .line 20
    .line 21
    iget-boolean v1, p0, Lo2/i;->j:Z

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->geodesic(Z)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 24
    .line 25
    .line 26
    iget v1, p0, Lo2/i;->k:F

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->zIndex(F)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Lo2/i;->l:Lcom/google/android/gms/maps/model/Cap;

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->startCap(Lcom/google/android/gms/maps/model/Cap;)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lo2/i;->l:Lcom/google/android/gms/maps/model/Cap;

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->endCap(Lcom/google/android/gms/maps/model/Cap;)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Lo2/i;->n:Ljava/util/List;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolylineOptions;->pattern(Ljava/util/List;)Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 44
    .line 45
    .line 46
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    return-object v0
.end method

.method public getPolylineOptions()Lcom/google/android/gms/maps/model/PolylineOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/i;->a:Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/i;->d()Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/i;->a:Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/i;->a:Lcom/google/android/gms/maps/model/PolylineOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setColor(I)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/i;->d:I

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setColor(I)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setCoordinates(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 10

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lo2/i;->c:Ljava/util/List;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    :goto_c
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-ge v0, v1, :cond_2f

    .line 18
    .line 19
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iget-object v2, p0, Lo2/i;->c:Ljava/util/List;

    .line 24
    .line 25
    new-instance v3, Lcom/google/android/gms/maps/model/LatLng;

    .line 26
    .line 27
    const-string v4, "latitude"

    .line 28
    .line 29
    invoke-interface {v1, v4}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 30
    .line 31
    .line 32
    move-result-wide v4

    .line 33
    const-string v6, "longitude"

    .line 34
    .line 35
    invoke-interface {v1, v6}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 36
    .line 37
    .line 38
    move-result-wide v6

    .line 39
    invoke-direct {v3, v4, v5, v6, v7}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v2, v0, v3}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    add-int/lit8 v0, v0, 0x1

    .line 46
    .line 47
    goto :goto_c

    .line 48
    :cond_2f
    iget-object p1, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 49
    .line 50
    if-eqz p1, :cond_38

    .line 51
    .line 52
    iget-object v0, p0, Lo2/i;->c:Ljava/util/List;

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/Polyline;->setPoints(Ljava/util/List;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    return-void
.end method

.method public setGeodesic(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/i;->j:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setGeodesic(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setLineCap(Lcom/google/android/gms/maps/model/Cap;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lo2/i;->l:Lcom/google/android/gms/maps/model/Cap;

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_e

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setStartCap(Lcom/google/android/gms/maps/model/Cap;)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setEndCap(Lcom/google/android/gms/maps/model/Cap;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    invoke-virtual {p0}, Lo2/i;->c()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public setLineDashPattern(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lo2/i;->m:Lcom/facebook/react/bridge/ReadableArray;

    .line 2
    .line 3
    invoke-virtual {p0}, Lo2/i;->c()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setTappable(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/i;->i:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setClickable(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setWidth(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/i;->e:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setWidth(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/i;->k:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/i;->b:Lcom/google/android/gms/maps/model/Polyline;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polyline;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method
