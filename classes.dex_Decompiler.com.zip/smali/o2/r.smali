###### Class o2.r (o2.r)
.class public Lo2/r;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)Z
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/maps/model/LatLngBounds;->getCenter()Lcom/google/android/gms/maps/model/LatLng;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    iget-wide v3, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 10
    .line 11
    iget-wide v9, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 12
    .line 13
    iget-object v2, v0, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 14
    .line 15
    iget-wide v5, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 16
    .line 17
    iget-object v7, v0, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 18
    .line 19
    iget-wide v11, v7, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 20
    .line 21
    sub-double v13, v5, v11

    .line 22
    .line 23
    iget-wide v5, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 24
    .line 25
    iget-wide v7, v7, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 26
    .line 27
    sub-double v11, v5, v7

    .line 28
    .line 29
    invoke-virtual/range {p1 .. p1}, Lcom/google/android/gms/maps/model/LatLngBounds;->getCenter()Lcom/google/android/gms/maps/model/LatLng;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    iget-wide v5, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 34
    .line 35
    iget-wide v7, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 36
    .line 37
    iget-object v2, v1, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 38
    .line 39
    move-wide v15, v7

    .line 40
    iget-wide v7, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 41
    .line 42
    iget-object v0, v1, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 43
    .line 44
    move-wide/from16 v19, v11

    .line 45
    .line 46
    iget-wide v11, v0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 47
    .line 48
    sub-double v11, v7, v11

    .line 49
    .line 50
    iget-wide v7, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 51
    .line 52
    iget-wide v0, v0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 53
    .line 54
    sub-double v0, v7, v0

    .line 55
    .line 56
    invoke-static/range {p0 .. p1}, Lo2/r;->b(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)D

    .line 57
    .line 58
    .line 59
    move-result-wide v17

    .line 60
    invoke-static/range {p0 .. p1}, Lo2/r;->c(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)D

    .line 61
    .line 62
    .line 63
    move-result-wide v21

    .line 64
    move-wide/from16 v7, v17

    .line 65
    .line 66
    invoke-static/range {v3 .. v8}, Lo2/r;->d(DDD)Z

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-nez v2, :cond_67

    .line 71
    .line 72
    move-wide v5, v9

    .line 73
    move-wide v7, v15

    .line 74
    move-wide/from16 v9, v21

    .line 75
    .line 76
    invoke-static/range {v5 .. v10}, Lo2/r;->d(DDD)Z

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    if-nez v2, :cond_67

    .line 81
    .line 82
    move-wide v15, v11

    .line 83
    invoke-static/range {v13 .. v18}, Lo2/r;->d(DDD)Z

    .line 84
    .line 85
    .line 86
    move-result v2

    .line 87
    if-nez v2, :cond_67

    .line 88
    .line 89
    move-wide/from16 v15, v19

    .line 90
    .line 91
    move-wide/from16 v17, v0

    .line 92
    .line 93
    move-wide/from16 v19, v21

    .line 94
    .line 95
    invoke-static/range {v15 .. v20}, Lo2/r;->d(DDD)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    if-eqz v0, :cond_65

    .line 100
    .line 101
    goto :goto_67

    .line 102
    :cond_65
    const/4 v0, 0x0

    .line 103
    goto :goto_68

    .line 104
    :cond_67
    :goto_67
    const/4 v0, 0x1

    .line 105
    :goto_68
    return v0
.end method

.method public static b(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)D
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    iget-wide v0, v0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 4
    .line 5
    iget-object p0, p0, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 6
    .line 7
    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 8
    .line 9
    sub-double/2addr v0, v2

    .line 10
    iget-object p0, p1, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 11
    .line 12
    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 13
    .line 14
    iget-object p0, p1, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 15
    .line 16
    iget-wide p0, p0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 17
    .line 18
    sub-double/2addr v2, p0

    .line 19
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    .line 20
    .line 21
    .line 22
    move-result-wide p0

    .line 23
    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    invoke-static {p0, p1, v0, v1}, Ljava/lang/Math;->min(DD)D

    .line 28
    .line 29
    .line 30
    move-result-wide p0

    .line 31
    const-wide/high16 v0, 0x40a4000000000000L    # 2560.0

    .line 32
    .line 33
    div-double/2addr p0, v0

    .line 34
    return-wide p0
.end method

.method public static c(Lcom/google/android/gms/maps/model/LatLngBounds;Lcom/google/android/gms/maps/model/LatLngBounds;)D
    .registers 6

    .line 1
    iget-object v0, p0, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 2
    .line 3
    iget-wide v0, v0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 4
    .line 5
    iget-object p0, p0, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 6
    .line 7
    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 8
    .line 9
    sub-double/2addr v0, v2

    .line 10
    iget-object p0, p1, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 11
    .line 12
    iget-wide v2, p0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 13
    .line 14
    iget-object p0, p1, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 15
    .line 16
    iget-wide p0, p0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 17
    .line 18
    sub-double/2addr v2, p0

    .line 19
    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    .line 20
    .line 21
    .line 22
    move-result-wide p0

    .line 23
    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    invoke-static {p0, p1, v0, v1}, Ljava/lang/Math;->min(DD)D

    .line 28
    .line 29
    .line 30
    move-result-wide p0

    .line 31
    const-wide/high16 v0, 0x40a4000000000000L    # 2560.0

    .line 32
    .line 33
    div-double/2addr p0, v0

    .line 34
    return-wide p0
.end method

.method public static d(DDD)Z
    .registers 6

    sub-double/2addr p0, p2

    invoke-static {p0, p1}, Ljava/lang/Math;->abs(D)D

    move-result-wide p0

    cmpl-double p2, p0, p4

    if-lez p2, :cond_b

    const/4 p0, 0x1

    goto :goto_c

    :cond_b
    const/4 p0, 0x0

    :goto_c
    return p0
.end method
