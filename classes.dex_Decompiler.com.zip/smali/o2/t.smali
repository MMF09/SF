###### Class o2.t (o2.t)
.class public Lo2/t;
.super Lcom/facebook/react/uimanager/events/Event;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/facebook/react/uimanager/events/Event<",
        "Lo2/t;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Lcom/google/android/gms/maps/model/LatLngBounds;

.field public final b:Z

.field public final c:Z


# direct methods
.method public constructor <init>(ILcom/google/android/gms/maps/model/LatLngBounds;ZZ)V
    .registers 5

    .line 1
    invoke-direct {p0, p1}, Lcom/facebook/react/uimanager/events/Event;-><init>(I)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lo2/t;->a:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 5
    .line 6
    iput-boolean p3, p0, Lo2/t;->b:Z

    .line 7
    .line 8
    iput-boolean p4, p0, Lo2/t;->c:Z

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public canCoalesce()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public dispatch(Lcom/facebook/react/uimanager/events/RCTEventEmitter;)V
    .registers 9

    .line 1
    new-instance v0, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-boolean v1, p0, Lo2/t;->b:Z

    .line 7
    .line 8
    const-string v2, "continuous"

    .line 9
    .line 10
    invoke-interface {v0, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 11
    .line 12
    .line 13
    new-instance v1, Lcom/facebook/react/bridge/WritableNativeMap;

    .line 14
    .line 15
    invoke-direct {v1}, Lcom/facebook/react/bridge/WritableNativeMap;-><init>()V

    .line 16
    .line 17
    .line 18
    iget-object v2, p0, Lo2/t;->a:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 19
    .line 20
    invoke-virtual {v2}, Lcom/google/android/gms/maps/model/LatLngBounds;->getCenter()Lcom/google/android/gms/maps/model/LatLng;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    iget-wide v3, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 25
    .line 26
    const-string v5, "latitude"

    .line 27
    .line 28
    invoke-interface {v1, v5, v3, v4}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 29
    .line 30
    .line 31
    iget-wide v2, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 32
    .line 33
    const-string v4, "longitude"

    .line 34
    .line 35
    invoke-interface {v1, v4, v2, v3}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 36
    .line 37
    .line 38
    iget-object v2, p0, Lo2/t;->a:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 39
    .line 40
    iget-object v3, v2, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 41
    .line 42
    iget-wide v3, v3, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 43
    .line 44
    iget-object v2, v2, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 45
    .line 46
    iget-wide v5, v2, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    .line 47
    .line 48
    sub-double/2addr v3, v5

    .line 49
    const-string v2, "latitudeDelta"

    .line 50
    .line 51
    invoke-interface {v1, v2, v3, v4}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 52
    .line 53
    .line 54
    iget-object v2, p0, Lo2/t;->a:Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 55
    .line 56
    iget-object v3, v2, Lcom/google/android/gms/maps/model/LatLngBounds;->northeast:Lcom/google/android/gms/maps/model/LatLng;

    .line 57
    .line 58
    iget-wide v3, v3, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 59
    .line 60
    iget-object v2, v2, Lcom/google/android/gms/maps/model/LatLngBounds;->southwest:Lcom/google/android/gms/maps/model/LatLng;

    .line 61
    .line 62
    iget-wide v5, v2, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    .line 63
    .line 64
    sub-double/2addr v3, v5

    .line 65
    const-string v2, "longitudeDelta"

    .line 66
    .line 67
    invoke-interface {v1, v2, v3, v4}, Lcom/facebook/react/bridge/WritableMap;->putDouble(Ljava/lang/String;D)V

    .line 68
    .line 69
    .line 70
    const-string v2, "region"

    .line 71
    .line 72
    invoke-interface {v0, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putMap(Ljava/lang/String;Lcom/facebook/react/bridge/ReadableMap;)V

    .line 73
    .line 74
    .line 75
    iget-boolean v1, p0, Lo2/t;->c:Z

    .line 76
    .line 77
    const-string v2, "isGesture"

    .line 78
    .line 79
    invoke-interface {v0, v2, v1}, Lcom/facebook/react/bridge/WritableMap;->putBoolean(Ljava/lang/String;Z)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, Lcom/facebook/react/uimanager/events/Event;->getViewTag()I

    .line 83
    .line 84
    .line 85
    move-result v1

    .line 86
    invoke-virtual {p0}, Lo2/t;->getEventName()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-interface {p1, v1, v2, v0}, Lcom/facebook/react/uimanager/events/RCTEventEmitter;->receiveEvent(ILjava/lang/String;Lcom/facebook/react/bridge/WritableMap;)V

    .line 91
    .line 92
    .line 93
    return-void
.end method

.method public getEventName()Ljava/lang/String;
    .registers 2

    const-string v0, "topChange"

    return-object v0
.end method
