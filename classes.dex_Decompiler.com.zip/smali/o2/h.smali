###### Class o2.h (o2.h)
.class public Lo2/h;
.super Lo2/c;
.source "SourceFile"


# instance fields
.field public a:Lcom/google/android/gms/maps/model/PolygonOptions;

.field public b:Lcom/google/android/gms/maps/model/Polygon;

.field public c:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;"
        }
    .end annotation
.end field

.field public d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Lcom/google/android/gms/maps/model/LatLng;",
            ">;>;"
        }
    .end annotation
.end field

.field public e:I

.field public i:I

.field public j:F

.field public k:Z

.field public l:Z

.field public m:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lo2/c;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 2

    iget-object p1, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    invoke-virtual {p1}, Lcom/google/android/gms/maps/model/Polygon;->remove()V

    return-void
.end method

.method public b(Lcom/google/android/gms/maps/GoogleMap;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lo2/h;->getPolygonOptions()Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/GoogleMap;->addPolygon(Lcom/google/android/gms/maps/model/PolygonOptions;)Lcom/google/android/gms/maps/model/Polygon;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iput-object p1, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 10
    .line 11
    iget-boolean v0, p0, Lo2/h;->l:Z

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/Polygon;->setClickable(Z)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final c()Lcom/google/android/gms/maps/model/PolygonOptions;
    .registers 4

    .line 1
    new-instance v0, Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/google/android/gms/maps/model/PolygonOptions;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lo2/h;->c:Ljava/util/List;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->addAll(Ljava/lang/Iterable;)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 9
    .line 10
    .line 11
    iget v1, p0, Lo2/h;->i:I

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->fillColor(I)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 14
    .line 15
    .line 16
    iget v1, p0, Lo2/h;->e:I

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->strokeColor(I)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 19
    .line 20
    .line 21
    iget v1, p0, Lo2/h;->j:F

    .line 22
    .line 23
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->strokeWidth(F)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 24
    .line 25
    .line 26
    iget-boolean v1, p0, Lo2/h;->k:Z

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->geodesic(Z)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 29
    .line 30
    .line 31
    iget v1, p0, Lo2/h;->m:F

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/PolygonOptions;->zIndex(F)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lo2/h;->d:Ljava/util/List;

    .line 37
    .line 38
    if-eqz v1, :cond_3e

    .line 39
    .line 40
    const/4 v1, 0x0

    .line 41
    :goto_28
    iget-object v2, p0, Lo2/h;->d:Ljava/util/List;

    .line 42
    .line 43
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-ge v1, v2, :cond_3e

    .line 48
    .line 49
    iget-object v2, p0, Lo2/h;->d:Ljava/util/List;

    .line 50
    .line 51
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    check-cast v2, Ljava/lang/Iterable;

    .line 56
    .line 57
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/PolygonOptions;->addHole(Ljava/lang/Iterable;)Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 58
    .line 59
    .line 60
    add-int/lit8 v1, v1, 0x1

    .line 61
    .line 62
    goto :goto_28

    .line 63
    :cond_3e
    return-object v0
.end method

.method public getFeature()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    return-object v0
.end method

.method public getPolygonOptions()Lcom/google/android/gms/maps/model/PolygonOptions;
    .registers 2

    .line 1
    iget-object v0, p0, Lo2/h;->a:Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, Lo2/h;->c()Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Lo2/h;->a:Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, Lo2/h;->a:Lcom/google/android/gms/maps/model/PolygonOptions;

    .line 12
    .line 13
    return-object v0
.end method

.method public setCoordinates(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 10

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lo2/h;->c:Ljava/util/List;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    :goto_c
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-ge v0, v1, :cond_2f

    .line 18
    .line 19
    invoke-interface {p1, v0}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    iget-object v2, p0, Lo2/h;->c:Ljava/util/List;

    .line 24
    .line 25
    new-instance v3, Lcom/google/android/gms/maps/model/LatLng;

    .line 26
    .line 27
    const-string v4, "latitude"

    .line 28
    .line 29
    invoke-interface {v1, v4}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 30
    .line 31
    .line 32
    move-result-wide v4

    .line 33
    const-string v6, "longitude"

    .line 34
    .line 35
    invoke-interface {v1, v6}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 36
    .line 37
    .line 38
    move-result-wide v6

    .line 39
    invoke-direct {v3, v4, v5, v6, v7}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 40
    .line 41
    .line 42
    invoke-interface {v2, v0, v3}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    add-int/lit8 v0, v0, 0x1

    .line 46
    .line 47
    goto :goto_c

    .line 48
    :cond_2f
    iget-object p1, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 49
    .line 50
    if-eqz p1, :cond_38

    .line 51
    .line 52
    iget-object v0, p0, Lo2/h;->c:Ljava/util/List;

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/Polygon;->setPoints(Ljava/util/List;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    return-void
.end method

.method public setFillColor(I)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/h;->i:I

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setFillColor(I)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setGeodesic(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/h;->k:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setGeodesic(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setHoles(Lcom/facebook/react/bridge/ReadableArray;)V
    .registers 14

    .line 1
    if-nez p1, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lo2/h;->d:Ljava/util/List;

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    const/4 v1, 0x0

    .line 17
    :goto_10
    invoke-interface {p1}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-ge v1, v2, :cond_60

    .line 22
    .line 23
    invoke-interface {p1, v1}, Lcom/facebook/react/bridge/ReadableArray;->getArray(I)Lcom/facebook/react/bridge/ReadableArray;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-interface {v2}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const/4 v4, 0x3

    .line 32
    if-ge v3, v4, :cond_22

    .line 33
    .line 34
    goto :goto_5d

    .line 35
    :cond_22
    new-instance v3, Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 38
    .line 39
    .line 40
    const/4 v5, 0x0

    .line 41
    :goto_28
    invoke-interface {v2}, Lcom/facebook/react/bridge/ReadableArray;->size()I

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    if-ge v5, v6, :cond_49

    .line 46
    .line 47
    invoke-interface {v2, v5}, Lcom/facebook/react/bridge/ReadableArray;->getMap(I)Lcom/facebook/react/bridge/ReadableMap;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    new-instance v7, Lcom/google/android/gms/maps/model/LatLng;

    .line 52
    .line 53
    const-string v8, "latitude"

    .line 54
    .line 55
    invoke-interface {v6, v8}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 56
    .line 57
    .line 58
    move-result-wide v8

    .line 59
    const-string v10, "longitude"

    .line 60
    .line 61
    invoke-interface {v6, v10}, Lcom/facebook/react/bridge/ReadableMap;->getDouble(Ljava/lang/String;)D

    .line 62
    .line 63
    .line 64
    move-result-wide v10

    .line 65
    invoke-direct {v7, v8, v9, v10, v11}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 66
    .line 67
    .line 68
    invoke-interface {v3, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    add-int/lit8 v5, v5, 0x1

    .line 72
    .line 73
    goto :goto_28

    .line 74
    :cond_49
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    if-ne v2, v4, :cond_58

    .line 79
    .line 80
    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    check-cast v2, Lcom/google/android/gms/maps/model/LatLng;

    .line 85
    .line 86
    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    :cond_58
    iget-object v2, p0, Lo2/h;->d:Ljava/util/List;

    .line 90
    .line 91
    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    :goto_5d
    add-int/lit8 v1, v1, 0x1

    .line 95
    .line 96
    goto :goto_10

    .line 97
    :cond_60
    iget-object p1, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 98
    .line 99
    if-eqz p1, :cond_69

    .line 100
    .line 101
    iget-object v0, p0, Lo2/h;->d:Ljava/util/List;

    .line 102
    .line 103
    invoke-virtual {p1, v0}, Lcom/google/android/gms/maps/model/Polygon;->setHoles(Ljava/util/List;)V

    .line 104
    .line 105
    .line 106
    :cond_69
    return-void
.end method

.method public setStrokeColor(I)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/h;->e:I

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setStrokeColor(I)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setStrokeWidth(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/h;->j:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setStrokeWidth(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setTappable(Z)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Lo2/h;->l:Z

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setClickable(Z)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method

.method public setZIndex(F)V
    .registers 3

    .line 1
    iput p1, p0, Lo2/h;->m:F

    .line 2
    .line 3
    iget-object v0, p0, Lo2/h;->b:Lcom/google/android/gms/maps/model/Polygon;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lcom/google/android/gms/maps/model/Polygon;->setZIndex(F)V

    .line 8
    .line 9
    .line 10
    :cond_9
    return-void
.end method
