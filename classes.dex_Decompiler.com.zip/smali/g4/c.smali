###### Class g4.c (g4.c)
.class public interface abstract Lg4/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()I
.end method

.method public abstract c()I
.end method

.method public abstract d()I
.end method

.method public abstract e(Landroid/view/LayoutInflater;)Landroid/view/View;
.end method
