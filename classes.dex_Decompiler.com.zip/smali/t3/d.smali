###### Class t3.d (t3.d)
.class public Lt3/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Ljava/lang/String;

.field public static b:I


# direct methods
.method public static a(Landroid/content/Context;)Landroid/content/pm/PackageInfo;
    .registers 3

    .line 1
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const/16 v1, 0x4000

    .line 10
    .line 11
    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 12
    .line 13
    .line 14
    move-result-object p0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_e} :catch_f

    .line 15
    goto :goto_19

    .line 16
    :catch_f
    sget-object p0, Lr3/a;->c:Lcom/alibaba/android/arouter/facade/template/ILogger;

    .line 17
    .line 18
    const-string v0, "ARouter::"

    .line 19
    .line 20
    const-string v1, "Get package info error."

    .line 21
    .line 22
    invoke-interface {p0, v0, v1}, Lcom/alibaba/android/arouter/facade/template/ILogger;->error(Ljava/lang/String;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    const/4 p0, 0x0

    .line 26
    :goto_19
    return-object p0
.end method

.method public static b(Landroid/content/Context;)Z
    .registers 7

    .line 1
    invoke-static {p0}, Lt3/d;->a(Landroid/content/Context;)Landroid/content/pm/PackageInfo;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const/4 v0, 0x1

    .line 6
    if-eqz p0, :cond_2e

    .line 7
    .line 8
    iget-object v1, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    .line 9
    .line 10
    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 11
    .line 12
    const-string v2, "SP_AROUTER_CACHE"

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    invoke-static {v2, v3}, Lcom/shopee/foody/common/framework/sp/SafelySpManager;->getSafelySp(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    const/4 v4, 0x0

    .line 20
    const-string v5, "LAST_VERSION_NAME"

    .line 21
    .line 22
    invoke-interface {v2, v5, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_2a

    .line 31
    .line 32
    const/4 v4, -0x1

    .line 33
    const-string v5, "LAST_VERSION_CODE"

    .line 34
    .line 35
    invoke-interface {v2, v5, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eq p0, v2, :cond_29

    .line 40
    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    return v3

    .line 43
    :cond_2a
    :goto_2a
    sput-object v1, Lt3/d;->a:Ljava/lang/String;

    .line 44
    .line 45
    sput p0, Lt3/d;->b:I

    .line 46
    .line 47
    :cond_2e
    return v0
.end method

.method public static c(Landroid/content/Context;)V
    .registers 3

    .line 1
    sget-object p0, Lt3/d;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-nez p0, :cond_2a

    .line 8
    .line 9
    sget p0, Lt3/d;->b:I

    .line 10
    .line 11
    if-eqz p0, :cond_2a

    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    const-string v0, "SP_AROUTER_CACHE"

    .line 15
    .line 16
    invoke-static {v0, p0}, Lcom/shopee/foody/common/framework/sp/SafelySpManager;->getSafelySp(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    sget-object v0, Lt3/d;->a:Ljava/lang/String;

    .line 25
    .line 26
    const-string v1, "LAST_VERSION_NAME"

    .line 27
    .line 28
    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    sget v0, Lt3/d;->b:I

    .line 33
    .line 34
    const-string v1, "LAST_VERSION_CODE"

    .line 35
    .line 36
    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void
.end method
