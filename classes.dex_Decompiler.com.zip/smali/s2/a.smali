###### Class s2.a (s2.a)
.class public abstract Ls2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lt2/a$b;
.implements Ls2/k;
.implements Ls2/e;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Ls2/a$b;
    }
.end annotation


# instance fields
.field public final a:Landroid/graphics/PathMeasure;

.field public final b:Landroid/graphics/Path;

.field public final c:Landroid/graphics/Path;

.field public final d:Landroid/graphics/RectF;

.field public final e:Lq2/f;

.field public final f:Lcom/airbnb/lottie/model/layer/a;

.field public final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ls2/a$b;",
            ">;"
        }
    .end annotation
.end field

.field public final h:[F

.field public final i:Landroid/graphics/Paint;

.field public final j:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final k:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final l:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;>;"
        }
    .end annotation
.end field

.field public final m:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public n:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Landroid/graphics/ColorFilter;",
            "Landroid/graphics/ColorFilter;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lq2/f;Lcom/airbnb/lottie/model/layer/a;Landroid/graphics/Paint$Cap;Landroid/graphics/Paint$Join;FLw2/d;Lw2/b;Ljava/util/List;Lw2/b;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lq2/f;",
            "Lcom/airbnb/lottie/model/layer/a;",
            "Landroid/graphics/Paint$Cap;",
            "Landroid/graphics/Paint$Join;",
            "F",
            "Lw2/d;",
            "Lw2/b;",
            "Ljava/util/List<",
            "Lw2/b;",
            ">;",
            "Lw2/b;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/graphics/PathMeasure;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/graphics/PathMeasure;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 10
    .line 11
    new-instance v0, Landroid/graphics/Path;

    .line 12
    .line 13
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 17
    .line 18
    new-instance v0, Landroid/graphics/Path;

    .line 19
    .line 20
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 24
    .line 25
    new-instance v0, Landroid/graphics/RectF;

    .line 26
    .line 27
    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object v0, p0, Ls2/a;->d:Landroid/graphics/RectF;

    .line 31
    .line 32
    new-instance v0, Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object v0, p0, Ls2/a;->g:Ljava/util/List;

    .line 38
    .line 39
    new-instance v0, Lr2/a;

    .line 40
    .line 41
    const/4 v1, 0x1

    .line 42
    invoke-direct {v0, v1}, Lr2/a;-><init>(I)V

    .line 43
    .line 44
    .line 45
    iput-object v0, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 46
    .line 47
    iput-object p1, p0, Ls2/a;->e:Lq2/f;

    .line 48
    .line 49
    iput-object p2, p0, Ls2/a;->f:Lcom/airbnb/lottie/model/layer/a;

    .line 50
    .line 51
    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    .line 52
    .line 53
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setStrokeMiter(F)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p6}, Lw2/d;->a()Lt2/a;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, Ls2/a;->k:Lt2/a;

    .line 70
    .line 71
    invoke-virtual {p7}, Lw2/b;->a()Lt2/a;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    iput-object p1, p0, Ls2/a;->j:Lt2/a;

    .line 76
    .line 77
    if-nez p9, :cond_52

    .line 78
    .line 79
    const/4 p1, 0x0

    .line 80
    iput-object p1, p0, Ls2/a;->m:Lt2/a;

    .line 81
    .line 82
    goto :goto_58

    .line 83
    :cond_52
    invoke-virtual {p9}, Lw2/b;->a()Lt2/a;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    iput-object p1, p0, Ls2/a;->m:Lt2/a;

    .line 88
    .line 89
    :goto_58
    new-instance p1, Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-interface {p8}, Ljava/util/List;->size()I

    .line 92
    .line 93
    .line 94
    move-result p3

    .line 95
    invoke-direct {p1, p3}, Ljava/util/ArrayList;-><init>(I)V

    .line 96
    .line 97
    .line 98
    iput-object p1, p0, Ls2/a;->l:Ljava/util/List;

    .line 99
    .line 100
    invoke-interface {p8}, Ljava/util/List;->size()I

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    new-array p1, p1, [F

    .line 105
    .line 106
    iput-object p1, p0, Ls2/a;->h:[F

    .line 107
    .line 108
    const/4 p1, 0x0

    .line 109
    const/4 p3, 0x0

    .line 110
    :goto_6d
    invoke-interface {p8}, Ljava/util/List;->size()I

    .line 111
    .line 112
    .line 113
    move-result p4

    .line 114
    if-ge p3, p4, :cond_85

    .line 115
    .line 116
    iget-object p4, p0, Ls2/a;->l:Ljava/util/List;

    .line 117
    .line 118
    invoke-interface {p8, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object p5

    .line 122
    check-cast p5, Lw2/b;

    .line 123
    .line 124
    invoke-virtual {p5}, Lw2/b;->a()Lt2/a;

    .line 125
    .line 126
    .line 127
    move-result-object p5

    .line 128
    invoke-interface {p4, p5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    add-int/lit8 p3, p3, 0x1

    .line 132
    .line 133
    goto :goto_6d

    .line 134
    :cond_85
    iget-object p3, p0, Ls2/a;->k:Lt2/a;

    .line 135
    .line 136
    invoke-virtual {p2, p3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 137
    .line 138
    .line 139
    iget-object p3, p0, Ls2/a;->j:Lt2/a;

    .line 140
    .line 141
    invoke-virtual {p2, p3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 142
    .line 143
    .line 144
    const/4 p3, 0x0

    .line 145
    :goto_90
    iget-object p4, p0, Ls2/a;->l:Ljava/util/List;

    .line 146
    .line 147
    invoke-interface {p4}, Ljava/util/List;->size()I

    .line 148
    .line 149
    .line 150
    move-result p4

    .line 151
    if-ge p3, p4, :cond_a6

    .line 152
    .line 153
    iget-object p4, p0, Ls2/a;->l:Ljava/util/List;

    .line 154
    .line 155
    invoke-interface {p4, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p4

    .line 159
    check-cast p4, Lt2/a;

    .line 160
    .line 161
    invoke-virtual {p2, p4}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 162
    .line 163
    .line 164
    add-int/lit8 p3, p3, 0x1

    .line 165
    .line 166
    goto :goto_90

    .line 167
    :cond_a6
    iget-object p3, p0, Ls2/a;->m:Lt2/a;

    .line 168
    .line 169
    if-eqz p3, :cond_ad

    .line 170
    .line 171
    invoke-virtual {p2, p3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 172
    .line 173
    .line 174
    :cond_ad
    iget-object p2, p0, Ls2/a;->k:Lt2/a;

    .line 175
    .line 176
    invoke-virtual {p2, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 177
    .line 178
    .line 179
    iget-object p2, p0, Ls2/a;->j:Lt2/a;

    .line 180
    .line 181
    invoke-virtual {p2, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 182
    .line 183
    .line 184
    :goto_b7
    invoke-interface {p8}, Ljava/util/List;->size()I

    .line 185
    .line 186
    .line 187
    move-result p2

    .line 188
    if-ge p1, p2, :cond_cb

    .line 189
    .line 190
    iget-object p2, p0, Ls2/a;->l:Ljava/util/List;

    .line 191
    .line 192
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 193
    .line 194
    .line 195
    move-result-object p2

    .line 196
    check-cast p2, Lt2/a;

    .line 197
    .line 198
    invoke-virtual {p2, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 199
    .line 200
    .line 201
    add-int/lit8 p1, p1, 0x1

    .line 202
    .line 203
    goto :goto_b7

    .line 204
    :cond_cb
    iget-object p1, p0, Ls2/a;->m:Lt2/a;

    .line 205
    .line 206
    if-eqz p1, :cond_d2

    .line 207
    .line 208
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 209
    .line 210
    .line 211
    :cond_d2
    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/RectF;Landroid/graphics/Matrix;Z)V
    .registers 10

    .line 1
    const-string p3, "StrokeContent#getBounds"

    .line 2
    .line 3
    invoke-static {p3}, Lq2/c;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    const/4 v1, 0x0

    .line 13
    :goto_c
    iget-object v2, p0, Ls2/a;->g:Ljava/util/List;

    .line 14
    .line 15
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-ge v1, v2, :cond_40

    .line 20
    .line 21
    iget-object v2, p0, Ls2/a;->g:Ljava/util/List;

    .line 22
    .line 23
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Ls2/a$b;

    .line 28
    .line 29
    const/4 v3, 0x0

    .line 30
    :goto_1d
    invoke-static {v2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    if-ge v3, v4, :cond_3d

    .line 39
    .line 40
    iget-object v4, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 41
    .line 42
    invoke-static {v2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 43
    .line 44
    .line 45
    move-result-object v5

    .line 46
    invoke-interface {v5, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    check-cast v5, Ls2/m;

    .line 51
    .line 52
    invoke-interface {v5}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 53
    .line 54
    .line 55
    move-result-object v5

    .line 56
    invoke-virtual {v4, v5, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 57
    .line 58
    .line 59
    add-int/lit8 v3, v3, 0x1

    .line 60
    .line 61
    goto :goto_1d

    .line 62
    :cond_3d
    add-int/lit8 v1, v1, 0x1

    .line 63
    .line 64
    goto :goto_c

    .line 65
    :cond_40
    iget-object p2, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 66
    .line 67
    iget-object v1, p0, Ls2/a;->d:Landroid/graphics/RectF;

    .line 68
    .line 69
    invoke-virtual {p2, v1, v0}, Landroid/graphics/Path;->computeBounds(Landroid/graphics/RectF;Z)V

    .line 70
    .line 71
    .line 72
    iget-object p2, p0, Ls2/a;->j:Lt2/a;

    .line 73
    .line 74
    check-cast p2, Lt2/c;

    .line 75
    .line 76
    invoke-virtual {p2}, Lt2/c;->o()F

    .line 77
    .line 78
    .line 79
    move-result p2

    .line 80
    iget-object v0, p0, Ls2/a;->d:Landroid/graphics/RectF;

    .line 81
    .line 82
    iget v1, v0, Landroid/graphics/RectF;->left:F

    .line 83
    .line 84
    const/high16 v2, 0x40000000    # 2.0f

    .line 85
    .line 86
    div-float/2addr p2, v2

    .line 87
    sub-float/2addr v1, p2

    .line 88
    iget v2, v0, Landroid/graphics/RectF;->top:F

    .line 89
    .line 90
    sub-float/2addr v2, p2

    .line 91
    iget v3, v0, Landroid/graphics/RectF;->right:F

    .line 92
    .line 93
    add-float/2addr v3, p2

    .line 94
    iget v4, v0, Landroid/graphics/RectF;->bottom:F

    .line 95
    .line 96
    add-float/2addr v4, p2

    .line 97
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    .line 98
    .line 99
    .line 100
    iget-object p2, p0, Ls2/a;->d:Landroid/graphics/RectF;

    .line 101
    .line 102
    invoke-virtual {p1, p2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    .line 103
    .line 104
    .line 105
    iget p2, p1, Landroid/graphics/RectF;->left:F

    .line 106
    .line 107
    const/high16 v0, 0x3f800000    # 1.0f

    .line 108
    .line 109
    sub-float/2addr p2, v0

    .line 110
    iget v1, p1, Landroid/graphics/RectF;->top:F

    .line 111
    .line 112
    sub-float/2addr v1, v0

    .line 113
    iget v2, p1, Landroid/graphics/RectF;->right:F

    .line 114
    .line 115
    add-float/2addr v2, v0

    .line 116
    iget v3, p1, Landroid/graphics/RectF;->bottom:F

    .line 117
    .line 118
    add-float/2addr v3, v0

    .line 119
    invoke-virtual {p1, p2, v1, v2, v3}, Landroid/graphics/RectF;->set(FFFF)V

    .line 120
    .line 121
    .line 122
    invoke-static {p3}, Lq2/c;->b(Ljava/lang/String;)F

    .line 123
    .line 124
    .line 125
    return-void
.end method

.method public final b(Landroid/graphics/Matrix;)V
    .registers 7

    .line 1
    const-string v0, "StrokeContent#applyDashPattern"

    .line 2
    .line 3
    invoke-static {v0}, Lq2/c;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Ls2/a;->l:Ljava/util/List;

    .line 7
    .line 8
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_11

    .line 13
    .line 14
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    invoke-static {p1}, Lc3/j;->g(Landroid/graphics/Matrix;)F

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    const/4 v1, 0x0

    .line 23
    :goto_16
    iget-object v2, p0, Ls2/a;->l:Ljava/util/List;

    .line 24
    .line 25
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    if-ge v1, v2, :cond_5d

    .line 30
    .line 31
    iget-object v2, p0, Ls2/a;->h:[F

    .line 32
    .line 33
    iget-object v3, p0, Ls2/a;->l:Ljava/util/List;

    .line 34
    .line 35
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    check-cast v3, Lt2/a;

    .line 40
    .line 41
    invoke-virtual {v3}, Lt2/a;->h()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    check-cast v3, Ljava/lang/Float;

    .line 46
    .line 47
    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    aput v3, v2, v1

    .line 52
    .line 53
    rem-int/lit8 v2, v1, 0x2

    .line 54
    .line 55
    if-nez v2, :cond_45

    .line 56
    .line 57
    iget-object v2, p0, Ls2/a;->h:[F

    .line 58
    .line 59
    aget v3, v2, v1

    .line 60
    .line 61
    const/high16 v4, 0x3f800000    # 1.0f

    .line 62
    .line 63
    cmpg-float v3, v3, v4

    .line 64
    .line 65
    if-gez v3, :cond_52

    .line 66
    .line 67
    aput v4, v2, v1

    .line 68
    .line 69
    goto :goto_52

    .line 70
    :cond_45
    iget-object v2, p0, Ls2/a;->h:[F

    .line 71
    .line 72
    aget v3, v2, v1

    .line 73
    .line 74
    const v4, 0x3dcccccd    # 0.1f

    .line 75
    .line 76
    .line 77
    cmpg-float v3, v3, v4

    .line 78
    .line 79
    if-gez v3, :cond_52

    .line 80
    .line 81
    aput v4, v2, v1

    .line 82
    .line 83
    :cond_52
    :goto_52
    iget-object v2, p0, Ls2/a;->h:[F

    .line 84
    .line 85
    aget v3, v2, v1

    .line 86
    .line 87
    mul-float v3, v3, p1

    .line 88
    .line 89
    aput v3, v2, v1

    .line 90
    .line 91
    add-int/lit8 v1, v1, 0x1

    .line 92
    .line 93
    goto :goto_16

    .line 94
    :cond_5d
    iget-object v1, p0, Ls2/a;->m:Lt2/a;

    .line 95
    .line 96
    if-nez v1, :cond_63

    .line 97
    .line 98
    const/4 p1, 0x0

    .line 99
    goto :goto_6f

    .line 100
    :cond_63
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    check-cast v1, Ljava/lang/Float;

    .line 105
    .line 106
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    mul-float p1, p1, v1

    .line 111
    .line 112
    :goto_6f
    iget-object v1, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 113
    .line 114
    new-instance v2, Landroid/graphics/DashPathEffect;

    .line 115
    .line 116
    iget-object v3, p0, Ls2/a;->h:[F

    .line 117
    .line 118
    invoke-direct {v2, v3, p1}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 122
    .line 123
    .line 124
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 125
    .line 126
    .line 127
    return-void
.end method

.method public c(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V
    .registers 10

    .line 1
    const-string v0, "StrokeContent#draw"

    .line 2
    .line 3
    invoke-static {v0}, Lq2/c;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p2}, Lc3/j;->h(Landroid/graphics/Matrix;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_f

    .line 11
    .line 12
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_f
    int-to-float p3, p3

    .line 17
    const/high16 v1, 0x437f0000    # 255.0f

    .line 18
    .line 19
    div-float/2addr p3, v1

    .line 20
    iget-object v2, p0, Ls2/a;->k:Lt2/a;

    .line 21
    .line 22
    check-cast v2, Lt2/e;

    .line 23
    .line 24
    invoke-virtual {v2}, Lt2/e;->o()I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    int-to-float v2, v2

    .line 29
    mul-float p3, p3, v2

    .line 30
    .line 31
    const/high16 v2, 0x42c80000    # 100.0f

    .line 32
    .line 33
    div-float/2addr p3, v2

    .line 34
    mul-float p3, p3, v1

    .line 35
    .line 36
    float-to-int p3, p3

    .line 37
    iget-object v1, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 38
    .line 39
    const/16 v2, 0xff

    .line 40
    .line 41
    const/4 v3, 0x0

    .line 42
    invoke-static {p3, v3, v2}, Lc3/i;->d(III)I

    .line 43
    .line 44
    .line 45
    move-result p3

    .line 46
    invoke-virtual {v1, p3}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 47
    .line 48
    .line 49
    iget-object p3, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 50
    .line 51
    iget-object v1, p0, Ls2/a;->j:Lt2/a;

    .line 52
    .line 53
    check-cast v1, Lt2/c;

    .line 54
    .line 55
    invoke-virtual {v1}, Lt2/c;->o()F

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    invoke-static {p2}, Lc3/j;->g(Landroid/graphics/Matrix;)F

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    mul-float v1, v1, v2

    .line 64
    .line 65
    invoke-virtual {p3, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 66
    .line 67
    .line 68
    iget-object p3, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 69
    .line 70
    invoke-virtual {p3}, Landroid/graphics/Paint;->getStrokeWidth()F

    .line 71
    .line 72
    .line 73
    move-result p3

    .line 74
    const/4 v1, 0x0

    .line 75
    cmpg-float p3, p3, v1

    .line 76
    .line 77
    if-gtz p3, :cond_52

    .line 78
    .line 79
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :cond_52
    invoke-virtual {p0, p2}, Ls2/a;->b(Landroid/graphics/Matrix;)V

    .line 84
    .line 85
    .line 86
    iget-object p3, p0, Ls2/a;->n:Lt2/a;

    .line 87
    .line 88
    if-eqz p3, :cond_64

    .line 89
    .line 90
    iget-object v1, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 91
    .line 92
    invoke-virtual {p3}, Lt2/a;->h()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object p3

    .line 96
    check-cast p3, Landroid/graphics/ColorFilter;

    .line 97
    .line 98
    invoke-virtual {v1, p3}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 99
    .line 100
    .line 101
    :cond_64
    :goto_64
    iget-object p3, p0, Ls2/a;->g:Ljava/util/List;

    .line 102
    .line 103
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 104
    .line 105
    .line 106
    move-result p3

    .line 107
    if-ge v3, p3, :cond_bf

    .line 108
    .line 109
    iget-object p3, p0, Ls2/a;->g:Ljava/util/List;

    .line 110
    .line 111
    invoke-interface {p3, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object p3

    .line 115
    check-cast p3, Ls2/a$b;

    .line 116
    .line 117
    invoke-static {p3}, Ls2/a$b;->b(Ls2/a$b;)Ls2/s;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    if-eqz v1, :cond_7e

    .line 122
    .line 123
    invoke-virtual {p0, p1, p3, p2}, Ls2/a;->h(Landroid/graphics/Canvas;Ls2/a$b;Landroid/graphics/Matrix;)V

    .line 124
    .line 125
    .line 126
    goto :goto_bc

    .line 127
    :cond_7e
    const-string v1, "StrokeContent#buildPath"

    .line 128
    .line 129
    invoke-static {v1}, Lq2/c;->a(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    iget-object v2, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 133
    .line 134
    invoke-virtual {v2}, Landroid/graphics/Path;->reset()V

    .line 135
    .line 136
    .line 137
    invoke-static {p3}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 138
    .line 139
    .line 140
    move-result-object v2

    .line 141
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    add-int/lit8 v2, v2, -0x1

    .line 146
    .line 147
    :goto_92
    if-ltz v2, :cond_aa

    .line 148
    .line 149
    iget-object v4, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 150
    .line 151
    invoke-static {p3}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 152
    .line 153
    .line 154
    move-result-object v5

    .line 155
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v5

    .line 159
    check-cast v5, Ls2/m;

    .line 160
    .line 161
    invoke-interface {v5}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 162
    .line 163
    .line 164
    move-result-object v5

    .line 165
    invoke-virtual {v4, v5, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 166
    .line 167
    .line 168
    add-int/lit8 v2, v2, -0x1

    .line 169
    .line 170
    goto :goto_92

    .line 171
    :cond_aa
    invoke-static {v1}, Lq2/c;->b(Ljava/lang/String;)F

    .line 172
    .line 173
    .line 174
    const-string p3, "StrokeContent#drawPath"

    .line 175
    .line 176
    invoke-static {p3}, Lq2/c;->a(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    iget-object v1, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 180
    .line 181
    iget-object v2, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 182
    .line 183
    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 184
    .line 185
    .line 186
    invoke-static {p3}, Lq2/c;->b(Ljava/lang/String;)F

    .line 187
    .line 188
    .line 189
    :goto_bc
    add-int/lit8 v3, v3, 0x1

    .line 190
    .line 191
    goto :goto_64

    .line 192
    :cond_bf
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 193
    .line 194
    .line 195
    return-void
.end method

.method public d()V
    .registers 2

    iget-object v0, p0, Ls2/a;->e:Lq2/f;

    invoke-virtual {v0}, Lq2/f;->invalidateSelf()V

    return-void
.end method

.method public e(Ljava/util/List;Ljava/util/List;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    add-int/lit8 v0, v0, -0x1

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    move-object v2, v1

    .line 9
    :goto_8
    if-ltz v0, :cond_22

    .line 10
    .line 11
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v3

    .line 15
    check-cast v3, Ls2/c;

    .line 16
    .line 17
    instance-of v4, v3, Ls2/s;

    .line 18
    .line 19
    if-eqz v4, :cond_1f

    .line 20
    .line 21
    check-cast v3, Ls2/s;

    .line 22
    .line 23
    invoke-virtual {v3}, Ls2/s;->i()Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    sget-object v5, Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;->INDIVIDUALLY:Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 28
    .line 29
    if-ne v4, v5, :cond_1f

    .line 30
    .line 31
    move-object v2, v3

    .line 32
    :cond_1f
    add-int/lit8 v0, v0, -0x1

    .line 33
    .line 34
    goto :goto_8

    .line 35
    :cond_22
    if-eqz v2, :cond_27

    .line 36
    .line 37
    invoke-virtual {v2, p0}, Ls2/s;->b(Lt2/a$b;)V

    .line 38
    .line 39
    .line 40
    :cond_27
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    add-int/lit8 p1, p1, -0x1

    .line 45
    .line 46
    move-object v0, v1

    .line 47
    :goto_2e
    if-ltz p1, :cond_6c

    .line 48
    .line 49
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    check-cast v3, Ls2/c;

    .line 54
    .line 55
    instance-of v4, v3, Ls2/s;

    .line 56
    .line 57
    if-eqz v4, :cond_55

    .line 58
    .line 59
    move-object v4, v3

    .line 60
    check-cast v4, Ls2/s;

    .line 61
    .line 62
    invoke-virtual {v4}, Ls2/s;->i()Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 63
    .line 64
    .line 65
    move-result-object v5

    .line 66
    sget-object v6, Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;->INDIVIDUALLY:Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 67
    .line 68
    if-ne v5, v6, :cond_55

    .line 69
    .line 70
    if-eqz v0, :cond_4c

    .line 71
    .line 72
    iget-object v3, p0, Ls2/a;->g:Ljava/util/List;

    .line 73
    .line 74
    invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    :cond_4c
    new-instance v0, Ls2/a$b;

    .line 78
    .line 79
    invoke-direct {v0, v4, v1}, Ls2/a$b;-><init>(Ls2/s;Ls2/a$a;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v4, p0}, Ls2/s;->b(Lt2/a$b;)V

    .line 83
    .line 84
    .line 85
    goto :goto_69

    .line 86
    :cond_55
    instance-of v4, v3, Ls2/m;

    .line 87
    .line 88
    if-eqz v4, :cond_69

    .line 89
    .line 90
    if-nez v0, :cond_60

    .line 91
    .line 92
    new-instance v0, Ls2/a$b;

    .line 93
    .line 94
    invoke-direct {v0, v2, v1}, Ls2/a$b;-><init>(Ls2/s;Ls2/a$a;)V

    .line 95
    .line 96
    .line 97
    :cond_60
    invoke-static {v0}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 98
    .line 99
    .line 100
    move-result-object v4

    .line 101
    check-cast v3, Ls2/m;

    .line 102
    .line 103
    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    :cond_69
    :goto_69
    add-int/lit8 p1, p1, -0x1

    .line 107
    .line 108
    goto :goto_2e

    .line 109
    :cond_6c
    if-eqz v0, :cond_73

    .line 110
    .line 111
    iget-object p1, p0, Ls2/a;->g:Ljava/util/List;

    .line 112
    .line 113
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    :cond_73
    return-void
.end method

.method public f(Lv2/d;ILjava/util/List;Lv2/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv2/d;",
            "I",
            "Ljava/util/List<",
            "Lv2/d;",
            ">;",
            "Lv2/d;",
            ")V"
        }
    .end annotation

    invoke-static {p1, p2, p3, p4, p0}, Lc3/i;->m(Lv2/d;ILjava/util/List;Lv2/d;Ls2/k;)V

    return-void
.end method

.method public g(Ljava/lang/Object;Ld3/c;)V
    .registers 4
    .param p2    # Ld3/c;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/CallSuper;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ld3/c<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Lq2/k;->d:Ljava/lang/Integer;

    .line 2
    .line 3
    if-ne p1, v0, :cond_a

    .line 4
    .line 5
    iget-object p1, p0, Ls2/a;->k:Lt2/a;

    .line 6
    .line 7
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 8
    .line 9
    .line 10
    goto :goto_38

    .line 11
    :cond_a
    sget-object v0, Lq2/k;->o:Ljava/lang/Float;

    .line 12
    .line 13
    if-ne p1, v0, :cond_14

    .line 14
    .line 15
    iget-object p1, p0, Ls2/a;->j:Lt2/a;

    .line 16
    .line 17
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 18
    .line 19
    .line 20
    goto :goto_38

    .line 21
    :cond_14
    sget-object v0, Lq2/k;->C:Landroid/graphics/ColorFilter;

    .line 22
    .line 23
    if-ne p1, v0, :cond_38

    .line 24
    .line 25
    iget-object p1, p0, Ls2/a;->n:Lt2/a;

    .line 26
    .line 27
    if-eqz p1, :cond_21

    .line 28
    .line 29
    iget-object v0, p0, Ls2/a;->f:Lcom/airbnb/lottie/model/layer/a;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, Lcom/airbnb/lottie/model/layer/a;->C(Lt2/a;)V

    .line 32
    .line 33
    .line 34
    :cond_21
    if-nez p2, :cond_27

    .line 35
    .line 36
    const/4 p1, 0x0

    .line 37
    iput-object p1, p0, Ls2/a;->n:Lt2/a;

    .line 38
    .line 39
    goto :goto_38

    .line 40
    :cond_27
    new-instance p1, Lt2/p;

    .line 41
    .line 42
    invoke-direct {p1, p2}, Lt2/p;-><init>(Ld3/c;)V

    .line 43
    .line 44
    .line 45
    iput-object p1, p0, Ls2/a;->n:Lt2/a;

    .line 46
    .line 47
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Ls2/a;->f:Lcom/airbnb/lottie/model/layer/a;

    .line 51
    .line 52
    iget-object p2, p0, Ls2/a;->n:Lt2/a;

    .line 53
    .line 54
    invoke-virtual {p1, p2}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    :goto_38
    return-void
.end method

.method public final h(Landroid/graphics/Canvas;Ls2/a$b;Landroid/graphics/Matrix;)V
    .registers 16

    .line 1
    const-string v0, "StrokeContent#applyTrimPath"

    .line 2
    .line 3
    invoke-static {v0}, Lq2/c;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-static {p2}, Ls2/a$b;->b(Ls2/a$b;)Ls2/s;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    if-nez v1, :cond_f

    .line 11
    .line 12
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 13
    .line 14
    .line 15
    return-void

    .line 16
    :cond_f
    iget-object v1, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 17
    .line 18
    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 19
    .line 20
    .line 21
    invoke-static {p2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    add-int/lit8 v1, v1, -0x1

    .line 30
    .line 31
    :goto_1e
    if-ltz v1, :cond_36

    .line 32
    .line 33
    iget-object v2, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 34
    .line 35
    invoke-static {p2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, Ls2/m;

    .line 44
    .line 45
    invoke-interface {v3}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 46
    .line 47
    .line 48
    move-result-object v3

    .line 49
    invoke-virtual {v2, v3, p3}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 50
    .line 51
    .line 52
    add-int/lit8 v1, v1, -0x1

    .line 53
    .line 54
    goto :goto_1e

    .line 55
    :cond_36
    iget-object v1, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 56
    .line 57
    iget-object v2, p0, Ls2/a;->b:Landroid/graphics/Path;

    .line 58
    .line 59
    const/4 v3, 0x0

    .line 60
    invoke-virtual {v1, v2, v3}, Landroid/graphics/PathMeasure;->setPath(Landroid/graphics/Path;Z)V

    .line 61
    .line 62
    .line 63
    iget-object v1, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 64
    .line 65
    invoke-virtual {v1}, Landroid/graphics/PathMeasure;->getLength()F

    .line 66
    .line 67
    .line 68
    move-result v1

    .line 69
    :goto_44
    iget-object v2, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 70
    .line 71
    invoke-virtual {v2}, Landroid/graphics/PathMeasure;->nextContour()Z

    .line 72
    .line 73
    .line 74
    move-result v2

    .line 75
    if-eqz v2, :cond_54

    .line 76
    .line 77
    iget-object v2, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 78
    .line 79
    invoke-virtual {v2}, Landroid/graphics/PathMeasure;->getLength()F

    .line 80
    .line 81
    .line 82
    move-result v2

    .line 83
    add-float/2addr v1, v2

    .line 84
    goto :goto_44

    .line 85
    :cond_54
    invoke-static {p2}, Ls2/a$b;->b(Ls2/a$b;)Ls2/s;

    .line 86
    .line 87
    .line 88
    move-result-object v2

    .line 89
    invoke-virtual {v2}, Ls2/s;->g()Lt2/a;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v2

    .line 97
    check-cast v2, Ljava/lang/Float;

    .line 98
    .line 99
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    mul-float v2, v2, v1

    .line 104
    .line 105
    const/high16 v4, 0x43b40000    # 360.0f

    .line 106
    .line 107
    div-float/2addr v2, v4

    .line 108
    invoke-static {p2}, Ls2/a$b;->b(Ls2/a$b;)Ls2/s;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-virtual {v4}, Ls2/s;->h()Lt2/a;

    .line 113
    .line 114
    .line 115
    move-result-object v4

    .line 116
    invoke-virtual {v4}, Lt2/a;->h()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    check-cast v4, Ljava/lang/Float;

    .line 121
    .line 122
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    .line 123
    .line 124
    .line 125
    move-result v4

    .line 126
    mul-float v4, v4, v1

    .line 127
    .line 128
    const/high16 v5, 0x42c80000    # 100.0f

    .line 129
    .line 130
    div-float/2addr v4, v5

    .line 131
    add-float/2addr v4, v2

    .line 132
    invoke-static {p2}, Ls2/a$b;->b(Ls2/a$b;)Ls2/s;

    .line 133
    .line 134
    .line 135
    move-result-object v6

    .line 136
    invoke-virtual {v6}, Ls2/s;->f()Lt2/a;

    .line 137
    .line 138
    .line 139
    move-result-object v6

    .line 140
    invoke-virtual {v6}, Lt2/a;->h()Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v6

    .line 144
    check-cast v6, Ljava/lang/Float;

    .line 145
    .line 146
    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    .line 147
    .line 148
    .line 149
    move-result v6

    .line 150
    mul-float v6, v6, v1

    .line 151
    .line 152
    div-float/2addr v6, v5

    .line 153
    add-float/2addr v6, v2

    .line 154
    invoke-static {p2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 155
    .line 156
    .line 157
    move-result-object v2

    .line 158
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    add-int/lit8 v2, v2, -0x1

    .line 163
    .line 164
    const/4 v5, 0x0

    .line 165
    const/4 v7, 0x0

    .line 166
    :goto_a5
    if-ltz v2, :cond_136

    .line 167
    .line 168
    iget-object v8, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 169
    .line 170
    invoke-static {p2}, Ls2/a$b;->a(Ls2/a$b;)Ljava/util/List;

    .line 171
    .line 172
    .line 173
    move-result-object v9

    .line 174
    invoke-interface {v9, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v9

    .line 178
    check-cast v9, Ls2/m;

    .line 179
    .line 180
    invoke-interface {v9}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 181
    .line 182
    .line 183
    move-result-object v9

    .line 184
    invoke-virtual {v8, v9}, Landroid/graphics/Path;->set(Landroid/graphics/Path;)V

    .line 185
    .line 186
    .line 187
    iget-object v8, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 188
    .line 189
    invoke-virtual {v8, p3}, Landroid/graphics/Path;->transform(Landroid/graphics/Matrix;)V

    .line 190
    .line 191
    .line 192
    iget-object v8, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 193
    .line 194
    iget-object v9, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 195
    .line 196
    invoke-virtual {v8, v9, v3}, Landroid/graphics/PathMeasure;->setPath(Landroid/graphics/Path;Z)V

    .line 197
    .line 198
    .line 199
    iget-object v8, p0, Ls2/a;->a:Landroid/graphics/PathMeasure;

    .line 200
    .line 201
    invoke-virtual {v8}, Landroid/graphics/PathMeasure;->getLength()F

    .line 202
    .line 203
    .line 204
    move-result v8

    .line 205
    const/high16 v9, 0x3f800000    # 1.0f

    .line 206
    .line 207
    cmpl-float v10, v6, v1

    .line 208
    .line 209
    if-lez v10, :cond_f9

    .line 210
    .line 211
    sub-float v10, v6, v1

    .line 212
    .line 213
    add-float v11, v7, v8

    .line 214
    .line 215
    cmpg-float v11, v10, v11

    .line 216
    .line 217
    if-gez v11, :cond_f9

    .line 218
    .line 219
    cmpg-float v11, v7, v10

    .line 220
    .line 221
    if-gez v11, :cond_f9

    .line 222
    .line 223
    cmpl-float v11, v4, v1

    .line 224
    .line 225
    if-lez v11, :cond_e6

    .line 226
    .line 227
    sub-float v11, v4, v1

    .line 228
    .line 229
    div-float/2addr v11, v8

    .line 230
    goto :goto_e7

    .line 231
    :cond_e6
    const/4 v11, 0x0

    .line 232
    :goto_e7
    div-float/2addr v10, v8

    .line 233
    invoke-static {v10, v9}, Ljava/lang/Math;->min(FF)F

    .line 234
    .line 235
    .line 236
    move-result v9

    .line 237
    iget-object v10, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 238
    .line 239
    invoke-static {v10, v11, v9, v5}, Lc3/j;->a(Landroid/graphics/Path;FFF)V

    .line 240
    .line 241
    .line 242
    iget-object v9, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 243
    .line 244
    iget-object v10, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 245
    .line 246
    invoke-virtual {p1, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 247
    .line 248
    .line 249
    goto :goto_131

    .line 250
    :cond_f9
    add-float v10, v7, v8

    .line 251
    .line 252
    cmpg-float v11, v10, v4

    .line 253
    .line 254
    if-ltz v11, :cond_131

    .line 255
    .line 256
    cmpl-float v11, v7, v6

    .line 257
    .line 258
    if-lez v11, :cond_104

    .line 259
    .line 260
    goto :goto_131

    .line 261
    :cond_104
    cmpg-float v11, v10, v6

    .line 262
    .line 263
    if-gtz v11, :cond_114

    .line 264
    .line 265
    cmpg-float v11, v4, v7

    .line 266
    .line 267
    if-gez v11, :cond_114

    .line 268
    .line 269
    iget-object v9, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 270
    .line 271
    iget-object v10, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 272
    .line 273
    invoke-virtual {p1, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 274
    .line 275
    .line 276
    goto :goto_131

    .line 277
    :cond_114
    cmpg-float v11, v4, v7

    .line 278
    .line 279
    if-gez v11, :cond_11a

    .line 280
    .line 281
    const/4 v11, 0x0

    .line 282
    goto :goto_11d

    .line 283
    :cond_11a
    sub-float v11, v4, v7

    .line 284
    .line 285
    div-float/2addr v11, v8

    .line 286
    :goto_11d
    cmpl-float v10, v6, v10

    .line 287
    .line 288
    if-lez v10, :cond_122

    .line 289
    .line 290
    goto :goto_125

    .line 291
    :cond_122
    sub-float v9, v6, v7

    .line 292
    .line 293
    div-float/2addr v9, v8

    .line 294
    :goto_125
    iget-object v10, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 295
    .line 296
    invoke-static {v10, v11, v9, v5}, Lc3/j;->a(Landroid/graphics/Path;FFF)V

    .line 297
    .line 298
    .line 299
    iget-object v9, p0, Ls2/a;->c:Landroid/graphics/Path;

    .line 300
    .line 301
    iget-object v10, p0, Ls2/a;->i:Landroid/graphics/Paint;

    .line 302
    .line 303
    invoke-virtual {p1, v9, v10}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 304
    .line 305
    .line 306
    :cond_131
    :goto_131
    add-float/2addr v7, v8

    .line 307
    add-int/lit8 v2, v2, -0x1

    .line 308
    .line 309
    goto/16 :goto_a5

    .line 310
    .line 311
    :cond_136
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 312
    .line 313
    .line 314
    return-void
.end method

###### Class s2.a.C0063a (s2.a$a)
.class public synthetic Ls2/a$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ls2/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation

###### Class s2.a.b (s2.a$b)
.class public final Ls2/a$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ls2/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ls2/m;",
            ">;"
        }
    .end annotation
.end field

.field public final b:Ls2/s;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ls2/s;)V
    .registers 3
    .param p1    # Ls2/s;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ls2/a$b;->a:Ljava/util/List;

    .line 4
    iput-object p1, p0, Ls2/a$b;->b:Ls2/s;

    return-void
.end method

.method public synthetic constructor <init>(Ls2/s;Ls2/a$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Ls2/a$b;-><init>(Ls2/s;)V

    return-void
.end method

.method public static synthetic a(Ls2/a$b;)Ljava/util/List;
    .registers 1

    iget-object p0, p0, Ls2/a$b;->a:Ljava/util/List;

    return-object p0
.end method

.method public static synthetic b(Ls2/a$b;)Ls2/s;
    .registers 1

    iget-object p0, p0, Ls2/a$b;->b:Ls2/s;

    return-object p0
.end method
