###### Class s2.q (s2.q)
.class public Ls2/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/m;
.implements Lt2/a$b;


# instance fields
.field public final a:Landroid/graphics/Path;

.field public final b:Ljava/lang/String;

.field public final c:Z

.field public final d:Lq2/f;

.field public final e:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Landroid/graphics/Path;",
            ">;"
        }
    .end annotation
.end field

.field public f:Z

.field public g:Ls2/b;


# direct methods
.method public constructor <init>(Lq2/f;Lcom/airbnb/lottie/model/layer/a;Lx2/j;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 10
    .line 11
    new-instance v0, Ls2/b;

    .line 12
    .line 13
    invoke-direct {v0}, Ls2/b;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Ls2/q;->g:Ls2/b;

    .line 17
    .line 18
    invoke-virtual {p3}, Lx2/j;->b()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    iput-object v0, p0, Ls2/q;->b:Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {p3}, Lx2/j;->d()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    iput-boolean v0, p0, Ls2/q;->c:Z

    .line 29
    .line 30
    iput-object p1, p0, Ls2/q;->d:Lq2/f;

    .line 31
    .line 32
    invoke-virtual {p3}, Lx2/j;->c()Lw2/h;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {p1}, Lw2/h;->a()Lt2/a;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    iput-object p1, p0, Ls2/q;->e:Lt2/a;

    .line 41
    .line 42
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 46
    .line 47
    .line 48
    return-void
.end method


# virtual methods
.method public final b()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Ls2/q;->f:Z

    .line 3
    .line 4
    iget-object v0, p0, Ls2/q;->d:Lq2/f;

    .line 5
    .line 6
    invoke-virtual {v0}, Lq2/f;->invalidateSelf()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public d()V
    .registers 1

    invoke-virtual {p0}, Ls2/q;->b()V

    return-void
.end method

.method public e(Ljava/util/List;Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 p2, 0x0

    .line 2
    :goto_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-ge p2, v0, :cond_26

    .line 7
    .line 8
    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ls2/c;

    .line 13
    .line 14
    instance-of v1, v0, Ls2/s;

    .line 15
    .line 16
    if-eqz v1, :cond_23

    .line 17
    .line 18
    check-cast v0, Ls2/s;

    .line 19
    .line 20
    invoke-virtual {v0}, Ls2/s;->i()Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    sget-object v2, Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;->SIMULTANEOUSLY:Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 25
    .line 26
    if-ne v1, v2, :cond_23

    .line 27
    .line 28
    iget-object v1, p0, Ls2/q;->g:Ls2/b;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Ls2/b;->a(Ls2/s;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, p0}, Ls2/s;->b(Lt2/a$b;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    add-int/lit8 p2, p2, 0x1

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_26
    return-void
.end method

.method public getPath()Landroid/graphics/Path;
    .registers 4

    .line 1
    iget-boolean v0, p0, Ls2/q;->f:Z

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 6
    .line 7
    return-object v0

    .line 8
    :cond_7
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 11
    .line 12
    .line 13
    iget-boolean v0, p0, Ls2/q;->c:Z

    .line 14
    .line 15
    const/4 v1, 0x1

    .line 16
    if-eqz v0, :cond_16

    .line 17
    .line 18
    iput-boolean v1, p0, Ls2/q;->f:Z

    .line 19
    .line 20
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_16
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 24
    .line 25
    iget-object v2, p0, Ls2/q;->e:Lt2/a;

    .line 26
    .line 27
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    check-cast v2, Landroid/graphics/Path;

    .line 32
    .line 33
    invoke-virtual {v0, v2}, Landroid/graphics/Path;->set(Landroid/graphics/Path;)V

    .line 34
    .line 35
    .line 36
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 37
    .line 38
    sget-object v2, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 39
    .line 40
    invoke-virtual {v0, v2}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 41
    .line 42
    .line 43
    iget-object v0, p0, Ls2/q;->g:Ls2/b;

    .line 44
    .line 45
    iget-object v2, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 46
    .line 47
    invoke-virtual {v0, v2}, Ls2/b;->b(Landroid/graphics/Path;)V

    .line 48
    .line 49
    .line 50
    iput-boolean v1, p0, Ls2/q;->f:Z

    .line 51
    .line 52
    iget-object v0, p0, Ls2/q;->a:Landroid/graphics/Path;

    .line 53
    .line 54
    return-object v0
.end method
