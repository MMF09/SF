###### Class s2.e (s2.e)
.class public interface abstract Ls2/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/c;


# virtual methods
.method public abstract a(Landroid/graphics/RectF;Landroid/graphics/Matrix;Z)V
.end method

.method public abstract c(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V
.end method
