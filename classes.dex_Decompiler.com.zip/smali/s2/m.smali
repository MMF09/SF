###### Class s2.m (s2.m)
.class public interface abstract Ls2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/c;


# virtual methods
.method public abstract getPath()Landroid/graphics/Path;
.end method
