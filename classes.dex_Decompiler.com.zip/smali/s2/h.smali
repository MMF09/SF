###### Class s2.h (s2.h)
.class public Ls2/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/e;
.implements Lt2/a$b;
.implements Ls2/k;


# instance fields
.field public final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/NonNull;
    .end annotation
.end field

.field public final b:Z

.field public final c:Lcom/airbnb/lottie/model/layer/a;

.field public final d:Landroidx/collection/LongSparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/LongSparseArray<",
            "Landroid/graphics/LinearGradient;",
            ">;"
        }
    .end annotation
.end field

.field public final e:Landroidx/collection/LongSparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/LongSparseArray<",
            "Landroid/graphics/RadialGradient;",
            ">;"
        }
    .end annotation
.end field

.field public final f:Landroid/graphics/Path;

.field public final g:Landroid/graphics/Paint;

.field public final h:Landroid/graphics/RectF;

.field public final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ls2/m;",
            ">;"
        }
    .end annotation
.end field

.field public final j:Lcom/airbnb/lottie/model/content/GradientType;

.field public final k:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Lx2/c;",
            "Lx2/c;",
            ">;"
        }
    .end annotation
.end field

.field public final l:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final m:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Landroid/graphics/PointF;",
            "Landroid/graphics/PointF;",
            ">;"
        }
    .end annotation
.end field

.field public final n:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Landroid/graphics/PointF;",
            "Landroid/graphics/PointF;",
            ">;"
        }
    .end annotation
.end field

.field public o:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Landroid/graphics/ColorFilter;",
            "Landroid/graphics/ColorFilter;",
            ">;"
        }
    .end annotation
.end field

.field public p:Lt2/p;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field public final q:Lq2/f;

.field public final r:I


# direct methods
.method public constructor <init>(Lq2/f;Lcom/airbnb/lottie/model/layer/a;Lx2/d;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroidx/collection/LongSparseArray;

    .line 5
    .line 6
    invoke-direct {v0}, Landroidx/collection/LongSparseArray;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ls2/h;->d:Landroidx/collection/LongSparseArray;

    .line 10
    .line 11
    new-instance v0, Landroidx/collection/LongSparseArray;

    .line 12
    .line 13
    invoke-direct {v0}, Landroidx/collection/LongSparseArray;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Ls2/h;->e:Landroidx/collection/LongSparseArray;

    .line 17
    .line 18
    new-instance v0, Landroid/graphics/Path;

    .line 19
    .line 20
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v0, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 24
    .line 25
    new-instance v1, Lr2/a;

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-direct {v1, v2}, Lr2/a;-><init>(I)V

    .line 29
    .line 30
    .line 31
    iput-object v1, p0, Ls2/h;->g:Landroid/graphics/Paint;

    .line 32
    .line 33
    new-instance v1, Landroid/graphics/RectF;

    .line 34
    .line 35
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object v1, p0, Ls2/h;->h:Landroid/graphics/RectF;

    .line 39
    .line 40
    new-instance v1, Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object v1, p0, Ls2/h;->i:Ljava/util/List;

    .line 46
    .line 47
    iput-object p2, p0, Ls2/h;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 48
    .line 49
    invoke-virtual {p3}, Lx2/d;->f()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    iput-object v1, p0, Ls2/h;->a:Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {p3}, Lx2/d;->i()Z

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    iput-boolean v1, p0, Ls2/h;->b:Z

    .line 60
    .line 61
    iput-object p1, p0, Ls2/h;->q:Lq2/f;

    .line 62
    .line 63
    invoke-virtual {p3}, Lx2/d;->e()Lcom/airbnb/lottie/model/content/GradientType;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    iput-object v1, p0, Ls2/h;->j:Lcom/airbnb/lottie/model/content/GradientType;

    .line 68
    .line 69
    invoke-virtual {p3}, Lx2/d;->c()Landroid/graphics/Path$FillType;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    invoke-virtual {v0, v1}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p1}, Lq2/f;->n()Lq2/d;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    invoke-virtual {p1}, Lq2/d;->d()F

    .line 81
    .line 82
    .line 83
    move-result p1

    .line 84
    const/high16 v0, 0x42000000    # 32.0f

    .line 85
    .line 86
    div-float/2addr p1, v0

    .line 87
    float-to-int p1, p1

    .line 88
    iput p1, p0, Ls2/h;->r:I

    .line 89
    .line 90
    invoke-virtual {p3}, Lx2/d;->d()Lw2/c;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Lw2/c;->a()Lt2/a;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    iput-object p1, p0, Ls2/h;->k:Lt2/a;

    .line 99
    .line 100
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 101
    .line 102
    .line 103
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {p3}, Lx2/d;->g()Lw2/d;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    invoke-virtual {p1}, Lw2/d;->a()Lt2/a;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    iput-object p1, p0, Ls2/h;->l:Lt2/a;

    .line 115
    .line 116
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p3}, Lx2/d;->h()Lw2/f;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-virtual {p1}, Lw2/f;->a()Lt2/a;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    iput-object p1, p0, Ls2/h;->m:Lt2/a;

    .line 131
    .line 132
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p3}, Lx2/d;->b()Lw2/f;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    invoke-virtual {p1}, Lw2/f;->a()Lt2/a;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    iput-object p1, p0, Ls2/h;->n:Lt2/a;

    .line 147
    .line 148
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 152
    .line 153
    .line 154
    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/RectF;Landroid/graphics/Matrix;Z)V
    .registers 7

    .line 1
    iget-object p3, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 2
    .line 3
    invoke-virtual {p3}, Landroid/graphics/Path;->reset()V

    .line 4
    .line 5
    .line 6
    const/4 p3, 0x0

    .line 7
    const/4 v0, 0x0

    .line 8
    :goto_7
    iget-object v1, p0, Ls2/h;->i:Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-ge v0, v1, :cond_23

    .line 15
    .line 16
    iget-object v1, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 17
    .line 18
    iget-object v2, p0, Ls2/h;->i:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ls2/m;

    .line 25
    .line 26
    invoke-interface {v2}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v1, v2, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 31
    .line 32
    .line 33
    add-int/lit8 v0, v0, 0x1

    .line 34
    .line 35
    goto :goto_7

    .line 36
    :cond_23
    iget-object p2, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 37
    .line 38
    invoke-virtual {p2, p1, p3}, Landroid/graphics/Path;->computeBounds(Landroid/graphics/RectF;Z)V

    .line 39
    .line 40
    .line 41
    iget p2, p1, Landroid/graphics/RectF;->left:F

    .line 42
    .line 43
    const/high16 p3, 0x3f800000    # 1.0f

    .line 44
    .line 45
    sub-float/2addr p2, p3

    .line 46
    iget v0, p1, Landroid/graphics/RectF;->top:F

    .line 47
    .line 48
    sub-float/2addr v0, p3

    .line 49
    iget v1, p1, Landroid/graphics/RectF;->right:F

    .line 50
    .line 51
    add-float/2addr v1, p3

    .line 52
    iget v2, p1, Landroid/graphics/RectF;->bottom:F

    .line 53
    .line 54
    add-float/2addr v2, p3

    .line 55
    invoke-virtual {p1, p2, v0, v1, v2}, Landroid/graphics/RectF;->set(FFFF)V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public final b([I)[I
    .registers 6

    .line 1
    iget-object v0, p0, Ls2/h;->p:Lt2/p;

    .line 2
    .line 3
    if-eqz v0, :cond_2e

    .line 4
    .line 5
    invoke-virtual {v0}, Lt2/p;->h()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, [Ljava/lang/Integer;

    .line 10
    .line 11
    array-length v1, p1

    .line 12
    array-length v2, v0

    .line 13
    const/4 v3, 0x0

    .line 14
    if-ne v1, v2, :cond_1d

    .line 15
    .line 16
    :goto_f
    array-length v1, p1

    .line 17
    if-ge v3, v1, :cond_2e

    .line 18
    .line 19
    aget-object v1, v0, v3

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    aput v1, p1, v3

    .line 26
    .line 27
    add-int/lit8 v3, v3, 0x1

    .line 28
    .line 29
    goto :goto_f

    .line 30
    :cond_1d
    array-length p1, v0

    .line 31
    new-array p1, p1, [I

    .line 32
    .line 33
    :goto_20
    array-length v1, v0

    .line 34
    if-ge v3, v1, :cond_2e

    .line 35
    .line 36
    aget-object v1, v0, v3

    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    aput v1, p1, v3

    .line 43
    .line 44
    add-int/lit8 v3, v3, 0x1

    .line 45
    .line 46
    goto :goto_20

    .line 47
    :cond_2e
    return-object p1
.end method

.method public c(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V
    .registers 9

    .line 1
    iget-boolean v0, p0, Ls2/h;->b:Z

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const-string v0, "GradientFillContent#draw"

    .line 7
    .line 8
    invoke-static {v0}, Lq2/c;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 12
    .line 13
    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 14
    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_11
    iget-object v3, p0, Ls2/h;->i:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-ge v2, v3, :cond_2d

    .line 25
    .line 26
    iget-object v3, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 27
    .line 28
    iget-object v4, p0, Ls2/h;->i:Ljava/util/List;

    .line 29
    .line 30
    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Ls2/m;

    .line 35
    .line 36
    invoke-interface {v4}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    invoke-virtual {v3, v4, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 41
    .line 42
    .line 43
    add-int/lit8 v2, v2, 0x1

    .line 44
    .line 45
    goto :goto_11

    .line 46
    :cond_2d
    iget-object v2, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 47
    .line 48
    iget-object v3, p0, Ls2/h;->h:Landroid/graphics/RectF;

    .line 49
    .line 50
    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->computeBounds(Landroid/graphics/RectF;Z)V

    .line 51
    .line 52
    .line 53
    iget-object v2, p0, Ls2/h;->j:Lcom/airbnb/lottie/model/content/GradientType;

    .line 54
    .line 55
    sget-object v3, Lcom/airbnb/lottie/model/content/GradientType;->LINEAR:Lcom/airbnb/lottie/model/content/GradientType;

    .line 56
    .line 57
    if-ne v2, v3, :cond_3f

    .line 58
    .line 59
    invoke-virtual {p0}, Ls2/h;->i()Landroid/graphics/LinearGradient;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    goto :goto_43

    .line 64
    :cond_3f
    invoke-virtual {p0}, Ls2/h;->j()Landroid/graphics/RadialGradient;

    .line 65
    .line 66
    .line 67
    move-result-object v2

    .line 68
    :goto_43
    invoke-virtual {v2, p2}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    .line 69
    .line 70
    .line 71
    iget-object p2, p0, Ls2/h;->g:Landroid/graphics/Paint;

    .line 72
    .line 73
    invoke-virtual {p2, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 74
    .line 75
    .line 76
    iget-object p2, p0, Ls2/h;->o:Lt2/a;

    .line 77
    .line 78
    if-eqz p2, :cond_5a

    .line 79
    .line 80
    iget-object v2, p0, Ls2/h;->g:Landroid/graphics/Paint;

    .line 81
    .line 82
    invoke-virtual {p2}, Lt2/a;->h()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p2

    .line 86
    check-cast p2, Landroid/graphics/ColorFilter;

    .line 87
    .line 88
    invoke-virtual {v2, p2}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 89
    .line 90
    .line 91
    :cond_5a
    int-to-float p2, p3

    .line 92
    const/high16 p3, 0x437f0000    # 255.0f

    .line 93
    .line 94
    div-float/2addr p2, p3

    .line 95
    iget-object v2, p0, Ls2/h;->l:Lt2/a;

    .line 96
    .line 97
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v2

    .line 101
    check-cast v2, Ljava/lang/Integer;

    .line 102
    .line 103
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 104
    .line 105
    .line 106
    move-result v2

    .line 107
    int-to-float v2, v2

    .line 108
    mul-float p2, p2, v2

    .line 109
    .line 110
    const/high16 v2, 0x42c80000    # 100.0f

    .line 111
    .line 112
    div-float/2addr p2, v2

    .line 113
    mul-float p2, p2, p3

    .line 114
    .line 115
    float-to-int p2, p2

    .line 116
    iget-object p3, p0, Ls2/h;->g:Landroid/graphics/Paint;

    .line 117
    .line 118
    const/16 v2, 0xff

    .line 119
    .line 120
    invoke-static {p2, v1, v2}, Lc3/i;->d(III)I

    .line 121
    .line 122
    .line 123
    move-result p2

    .line 124
    invoke-virtual {p3, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 125
    .line 126
    .line 127
    iget-object p2, p0, Ls2/h;->f:Landroid/graphics/Path;

    .line 128
    .line 129
    iget-object p3, p0, Ls2/h;->g:Landroid/graphics/Paint;

    .line 130
    .line 131
    invoke-virtual {p1, p2, p3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 132
    .line 133
    .line 134
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 135
    .line 136
    .line 137
    return-void
.end method

.method public d()V
    .registers 2

    iget-object v0, p0, Ls2/h;->q:Lq2/f;

    invoke-virtual {v0}, Lq2/f;->invalidateSelf()V

    return-void
.end method

.method public e(Ljava/util/List;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 p1, 0x0

    .line 2
    :goto_1
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-ge p1, v0, :cond_1b

    .line 7
    .line 8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ls2/c;

    .line 13
    .line 14
    instance-of v1, v0, Ls2/m;

    .line 15
    .line 16
    if-eqz v1, :cond_18

    .line 17
    .line 18
    iget-object v1, p0, Ls2/h;->i:Ljava/util/List;

    .line 19
    .line 20
    check-cast v0, Ls2/m;

    .line 21
    .line 22
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    :cond_18
    add-int/lit8 p1, p1, 0x1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1b
    return-void
.end method

.method public f(Lv2/d;ILjava/util/List;Lv2/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv2/d;",
            "I",
            "Ljava/util/List<",
            "Lv2/d;",
            ">;",
            "Lv2/d;",
            ")V"
        }
    .end annotation

    invoke-static {p1, p2, p3, p4, p0}, Lc3/i;->m(Lv2/d;ILjava/util/List;Lv2/d;Ls2/k;)V

    return-void
.end method

.method public g(Ljava/lang/Object;Ld3/c;)V
    .registers 5
    .param p2    # Ld3/c;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ld3/c<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Lq2/k;->d:Ljava/lang/Integer;

    .line 2
    .line 3
    if-ne p1, v0, :cond_a

    .line 4
    .line 5
    iget-object p1, p0, Ls2/h;->l:Lt2/a;

    .line 6
    .line 7
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 8
    .line 9
    .line 10
    goto :goto_5c

    .line 11
    :cond_a
    sget-object v0, Lq2/k;->C:Landroid/graphics/ColorFilter;

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    if-ne p1, v0, :cond_2f

    .line 15
    .line 16
    iget-object p1, p0, Ls2/h;->o:Lt2/a;

    .line 17
    .line 18
    if-eqz p1, :cond_18

    .line 19
    .line 20
    iget-object v0, p0, Ls2/h;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 21
    .line 22
    invoke-virtual {v0, p1}, Lcom/airbnb/lottie/model/layer/a;->C(Lt2/a;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    if-nez p2, :cond_1d

    .line 26
    .line 27
    iput-object v1, p0, Ls2/h;->o:Lt2/a;

    .line 28
    .line 29
    goto :goto_5c

    .line 30
    :cond_1d
    new-instance p1, Lt2/p;

    .line 31
    .line 32
    invoke-direct {p1, p2}, Lt2/p;-><init>(Ld3/c;)V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, Ls2/h;->o:Lt2/a;

    .line 36
    .line 37
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 38
    .line 39
    .line 40
    iget-object p1, p0, Ls2/h;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 41
    .line 42
    iget-object p2, p0, Ls2/h;->o:Lt2/a;

    .line 43
    .line 44
    invoke-virtual {p1, p2}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 45
    .line 46
    .line 47
    goto :goto_5c

    .line 48
    :cond_2f
    sget-object v0, Lq2/k;->D:[Ljava/lang/Integer;

    .line 49
    .line 50
    if-ne p1, v0, :cond_5c

    .line 51
    .line 52
    iget-object p1, p0, Ls2/h;->p:Lt2/p;

    .line 53
    .line 54
    if-eqz p1, :cond_3c

    .line 55
    .line 56
    iget-object v0, p0, Ls2/h;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 57
    .line 58
    invoke-virtual {v0, p1}, Lcom/airbnb/lottie/model/layer/a;->C(Lt2/a;)V

    .line 59
    .line 60
    .line 61
    :cond_3c
    if-nez p2, :cond_41

    .line 62
    .line 63
    iput-object v1, p0, Ls2/h;->p:Lt2/p;

    .line 64
    .line 65
    goto :goto_5c

    .line 66
    :cond_41
    iget-object p1, p0, Ls2/h;->d:Landroidx/collection/LongSparseArray;

    .line 67
    .line 68
    invoke-virtual {p1}, Landroidx/collection/LongSparseArray;->clear()V

    .line 69
    .line 70
    .line 71
    iget-object p1, p0, Ls2/h;->e:Landroidx/collection/LongSparseArray;

    .line 72
    .line 73
    invoke-virtual {p1}, Landroidx/collection/LongSparseArray;->clear()V

    .line 74
    .line 75
    .line 76
    new-instance p1, Lt2/p;

    .line 77
    .line 78
    invoke-direct {p1, p2}, Lt2/p;-><init>(Ld3/c;)V

    .line 79
    .line 80
    .line 81
    iput-object p1, p0, Ls2/h;->p:Lt2/p;

    .line 82
    .line 83
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 84
    .line 85
    .line 86
    iget-object p1, p0, Ls2/h;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 87
    .line 88
    iget-object p2, p0, Ls2/h;->p:Lt2/p;

    .line 89
    .line 90
    invoke-virtual {p1, p2}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 91
    .line 92
    .line 93
    :cond_5c
    :goto_5c
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ls2/h;->a:Ljava/lang/String;

    return-object v0
.end method

.method public final h()I
    .registers 5

    .line 1
    iget-object v0, p0, Ls2/h;->m:Lt2/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lt2/a;->f()F

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Ls2/h;->r:I

    .line 8
    .line 9
    int-to-float v1, v1

    .line 10
    mul-float v0, v0, v1

    .line 11
    .line 12
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    iget-object v1, p0, Ls2/h;->n:Lt2/a;

    .line 17
    .line 18
    invoke-virtual {v1}, Lt2/a;->f()F

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    iget v2, p0, Ls2/h;->r:I

    .line 23
    .line 24
    int-to-float v2, v2

    .line 25
    mul-float v1, v1, v2

    .line 26
    .line 27
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    iget-object v2, p0, Ls2/h;->k:Lt2/a;

    .line 32
    .line 33
    invoke-virtual {v2}, Lt2/a;->f()F

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    iget v3, p0, Ls2/h;->r:I

    .line 38
    .line 39
    int-to-float v3, v3

    .line 40
    mul-float v2, v2, v3

    .line 41
    .line 42
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v0, :cond_34

    .line 47
    .line 48
    const/16 v3, 0x20f

    .line 49
    .line 50
    mul-int v3, v3, v0

    .line 51
    .line 52
    goto :goto_36

    .line 53
    :cond_34
    const/16 v3, 0x11

    .line 54
    .line 55
    :goto_36
    if-eqz v1, :cond_3c

    .line 56
    .line 57
    mul-int/lit8 v3, v3, 0x1f

    .line 58
    .line 59
    mul-int v3, v3, v1

    .line 60
    .line 61
    :cond_3c
    if-eqz v2, :cond_42

    .line 62
    .line 63
    mul-int/lit8 v3, v3, 0x1f

    .line 64
    .line 65
    mul-int v3, v3, v2

    .line 66
    .line 67
    :cond_42
    return v3
.end method

.method public final i()Landroid/graphics/LinearGradient;
    .registers 15

    .line 1
    invoke-virtual {p0}, Ls2/h;->h()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Ls2/h;->d:Landroidx/collection/LongSparseArray;

    .line 6
    .line 7
    int-to-long v2, v0

    .line 8
    invoke-virtual {v1, v2, v3}, Landroidx/collection/LongSparseArray;->get(J)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroid/graphics/LinearGradient;

    .line 13
    .line 14
    if-eqz v0, :cond_10

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_10
    iget-object v0, p0, Ls2/h;->m:Lt2/a;

    .line 18
    .line 19
    invoke-virtual {v0}, Lt2/a;->h()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Landroid/graphics/PointF;

    .line 24
    .line 25
    iget-object v1, p0, Ls2/h;->n:Lt2/a;

    .line 26
    .line 27
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Landroid/graphics/PointF;

    .line 32
    .line 33
    iget-object v4, p0, Ls2/h;->k:Lt2/a;

    .line 34
    .line 35
    invoke-virtual {v4}, Lt2/a;->h()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    check-cast v4, Lx2/c;

    .line 40
    .line 41
    invoke-virtual {v4}, Lx2/c;->a()[I

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    invoke-virtual {p0, v5}, Ls2/h;->b([I)[I

    .line 46
    .line 47
    .line 48
    move-result-object v11

    .line 49
    invoke-virtual {v4}, Lx2/c;->b()[F

    .line 50
    .line 51
    .line 52
    move-result-object v12

    .line 53
    new-instance v4, Landroid/graphics/LinearGradient;

    .line 54
    .line 55
    iget v7, v0, Landroid/graphics/PointF;->x:F

    .line 56
    .line 57
    iget v8, v0, Landroid/graphics/PointF;->y:F

    .line 58
    .line 59
    iget v9, v1, Landroid/graphics/PointF;->x:F

    .line 60
    .line 61
    iget v10, v1, Landroid/graphics/PointF;->y:F

    .line 62
    .line 63
    sget-object v13, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 64
    .line 65
    move-object v6, v4

    .line 66
    invoke-direct/range {v6 .. v13}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 67
    .line 68
    .line 69
    iget-object v0, p0, Ls2/h;->d:Landroidx/collection/LongSparseArray;

    .line 70
    .line 71
    invoke-virtual {v0, v2, v3, v4}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    return-object v4
.end method

.method public final j()Landroid/graphics/RadialGradient;
    .registers 14

    .line 1
    invoke-virtual {p0}, Ls2/h;->h()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Ls2/h;->e:Landroidx/collection/LongSparseArray;

    .line 6
    .line 7
    int-to-long v2, v0

    .line 8
    invoke-virtual {v1, v2, v3}, Landroidx/collection/LongSparseArray;->get(J)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Landroid/graphics/RadialGradient;

    .line 13
    .line 14
    if-eqz v0, :cond_10

    .line 15
    .line 16
    return-object v0

    .line 17
    :cond_10
    iget-object v0, p0, Ls2/h;->m:Lt2/a;

    .line 18
    .line 19
    invoke-virtual {v0}, Lt2/a;->h()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Landroid/graphics/PointF;

    .line 24
    .line 25
    iget-object v1, p0, Ls2/h;->n:Lt2/a;

    .line 26
    .line 27
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Landroid/graphics/PointF;

    .line 32
    .line 33
    iget-object v4, p0, Ls2/h;->k:Lt2/a;

    .line 34
    .line 35
    invoke-virtual {v4}, Lt2/a;->h()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    check-cast v4, Lx2/c;

    .line 40
    .line 41
    invoke-virtual {v4}, Lx2/c;->a()[I

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    invoke-virtual {p0, v5}, Ls2/h;->b([I)[I

    .line 46
    .line 47
    .line 48
    move-result-object v10

    .line 49
    invoke-virtual {v4}, Lx2/c;->b()[F

    .line 50
    .line 51
    .line 52
    move-result-object v11

    .line 53
    iget v7, v0, Landroid/graphics/PointF;->x:F

    .line 54
    .line 55
    iget v8, v0, Landroid/graphics/PointF;->y:F

    .line 56
    .line 57
    iget v0, v1, Landroid/graphics/PointF;->x:F

    .line 58
    .line 59
    iget v1, v1, Landroid/graphics/PointF;->y:F

    .line 60
    .line 61
    sub-float/2addr v0, v7

    .line 62
    float-to-double v4, v0

    .line 63
    sub-float/2addr v1, v8

    .line 64
    float-to-double v0, v1

    .line 65
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->hypot(DD)D

    .line 66
    .line 67
    .line 68
    move-result-wide v0

    .line 69
    double-to-float v0, v0

    .line 70
    const/4 v1, 0x0

    .line 71
    cmpg-float v1, v0, v1

    .line 72
    .line 73
    if-gtz v1, :cond_51

    .line 74
    .line 75
    const v0, 0x3a83126f    # 0.001f

    .line 76
    .line 77
    .line 78
    const v9, 0x3a83126f    # 0.001f

    .line 79
    .line 80
    .line 81
    goto :goto_52

    .line 82
    :cond_51
    move v9, v0

    .line 83
    :goto_52
    new-instance v0, Landroid/graphics/RadialGradient;

    .line 84
    .line 85
    sget-object v12, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    .line 86
    .line 87
    move-object v6, v0

    .line 88
    invoke-direct/range {v6 .. v12}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 89
    .line 90
    .line 91
    iget-object v1, p0, Ls2/h;->e:Landroidx/collection/LongSparseArray;

    .line 92
    .line 93
    invoke-virtual {v1, v2, v3, v0}, Landroidx/collection/LongSparseArray;->put(JLjava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    return-object v0
.end method
