###### Class s2.j (s2.j)
.class public interface abstract Ls2/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/util/ListIterator;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ListIterator<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation
.end method
