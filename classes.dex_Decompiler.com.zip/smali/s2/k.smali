###### Class s2.k (s2.k)
.class public interface abstract Ls2/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv2/e;
.implements Ls2/c;
