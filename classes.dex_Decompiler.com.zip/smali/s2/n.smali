###### Class s2.n (s2.n)
.class public Ls2/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/m;
.implements Lt2/a$b;
.implements Ls2/k;


# instance fields
.field public final a:Landroid/graphics/Path;

.field public final b:Ljava/lang/String;

.field public final c:Lq2/f;

.field public final d:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

.field public final e:Z

.field public final f:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Landroid/graphics/PointF;",
            ">;"
        }
    .end annotation
.end field

.field public final h:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final i:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final j:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final k:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public final l:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "*",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ls2/b;

.field public n:Z


# direct methods
.method public constructor <init>(Lq2/f;Lcom/airbnb/lottie/model/layer/a;Lcom/airbnb/lottie/model/content/PolystarShape;)V
    .registers 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 10
    .line 11
    new-instance v0, Ls2/b;

    .line 12
    .line 13
    invoke-direct {v0}, Ls2/b;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Ls2/n;->m:Ls2/b;

    .line 17
    .line 18
    iput-object p1, p0, Ls2/n;->c:Lq2/f;

    .line 19
    .line 20
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->d()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Ls2/n;->b:Ljava/lang/String;

    .line 25
    .line 26
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->j()Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iput-object p1, p0, Ls2/n;->d:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    .line 31
    .line 32
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->k()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    iput-boolean v0, p0, Ls2/n;->e:Z

    .line 37
    .line 38
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->g()Lw2/b;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-virtual {v0}, Lw2/b;->a()Lt2/a;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    iput-object v0, p0, Ls2/n;->f:Lt2/a;

    .line 47
    .line 48
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->h()Lw2/m;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-interface {v1}, Lw2/m;->a()Lt2/a;

    .line 53
    .line 54
    .line 55
    move-result-object v1

    .line 56
    iput-object v1, p0, Ls2/n;->g:Lt2/a;

    .line 57
    .line 58
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->i()Lw2/b;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    invoke-virtual {v2}, Lw2/b;->a()Lt2/a;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    iput-object v2, p0, Ls2/n;->h:Lt2/a;

    .line 67
    .line 68
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->e()Lw2/b;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    invoke-virtual {v3}, Lw2/b;->a()Lt2/a;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    iput-object v3, p0, Ls2/n;->j:Lt2/a;

    .line 77
    .line 78
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->f()Lw2/b;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-virtual {v4}, Lw2/b;->a()Lt2/a;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    iput-object v4, p0, Ls2/n;->l:Lt2/a;

    .line 87
    .line 88
    sget-object v5, Lcom/airbnb/lottie/model/content/PolystarShape$Type;->STAR:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    .line 89
    .line 90
    if-ne p1, v5, :cond_70

    .line 91
    .line 92
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->b()Lw2/b;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    invoke-virtual {v6}, Lw2/b;->a()Lt2/a;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    iput-object v6, p0, Ls2/n;->i:Lt2/a;

    .line 101
    .line 102
    invoke-virtual {p3}, Lcom/airbnb/lottie/model/content/PolystarShape;->c()Lw2/b;

    .line 103
    .line 104
    .line 105
    move-result-object p3

    .line 106
    invoke-virtual {p3}, Lw2/b;->a()Lt2/a;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    iput-object p3, p0, Ls2/n;->k:Lt2/a;

    .line 111
    .line 112
    goto :goto_75

    .line 113
    :cond_70
    const/4 p3, 0x0

    .line 114
    iput-object p3, p0, Ls2/n;->i:Lt2/a;

    .line 115
    .line 116
    iput-object p3, p0, Ls2/n;->k:Lt2/a;

    .line 117
    .line 118
    :goto_75
    invoke-virtual {p2, v0}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {p2, v1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {p2, v2}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {p2, v3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p2, v4}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 131
    .line 132
    .line 133
    if-ne p1, v5, :cond_90

    .line 134
    .line 135
    iget-object p3, p0, Ls2/n;->i:Lt2/a;

    .line 136
    .line 137
    invoke-virtual {p2, p3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 138
    .line 139
    .line 140
    iget-object p3, p0, Ls2/n;->k:Lt2/a;

    .line 141
    .line 142
    invoke-virtual {p2, p3}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 143
    .line 144
    .line 145
    :cond_90
    invoke-virtual {v0, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {v2, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v3, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v4, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 158
    .line 159
    .line 160
    if-ne p1, v5, :cond_ab

    .line 161
    .line 162
    iget-object p1, p0, Ls2/n;->i:Lt2/a;

    .line 163
    .line 164
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 165
    .line 166
    .line 167
    iget-object p1, p0, Ls2/n;->k:Lt2/a;

    .line 168
    .line 169
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 170
    .line 171
    .line 172
    :cond_ab
    return-void
.end method


# virtual methods
.method public final b()V
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ls2/n;->f:Lt2/a;

    .line 4
    .line 5
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Ljava/lang/Float;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    float-to-double v1, v1

    .line 16
    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    .line 17
    .line 18
    .line 19
    move-result-wide v1

    .line 20
    double-to-int v1, v1

    .line 21
    iget-object v2, v0, Ls2/n;->h:Lt2/a;

    .line 22
    .line 23
    if-nez v2, :cond_1b

    .line 24
    .line 25
    const-wide/16 v2, 0x0

    .line 26
    .line 27
    goto :goto_26

    .line 28
    :cond_1b
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    check-cast v2, Ljava/lang/Float;

    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    float-to-double v2, v2

    .line 39
    :goto_26
    const-wide v4, 0x4056800000000000L    # 90.0

    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    sub-double/2addr v2, v4

    .line 45
    invoke-static {v2, v3}, Ljava/lang/Math;->toRadians(D)D

    .line 46
    .line 47
    .line 48
    move-result-wide v2

    .line 49
    const-wide v4, 0x401921fb54442d18L    # 6.283185307179586

    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    int-to-double v6, v1

    .line 55
    div-double/2addr v4, v6

    .line 56
    double-to-float v1, v4

    .line 57
    iget-object v4, v0, Ls2/n;->l:Lt2/a;

    .line 58
    .line 59
    invoke-virtual {v4}, Lt2/a;->h()Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    check-cast v4, Ljava/lang/Float;

    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    .line 66
    .line 67
    .line 68
    move-result v4

    .line 69
    const/high16 v5, 0x42c80000    # 100.0f

    .line 70
    .line 71
    div-float/2addr v4, v5

    .line 72
    iget-object v5, v0, Ls2/n;->j:Lt2/a;

    .line 73
    .line 74
    invoke-virtual {v5}, Lt2/a;->h()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    check-cast v5, Ljava/lang/Float;

    .line 79
    .line 80
    invoke-virtual {v5}, Ljava/lang/Float;->floatValue()F

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    float-to-double v8, v5

    .line 85
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 86
    .line 87
    .line 88
    move-result-wide v10

    .line 89
    mul-double v10, v10, v8

    .line 90
    .line 91
    double-to-float v10, v10

    .line 92
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 93
    .line 94
    .line 95
    move-result-wide v11

    .line 96
    mul-double v11, v11, v8

    .line 97
    .line 98
    double-to-float v11, v11

    .line 99
    iget-object v12, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 100
    .line 101
    invoke-virtual {v12, v10, v11}, Landroid/graphics/Path;->moveTo(FF)V

    .line 102
    .line 103
    .line 104
    float-to-double v12, v1

    .line 105
    add-double/2addr v2, v12

    .line 106
    invoke-static {v6, v7}, Ljava/lang/Math;->ceil(D)D

    .line 107
    .line 108
    .line 109
    move-result-wide v6

    .line 110
    const/4 v1, 0x0

    .line 111
    :goto_6e
    int-to-double v14, v1

    .line 112
    cmpg-double v16, v14, v6

    .line 113
    .line 114
    if-gez v16, :cond_fb

    .line 115
    .line 116
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 117
    .line 118
    .line 119
    move-result-wide v14

    .line 120
    mul-double v14, v14, v8

    .line 121
    .line 122
    double-to-float v14, v14

    .line 123
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 124
    .line 125
    .line 126
    move-result-wide v15

    .line 127
    move-wide/from16 v23, v6

    .line 128
    .line 129
    mul-double v6, v8, v15

    .line 130
    .line 131
    double-to-float v6, v6

    .line 132
    const/4 v7, 0x0

    .line 133
    cmpl-float v7, v4, v7

    .line 134
    .line 135
    if-eqz v7, :cond_e1

    .line 136
    .line 137
    move-wide/from16 v25, v8

    .line 138
    .line 139
    float-to-double v7, v11

    .line 140
    move v9, v1

    .line 141
    move-wide/from16 v27, v2

    .line 142
    .line 143
    float-to-double v1, v10

    .line 144
    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->atan2(DD)D

    .line 145
    .line 146
    .line 147
    move-result-wide v1

    .line 148
    const-wide v7, 0x3ff921fb54442d18L    # 1.5707963267948966

    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    sub-double/2addr v1, v7

    .line 154
    double-to-float v1, v1

    .line 155
    float-to-double v1, v1

    .line 156
    invoke-static {v1, v2}, Ljava/lang/Math;->cos(D)D

    .line 157
    .line 158
    .line 159
    move-result-wide v7

    .line 160
    double-to-float v3, v7

    .line 161
    invoke-static {v1, v2}, Ljava/lang/Math;->sin(D)D

    .line 162
    .line 163
    .line 164
    move-result-wide v1

    .line 165
    double-to-float v1, v1

    .line 166
    float-to-double v7, v6

    .line 167
    move-wide/from16 v29, v12

    .line 168
    .line 169
    float-to-double v12, v14

    .line 170
    invoke-static {v7, v8, v12, v13}, Ljava/lang/Math;->atan2(DD)D

    .line 171
    .line 172
    .line 173
    move-result-wide v7

    .line 174
    const-wide v12, 0x3ff921fb54442d18L    # 1.5707963267948966

    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    sub-double/2addr v7, v12

    .line 180
    double-to-float v2, v7

    .line 181
    float-to-double v7, v2

    .line 182
    invoke-static {v7, v8}, Ljava/lang/Math;->cos(D)D

    .line 183
    .line 184
    .line 185
    move-result-wide v12

    .line 186
    double-to-float v2, v12

    .line 187
    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    .line 188
    .line 189
    .line 190
    move-result-wide v7

    .line 191
    double-to-float v7, v7

    .line 192
    mul-float v8, v5, v4

    .line 193
    .line 194
    const/high16 v12, 0x3e800000    # 0.25f

    .line 195
    .line 196
    mul-float v8, v8, v12

    .line 197
    .line 198
    mul-float v3, v3, v8

    .line 199
    .line 200
    mul-float v1, v1, v8

    .line 201
    .line 202
    mul-float v2, v2, v8

    .line 203
    .line 204
    mul-float v8, v8, v7

    .line 205
    .line 206
    iget-object v7, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 207
    .line 208
    sub-float v17, v10, v3

    .line 209
    .line 210
    sub-float v18, v11, v1

    .line 211
    .line 212
    add-float v19, v14, v2

    .line 213
    .line 214
    add-float v20, v6, v8

    .line 215
    .line 216
    move-object/from16 v16, v7

    .line 217
    .line 218
    move/from16 v21, v14

    .line 219
    .line 220
    move/from16 v22, v6

    .line 221
    .line 222
    invoke-virtual/range {v16 .. v22}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 223
    .line 224
    .line 225
    goto :goto_ed

    .line 226
    :cond_e1
    move-wide/from16 v27, v2

    .line 227
    .line 228
    move-wide/from16 v25, v8

    .line 229
    .line 230
    move-wide/from16 v29, v12

    .line 231
    .line 232
    move v9, v1

    .line 233
    iget-object v1, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 234
    .line 235
    invoke-virtual {v1, v14, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 236
    .line 237
    .line 238
    :goto_ed
    add-double v2, v27, v29

    .line 239
    .line 240
    add-int/lit8 v1, v9, 0x1

    .line 241
    .line 242
    move v11, v6

    .line 243
    move v10, v14

    .line 244
    move-wide/from16 v6, v23

    .line 245
    .line 246
    move-wide/from16 v8, v25

    .line 247
    .line 248
    move-wide/from16 v12, v29

    .line 249
    .line 250
    goto/16 :goto_6e

    .line 251
    .line 252
    :cond_fb
    iget-object v1, v0, Ls2/n;->g:Lt2/a;

    .line 253
    .line 254
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    check-cast v1, Landroid/graphics/PointF;

    .line 259
    .line 260
    iget-object v2, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 261
    .line 262
    iget v3, v1, Landroid/graphics/PointF;->x:F

    .line 263
    .line 264
    iget v1, v1, Landroid/graphics/PointF;->y:F

    .line 265
    .line 266
    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->offset(FF)V

    .line 267
    .line 268
    .line 269
    iget-object v1, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 270
    .line 271
    invoke-virtual {v1}, Landroid/graphics/Path;->close()V

    .line 272
    .line 273
    .line 274
    return-void
.end method

.method public d()V
    .registers 1

    invoke-virtual {p0}, Ls2/n;->i()V

    return-void
.end method

.method public e(Ljava/util/List;Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 p2, 0x0

    .line 2
    :goto_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-ge p2, v0, :cond_26

    .line 7
    .line 8
    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ls2/c;

    .line 13
    .line 14
    instance-of v1, v0, Ls2/s;

    .line 15
    .line 16
    if-eqz v1, :cond_23

    .line 17
    .line 18
    check-cast v0, Ls2/s;

    .line 19
    .line 20
    invoke-virtual {v0}, Ls2/s;->i()Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    sget-object v2, Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;->SIMULTANEOUSLY:Lcom/airbnb/lottie/model/content/ShapeTrimPath$Type;

    .line 25
    .line 26
    if-ne v1, v2, :cond_23

    .line 27
    .line 28
    iget-object v1, p0, Ls2/n;->m:Ls2/b;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Ls2/b;->a(Ls2/s;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, p0}, Ls2/s;->b(Lt2/a$b;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    add-int/lit8 p2, p2, 0x1

    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_26
    return-void
.end method

.method public f(Lv2/d;ILjava/util/List;Lv2/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv2/d;",
            "I",
            "Ljava/util/List<",
            "Lv2/d;",
            ">;",
            "Lv2/d;",
            ")V"
        }
    .end annotation

    invoke-static {p1, p2, p3, p4, p0}, Lc3/i;->m(Lv2/d;ILjava/util/List;Lv2/d;Ls2/k;)V

    return-void
.end method

.method public g(Ljava/lang/Object;Ld3/c;)V
    .registers 4
    .param p2    # Ld3/c;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ld3/c<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Lq2/k;->s:Ljava/lang/Float;

    .line 2
    .line 3
    if-ne p1, v0, :cond_a

    .line 4
    .line 5
    iget-object p1, p0, Ls2/n;->f:Lt2/a;

    .line 6
    .line 7
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 8
    .line 9
    .line 10
    goto :goto_49

    .line 11
    :cond_a
    sget-object v0, Lq2/k;->t:Ljava/lang/Float;

    .line 12
    .line 13
    if-ne p1, v0, :cond_14

    .line 14
    .line 15
    iget-object p1, p0, Ls2/n;->h:Lt2/a;

    .line 16
    .line 17
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 18
    .line 19
    .line 20
    goto :goto_49

    .line 21
    :cond_14
    sget-object v0, Lq2/k;->j:Landroid/graphics/PointF;

    .line 22
    .line 23
    if-ne p1, v0, :cond_1e

    .line 24
    .line 25
    iget-object p1, p0, Ls2/n;->g:Lt2/a;

    .line 26
    .line 27
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 28
    .line 29
    .line 30
    goto :goto_49

    .line 31
    :cond_1e
    sget-object v0, Lq2/k;->u:Ljava/lang/Float;

    .line 32
    .line 33
    if-ne p1, v0, :cond_2a

    .line 34
    .line 35
    iget-object v0, p0, Ls2/n;->i:Lt2/a;

    .line 36
    .line 37
    if-eqz v0, :cond_2a

    .line 38
    .line 39
    invoke-virtual {v0, p2}, Lt2/a;->m(Ld3/c;)V

    .line 40
    .line 41
    .line 42
    goto :goto_49

    .line 43
    :cond_2a
    sget-object v0, Lq2/k;->v:Ljava/lang/Float;

    .line 44
    .line 45
    if-ne p1, v0, :cond_34

    .line 46
    .line 47
    iget-object p1, p0, Ls2/n;->j:Lt2/a;

    .line 48
    .line 49
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 50
    .line 51
    .line 52
    goto :goto_49

    .line 53
    :cond_34
    sget-object v0, Lq2/k;->w:Ljava/lang/Float;

    .line 54
    .line 55
    if-ne p1, v0, :cond_40

    .line 56
    .line 57
    iget-object v0, p0, Ls2/n;->k:Lt2/a;

    .line 58
    .line 59
    if-eqz v0, :cond_40

    .line 60
    .line 61
    invoke-virtual {v0, p2}, Lt2/a;->m(Ld3/c;)V

    .line 62
    .line 63
    .line 64
    goto :goto_49

    .line 65
    :cond_40
    sget-object v0, Lq2/k;->x:Ljava/lang/Float;

    .line 66
    .line 67
    if-ne p1, v0, :cond_49

    .line 68
    .line 69
    iget-object p1, p0, Ls2/n;->l:Lt2/a;

    .line 70
    .line 71
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 72
    .line 73
    .line 74
    :cond_49
    :goto_49
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ls2/n;->b:Ljava/lang/String;

    return-object v0
.end method

.method public getPath()Landroid/graphics/Path;
    .registers 4

    .line 1
    iget-boolean v0, p0, Ls2/n;->n:Z

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    iget-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 6
    .line 7
    return-object v0

    .line 8
    :cond_7
    iget-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 9
    .line 10
    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 11
    .line 12
    .line 13
    iget-boolean v0, p0, Ls2/n;->e:Z

    .line 14
    .line 15
    const/4 v1, 0x1

    .line 16
    if-eqz v0, :cond_16

    .line 17
    .line 18
    iput-boolean v1, p0, Ls2/n;->n:Z

    .line 19
    .line 20
    iget-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_16
    sget-object v0, Ls2/n$a;->a:[I

    .line 24
    .line 25
    iget-object v2, p0, Ls2/n;->d:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    aget v0, v0, v2

    .line 32
    .line 33
    if-eq v0, v1, :cond_2a

    .line 34
    .line 35
    const/4 v2, 0x2

    .line 36
    if-eq v0, v2, :cond_26

    .line 37
    .line 38
    goto :goto_2d

    .line 39
    :cond_26
    invoke-virtual {p0}, Ls2/n;->b()V

    .line 40
    .line 41
    .line 42
    goto :goto_2d

    .line 43
    :cond_2a
    invoke-virtual {p0}, Ls2/n;->h()V

    .line 44
    .line 45
    .line 46
    :goto_2d
    iget-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/graphics/Path;->close()V

    .line 49
    .line 50
    .line 51
    iget-object v0, p0, Ls2/n;->m:Ls2/b;

    .line 52
    .line 53
    iget-object v2, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 54
    .line 55
    invoke-virtual {v0, v2}, Ls2/b;->b(Landroid/graphics/Path;)V

    .line 56
    .line 57
    .line 58
    iput-boolean v1, p0, Ls2/n;->n:Z

    .line 59
    .line 60
    iget-object v0, p0, Ls2/n;->a:Landroid/graphics/Path;

    .line 61
    .line 62
    return-object v0
.end method

.method public final h()V
    .registers 44

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ls2/n;->f:Lt2/a;

    .line 4
    .line 5
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Ljava/lang/Float;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    iget-object v2, v0, Ls2/n;->h:Lt2/a;

    .line 16
    .line 17
    if-nez v2, :cond_15

    .line 18
    .line 19
    const-wide/16 v2, 0x0

    .line 20
    .line 21
    goto :goto_20

    .line 22
    :cond_15
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Ljava/lang/Float;

    .line 27
    .line 28
    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    float-to-double v2, v2

    .line 33
    :goto_20
    const-wide v4, 0x4056800000000000L    # 90.0

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    sub-double/2addr v2, v4

    .line 39
    invoke-static {v2, v3}, Ljava/lang/Math;->toRadians(D)D

    .line 40
    .line 41
    .line 42
    move-result-wide v2

    .line 43
    const-wide v4, 0x401921fb54442d18L    # 6.283185307179586

    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    float-to-double v6, v1

    .line 49
    div-double/2addr v4, v6

    .line 50
    double-to-float v4, v4

    .line 51
    const/high16 v5, 0x40000000    # 2.0f

    .line 52
    .line 53
    div-float v8, v4, v5

    .line 54
    .line 55
    float-to-int v9, v1

    .line 56
    int-to-float v9, v9

    .line 57
    sub-float/2addr v1, v9

    .line 58
    const/4 v9, 0x0

    .line 59
    cmpl-float v10, v1, v9

    .line 60
    .line 61
    if-eqz v10, :cond_45

    .line 62
    .line 63
    const/high16 v11, 0x3f800000    # 1.0f

    .line 64
    .line 65
    sub-float/2addr v11, v1

    .line 66
    mul-float v11, v11, v8

    .line 67
    .line 68
    float-to-double v11, v11

    .line 69
    add-double/2addr v2, v11

    .line 70
    :cond_45
    iget-object v11, v0, Ls2/n;->j:Lt2/a;

    .line 71
    .line 72
    invoke-virtual {v11}, Lt2/a;->h()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v11

    .line 76
    check-cast v11, Ljava/lang/Float;

    .line 77
    .line 78
    invoke-virtual {v11}, Ljava/lang/Float;->floatValue()F

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    iget-object v12, v0, Ls2/n;->i:Lt2/a;

    .line 83
    .line 84
    invoke-virtual {v12}, Lt2/a;->h()Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v12

    .line 88
    check-cast v12, Ljava/lang/Float;

    .line 89
    .line 90
    invoke-virtual {v12}, Ljava/lang/Float;->floatValue()F

    .line 91
    .line 92
    .line 93
    move-result v12

    .line 94
    iget-object v13, v0, Ls2/n;->k:Lt2/a;

    .line 95
    .line 96
    const/high16 v14, 0x42c80000    # 100.0f

    .line 97
    .line 98
    if-eqz v13, :cond_6f

    .line 99
    .line 100
    invoke-virtual {v13}, Lt2/a;->h()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v13

    .line 104
    check-cast v13, Ljava/lang/Float;

    .line 105
    .line 106
    invoke-virtual {v13}, Ljava/lang/Float;->floatValue()F

    .line 107
    .line 108
    .line 109
    move-result v13

    .line 110
    div-float/2addr v13, v14

    .line 111
    goto :goto_70

    .line 112
    :cond_6f
    const/4 v13, 0x0

    .line 113
    :goto_70
    iget-object v15, v0, Ls2/n;->l:Lt2/a;

    .line 114
    .line 115
    if-eqz v15, :cond_80

    .line 116
    .line 117
    invoke-virtual {v15}, Lt2/a;->h()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v15

    .line 121
    check-cast v15, Ljava/lang/Float;

    .line 122
    .line 123
    invoke-virtual {v15}, Ljava/lang/Float;->floatValue()F

    .line 124
    .line 125
    .line 126
    move-result v15

    .line 127
    div-float/2addr v15, v14

    .line 128
    goto :goto_81

    .line 129
    :cond_80
    const/4 v15, 0x0

    .line 130
    :goto_81
    if-eqz v10, :cond_a8

    .line 131
    .line 132
    sub-float v14, v11, v12

    .line 133
    .line 134
    mul-float v14, v14, v1

    .line 135
    .line 136
    add-float/2addr v14, v12

    .line 137
    move/from16 v17, v10

    .line 138
    .line 139
    float-to-double v9, v14

    .line 140
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 141
    .line 142
    .line 143
    move-result-wide v18

    .line 144
    move-wide/from16 v20, v6

    .line 145
    .line 146
    mul-double v5, v9, v18

    .line 147
    .line 148
    double-to-float v5, v5

    .line 149
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 150
    .line 151
    .line 152
    move-result-wide v18

    .line 153
    mul-double v9, v9, v18

    .line 154
    .line 155
    double-to-float v6, v9

    .line 156
    iget-object v9, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 157
    .line 158
    invoke-virtual {v9, v5, v6}, Landroid/graphics/Path;->moveTo(FF)V

    .line 159
    .line 160
    .line 161
    mul-float v9, v4, v1

    .line 162
    .line 163
    const/high16 v7, 0x40000000    # 2.0f

    .line 164
    .line 165
    div-float/2addr v9, v7

    .line 166
    float-to-double v9, v9

    .line 167
    add-double/2addr v2, v9

    .line 168
    goto :goto_c6

    .line 169
    :cond_a8
    move-wide/from16 v20, v6

    .line 170
    .line 171
    move/from16 v17, v10

    .line 172
    .line 173
    float-to-double v5, v11

    .line 174
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 175
    .line 176
    .line 177
    move-result-wide v9

    .line 178
    mul-double v9, v9, v5

    .line 179
    .line 180
    double-to-float v9, v9

    .line 181
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 182
    .line 183
    .line 184
    move-result-wide v18

    .line 185
    mul-double v5, v5, v18

    .line 186
    .line 187
    double-to-float v6, v5

    .line 188
    iget-object v5, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 189
    .line 190
    invoke-virtual {v5, v9, v6}, Landroid/graphics/Path;->moveTo(FF)V

    .line 191
    .line 192
    .line 193
    move v10, v6

    .line 194
    float-to-double v5, v8

    .line 195
    add-double/2addr v2, v5

    .line 196
    move v5, v9

    .line 197
    move v6, v10

    .line 198
    const/4 v14, 0x0

    .line 199
    :goto_c6
    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->ceil(D)D

    .line 200
    .line 201
    .line 202
    move-result-wide v9

    .line 203
    const-wide/high16 v18, 0x4000000000000000L    # 2.0

    .line 204
    .line 205
    mul-double v9, v9, v18

    .line 206
    .line 207
    const/16 v20, 0x0

    .line 208
    .line 209
    move/from16 v22, v11

    .line 210
    .line 211
    move/from16 v23, v12

    .line 212
    .line 213
    const/4 v7, 0x0

    .line 214
    const/16 v21, 0x0

    .line 215
    .line 216
    :goto_d7
    int-to-double v11, v7

    .line 217
    cmpg-double v24, v11, v9

    .line 218
    .line 219
    if-gez v24, :cond_1da

    .line 220
    .line 221
    if-eqz v21, :cond_e1

    .line 222
    .line 223
    move/from16 v24, v22

    .line 224
    .line 225
    goto :goto_e3

    .line 226
    :cond_e1
    move/from16 v24, v23

    .line 227
    .line 228
    :goto_e3
    const/16 v16, 0x0

    .line 229
    .line 230
    cmpl-float v25, v14, v16

    .line 231
    .line 232
    if-eqz v25, :cond_fc

    .line 233
    .line 234
    sub-double v26, v9, v18

    .line 235
    .line 236
    cmpl-double v28, v11, v26

    .line 237
    .line 238
    if-nez v28, :cond_fc

    .line 239
    .line 240
    mul-float v26, v4, v1

    .line 241
    .line 242
    const/high16 v20, 0x40000000    # 2.0f

    .line 243
    .line 244
    div-float v26, v26, v20

    .line 245
    .line 246
    move/from16 v42, v26

    .line 247
    .line 248
    move/from16 v26, v4

    .line 249
    .line 250
    move/from16 v4, v42

    .line 251
    .line 252
    goto :goto_101

    .line 253
    :cond_fc
    const/high16 v20, 0x40000000    # 2.0f

    .line 254
    .line 255
    move/from16 v26, v4

    .line 256
    .line 257
    move v4, v8

    .line 258
    :goto_101
    const-wide/high16 v27, 0x3ff0000000000000L    # 1.0

    .line 259
    .line 260
    if-eqz v25, :cond_111

    .line 261
    .line 262
    sub-double v29, v9, v27

    .line 263
    .line 264
    cmpl-double v25, v11, v29

    .line 265
    .line 266
    if-nez v25, :cond_111

    .line 267
    .line 268
    move/from16 v25, v8

    .line 269
    .line 270
    move-wide/from16 v29, v11

    .line 271
    .line 272
    move v8, v14

    .line 273
    goto :goto_117

    .line 274
    :cond_111
    move/from16 v25, v8

    .line 275
    .line 276
    move-wide/from16 v29, v11

    .line 277
    .line 278
    move/from16 v8, v24

    .line 279
    .line 280
    :goto_117
    float-to-double v11, v8

    .line 281
    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    .line 282
    .line 283
    .line 284
    move-result-wide v31

    .line 285
    move-wide/from16 v33, v9

    .line 286
    .line 287
    mul-double v8, v11, v31

    .line 288
    .line 289
    double-to-float v8, v8

    .line 290
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 291
    .line 292
    .line 293
    move-result-wide v9

    .line 294
    mul-double v11, v11, v9

    .line 295
    .line 296
    double-to-float v9, v11

    .line 297
    const/4 v10, 0x0

    .line 298
    cmpl-float v11, v13, v10

    .line 299
    .line 300
    if-nez v11, :cond_13c

    .line 301
    .line 302
    cmpl-float v11, v15, v10

    .line 303
    .line 304
    if-nez v11, :cond_13c

    .line 305
    .line 306
    iget-object v5, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 307
    .line 308
    invoke-virtual {v5, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 309
    .line 310
    .line 311
    move/from16 v16, v13

    .line 312
    .line 313
    move/from16 v24, v14

    .line 314
    .line 315
    goto/16 :goto_1c6

    .line 316
    .line 317
    :cond_13c
    float-to-double v11, v6

    .line 318
    move/from16 v16, v13

    .line 319
    .line 320
    move/from16 v24, v14

    .line 321
    .line 322
    float-to-double v13, v5

    .line 323
    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->atan2(DD)D

    .line 324
    .line 325
    .line 326
    move-result-wide v11

    .line 327
    const-wide v13, 0x3ff921fb54442d18L    # 1.5707963267948966

    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    sub-double/2addr v11, v13

    .line 333
    double-to-float v11, v11

    .line 334
    float-to-double v11, v11

    .line 335
    invoke-static {v11, v12}, Ljava/lang/Math;->cos(D)D

    .line 336
    .line 337
    .line 338
    move-result-wide v13

    .line 339
    double-to-float v13, v13

    .line 340
    invoke-static {v11, v12}, Ljava/lang/Math;->sin(D)D

    .line 341
    .line 342
    .line 343
    move-result-wide v11

    .line 344
    double-to-float v11, v11

    .line 345
    move v14, v11

    .line 346
    float-to-double v10, v9

    .line 347
    move/from16 v35, v13

    .line 348
    .line 349
    float-to-double v12, v8

    .line 350
    invoke-static {v10, v11, v12, v13}, Ljava/lang/Math;->atan2(DD)D

    .line 351
    .line 352
    .line 353
    move-result-wide v10

    .line 354
    const-wide v12, 0x3ff921fb54442d18L    # 1.5707963267948966

    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    sub-double/2addr v10, v12

    .line 360
    double-to-float v10, v10

    .line 361
    float-to-double v10, v10

    .line 362
    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    .line 363
    .line 364
    .line 365
    move-result-wide v12

    .line 366
    double-to-float v12, v12

    .line 367
    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    .line 368
    .line 369
    .line 370
    move-result-wide v10

    .line 371
    double-to-float v10, v10

    .line 372
    if-eqz v21, :cond_178

    .line 373
    .line 374
    move/from16 v11, v16

    .line 375
    .line 376
    goto :goto_179

    .line 377
    :cond_178
    move v11, v15

    .line 378
    :goto_179
    if-eqz v21, :cond_17d

    .line 379
    .line 380
    move v13, v15

    .line 381
    goto :goto_17f

    .line 382
    :cond_17d
    move/from16 v13, v16

    .line 383
    .line 384
    :goto_17f
    if-eqz v21, :cond_184

    .line 385
    .line 386
    move/from16 v31, v23

    .line 387
    .line 388
    goto :goto_186

    .line 389
    :cond_184
    move/from16 v31, v22

    .line 390
    .line 391
    :goto_186
    if-eqz v21, :cond_18b

    .line 392
    .line 393
    move/from16 v32, v22

    .line 394
    .line 395
    goto :goto_18d

    .line 396
    :cond_18b
    move/from16 v32, v23

    .line 397
    .line 398
    :goto_18d
    mul-float v31, v31, v11

    .line 399
    .line 400
    const v11, 0x3ef4e26d    # 0.47829f

    .line 401
    .line 402
    .line 403
    mul-float v31, v31, v11

    .line 404
    .line 405
    mul-float v35, v35, v31

    .line 406
    .line 407
    mul-float v31, v31, v14

    .line 408
    .line 409
    mul-float v32, v32, v13

    .line 410
    .line 411
    mul-float v32, v32, v11

    .line 412
    .line 413
    mul-float v12, v12, v32

    .line 414
    .line 415
    mul-float v32, v32, v10

    .line 416
    .line 417
    if-eqz v17, :cond_1b3

    .line 418
    .line 419
    if-nez v7, :cond_1a9

    .line 420
    .line 421
    mul-float v35, v35, v1

    .line 422
    .line 423
    mul-float v31, v31, v1

    .line 424
    .line 425
    goto :goto_1b3

    .line 426
    :cond_1a9
    sub-double v10, v33, v27

    .line 427
    .line 428
    cmpl-double v13, v29, v10

    .line 429
    .line 430
    if-nez v13, :cond_1b3

    .line 431
    .line 432
    mul-float v12, v12, v1

    .line 433
    .line 434
    mul-float v32, v32, v1

    .line 435
    .line 436
    :cond_1b3
    :goto_1b3
    iget-object v10, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 437
    .line 438
    sub-float v36, v5, v35

    .line 439
    .line 440
    sub-float v37, v6, v31

    .line 441
    .line 442
    add-float v38, v8, v12

    .line 443
    .line 444
    add-float v39, v9, v32

    .line 445
    .line 446
    move-object/from16 v35, v10

    .line 447
    .line 448
    move/from16 v40, v8

    .line 449
    .line 450
    move/from16 v41, v9

    .line 451
    .line 452
    invoke-virtual/range {v35 .. v41}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 453
    .line 454
    .line 455
    :goto_1c6
    float-to-double v4, v4

    .line 456
    add-double/2addr v2, v4

    .line 457
    xor-int/lit8 v21, v21, 0x1

    .line 458
    .line 459
    add-int/lit8 v7, v7, 0x1

    .line 460
    .line 461
    move v5, v8

    .line 462
    move v6, v9

    .line 463
    move/from16 v13, v16

    .line 464
    .line 465
    move/from16 v14, v24

    .line 466
    .line 467
    move/from16 v8, v25

    .line 468
    .line 469
    move/from16 v4, v26

    .line 470
    .line 471
    move-wide/from16 v9, v33

    .line 472
    .line 473
    goto/16 :goto_d7

    .line 474
    .line 475
    :cond_1da
    iget-object v1, v0, Ls2/n;->g:Lt2/a;

    .line 476
    .line 477
    invoke-virtual {v1}, Lt2/a;->h()Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    move-result-object v1

    .line 481
    check-cast v1, Landroid/graphics/PointF;

    .line 482
    .line 483
    iget-object v2, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 484
    .line 485
    iget v3, v1, Landroid/graphics/PointF;->x:F

    .line 486
    .line 487
    iget v1, v1, Landroid/graphics/PointF;->y:F

    .line 488
    .line 489
    invoke-virtual {v2, v3, v1}, Landroid/graphics/Path;->offset(FF)V

    .line 490
    .line 491
    .line 492
    iget-object v1, v0, Ls2/n;->a:Landroid/graphics/Path;

    .line 493
    .line 494
    invoke-virtual {v1}, Landroid/graphics/Path;->close()V

    .line 495
    .line 496
    .line 497
    return-void
.end method

.method public final i()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Ls2/n;->n:Z

    .line 3
    .line 4
    iget-object v0, p0, Ls2/n;->c:Lq2/f;

    .line 5
    .line 6
    invoke-virtual {v0}, Lq2/f;->invalidateSelf()V

    .line 7
    .line 8
    .line 9
    return-void
.end method

###### Class s2.n.a (s2.n$a)
.class public synthetic Ls2/n$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Ls2/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic a:[I


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/airbnb/lottie/model/content/PolystarShape$Type;->values()[Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, Ls2/n$a;->a:[I

    :try_start_9
    sget-object v1, Lcom/airbnb/lottie/model/content/PolystarShape$Type;->STAR:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_12} :catch_12

    :catch_12
    :try_start_12
    sget-object v0, Ls2/n$a;->a:[I

    sget-object v1, Lcom/airbnb/lottie/model/content/PolystarShape$Type;->POLYGON:Lcom/airbnb/lottie/model/content/PolystarShape$Type;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1d} :catch_1d

    :catch_1d
    return-void
.end method
