###### Class s2.g (s2.g)
.class public Ls2/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls2/e;
.implements Lt2/a$b;
.implements Ls2/k;


# instance fields
.field public final a:Landroid/graphics/Path;

.field public final b:Landroid/graphics/Paint;

.field public final c:Lcom/airbnb/lottie/model/layer/a;

.field public final d:Ljava/lang/String;

.field public final e:Z

.field public final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ls2/m;",
            ">;"
        }
    .end annotation
.end field

.field public final g:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final h:Lt2/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public i:Lt2/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt2/a<",
            "Landroid/graphics/ColorFilter;",
            "Landroid/graphics/ColorFilter;",
            ">;"
        }
    .end annotation
.end field

.field public final j:Lq2/f;


# direct methods
.method public constructor <init>(Lq2/f;Lcom/airbnb/lottie/model/layer/a;Lx2/h;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/graphics/Path;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 10
    .line 11
    new-instance v1, Lr2/a;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    invoke-direct {v1, v2}, Lr2/a;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, Ls2/g;->b:Landroid/graphics/Paint;

    .line 18
    .line 19
    new-instance v1, Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v1, p0, Ls2/g;->f:Ljava/util/List;

    .line 25
    .line 26
    iput-object p2, p0, Ls2/g;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 27
    .line 28
    invoke-virtual {p3}, Lx2/h;->d()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    iput-object v1, p0, Ls2/g;->d:Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {p3}, Lx2/h;->f()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iput-boolean v1, p0, Ls2/g;->e:Z

    .line 39
    .line 40
    iput-object p1, p0, Ls2/g;->j:Lq2/f;

    .line 41
    .line 42
    invoke-virtual {p3}, Lx2/h;->b()Lw2/a;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    if-eqz p1, :cond_5e

    .line 47
    .line 48
    invoke-virtual {p3}, Lx2/h;->e()Lw2/d;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    if-nez p1, :cond_36

    .line 53
    .line 54
    goto :goto_5e

    .line 55
    :cond_36
    invoke-virtual {p3}, Lx2/h;->c()Landroid/graphics/Path$FillType;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-virtual {v0, p1}, Landroid/graphics/Path;->setFillType(Landroid/graphics/Path$FillType;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p3}, Lx2/h;->b()Lw2/a;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-virtual {p1}, Lw2/a;->a()Lt2/a;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    iput-object p1, p0, Ls2/g;->g:Lt2/a;

    .line 71
    .line 72
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p3}, Lx2/h;->e()Lw2/d;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    invoke-virtual {p1}, Lw2/d;->a()Lt2/a;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    iput-object p1, p0, Ls2/g;->h:Lt2/a;

    .line 87
    .line 88
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p2, p1}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 92
    .line 93
    .line 94
    return-void

    .line 95
    :cond_5e
    :goto_5e
    const/4 p1, 0x0

    .line 96
    iput-object p1, p0, Ls2/g;->g:Lt2/a;

    .line 97
    .line 98
    iput-object p1, p0, Ls2/g;->h:Lt2/a;

    .line 99
    .line 100
    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/RectF;Landroid/graphics/Matrix;Z)V
    .registers 7

    .line 1
    iget-object p3, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 2
    .line 3
    invoke-virtual {p3}, Landroid/graphics/Path;->reset()V

    .line 4
    .line 5
    .line 6
    const/4 p3, 0x0

    .line 7
    const/4 v0, 0x0

    .line 8
    :goto_7
    iget-object v1, p0, Ls2/g;->f:Ljava/util/List;

    .line 9
    .line 10
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-ge v0, v1, :cond_23

    .line 15
    .line 16
    iget-object v1, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 17
    .line 18
    iget-object v2, p0, Ls2/g;->f:Ljava/util/List;

    .line 19
    .line 20
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ls2/m;

    .line 25
    .line 26
    invoke-interface {v2}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    invoke-virtual {v1, v2, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 31
    .line 32
    .line 33
    add-int/lit8 v0, v0, 0x1

    .line 34
    .line 35
    goto :goto_7

    .line 36
    :cond_23
    iget-object p2, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 37
    .line 38
    invoke-virtual {p2, p1, p3}, Landroid/graphics/Path;->computeBounds(Landroid/graphics/RectF;Z)V

    .line 39
    .line 40
    .line 41
    iget p2, p1, Landroid/graphics/RectF;->left:F

    .line 42
    .line 43
    const/high16 p3, 0x3f800000    # 1.0f

    .line 44
    .line 45
    sub-float/2addr p2, p3

    .line 46
    iget v0, p1, Landroid/graphics/RectF;->top:F

    .line 47
    .line 48
    sub-float/2addr v0, p3

    .line 49
    iget v1, p1, Landroid/graphics/RectF;->right:F

    .line 50
    .line 51
    add-float/2addr v1, p3

    .line 52
    iget v2, p1, Landroid/graphics/RectF;->bottom:F

    .line 53
    .line 54
    add-float/2addr v2, p3

    .line 55
    invoke-virtual {p1, p2, v0, v1, v2}, Landroid/graphics/RectF;->set(FFFF)V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public c(Landroid/graphics/Canvas;Landroid/graphics/Matrix;I)V
    .registers 8

    .line 1
    iget-boolean v0, p0, Ls2/g;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const-string v0, "FillContent#draw"

    .line 7
    .line 8
    invoke-static {v0}, Lq2/c;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Ls2/g;->b:Landroid/graphics/Paint;

    .line 12
    .line 13
    iget-object v2, p0, Ls2/g;->g:Lt2/a;

    .line 14
    .line 15
    check-cast v2, Lt2/b;

    .line 16
    .line 17
    invoke-virtual {v2}, Lt2/b;->o()I

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 22
    .line 23
    .line 24
    int-to-float p3, p3

    .line 25
    const/high16 v1, 0x437f0000    # 255.0f

    .line 26
    .line 27
    div-float/2addr p3, v1

    .line 28
    iget-object v2, p0, Ls2/g;->h:Lt2/a;

    .line 29
    .line 30
    invoke-virtual {v2}, Lt2/a;->h()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    check-cast v2, Ljava/lang/Integer;

    .line 35
    .line 36
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    int-to-float v2, v2

    .line 41
    mul-float p3, p3, v2

    .line 42
    .line 43
    const/high16 v2, 0x42c80000    # 100.0f

    .line 44
    .line 45
    div-float/2addr p3, v2

    .line 46
    mul-float p3, p3, v1

    .line 47
    .line 48
    float-to-int p3, p3

    .line 49
    iget-object v1, p0, Ls2/g;->b:Landroid/graphics/Paint;

    .line 50
    .line 51
    const/16 v2, 0xff

    .line 52
    .line 53
    const/4 v3, 0x0

    .line 54
    invoke-static {p3, v3, v2}, Lc3/i;->d(III)I

    .line 55
    .line 56
    .line 57
    move-result p3

    .line 58
    invoke-virtual {v1, p3}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 59
    .line 60
    .line 61
    iget-object p3, p0, Ls2/g;->i:Lt2/a;

    .line 62
    .line 63
    if-eqz p3, :cond_4b

    .line 64
    .line 65
    iget-object v1, p0, Ls2/g;->b:Landroid/graphics/Paint;

    .line 66
    .line 67
    invoke-virtual {p3}, Lt2/a;->h()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p3

    .line 71
    check-cast p3, Landroid/graphics/ColorFilter;

    .line 72
    .line 73
    invoke-virtual {v1, p3}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    .line 74
    .line 75
    .line 76
    :cond_4b
    iget-object p3, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 77
    .line 78
    invoke-virtual {p3}, Landroid/graphics/Path;->reset()V

    .line 79
    .line 80
    .line 81
    :goto_50
    iget-object p3, p0, Ls2/g;->f:Ljava/util/List;

    .line 82
    .line 83
    invoke-interface {p3}, Ljava/util/List;->size()I

    .line 84
    .line 85
    .line 86
    move-result p3

    .line 87
    if-ge v3, p3, :cond_6c

    .line 88
    .line 89
    iget-object p3, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 90
    .line 91
    iget-object v1, p0, Ls2/g;->f:Ljava/util/List;

    .line 92
    .line 93
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    check-cast v1, Ls2/m;

    .line 98
    .line 99
    invoke-interface {v1}, Ls2/m;->getPath()Landroid/graphics/Path;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    invoke-virtual {p3, v1, p2}, Landroid/graphics/Path;->addPath(Landroid/graphics/Path;Landroid/graphics/Matrix;)V

    .line 104
    .line 105
    .line 106
    add-int/lit8 v3, v3, 0x1

    .line 107
    .line 108
    goto :goto_50

    .line 109
    :cond_6c
    iget-object p2, p0, Ls2/g;->a:Landroid/graphics/Path;

    .line 110
    .line 111
    iget-object p3, p0, Ls2/g;->b:Landroid/graphics/Paint;

    .line 112
    .line 113
    invoke-virtual {p1, p2, p3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 114
    .line 115
    .line 116
    invoke-static {v0}, Lq2/c;->b(Ljava/lang/String;)F

    .line 117
    .line 118
    .line 119
    return-void
.end method

.method public d()V
    .registers 2

    iget-object v0, p0, Ls2/g;->j:Lq2/f;

    invoke-virtual {v0}, Lq2/f;->invalidateSelf()V

    return-void
.end method

.method public e(Ljava/util/List;Ljava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;",
            "Ljava/util/List<",
            "Ls2/c;",
            ">;)V"
        }
    .end annotation

    .line 1
    const/4 p1, 0x0

    .line 2
    :goto_1
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    if-ge p1, v0, :cond_1b

    .line 7
    .line 8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ls2/c;

    .line 13
    .line 14
    instance-of v1, v0, Ls2/m;

    .line 15
    .line 16
    if-eqz v1, :cond_18

    .line 17
    .line 18
    iget-object v1, p0, Ls2/g;->f:Ljava/util/List;

    .line 19
    .line 20
    check-cast v0, Ls2/m;

    .line 21
    .line 22
    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    :cond_18
    add-int/lit8 p1, p1, 0x1

    .line 26
    .line 27
    goto :goto_1

    .line 28
    :cond_1b
    return-void
.end method

.method public f(Lv2/d;ILjava/util/List;Lv2/d;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv2/d;",
            "I",
            "Ljava/util/List<",
            "Lv2/d;",
            ">;",
            "Lv2/d;",
            ")V"
        }
    .end annotation

    invoke-static {p1, p2, p3, p4, p0}, Lc3/i;->m(Lv2/d;ILjava/util/List;Lv2/d;Ls2/k;)V

    return-void
.end method

.method public g(Ljava/lang/Object;Ld3/c;)V
    .registers 4
    .param p2    # Ld3/c;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ld3/c<",
            "TT;>;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Lq2/k;->a:Ljava/lang/Integer;

    .line 2
    .line 3
    if-ne p1, v0, :cond_a

    .line 4
    .line 5
    iget-object p1, p0, Ls2/g;->g:Lt2/a;

    .line 6
    .line 7
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 8
    .line 9
    .line 10
    goto :goto_38

    .line 11
    :cond_a
    sget-object v0, Lq2/k;->d:Ljava/lang/Integer;

    .line 12
    .line 13
    if-ne p1, v0, :cond_14

    .line 14
    .line 15
    iget-object p1, p0, Ls2/g;->h:Lt2/a;

    .line 16
    .line 17
    invoke-virtual {p1, p2}, Lt2/a;->m(Ld3/c;)V

    .line 18
    .line 19
    .line 20
    goto :goto_38

    .line 21
    :cond_14
    sget-object v0, Lq2/k;->C:Landroid/graphics/ColorFilter;

    .line 22
    .line 23
    if-ne p1, v0, :cond_38

    .line 24
    .line 25
    iget-object p1, p0, Ls2/g;->i:Lt2/a;

    .line 26
    .line 27
    if-eqz p1, :cond_21

    .line 28
    .line 29
    iget-object v0, p0, Ls2/g;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, Lcom/airbnb/lottie/model/layer/a;->C(Lt2/a;)V

    .line 32
    .line 33
    .line 34
    :cond_21
    if-nez p2, :cond_27

    .line 35
    .line 36
    const/4 p1, 0x0

    .line 37
    iput-object p1, p0, Ls2/g;->i:Lt2/a;

    .line 38
    .line 39
    goto :goto_38

    .line 40
    :cond_27
    new-instance p1, Lt2/p;

    .line 41
    .line 42
    invoke-direct {p1, p2}, Lt2/p;-><init>(Ld3/c;)V

    .line 43
    .line 44
    .line 45
    iput-object p1, p0, Ls2/g;->i:Lt2/a;

    .line 46
    .line 47
    invoke-virtual {p1, p0}, Lt2/a;->a(Lt2/a$b;)V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Ls2/g;->c:Lcom/airbnb/lottie/model/layer/a;

    .line 51
    .line 52
    iget-object p2, p0, Ls2/g;->i:Lt2/a;

    .line 53
    .line 54
    invoke-virtual {p1, p2}, Lcom/airbnb/lottie/model/layer/a;->i(Lt2/a;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    :goto_38
    return-void
.end method

.method public getName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Ls2/g;->d:Ljava/lang/String;

    return-object v0
.end method
