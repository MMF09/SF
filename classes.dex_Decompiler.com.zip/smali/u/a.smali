###### Class u.a (u.a)
.class public final synthetic Lu/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/hardware/camera2/params/InputConfiguration;)Z
    .registers 1

    invoke-virtual {p0}, Landroid/hardware/camera2/params/InputConfiguration;->isMultiResolution()Z

    move-result p0

    return p0
.end method
