###### Class defpackage.MMSDeviceClockFrequency (MMSDeviceClockFrequency)
.class public final LMMSDeviceClockFrequency;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LMMSDeviceClockFrequency$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT_FREQUENCY:Ljava/lang/Long;

.field public static final DEFAULT_NUMBER:Ljava/lang/Integer;

.field private static final serialVersionUID:J


# instance fields
.field public final frequency:Ljava/lang/Long;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x2
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT64:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final number:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x1
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, LMMSDeviceClockFrequency;->DEFAULT_NUMBER:Ljava/lang/Integer;

    .line 7
    .line 8
    const-wide/16 v0, 0x0

    .line 9
    .line 10
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, LMMSDeviceClockFrequency;->DEFAULT_FREQUENCY:Ljava/lang/Long;

    .line 15
    .line 16
    return-void
.end method

.method private constructor <init>(LMMSDeviceClockFrequency$Builder;)V
    .registers 4

    .line 5
    iget-object v0, p1, LMMSDeviceClockFrequency$Builder;->number:Ljava/lang/Integer;

    iget-object v1, p1, LMMSDeviceClockFrequency$Builder;->frequency:Ljava/lang/Long;

    invoke-direct {p0, v0, v1}, LMMSDeviceClockFrequency;-><init>(Ljava/lang/Integer;Ljava/lang/Long;)V

    .line 6
    invoke-virtual {p0, p1}, Lcom/squareup/wire/Message;->setBuilder(Lcom/squareup/wire/Message$Builder;)V

    return-void
.end method

.method public synthetic constructor <init>(LMMSDeviceClockFrequency$Builder;LMMSDeviceClockFrequency$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LMMSDeviceClockFrequency;-><init>(LMMSDeviceClockFrequency$Builder;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Integer;Ljava/lang/Long;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Lcom/squareup/wire/Message;-><init>()V

    .line 3
    iput-object p1, p0, LMMSDeviceClockFrequency;->number:Ljava/lang/Integer;

    .line 4
    iput-object p2, p0, LMMSDeviceClockFrequency;->frequency:Ljava/lang/Long;

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LMMSDeviceClockFrequency;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LMMSDeviceClockFrequency;

    .line 12
    .line 13
    iget-object v1, p0, LMMSDeviceClockFrequency;->number:Ljava/lang/Integer;

    .line 14
    .line 15
    iget-object v3, p1, LMMSDeviceClockFrequency;->number:Ljava/lang/Integer;

    .line 16
    .line 17
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_21

    .line 22
    .line 23
    iget-object v1, p0, LMMSDeviceClockFrequency;->frequency:Ljava/lang/Long;

    .line 24
    .line 25
    iget-object p1, p1, LMMSDeviceClockFrequency;->frequency:Ljava/lang/Long;

    .line 26
    .line 27
    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_21

    .line 32
    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v0, 0x0

    .line 35
    :goto_22
    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 2
    .line 3
    if-nez v0, :cond_1c

    .line 4
    .line 5
    iget-object v0, p0, LMMSDeviceClockFrequency;->number:Ljava/lang/Integer;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Integer;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    mul-int/lit8 v0, v0, 0x25

    .line 17
    .line 18
    iget-object v2, p0, LMMSDeviceClockFrequency;->frequency:Ljava/lang/Long;

    .line 19
    .line 20
    if-eqz v2, :cond_19

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Long;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    :cond_19
    add-int/2addr v0, v1

    .line 27
    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 28
    .line 29
    :cond_1c
    return v0
.end method

###### Class MMSDeviceClockFrequency.Builder (MMSDeviceClockFrequency$Builder)
.class public final LMMSDeviceClockFrequency$Builder;
.super Lcom/squareup/wire/Message$Builder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceClockFrequency;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/Message$Builder<",
        "LMMSDeviceClockFrequency;",
        ">;"
    }
.end annotation


# instance fields
.field public frequency:Ljava/lang/Long;

.field public number:Ljava/lang/Integer;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/squareup/wire/Message$Builder;-><init>()V

    return-void
.end method

.method public constructor <init>(LMMSDeviceClockFrequency;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/squareup/wire/Message$Builder;-><init>(Lcom/squareup/wire/Message;)V

    if-nez p1, :cond_6

    return-void

    .line 3
    :cond_6
    iget-object v0, p1, LMMSDeviceClockFrequency;->number:Ljava/lang/Integer;

    iput-object v0, p0, LMMSDeviceClockFrequency$Builder;->number:Ljava/lang/Integer;

    .line 4
    iget-object p1, p1, LMMSDeviceClockFrequency;->frequency:Ljava/lang/Long;

    iput-object p1, p0, LMMSDeviceClockFrequency$Builder;->frequency:Ljava/lang/Long;

    return-void
.end method


# virtual methods
.method public build()LMMSDeviceClockFrequency;
    .registers 3

    .line 2
    new-instance v0, LMMSDeviceClockFrequency;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, LMMSDeviceClockFrequency;-><init>(LMMSDeviceClockFrequency$Builder;LMMSDeviceClockFrequency$a;)V

    return-object v0
.end method

.method public bridge synthetic build()Lcom/squareup/wire/Message;
    .registers 2

    .line 1
    invoke-virtual {p0}, LMMSDeviceClockFrequency$Builder;->build()LMMSDeviceClockFrequency;

    move-result-object v0

    return-object v0
.end method

.method public frequency(Ljava/lang/Long;)LMMSDeviceClockFrequency$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceClockFrequency$Builder;->frequency:Ljava/lang/Long;

    return-object p0
.end method

.method public number(Ljava/lang/Integer;)LMMSDeviceClockFrequency$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceClockFrequency$Builder;->number:Ljava/lang/Integer;

    return-object p0
.end method

###### Class MMSDeviceClockFrequency.a (MMSDeviceClockFrequency$a)
.class public synthetic LMMSDeviceClockFrequency$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceClockFrequency;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation
