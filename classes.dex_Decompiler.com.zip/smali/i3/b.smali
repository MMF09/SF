###### Class i3.b (i3.b)
.class public final Li3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Li3/a;

.field public b:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2
    .param p1    # Landroid/content/Context;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Landroid/webkit/WebView;
    .registers 2

    iget-object v0, p0, Li3/b;->b:Landroid/webkit/WebView;

    return-object v0
.end method

.method public final b(Landroid/view/View;)V
    .registers 10
    .param p1    # Landroid/view/View;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    .line 1
    new-instance v7, Li3/a;

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v3, 0x0

    .line 5
    const/4 v4, 0x0

    .line 6
    const/16 v5, 0xe

    .line 7
    .line 8
    const/4 v6, 0x0

    .line 9
    move-object v0, v7

    .line 10
    move-object v1, p1

    .line 11
    invoke-direct/range {v0 .. v6}, Li3/a;-><init>(Landroid/view/View;IIZILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 12
    .line 13
    .line 14
    iput-object v7, p0, Li3/b;->a:Li3/a;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    const/4 v1, 0x2

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-static {v7, p1, v0, v1, v2}, Li3/a;->d(Li3/a;Landroid/view/View;ZILjava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
