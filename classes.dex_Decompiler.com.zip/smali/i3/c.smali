###### Class i3.c (i3.c)
.class public final Li3/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Li3/e;


# direct methods
.method public constructor <init>(Li3/e;)V
    .registers 2
    .param p1    # Li3/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Li3/c;->a:Li3/e;

    return-void
.end method


# virtual methods
.method public final getData(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    iget-object v0, p0, Li3/c;->a:Li3/e;

    const-string v1, ""

    if-eqz p1, :cond_7

    goto :goto_8

    :cond_7
    move-object p1, v1

    :goto_8
    if-eqz p2, :cond_b

    goto :goto_c

    :cond_b
    move-object p2, v1

    :goto_c
    invoke-interface {v0, p1, p2}, Li3/e;->e(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
