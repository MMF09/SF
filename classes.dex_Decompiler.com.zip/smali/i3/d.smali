###### Class i3.d (i3.d)
.class public final Li3/d;
.super Landroid/webkit/WebChromeClient;
.source "SourceFile"


# instance fields
.field public final a:Li3/e;


# direct methods
.method public constructor <init>(Li3/e;)V
    .registers 2
    .param p1    # Li3/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    iput-object p1, p0, Li3/d;->a:Li3/e;

    return-void
.end method


# virtual methods
.method public onCreateWindow(Landroid/webkit/WebView;ZZLandroid/os/Message;)Z
    .registers 5

    .line 1
    new-instance p2, Li3/b;

    .line 2
    .line 3
    if-nez p1, :cond_7

    .line 4
    .line 5
    invoke-static {}, Lkotlin/jvm/internal/Intrinsics;->throwNpe()V

    .line 6
    .line 7
    .line 8
    :cond_7
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const-string p3, "view!!.context"

    .line 13
    .line 14
    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->checkExpressionValueIsNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-direct {p2, p1}, Li3/b;-><init>(Landroid/content/Context;)V

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, Li3/d;->a:Li3/e;

    .line 21
    .line 22
    invoke-interface {p1}, Li3/e;->q()Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p2, p1}, Li3/b;->b(Landroid/view/View;)V

    .line 27
    .line 28
    .line 29
    if-eqz p4, :cond_21

    .line 30
    .line 31
    iget-object p1, p4, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 32
    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 p1, 0x0

    .line 35
    :goto_22
    if-eqz p1, :cond_32

    .line 36
    .line 37
    check-cast p1, Landroid/webkit/WebView$WebViewTransport;

    .line 38
    .line 39
    invoke-virtual {p2}, Li3/b;->a()Landroid/webkit/WebView;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    invoke-virtual {p1, p2}, Landroid/webkit/WebView$WebViewTransport;->setWebView(Landroid/webkit/WebView;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p4}, Landroid/os/Message;->sendToTarget()V

    .line 47
    .line 48
    .line 49
    const/4 p1, 0x1

    .line 50
    return p1

    .line 51
    :cond_32
    new-instance p1, Lkotlin/TypeCastException;

    .line 52
    .line 53
    const-string p2, "null cannot be cast to non-null type android.webkit.WebView.WebViewTransport"

    .line 54
    .line 55
    invoke-direct {p1, p2}, Lkotlin/TypeCastException;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw p1
.end method

.method public onProgressChanged(Landroid/webkit/WebView;I)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onProgressChanged(Landroid/webkit/WebView;I)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Li3/d;->a:Li3/e;

    .line 5
    .line 6
    invoke-interface {p1, p2}, Li3/e;->u(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
