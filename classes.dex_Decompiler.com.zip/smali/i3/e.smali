###### Class i3.e (i3.e)
.class public interface abstract Li3/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e(Ljava/lang/String;Ljava/lang/String;)V
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
.end method

.method public abstract f(Landroid/webkit/WebView;Ljava/lang/String;)V
.end method

.method public abstract q()Landroid/view/View;
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation
.end method

.method public abstract u(I)V
.end method

.method public abstract v(Z)V
.end method

.method public abstract w(Z)V
.end method
