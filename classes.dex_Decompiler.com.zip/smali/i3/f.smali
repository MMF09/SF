###### Class i3.f (i3.f)
.class public final Li3/f;
.super Landroid/webkit/WebViewClient;
.source "SourceFile"


# instance fields
.field public a:Z

.field public final b:Li3/e;


# direct methods
.method public constructor <init>(Li3/e;)V
    .registers 2
    .param p1    # Li3/e;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    iput-object p1, p0, Li3/f;->b:Li3/e;

    return-void
.end method


# virtual methods
.method public onFormResubmission(Landroid/webkit/WebView;Landroid/os/Message;Landroid/os/Message;)V
    .registers 4

    if-eqz p3, :cond_5

    invoke-virtual {p3}, Landroid/os/Message;->sendToTarget()V

    :cond_5
    return-void
.end method

.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .registers 5

    .line 1
    iget-object v0, p0, Li3/f;->b:Li3/e;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-interface {v0, v1}, Li3/e;->w(Z)V

    .line 5
    .line 6
    .line 7
    invoke-interface {v0, p1, p2}, Li3/e;->f(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iget-boolean p1, p0, Li3/f;->a:Z

    .line 11
    .line 12
    invoke-interface {v0, p1}, Li3/e;->v(Z)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .registers 4

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Li3/f;->b:Li3/e;

    .line 5
    .line 6
    const/4 p2, 0x1

    .line 7
    invoke-interface {p1, p2}, Li3/e;->w(Z)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public onReceivedError(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;Landroid/webkit/WebResourceError;)V
    .registers 4

    const/4 p1, 0x1

    iput-boolean p1, p0, Li3/f;->a:Z

    return-void
.end method
