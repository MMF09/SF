###### Class defpackage.MMSDeviceChipInfo (MMSDeviceChipInfo)
.class public final LMMSDeviceChipInfo;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LMMSDeviceChipInfo$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT_CPU_CLOCK_FREQUENCIES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_CPU_CORE_NUMBER:Ljava/lang/Integer;

.field public static final DEFAULT_CPU_STRUCTURE:Ljava/lang/String; = ""

.field public static final DEFAULT_GPU_CLOCK_FREQUENCIES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_GPU_MODEL:Ljava/lang/String; = ""

.field private static final serialVersionUID:J


# instance fields
.field public final cpu_clock_frequencies:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        messageType = LMMSDeviceClockFrequency;
        tag = 0x3
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public final cpu_core_number:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x2
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final cpu_structure:Ljava/lang/String;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x1
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final gpu_clock_frequencies:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        messageType = LMMSDeviceClockFrequency;
        tag = 0x5
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public final gpu_model:Ljava/lang/String;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x4
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, LMMSDeviceChipInfo;->DEFAULT_CPU_CORE_NUMBER:Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    sput-object v0, LMMSDeviceChipInfo;->DEFAULT_CPU_CLOCK_FREQUENCIES:Ljava/util/List;

    .line 13
    .line 14
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    sput-object v0, LMMSDeviceChipInfo;->DEFAULT_GPU_CLOCK_FREQUENCIES:Ljava/util/List;

    .line 19
    .line 20
    return-void
.end method

.method private constructor <init>(LMMSDeviceChipInfo$Builder;)V
    .registers 8

    .line 8
    iget-object v1, p1, LMMSDeviceChipInfo$Builder;->cpu_structure:Ljava/lang/String;

    iget-object v2, p1, LMMSDeviceChipInfo$Builder;->cpu_core_number:Ljava/lang/Integer;

    iget-object v3, p1, LMMSDeviceChipInfo$Builder;->cpu_clock_frequencies:Ljava/util/List;

    iget-object v4, p1, LMMSDeviceChipInfo$Builder;->gpu_model:Ljava/lang/String;

    iget-object v5, p1, LMMSDeviceChipInfo$Builder;->gpu_clock_frequencies:Ljava/util/List;

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, LMMSDeviceChipInfo;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/util/List;Ljava/lang/String;Ljava/util/List;)V

    .line 9
    invoke-virtual {p0, p1}, Lcom/squareup/wire/Message;->setBuilder(Lcom/squareup/wire/Message$Builder;)V

    return-void
.end method

.method public synthetic constructor <init>(LMMSDeviceChipInfo$Builder;LMMSDeviceChipInfo$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LMMSDeviceChipInfo;-><init>(LMMSDeviceChipInfo$Builder;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/util/List;Ljava/lang/String;Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;)V"
        }
    .end annotation

    .line 2
    invoke-direct {p0}, Lcom/squareup/wire/Message;-><init>()V

    .line 3
    iput-object p1, p0, LMMSDeviceChipInfo;->cpu_structure:Ljava/lang/String;

    .line 4
    iput-object p2, p0, LMMSDeviceChipInfo;->cpu_core_number:Ljava/lang/Integer;

    .line 5
    invoke-static {p3}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceChipInfo;->cpu_clock_frequencies:Ljava/util/List;

    .line 6
    iput-object p4, p0, LMMSDeviceChipInfo;->gpu_model:Ljava/lang/String;

    .line 7
    invoke-static {p5}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceChipInfo;->gpu_clock_frequencies:Ljava/util/List;

    return-void
.end method

.method public static synthetic access$000(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$100(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LMMSDeviceChipInfo;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LMMSDeviceChipInfo;

    .line 12
    .line 13
    iget-object v1, p0, LMMSDeviceChipInfo;->cpu_structure:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, LMMSDeviceChipInfo;->cpu_structure:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_3f

    .line 22
    .line 23
    iget-object v1, p0, LMMSDeviceChipInfo;->cpu_core_number:Ljava/lang/Integer;

    .line 24
    .line 25
    iget-object v3, p1, LMMSDeviceChipInfo;->cpu_core_number:Ljava/lang/Integer;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_3f

    .line 32
    .line 33
    iget-object v1, p0, LMMSDeviceChipInfo;->cpu_clock_frequencies:Ljava/util/List;

    .line 34
    .line 35
    iget-object v3, p1, LMMSDeviceChipInfo;->cpu_clock_frequencies:Ljava/util/List;

    .line 36
    .line 37
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_3f

    .line 42
    .line 43
    iget-object v1, p0, LMMSDeviceChipInfo;->gpu_model:Ljava/lang/String;

    .line 44
    .line 45
    iget-object v3, p1, LMMSDeviceChipInfo;->gpu_model:Ljava/lang/String;

    .line 46
    .line 47
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_3f

    .line 52
    .line 53
    iget-object v1, p0, LMMSDeviceChipInfo;->gpu_clock_frequencies:Ljava/util/List;

    .line 54
    .line 55
    iget-object p1, p1, LMMSDeviceChipInfo;->gpu_clock_frequencies:Ljava/util/List;

    .line 56
    .line 57
    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    if-eqz p1, :cond_3f

    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    const/4 v0, 0x0

    .line 65
    :goto_40
    return v0
.end method

.method public hashCode()I
    .registers 5

    .line 1
    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 2
    .line 3
    if-nez v0, :cond_42

    .line 4
    .line 5
    iget-object v0, p0, LMMSDeviceChipInfo;->cpu_structure:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    mul-int/lit8 v0, v0, 0x25

    .line 17
    .line 18
    iget-object v2, p0, LMMSDeviceChipInfo;->cpu_core_number:Ljava/lang/Integer;

    .line 19
    .line 20
    if-eqz v2, :cond_1a

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Integer;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x0

    .line 28
    :goto_1b
    add-int/2addr v0, v2

    .line 29
    mul-int/lit8 v0, v0, 0x25

    .line 30
    .line 31
    iget-object v2, p0, LMMSDeviceChipInfo;->cpu_clock_frequencies:Ljava/util/List;

    .line 32
    .line 33
    const/4 v3, 0x1

    .line 34
    if-eqz v2, :cond_28

    .line 35
    .line 36
    invoke-interface {v2}, Ljava/util/List;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    const/4 v2, 0x1

    .line 42
    :goto_29
    add-int/2addr v0, v2

    .line 43
    mul-int/lit8 v0, v0, 0x25

    .line 44
    .line 45
    iget-object v2, p0, LMMSDeviceChipInfo;->gpu_model:Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v2, :cond_34

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    :cond_34
    add-int/2addr v0, v1

    .line 54
    mul-int/lit8 v0, v0, 0x25

    .line 55
    .line 56
    iget-object v1, p0, LMMSDeviceChipInfo;->gpu_clock_frequencies:Ljava/util/List;

    .line 57
    .line 58
    if-eqz v1, :cond_3f

    .line 59
    .line 60
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    :cond_3f
    add-int/2addr v0, v3

    .line 65
    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 66
    .line 67
    :cond_42
    return v0
.end method

###### Class MMSDeviceChipInfo.Builder (MMSDeviceChipInfo$Builder)
.class public final LMMSDeviceChipInfo$Builder;
.super Lcom/squareup/wire/Message$Builder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceChipInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/Message$Builder<",
        "LMMSDeviceChipInfo;",
        ">;"
    }
.end annotation


# instance fields
.field public cpu_clock_frequencies:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public cpu_core_number:Ljava/lang/Integer;

.field public cpu_structure:Ljava/lang/String;

.field public gpu_clock_frequencies:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;"
        }
    .end annotation
.end field

.field public gpu_model:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/squareup/wire/Message$Builder;-><init>()V

    return-void
.end method

.method public constructor <init>(LMMSDeviceChipInfo;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/squareup/wire/Message$Builder;-><init>(Lcom/squareup/wire/Message;)V

    if-nez p1, :cond_6

    return-void

    .line 3
    :cond_6
    iget-object v0, p1, LMMSDeviceChipInfo;->cpu_structure:Ljava/lang/String;

    iput-object v0, p0, LMMSDeviceChipInfo$Builder;->cpu_structure:Ljava/lang/String;

    .line 4
    iget-object v0, p1, LMMSDeviceChipInfo;->cpu_core_number:Ljava/lang/Integer;

    iput-object v0, p0, LMMSDeviceChipInfo$Builder;->cpu_core_number:Ljava/lang/Integer;

    .line 5
    iget-object v0, p1, LMMSDeviceChipInfo;->cpu_clock_frequencies:Ljava/util/List;

    invoke-static {v0}, LMMSDeviceChipInfo;->access$000(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LMMSDeviceChipInfo$Builder;->cpu_clock_frequencies:Ljava/util/List;

    .line 6
    iget-object v0, p1, LMMSDeviceChipInfo;->gpu_model:Ljava/lang/String;

    iput-object v0, p0, LMMSDeviceChipInfo$Builder;->gpu_model:Ljava/lang/String;

    .line 7
    iget-object p1, p1, LMMSDeviceChipInfo;->gpu_clock_frequencies:Ljava/util/List;

    invoke-static {p1}, LMMSDeviceChipInfo;->access$100(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->gpu_clock_frequencies:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public build()LMMSDeviceChipInfo;
    .registers 3

    .line 2
    new-instance v0, LMMSDeviceChipInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, LMMSDeviceChipInfo;-><init>(LMMSDeviceChipInfo$Builder;LMMSDeviceChipInfo$a;)V

    return-object v0
.end method

.method public bridge synthetic build()Lcom/squareup/wire/Message;
    .registers 2

    .line 1
    invoke-virtual {p0}, LMMSDeviceChipInfo$Builder;->build()LMMSDeviceChipInfo;

    move-result-object v0

    return-object v0
.end method

.method public cpu_clock_frequencies(Ljava/util/List;)LMMSDeviceChipInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;)",
            "LMMSDeviceChipInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->cpu_clock_frequencies:Ljava/util/List;

    return-object p0
.end method

.method public cpu_core_number(Ljava/lang/Integer;)LMMSDeviceChipInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->cpu_core_number:Ljava/lang/Integer;

    return-object p0
.end method

.method public cpu_structure(Ljava/lang/String;)LMMSDeviceChipInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->cpu_structure:Ljava/lang/String;

    return-object p0
.end method

.method public gpu_clock_frequencies(Ljava/util/List;)LMMSDeviceChipInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LMMSDeviceClockFrequency;",
            ">;)",
            "LMMSDeviceChipInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->gpu_clock_frequencies:Ljava/util/List;

    return-object p0
.end method

.method public gpu_model(Ljava/lang/String;)LMMSDeviceChipInfo$Builder;
    .registers 2

    iput-object p1, p0, LMMSDeviceChipInfo$Builder;->gpu_model:Ljava/lang/String;

    return-object p0
.end method

###### Class MMSDeviceChipInfo.a (MMSDeviceChipInfo$a)
.class public synthetic LMMSDeviceChipInfo$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMMSDeviceChipInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation
