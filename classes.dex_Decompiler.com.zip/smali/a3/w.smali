###### Class a3.w (a3.w)
.class public La3/w;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lt2/h;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->n()Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;->BEGIN_OBJECT:Lcom/airbnb/lottie/parser/moshi/JsonReader$Token;

    .line 6
    .line 7
    if-ne v0, v1, :cond_a

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    :goto_b
    invoke-static {}, Lc3/j;->e()F

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    sget-object v2, La3/x;->a:La3/x;

    .line 17
    .line 18
    invoke-static {p0, p1, v1, v2, v0}, La3/q;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;FLa3/j0;Z)Ld3/a;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    new-instance v0, Lt2/h;

    .line 23
    .line 24
    invoke-direct {v0, p1, p0}, Lt2/h;-><init>(Lq2/d;Ld3/a;)V

    .line 25
    .line 26
    .line 27
    return-object v0
.end method
