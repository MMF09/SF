###### Class a3.d (a3.d)
.class public La3/d;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLq2/d;La3/j0;)Ljava/util/List;
    .registers 4
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/airbnb/lottie/parser/moshi/JsonReader;",
            "F",
            "Lq2/d;",
            "La3/j0<",
            "TT;>;)",
            "Ljava/util/List<",
            "Ld3/a<",
            "TT;>;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-static {p0, p2, p1, p3}, La3/r;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;FLa3/j0;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;
    .registers 4
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/airbnb/lottie/parser/moshi/JsonReader;",
            "Lq2/d;",
            "La3/j0<",
            "TT;>;)",
            "Ljava/util/List<",
            "Ld3/a<",
            "TT;>;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p0, p1, v0, p2}, La3/r;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;FLa3/j0;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static c(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/a;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lw2/a;

    sget-object v1, La3/f;->a:La3/f;

    invoke-static {p0, p1, v1}, La3/d;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;

    move-result-object p0

    invoke-direct {v0, p0}, Lw2/a;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public static d(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/j;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lw2/j;

    sget-object v1, La3/h;->a:La3/h;

    invoke-static {p0, p1, v1}, La3/d;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;

    move-result-object p0

    invoke-direct {v0, p0}, Lw2/j;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public static e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, La3/d;->f(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;Z)Lw2/b;

    move-result-object p0

    return-object p0
.end method

.method public static f(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;Z)Lw2/b;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    new-instance v0, Lw2/b;

    .line 2
    .line 3
    if-eqz p2, :cond_9

    .line 4
    .line 5
    invoke-static {}, Lc3/j;->e()F

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    goto :goto_b

    .line 10
    :cond_9
    const/high16 p2, 0x3f800000    # 1.0f

    .line 11
    .line 12
    :goto_b
    sget-object v1, La3/i;->a:La3/i;

    .line 13
    .line 14
    invoke-static {p0, p2, p1, v1}, La3/d;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLq2/d;La3/j0;)Ljava/util/List;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-direct {v0, p0}, Lw2/b;-><init>(Ljava/util/List;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public static g(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;I)Lw2/c;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    new-instance v0, Lw2/c;

    .line 2
    .line 3
    new-instance v1, La3/l;

    .line 4
    .line 5
    invoke-direct {v1, p2}, La3/l;-><init>(I)V

    .line 6
    .line 7
    .line 8
    invoke-static {p0, p1, v1}, La3/d;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-direct {v0, p0}, Lw2/c;-><init>(Ljava/util/List;)V

    .line 13
    .line 14
    .line 15
    return-object v0
.end method

.method public static h(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/d;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lw2/d;

    sget-object v1, La3/o;->a:La3/o;

    invoke-static {p0, p1, v1}, La3/d;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;

    move-result-object p0

    invoke-direct {v0, p0}, Lw2/d;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public static i(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/f;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    new-instance v0, Lw2/f;

    .line 2
    .line 3
    invoke-static {}, Lc3/j;->e()F

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    sget-object v2, La3/y;->a:La3/y;

    .line 8
    .line 9
    invoke-static {p0, v1, p1, v2}, La3/d;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLq2/d;La3/j0;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-direct {v0, p0}, Lw2/f;-><init>(Ljava/util/List;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public static j(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/g;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lw2/g;

    sget-object v1, La3/c0;->a:La3/c0;

    invoke-static {p0, p1, v1}, La3/d;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;La3/j0;)Ljava/util/List;

    move-result-object p0

    invoke-direct {v0, p0}, Lw2/g;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public static k(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/h;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    new-instance v0, Lw2/h;

    .line 2
    .line 3
    invoke-static {}, Lc3/j;->e()F

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    sget-object v2, La3/d0;->a:La3/d0;

    .line 8
    .line 9
    invoke-static {p0, v1, p1, v2}, La3/d;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLq2/d;La3/j0;)Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-direct {v0, p0}, Lw2/h;-><init>(Ljava/util/List;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method
