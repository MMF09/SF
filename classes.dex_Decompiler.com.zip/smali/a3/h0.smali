###### Class a3.h0 (a3.h0)
.class public La3/h0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

.field public static final b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 9

    .line 1
    const-string v0, "nm"

    .line 2
    .line 3
    const-string v1, "c"

    .line 4
    .line 5
    const-string v2, "w"

    .line 6
    .line 7
    const-string v3, "o"

    .line 8
    .line 9
    const-string v4, "lc"

    .line 10
    .line 11
    const-string v5, "lj"

    .line 12
    .line 13
    const-string v6, "ml"

    .line 14
    .line 15
    const-string v7, "hd"

    .line 16
    .line 17
    const-string v8, "d"

    .line 18
    .line 19
    filled-new-array/range {v0 .. v8}, [Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    sput-object v0, La3/h0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 28
    .line 29
    const-string v0, "n"

    .line 30
    .line 31
    const-string v1, "v"

    .line 32
    .line 33
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    sput-object v0, La3/h0;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 42
    .line 43
    return-void
.end method

.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lcom/airbnb/lottie/model/content/ShapeStroke;
    .registers 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v3, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x0

    .line 13
    const/4 v7, 0x0

    .line 14
    const/4 v8, 0x0

    .line 15
    const/4 v9, 0x0

    .line 16
    const/4 v10, 0x0

    .line 17
    const/4 v11, 0x0

    .line 18
    const/4 v12, 0x0

    .line 19
    :cond_12
    :goto_12
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 20
    .line 21
    .line 22
    move-result v13

    .line 23
    if-eqz v13, :cond_fc

    .line 24
    .line 25
    sget-object v13, La3/h0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 26
    .line 27
    invoke-virtual {v0, v13}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 28
    .line 29
    .line 30
    move-result v13

    .line 31
    const/4 v14, 0x1

    .line 32
    packed-switch v13, :pswitch_data_124

    .line 33
    .line 34
    .line 35
    move-object/from16 v2, p1

    .line 36
    .line 37
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 38
    .line 39
    .line 40
    goto :goto_12

    .line 41
    :pswitch_28
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 42
    .line 43
    .line 44
    :goto_2b
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 45
    .line 46
    .line 47
    move-result v13

    .line 48
    if-eqz v13, :cond_99

    .line 49
    .line 50
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 51
    .line 52
    .line 53
    const/4 v13, 0x0

    .line 54
    const/4 v15, 0x0

    .line 55
    :goto_36
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 56
    .line 57
    .line 58
    move-result v16

    .line 59
    if-eqz v16, :cond_57

    .line 60
    .line 61
    sget-object v2, La3/h0;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 62
    .line 63
    invoke-virtual {v0, v2}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-eqz v2, :cond_52

    .line 68
    .line 69
    if-eq v2, v14, :cond_4d

    .line 70
    .line 71
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 72
    .line 73
    .line 74
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 75
    .line 76
    .line 77
    goto :goto_36

    .line 78
    :cond_4d
    invoke-static/range {p0 .. p1}, La3/d;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;

    .line 79
    .line 80
    .line 81
    move-result-object v15

    .line 82
    goto :goto_36

    .line 83
    :cond_52
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v13

    .line 87
    goto :goto_36

    .line 88
    :cond_57
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    .line 92
    .line 93
    .line 94
    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    .line 95
    .line 96
    .line 97
    move-result v17

    .line 98
    sparse-switch v17, :sswitch_data_13a

    .line 99
    .line 100
    .line 101
    :goto_64
    const/4 v2, -0x1

    .line 102
    goto :goto_86

    .line 103
    :sswitch_66
    const-string v2, "o"

    .line 104
    .line 105
    invoke-virtual {v13, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    if-nez v2, :cond_6f

    .line 110
    .line 111
    goto :goto_64

    .line 112
    :cond_6f
    const/4 v2, 0x2

    .line 113
    goto :goto_86

    .line 114
    :sswitch_71
    const-string v2, "g"

    .line 115
    .line 116
    invoke-virtual {v13, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    if-nez v2, :cond_7a

    .line 121
    .line 122
    goto :goto_64

    .line 123
    :cond_7a
    const/4 v2, 0x1

    .line 124
    goto :goto_86

    .line 125
    :sswitch_7c
    const-string v2, "d"

    .line 126
    .line 127
    invoke-virtual {v13, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v2

    .line 131
    if-nez v2, :cond_85

    .line 132
    .line 133
    goto :goto_64

    .line 134
    :cond_85
    const/4 v2, 0x0

    .line 135
    :goto_86
    packed-switch v2, :pswitch_data_148

    .line 136
    .line 137
    .line 138
    move-object/from16 v2, p1

    .line 139
    .line 140
    goto :goto_2b

    .line 141
    :pswitch_8c
    move-object/from16 v2, p1

    .line 142
    .line 143
    move-object v5, v15

    .line 144
    goto :goto_2b

    .line 145
    :pswitch_90
    move-object/from16 v2, p1

    .line 146
    .line 147
    invoke-virtual {v2, v14}, Lq2/d;->t(Z)V

    .line 148
    .line 149
    .line 150
    invoke-interface {v3, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    goto :goto_2b

    .line 154
    :cond_99
    move-object/from16 v2, p1

    .line 155
    .line 156
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 157
    .line 158
    .line 159
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 160
    .line 161
    .line 162
    move-result v13

    .line 163
    if-ne v13, v14, :cond_12

    .line 164
    .line 165
    invoke-interface {v3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v13

    .line 169
    invoke-interface {v3, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    goto/16 :goto_12

    .line 173
    .line 174
    :pswitch_ad
    move-object/from16 v2, p1

    .line 175
    .line 176
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 177
    .line 178
    .line 179
    move-result v11

    .line 180
    goto/16 :goto_12

    .line 181
    .line 182
    :pswitch_b5
    move-object/from16 v2, p1

    .line 183
    .line 184
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 185
    .line 186
    .line 187
    move-result-wide v13

    .line 188
    double-to-float v10, v13

    .line 189
    goto/16 :goto_12

    .line 190
    .line 191
    :pswitch_be
    move-object/from16 v2, p1

    .line 192
    .line 193
    invoke-static {}, Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;->values()[Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;

    .line 194
    .line 195
    .line 196
    move-result-object v9

    .line 197
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 198
    .line 199
    .line 200
    move-result v13

    .line 201
    sub-int/2addr v13, v14

    .line 202
    aget-object v9, v9, v13

    .line 203
    .line 204
    goto/16 :goto_12

    .line 205
    .line 206
    :pswitch_cd
    move-object/from16 v2, p1

    .line 207
    .line 208
    invoke-static {}, Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;->values()[Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;

    .line 209
    .line 210
    .line 211
    move-result-object v8

    .line 212
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 213
    .line 214
    .line 215
    move-result v13

    .line 216
    sub-int/2addr v13, v14

    .line 217
    aget-object v8, v8, v13

    .line 218
    .line 219
    goto/16 :goto_12

    .line 220
    .line 221
    :pswitch_dc
    move-object/from16 v2, p1

    .line 222
    .line 223
    invoke-static/range {p0 .. p1}, La3/d;->h(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/d;

    .line 224
    .line 225
    .line 226
    move-result-object v12

    .line 227
    goto/16 :goto_12

    .line 228
    .line 229
    :pswitch_e4
    move-object/from16 v2, p1

    .line 230
    .line 231
    invoke-static/range {p0 .. p1}, La3/d;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;

    .line 232
    .line 233
    .line 234
    move-result-object v7

    .line 235
    goto/16 :goto_12

    .line 236
    .line 237
    :pswitch_ec
    move-object/from16 v2, p1

    .line 238
    .line 239
    invoke-static/range {p0 .. p1}, La3/d;->c(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/a;

    .line 240
    .line 241
    .line 242
    move-result-object v6

    .line 243
    goto/16 :goto_12

    .line 244
    .line 245
    :pswitch_f4
    move-object/from16 v2, p1

    .line 246
    .line 247
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v4

    .line 251
    goto/16 :goto_12

    .line 252
    .line 253
    :cond_fc
    if-nez v12, :cond_113

    .line 254
    .line 255
    new-instance v0, Lw2/d;

    .line 256
    .line 257
    new-instance v1, Ld3/a;

    .line 258
    .line 259
    const/16 v2, 0x64

    .line 260
    .line 261
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 262
    .line 263
    .line 264
    move-result-object v2

    .line 265
    invoke-direct {v1, v2}, Ld3/a;-><init>(Ljava/lang/Object;)V

    .line 266
    .line 267
    .line 268
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 269
    .line 270
    .line 271
    move-result-object v1

    .line 272
    invoke-direct {v0, v1}, Lw2/d;-><init>(Ljava/util/List;)V

    .line 273
    .line 274
    .line 275
    move-object v12, v0

    .line 276
    :cond_113
    new-instance v13, Lcom/airbnb/lottie/model/content/ShapeStroke;

    .line 277
    .line 278
    move-object v0, v13

    .line 279
    move-object v1, v4

    .line 280
    move-object v2, v5

    .line 281
    move-object v4, v6

    .line 282
    move-object v5, v12

    .line 283
    move-object v6, v7

    .line 284
    move-object v7, v8

    .line 285
    move-object v8, v9

    .line 286
    move v9, v10

    .line 287
    move v10, v11

    .line 288
    invoke-direct/range {v0 .. v10}, Lcom/airbnb/lottie/model/content/ShapeStroke;-><init>(Ljava/lang/String;Lw2/b;Ljava/util/List;Lw2/a;Lw2/d;Lw2/b;Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;FZ)V

    .line 289
    .line 290
    .line 291
    return-object v13

    .line 292
    nop

    .line 293
    :pswitch_data_124
    .packed-switch 0x0
        :pswitch_f4
        :pswitch_ec
        :pswitch_e4
        :pswitch_dc
        :pswitch_cd
        :pswitch_be
        :pswitch_b5
        :pswitch_ad
        :pswitch_28
    .end packed-switch

    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    :sswitch_data_13a
    .sparse-switch
        0x64 -> :sswitch_7c
        0x67 -> :sswitch_71
        0x6f -> :sswitch_66
    .end sparse-switch

    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    :pswitch_data_148
    .packed-switch 0x0
        :pswitch_90
        :pswitch_90
        :pswitch_8c
    .end packed-switch
.end method
