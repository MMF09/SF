###### Class a3.q (a3.q)
.class public La3/q;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Landroid/view/animation/Interpolator;

.field public static b:Landroidx/collection/SparseArrayCompat;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/SparseArrayCompat<",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/animation/Interpolator;",
            ">;>;"
        }
    .end annotation
.end field

.field public static c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 9

    .line 1
    new-instance v0, Landroid/view/animation/LinearInterpolator;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La3/q;->a:Landroid/view/animation/Interpolator;

    .line 7
    .line 8
    const-string v1, "t"

    .line 9
    .line 10
    const-string v2, "s"

    .line 11
    .line 12
    const-string v3, "e"

    .line 13
    .line 14
    const-string v4, "o"

    .line 15
    .line 16
    const-string v5, "i"

    .line 17
    .line 18
    const-string v6, "h"

    .line 19
    .line 20
    const-string v7, "to"

    .line 21
    .line 22
    const-string v8, "ti"

    .line 23
    .line 24
    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    sput-object v0, La3/q;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 33
    .line 34
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(I)Ljava/lang/ref/WeakReference;
    .registers 3
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/animation/Interpolator;",
            ">;"
        }
    .end annotation

    .line 1
    const-class v0, La3/q;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    invoke-static {}, La3/q;->e()Landroidx/collection/SparseArrayCompat;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    invoke-virtual {v1, p0}, Landroidx/collection/SparseArrayCompat;->get(I)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    check-cast p0, Ljava/lang/ref/WeakReference;

    .line 13
    .line 14
    monitor-exit v0

    .line 15
    return-object p0

    .line 16
    :catchall_f
    move-exception p0

    .line 17
    monitor-exit v0
    :try_end_11
    .catchall {:try_start_3 .. :try_end_11} :catchall_f

    .line 18
    throw p0
.end method

.method public static b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;FLa3/j0;Z)Ld3/a;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/airbnb/lottie/parser/moshi/JsonReader;",
            "Lq2/d;",
            "F",
            "La3/j0<",
            "TT;>;Z)",
            "Ld3/a<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    if-eqz p4, :cond_7

    .line 2
    .line 3
    invoke-static {p1, p0, p2, p3}, La3/q;->c(Lq2/d;Lcom/airbnb/lottie/parser/moshi/JsonReader;FLa3/j0;)Ld3/a;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0

    .line 8
    :cond_7
    invoke-static {p0, p2, p3}, La3/q;->d(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLa3/j0;)Ld3/a;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public static c(Lq2/d;Lcom/airbnb/lottie/parser/moshi/JsonReader;FLa3/j0;)Ld3/a;
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lq2/d;",
            "Lcom/airbnb/lottie/parser/moshi/JsonReader;",
            "F",
            "La3/j0<",
            "TT;>;)",
            "Ld3/a<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 8
    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    const/4 v5, 0x0

    .line 13
    move-object v7, v5

    .line 14
    move-object v8, v7

    .line 15
    move-object v9, v8

    .line 16
    move-object v10, v9

    .line 17
    move-object v14, v10

    .line 18
    move-object v15, v14

    .line 19
    const/4 v6, 0x0

    .line 20
    const/4 v13, 0x0

    .line 21
    :goto_14
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 22
    .line 23
    .line 24
    move-result v11

    .line 25
    if-eqz v11, :cond_56

    .line 26
    .line 27
    sget-object v11, La3/q;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 28
    .line 29
    invoke-virtual {v0, v11}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 30
    .line 31
    .line 32
    move-result v11

    .line 33
    packed-switch v11, :pswitch_data_10a

    .line 34
    .line 35
    .line 36
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 37
    .line 38
    .line 39
    goto :goto_14

    .line 40
    :pswitch_27
    invoke-static/range {p1 .. p2}, La3/p;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;

    .line 41
    .line 42
    .line 43
    move-result-object v14

    .line 44
    goto :goto_14

    .line 45
    :pswitch_2c
    invoke-static/range {p1 .. p2}, La3/p;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;

    .line 46
    .line 47
    .line 48
    move-result-object v15

    .line 49
    goto :goto_14

    .line 50
    :pswitch_31
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 51
    .line 52
    .line 53
    move-result v6

    .line 54
    const/4 v11, 0x1

    .line 55
    if-ne v6, v11, :cond_3a

    .line 56
    .line 57
    const/4 v6, 0x1

    .line 58
    goto :goto_14

    .line 59
    :cond_3a
    const/4 v6, 0x0

    .line 60
    goto :goto_14

    .line 61
    :pswitch_3c
    invoke-static/range {p1 .. p2}, La3/p;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;

    .line 62
    .line 63
    .line 64
    move-result-object v8

    .line 65
    goto :goto_14

    .line 66
    :pswitch_41
    invoke-static/range {p1 .. p2}, La3/p;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Landroid/graphics/PointF;

    .line 67
    .line 68
    .line 69
    move-result-object v7

    .line 70
    goto :goto_14

    .line 71
    :pswitch_46
    invoke-interface {v2, v0, v1}, La3/j0;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v9

    .line 75
    goto :goto_14

    .line 76
    :pswitch_4b
    invoke-interface {v2, v0, v1}, La3/j0;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v10

    .line 80
    goto :goto_14

    .line 81
    :pswitch_50
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 82
    .line 83
    .line 84
    move-result-wide v11

    .line 85
    double-to-float v13, v11

    .line 86
    goto :goto_14

    .line 87
    :cond_56
    invoke-virtual/range {p1 .. p1}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 88
    .line 89
    .line 90
    if-eqz v6, :cond_61

    .line 91
    .line 92
    sget-object v0, La3/q;->a:Landroid/view/animation/Interpolator;

    .line 93
    .line 94
    move-object v12, v0

    .line 95
    move-object v11, v10

    .line 96
    goto/16 :goto_fa

    .line 97
    .line 98
    :cond_61
    if-eqz v7, :cond_f6

    .line 99
    .line 100
    if-eqz v8, :cond_f6

    .line 101
    .line 102
    iget v0, v7, Landroid/graphics/PointF;->x:F

    .line 103
    .line 104
    neg-float v2, v1

    .line 105
    invoke-static {v0, v2, v1}, Lc3/i;->c(FFF)F

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    iput v0, v7, Landroid/graphics/PointF;->x:F

    .line 110
    .line 111
    iget v0, v7, Landroid/graphics/PointF;->y:F

    .line 112
    .line 113
    const/high16 v3, -0x3d380000    # -100.0f

    .line 114
    .line 115
    const/high16 v6, 0x42c80000    # 100.0f

    .line 116
    .line 117
    invoke-static {v0, v3, v6}, Lc3/i;->c(FFF)F

    .line 118
    .line 119
    .line 120
    move-result v0

    .line 121
    iput v0, v7, Landroid/graphics/PointF;->y:F

    .line 122
    .line 123
    iget v0, v8, Landroid/graphics/PointF;->x:F

    .line 124
    .line 125
    invoke-static {v0, v2, v1}, Lc3/i;->c(FFF)F

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    iput v0, v8, Landroid/graphics/PointF;->x:F

    .line 130
    .line 131
    iget v0, v8, Landroid/graphics/PointF;->y:F

    .line 132
    .line 133
    invoke-static {v0, v3, v6}, Lc3/i;->c(FFF)F

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    iput v0, v8, Landroid/graphics/PointF;->y:F

    .line 138
    .line 139
    iget v2, v7, Landroid/graphics/PointF;->x:F

    .line 140
    .line 141
    iget v3, v7, Landroid/graphics/PointF;->y:F

    .line 142
    .line 143
    iget v6, v8, Landroid/graphics/PointF;->x:F

    .line 144
    .line 145
    invoke-static {v2, v3, v6, v0}, Lc3/j;->i(FFFF)I

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    invoke-static {v2}, La3/q;->a(I)Ljava/lang/ref/WeakReference;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    if-eqz v0, :cond_a1

    .line 154
    .line 155
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    move-object v5, v3

    .line 160
    check-cast v5, Landroid/view/animation/Interpolator;

    .line 161
    .line 162
    :cond_a1
    if-eqz v0, :cond_a5

    .line 163
    .line 164
    if-nez v5, :cond_f4

    .line 165
    .line 166
    :cond_a5
    iget v0, v7, Landroid/graphics/PointF;->x:F

    .line 167
    .line 168
    div-float/2addr v0, v1

    .line 169
    iput v0, v7, Landroid/graphics/PointF;->x:F

    .line 170
    .line 171
    iget v0, v7, Landroid/graphics/PointF;->y:F

    .line 172
    .line 173
    div-float/2addr v0, v1

    .line 174
    iput v0, v7, Landroid/graphics/PointF;->y:F

    .line 175
    .line 176
    iget v0, v8, Landroid/graphics/PointF;->x:F

    .line 177
    .line 178
    div-float/2addr v0, v1

    .line 179
    iput v0, v8, Landroid/graphics/PointF;->x:F

    .line 180
    .line 181
    iget v3, v8, Landroid/graphics/PointF;->y:F

    .line 182
    .line 183
    div-float/2addr v3, v1

    .line 184
    iput v3, v8, Landroid/graphics/PointF;->y:F

    .line 185
    .line 186
    :try_start_b9
    iget v1, v7, Landroid/graphics/PointF;->x:F

    .line 187
    .line 188
    iget v5, v7, Landroid/graphics/PointF;->y:F

    .line 189
    .line 190
    invoke-static {v1, v5, v0, v3}, Landroidx/core/view/animation/PathInterpolatorCompat;->create(FFFF)Landroid/view/animation/Interpolator;

    .line 191
    .line 192
    .line 193
    move-result-object v0
    :try_end_c1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b9 .. :try_end_c1} :catch_c2

    .line 194
    goto :goto_eb

    .line 195
    :catch_c2
    move-exception v0

    .line 196
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    const-string v1, "The Path cannot loop back on itself."

    .line 201
    .line 202
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v0

    .line 206
    if-eqz v0, :cond_e6

    .line 207
    .line 208
    iget v0, v7, Landroid/graphics/PointF;->x:F

    .line 209
    .line 210
    const/high16 v1, 0x3f800000    # 1.0f

    .line 211
    .line 212
    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    iget v1, v7, Landroid/graphics/PointF;->y:F

    .line 217
    .line 218
    iget v3, v8, Landroid/graphics/PointF;->x:F

    .line 219
    .line 220
    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    iget v4, v8, Landroid/graphics/PointF;->y:F

    .line 225
    .line 226
    invoke-static {v0, v1, v3, v4}, Landroidx/core/view/animation/PathInterpolatorCompat;->create(FFFF)Landroid/view/animation/Interpolator;

    .line 227
    .line 228
    .line 229
    move-result-object v0

    .line 230
    goto :goto_eb

    .line 231
    :cond_e6
    new-instance v0, Landroid/view/animation/LinearInterpolator;

    .line 232
    .line 233
    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    .line 234
    .line 235
    .line 236
    :goto_eb
    move-object v5, v0

    .line 237
    :try_start_ec
    new-instance v0, Ljava/lang/ref/WeakReference;

    .line 238
    .line 239
    invoke-direct {v0, v5}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 240
    .line 241
    .line 242
    invoke-static {v2, v0}, La3/q;->f(ILjava/lang/ref/WeakReference;)V
    :try_end_f4
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_ec .. :try_end_f4} :catch_f4

    .line 243
    .line 244
    .line 245
    :catch_f4
    :cond_f4
    move-object v12, v5

    .line 246
    goto :goto_f9

    .line 247
    :cond_f6
    sget-object v0, La3/q;->a:Landroid/view/animation/Interpolator;

    .line 248
    .line 249
    move-object v12, v0

    .line 250
    :goto_f9
    move-object v11, v9

    .line 251
    :goto_fa
    new-instance v0, Ld3/a;

    .line 252
    .line 253
    const/4 v1, 0x0

    .line 254
    move-object v8, v0

    .line 255
    move-object/from16 v9, p0

    .line 256
    .line 257
    move-object v5, v14

    .line 258
    move-object v14, v1

    .line 259
    invoke-direct/range {v8 .. v14}, Ld3/a;-><init>(Lq2/d;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V

    .line 260
    .line 261
    .line 262
    iput-object v15, v0, Ld3/a;->m:Landroid/graphics/PointF;

    .line 263
    .line 264
    iput-object v5, v0, Ld3/a;->n:Landroid/graphics/PointF;

    .line 265
    .line 266
    return-object v0

    .line 267
    :pswitch_data_10a
    .packed-switch 0x0
        :pswitch_50
        :pswitch_4b
        :pswitch_46
        :pswitch_41
        :pswitch_3c
        :pswitch_31
        :pswitch_2c
        :pswitch_27
    .end packed-switch
.end method

.method public static d(Lcom/airbnb/lottie/parser/moshi/JsonReader;FLa3/j0;)Ld3/a;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/airbnb/lottie/parser/moshi/JsonReader;",
            "F",
            "La3/j0<",
            "TT;>;)",
            "Ld3/a<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-interface {p2, p0, p1}, La3/j0;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;F)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    new-instance p1, Ld3/a;

    .line 6
    .line 7
    invoke-direct {p1, p0}, Ld3/a;-><init>(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public static e()Landroidx/collection/SparseArrayCompat;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/collection/SparseArrayCompat<",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/animation/Interpolator;",
            ">;>;"
        }
    .end annotation

    .line 1
    sget-object v0, La3/q;->b:Landroidx/collection/SparseArrayCompat;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Landroidx/collection/SparseArrayCompat;

    .line 6
    .line 7
    invoke-direct {v0}, Landroidx/collection/SparseArrayCompat;-><init>()V

    .line 8
    .line 9
    .line 10
    sput-object v0, La3/q;->b:Landroidx/collection/SparseArrayCompat;

    .line 11
    .line 12
    :cond_b
    sget-object v0, La3/q;->b:Landroidx/collection/SparseArrayCompat;

    .line 13
    .line 14
    return-object v0
.end method

.method public static f(ILjava/lang/ref/WeakReference;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/view/animation/Interpolator;",
            ">;)V"
        }
    .end annotation

    .line 1
    const-class v0, La3/q;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    sget-object v1, La3/q;->b:Landroidx/collection/SparseArrayCompat;

    .line 5
    .line 6
    invoke-virtual {v1, p0, p1}, Landroidx/collection/SparseArrayCompat;->put(ILjava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    monitor-exit v0

    .line 10
    return-void

    .line 11
    :catchall_a
    move-exception p0

    .line 12
    monitor-exit v0
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_a

    .line 13
    throw p0
.end method
