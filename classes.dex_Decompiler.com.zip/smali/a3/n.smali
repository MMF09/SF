###### Class a3.n (a3.n)
.class public La3/n;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

.field public static final b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

.field public static final c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 12

    .line 1
    const-string v0, "nm"

    .line 2
    .line 3
    const-string v1, "g"

    .line 4
    .line 5
    const-string v2, "o"

    .line 6
    .line 7
    const-string v3, "t"

    .line 8
    .line 9
    const-string v4, "s"

    .line 10
    .line 11
    const-string v5, "e"

    .line 12
    .line 13
    const-string v6, "w"

    .line 14
    .line 15
    const-string v7, "lc"

    .line 16
    .line 17
    const-string v8, "lj"

    .line 18
    .line 19
    const-string v9, "ml"

    .line 20
    .line 21
    const-string v10, "hd"

    .line 22
    .line 23
    const-string v11, "d"

    .line 24
    .line 25
    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    sput-object v0, La3/n;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 34
    .line 35
    const-string v0, "p"

    .line 36
    .line 37
    const-string v1, "k"

    .line 38
    .line 39
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    sput-object v0, La3/n;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 48
    .line 49
    const-string v0, "n"

    .line 50
    .line 51
    const-string v1, "v"

    .line 52
    .line 53
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    sput-object v0, La3/n;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 62
    .line 63
    return-void
.end method

.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lcom/airbnb/lottie/model/content/a;
    .registers 23
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    new-instance v11, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    const/4 v4, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    const/4 v5, 0x0

    .line 13
    const/4 v6, 0x0

    .line 14
    const/4 v7, 0x0

    .line 15
    const/4 v8, 0x0

    .line 16
    const/4 v9, 0x0

    .line 17
    const/4 v10, 0x0

    .line 18
    const/4 v12, 0x0

    .line 19
    const/4 v13, 0x0

    .line 20
    const/4 v14, 0x0

    .line 21
    const/4 v15, 0x0

    .line 22
    const/16 v16, 0x0

    .line 23
    .line 24
    :goto_17
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 25
    .line 26
    .line 27
    move-result v17

    .line 28
    if-eqz v17, :cond_13a

    .line 29
    .line 30
    sget-object v3, La3/n;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 31
    .line 32
    invoke-virtual {v0, v3}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    packed-switch v3, :pswitch_data_168

    .line 37
    .line 38
    .line 39
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 40
    .line 41
    .line 42
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 43
    .line 44
    .line 45
    goto :goto_17

    .line 46
    :pswitch_2d
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 47
    .line 48
    .line 49
    :goto_30
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_94

    .line 54
    .line 55
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 56
    .line 57
    .line 58
    const/4 v3, 0x0

    .line 59
    const/16 v18, 0x0

    .line 60
    .line 61
    :goto_3c
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 62
    .line 63
    .line 64
    move-result v19

    .line 65
    if-eqz v19, :cond_64

    .line 66
    .line 67
    sget-object v2, La3/n;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 68
    .line 69
    invoke-virtual {v0, v2}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    if-eqz v2, :cond_5d

    .line 74
    .line 75
    move-object/from16 v20, v14

    .line 76
    .line 77
    const/4 v14, 0x1

    .line 78
    if-eq v2, v14, :cond_56

    .line 79
    .line 80
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 81
    .line 82
    .line 83
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 84
    .line 85
    .line 86
    goto :goto_5a

    .line 87
    :cond_56
    invoke-static/range {p0 .. p1}, La3/d;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;

    .line 88
    .line 89
    .line 90
    move-result-object v18

    .line 91
    :goto_5a
    move-object/from16 v14, v20

    .line 92
    .line 93
    goto :goto_3c

    .line 94
    :cond_5d
    move-object/from16 v20, v14

    .line 95
    .line 96
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    goto :goto_3c

    .line 101
    :cond_64
    move-object/from16 v20, v14

    .line 102
    .line 103
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 104
    .line 105
    .line 106
    const-string v2, "o"

    .line 107
    .line 108
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v2

    .line 112
    if-eqz v2, :cond_75

    .line 113
    .line 114
    move-object/from16 v14, v18

    .line 115
    .line 116
    const/4 v2, 0x1

    .line 117
    goto :goto_30

    .line 118
    :cond_75
    const-string v2, "d"

    .line 119
    .line 120
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    move-result v2

    .line 124
    if-nez v2, :cond_88

    .line 125
    .line 126
    const-string v2, "g"

    .line 127
    .line 128
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v2

    .line 132
    if-eqz v2, :cond_86

    .line 133
    .line 134
    goto :goto_88

    .line 135
    :cond_86
    const/4 v2, 0x1

    .line 136
    goto :goto_91

    .line 137
    :cond_88
    :goto_88
    const/4 v2, 0x1

    .line 138
    invoke-virtual {v1, v2}, Lq2/d;->t(Z)V

    .line 139
    .line 140
    .line 141
    move-object/from16 v3, v18

    .line 142
    .line 143
    invoke-interface {v11, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    :goto_91
    move-object/from16 v14, v20

    .line 147
    .line 148
    goto :goto_30

    .line 149
    :cond_94
    move-object/from16 v20, v14

    .line 150
    .line 151
    const/4 v2, 0x1

    .line 152
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 153
    .line 154
    .line 155
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-ne v3, v2, :cond_a9

    .line 160
    .line 161
    const/4 v2, 0x0

    .line 162
    invoke-interface {v11, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    invoke-interface {v11, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    goto :goto_aa

    .line 170
    :cond_a9
    const/4 v2, 0x0

    .line 171
    :goto_aa
    move-object/from16 v14, v20

    .line 172
    .line 173
    goto/16 :goto_17

    .line 174
    .line 175
    :pswitch_ae
    const/4 v2, 0x0

    .line 176
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 177
    .line 178
    .line 179
    move-result v15

    .line 180
    goto/16 :goto_17

    .line 181
    .line 182
    :pswitch_b5
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 183
    .line 184
    .line 185
    move-result-wide v2

    .line 186
    double-to-float v13, v2

    .line 187
    goto/16 :goto_17

    .line 188
    .line 189
    :pswitch_bc
    invoke-static {}, Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;->values()[Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;

    .line 190
    .line 191
    .line 192
    move-result-object v2

    .line 193
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 194
    .line 195
    .line 196
    move-result v3

    .line 197
    const/4 v12, 0x1

    .line 198
    sub-int/2addr v3, v12

    .line 199
    aget-object v12, v2, v3

    .line 200
    .line 201
    goto/16 :goto_17

    .line 202
    .line 203
    :pswitch_ca
    const/4 v2, 0x1

    .line 204
    invoke-static {}, Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;->values()[Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;

    .line 205
    .line 206
    .line 207
    move-result-object v3

    .line 208
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 209
    .line 210
    .line 211
    move-result v10

    .line 212
    sub-int/2addr v10, v2

    .line 213
    aget-object v10, v3, v10

    .line 214
    .line 215
    goto/16 :goto_17

    .line 216
    .line 217
    :pswitch_d8
    invoke-static/range {p0 .. p1}, La3/d;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;

    .line 218
    .line 219
    .line 220
    move-result-object v9

    .line 221
    goto/16 :goto_17

    .line 222
    .line 223
    :pswitch_de
    invoke-static/range {p0 .. p1}, La3/d;->i(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/f;

    .line 224
    .line 225
    .line 226
    move-result-object v8

    .line 227
    goto/16 :goto_17

    .line 228
    .line 229
    :pswitch_e4
    invoke-static/range {p0 .. p1}, La3/d;->i(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/f;

    .line 230
    .line 231
    .line 232
    move-result-object v7

    .line 233
    goto/16 :goto_17

    .line 234
    .line 235
    :pswitch_ea
    const/4 v2, 0x1

    .line 236
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 237
    .line 238
    .line 239
    move-result v3

    .line 240
    if-ne v3, v2, :cond_f4

    .line 241
    .line 242
    sget-object v2, Lcom/airbnb/lottie/model/content/GradientType;->LINEAR:Lcom/airbnb/lottie/model/content/GradientType;

    .line 243
    .line 244
    goto :goto_f6

    .line 245
    :cond_f4
    sget-object v2, Lcom/airbnb/lottie/model/content/GradientType;->RADIAL:Lcom/airbnb/lottie/model/content/GradientType;

    .line 246
    .line 247
    :goto_f6
    move-object v5, v2

    .line 248
    goto/16 :goto_17

    .line 249
    .line 250
    :pswitch_f9
    invoke-static/range {p0 .. p1}, La3/d;->h(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/d;

    .line 251
    .line 252
    .line 253
    move-result-object v16

    .line 254
    goto/16 :goto_17

    .line 255
    .line 256
    :pswitch_ff
    const/4 v2, -0x1

    .line 257
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 258
    .line 259
    .line 260
    :goto_103
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 261
    .line 262
    .line 263
    move-result v3

    .line 264
    if-eqz v3, :cond_12d

    .line 265
    .line 266
    sget-object v3, La3/n;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 267
    .line 268
    invoke-virtual {v0, v3}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    if-eqz v3, :cond_123

    .line 273
    .line 274
    move-object/from16 v18, v6

    .line 275
    .line 276
    const/4 v6, 0x1

    .line 277
    if-eq v3, v6, :cond_11d

    .line 278
    .line 279
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 280
    .line 281
    .line 282
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 283
    .line 284
    .line 285
    goto :goto_12a

    .line 286
    :cond_11d
    invoke-static {v0, v1, v2}, La3/d;->g(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;I)Lw2/c;

    .line 287
    .line 288
    .line 289
    move-result-object v3

    .line 290
    move-object v6, v3

    .line 291
    goto :goto_103

    .line 292
    :cond_123
    move-object/from16 v18, v6

    .line 293
    .line 294
    const/4 v6, 0x1

    .line 295
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 296
    .line 297
    .line 298
    move-result v2

    .line 299
    :goto_12a
    move-object/from16 v6, v18

    .line 300
    .line 301
    goto :goto_103

    .line 302
    :cond_12d
    move-object/from16 v18, v6

    .line 303
    .line 304
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 305
    .line 306
    .line 307
    goto/16 :goto_17

    .line 308
    .line 309
    :pswitch_134
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 310
    .line 311
    .line 312
    move-result-object v4

    .line 313
    goto/16 :goto_17

    .line 314
    .line 315
    :cond_13a
    if-nez v16, :cond_152

    .line 316
    .line 317
    new-instance v0, Lw2/d;

    .line 318
    .line 319
    new-instance v1, Ld3/a;

    .line 320
    .line 321
    const/16 v2, 0x64

    .line 322
    .line 323
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 324
    .line 325
    .line 326
    move-result-object v2

    .line 327
    invoke-direct {v1, v2}, Ld3/a;-><init>(Ljava/lang/Object;)V

    .line 328
    .line 329
    .line 330
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    invoke-direct {v0, v1}, Lw2/d;-><init>(Ljava/util/List;)V

    .line 335
    .line 336
    .line 337
    move-object/from16 v16, v0

    .line 338
    .line 339
    :cond_152
    new-instance v17, Lcom/airbnb/lottie/model/content/a;

    .line 340
    .line 341
    move-object/from16 v0, v17

    .line 342
    .line 343
    move-object v1, v4

    .line 344
    move-object v2, v5

    .line 345
    move-object v3, v6

    .line 346
    move-object/from16 v4, v16

    .line 347
    .line 348
    move-object v5, v7

    .line 349
    move-object v6, v8

    .line 350
    move-object v7, v9

    .line 351
    move-object v8, v10

    .line 352
    move-object v9, v12

    .line 353
    move v10, v13

    .line 354
    move-object v12, v14

    .line 355
    move v13, v15

    .line 356
    invoke-direct/range {v0 .. v13}, Lcom/airbnb/lottie/model/content/a;-><init>(Ljava/lang/String;Lcom/airbnb/lottie/model/content/GradientType;Lw2/c;Lw2/d;Lw2/f;Lw2/f;Lw2/b;Lcom/airbnb/lottie/model/content/ShapeStroke$LineCapType;Lcom/airbnb/lottie/model/content/ShapeStroke$LineJoinType;FLjava/util/List;Lw2/b;Z)V

    .line 357
    .line 358
    .line 359
    return-object v17

    .line 360
    nop

    .line 361
    :pswitch_data_168
    .packed-switch 0x0
        :pswitch_134
        :pswitch_ff
        :pswitch_f9
        :pswitch_ea
        :pswitch_e4
        :pswitch_de
        :pswitch_d8
        :pswitch_ca
        :pswitch_bc
        :pswitch_b5
        :pswitch_ae
        :pswitch_2d
    .end packed-switch
.end method
