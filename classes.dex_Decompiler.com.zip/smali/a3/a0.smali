###### Class a3.a0 (a3.a0)
.class public La3/a0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 5

    const-string v0, "nm"

    const-string v1, "p"

    const-string v2, "s"

    const-string v3, "r"

    const-string v4, "hd"

    filled-new-array {v0, v1, v2, v3, v4}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    move-result-object v0

    sput-object v0, La3/a0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    return-void
.end method

.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lx2/e;
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    move-object v3, v0

    .line 4
    move-object v4, v3

    .line 5
    move-object v5, v4

    .line 6
    move-object v6, v5

    .line 7
    const/4 v7, 0x0

    .line 8
    :goto_7
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_3e

    .line 13
    .line 14
    sget-object v0, La3/a0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_39

    .line 21
    .line 22
    const/4 v1, 0x1

    .line 23
    if-eq v0, v1, :cond_34

    .line 24
    .line 25
    const/4 v1, 0x2

    .line 26
    if-eq v0, v1, :cond_2f

    .line 27
    .line 28
    const/4 v1, 0x3

    .line 29
    if-eq v0, v1, :cond_2a

    .line 30
    .line 31
    const/4 v1, 0x4

    .line 32
    if-eq v0, v1, :cond_25

    .line 33
    .line 34
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 35
    .line 36
    .line 37
    goto :goto_7

    .line 38
    :cond_25
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    goto :goto_7

    .line 43
    :cond_2a
    invoke-static {p0, p1}, La3/d;->e(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/b;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    goto :goto_7

    .line 48
    :cond_2f
    invoke-static {p0, p1}, La3/d;->i(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/f;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    goto :goto_7

    .line 53
    :cond_34
    invoke-static {p0, p1}, La3/a;->b(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/m;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    goto :goto_7

    .line 58
    :cond_39
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    goto :goto_7

    .line 63
    :cond_3e
    new-instance p0, Lx2/e;

    .line 64
    .line 65
    move-object v2, p0

    .line 66
    invoke-direct/range {v2 .. v7}, Lx2/e;-><init>(Ljava/lang/String;Lw2/m;Lw2/f;Lw2/b;Z)V

    .line 67
    .line 68
    .line 69
    return-object p0
.end method
