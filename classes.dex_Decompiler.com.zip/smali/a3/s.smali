###### Class a3.s (a3.s)
.class public La3/s;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

.field public static final b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

.field public static final c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 23

    .line 1
    const-string v0, "nm"

    .line 2
    .line 3
    const-string v1, "ind"

    .line 4
    .line 5
    const-string v2, "refId"

    .line 6
    .line 7
    const-string v3, "ty"

    .line 8
    .line 9
    const-string v4, "parent"

    .line 10
    .line 11
    const-string v5, "sw"

    .line 12
    .line 13
    const-string v6, "sh"

    .line 14
    .line 15
    const-string v7, "sc"

    .line 16
    .line 17
    const-string v8, "ks"

    .line 18
    .line 19
    const-string v9, "tt"

    .line 20
    .line 21
    const-string v10, "masksProperties"

    .line 22
    .line 23
    const-string v11, "shapes"

    .line 24
    .line 25
    const-string v12, "t"

    .line 26
    .line 27
    const-string v13, "ef"

    .line 28
    .line 29
    const-string v14, "sr"

    .line 30
    .line 31
    const-string v15, "st"

    .line 32
    .line 33
    const-string v16, "w"

    .line 34
    .line 35
    const-string v17, "h"

    .line 36
    .line 37
    const-string v18, "ip"

    .line 38
    .line 39
    const-string v19, "op"

    .line 40
    .line 41
    const-string v20, "tm"

    .line 42
    .line 43
    const-string v21, "cl"

    .line 44
    .line 45
    const-string v22, "hd"

    .line 46
    .line 47
    filled-new-array/range {v0 .. v22}, [Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, La3/s;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 56
    .line 57
    const-string v0, "d"

    .line 58
    .line 59
    const-string v1, "a"

    .line 60
    .line 61
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    sput-object v0, La3/s;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 70
    .line 71
    const-string v0, "nm"

    .line 72
    .line 73
    filled-new-array {v0}, [Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    sput-object v0, La3/s;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 82
    .line 83
    return-void
.end method

.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lcom/airbnb/lottie/model/layer/Layer;
    .registers 40
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v7, p1

    .line 4
    .line 5
    sget-object v1, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->NONE:Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    .line 6
    .line 7
    new-instance v10, Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance v8, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 15
    .line 16
    .line 17
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 18
    .line 19
    .line 20
    const/high16 v2, 0x3f800000    # 1.0f

    .line 21
    .line 22
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 23
    .line 24
    .line 25
    move-result-object v9

    .line 26
    const/4 v3, 0x0

    .line 27
    const/4 v4, 0x0

    .line 28
    const/4 v11, 0x0

    .line 29
    invoke-static {v11}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 30
    .line 31
    .line 32
    move-result-object v12

    .line 33
    const-string v5, "UNSET"

    .line 34
    .line 35
    const-wide/16 v13, 0x0

    .line 36
    .line 37
    const-wide/16 v15, -0x1

    .line 38
    .line 39
    move-object/from16 v31, v1

    .line 40
    .line 41
    move-object/from16 v17, v4

    .line 42
    .line 43
    move-object/from16 v20, v17

    .line 44
    .line 45
    move-object/from16 v21, v20

    .line 46
    .line 47
    move-object/from16 v29, v21

    .line 48
    .line 49
    move-object/from16 v30, v29

    .line 50
    .line 51
    move-object/from16 v32, v30

    .line 52
    .line 53
    move-wide/from16 v18, v15

    .line 54
    .line 55
    const/4 v1, 0x0

    .line 56
    const/4 v2, 0x0

    .line 57
    const/16 v22, 0x0

    .line 58
    .line 59
    const/16 v23, 0x0

    .line 60
    .line 61
    const/16 v24, 0x0

    .line 62
    .line 63
    const/high16 v25, 0x3f800000    # 1.0f

    .line 64
    .line 65
    const/16 v26, 0x0

    .line 66
    .line 67
    const/16 v27, 0x0

    .line 68
    .line 69
    const/16 v28, 0x0

    .line 70
    .line 71
    const/16 v33, 0x0

    .line 72
    .line 73
    move-wide v15, v13

    .line 74
    move-object/from16 v14, v32

    .line 75
    .line 76
    move-object v13, v5

    .line 77
    :cond_4c
    :goto_4c
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    if-eqz v4, :cond_213

    .line 82
    .line 83
    sget-object v4, La3/s;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 84
    .line 85
    invoke-virtual {v0, v4}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    const/4 v5, 0x1

    .line 90
    packed-switch v4, :pswitch_data_2c0

    .line 91
    .line 92
    .line 93
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 94
    .line 95
    .line 96
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 97
    .line 98
    .line 99
    goto :goto_4c

    .line 100
    :pswitch_63
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 101
    .line 102
    .line 103
    move-result v33

    .line 104
    goto :goto_4c

    .line 105
    :pswitch_68
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v14

    .line 109
    goto :goto_4c

    .line 110
    :pswitch_6d
    invoke-static {v0, v7, v3}, La3/d;->f(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;Z)Lw2/b;

    .line 111
    .line 112
    .line 113
    move-result-object v32

    .line 114
    goto :goto_4c

    .line 115
    :pswitch_72
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 116
    .line 117
    .line 118
    move-result-wide v4

    .line 119
    double-to-float v2, v4

    .line 120
    goto :goto_4c

    .line 121
    :pswitch_78
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 122
    .line 123
    .line 124
    move-result-wide v4

    .line 125
    double-to-float v1, v4

    .line 126
    goto :goto_4c

    .line 127
    :pswitch_7e
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 128
    .line 129
    .line 130
    move-result v4

    .line 131
    int-to-float v4, v4

    .line 132
    invoke-static {}, Lc3/j;->e()F

    .line 133
    .line 134
    .line 135
    move-result v5

    .line 136
    mul-float v4, v4, v5

    .line 137
    .line 138
    float-to-int v4, v4

    .line 139
    move/from16 v28, v4

    .line 140
    .line 141
    goto :goto_4c

    .line 142
    :pswitch_8d
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    int-to-float v4, v4

    .line 147
    invoke-static {}, Lc3/j;->e()F

    .line 148
    .line 149
    .line 150
    move-result v5

    .line 151
    mul-float v4, v4, v5

    .line 152
    .line 153
    float-to-int v4, v4

    .line 154
    move/from16 v27, v4

    .line 155
    .line 156
    goto :goto_4c

    .line 157
    :pswitch_9c
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 158
    .line 159
    .line 160
    move-result-wide v4

    .line 161
    double-to-float v4, v4

    .line 162
    move/from16 v26, v4

    .line 163
    .line 164
    goto :goto_4c

    .line 165
    :pswitch_a4
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->i()D

    .line 166
    .line 167
    .line 168
    move-result-wide v4

    .line 169
    double-to-float v4, v4

    .line 170
    move/from16 v25, v4

    .line 171
    .line 172
    goto :goto_4c

    .line 173
    :pswitch_ac
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 174
    .line 175
    .line 176
    new-instance v4, Ljava/util/ArrayList;

    .line 177
    .line 178
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 179
    .line 180
    .line 181
    :goto_b4
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 182
    .line 183
    .line 184
    move-result v5

    .line 185
    if-eqz v5, :cond_de

    .line 186
    .line 187
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 188
    .line 189
    .line 190
    :goto_bd
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 191
    .line 192
    .line 193
    move-result v5

    .line 194
    if-eqz v5, :cond_da

    .line 195
    .line 196
    sget-object v5, La3/s;->c:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 197
    .line 198
    invoke-virtual {v0, v5}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 199
    .line 200
    .line 201
    move-result v5

    .line 202
    if-eqz v5, :cond_d2

    .line 203
    .line 204
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 205
    .line 206
    .line 207
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 208
    .line 209
    .line 210
    goto :goto_bd

    .line 211
    :cond_d2
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v5

    .line 215
    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    goto :goto_bd

    .line 219
    :cond_da
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 220
    .line 221
    .line 222
    goto :goto_b4

    .line 223
    :cond_de
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 224
    .line 225
    .line 226
    new-instance v5, Ljava/lang/StringBuilder;

    .line 227
    .line 228
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 229
    .line 230
    .line 231
    const-string v6, "Lottie doesn\'t support layer effects. If you are using them for  fills, strokes, trim paths etc. then try adding them directly as contents  in your shape. Found: "

    .line 232
    .line 233
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 237
    .line 238
    .line 239
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v4

    .line 243
    invoke-virtual {v7, v4}, Lq2/d;->a(Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    goto/16 :goto_4c

    .line 247
    .line 248
    :pswitch_f7
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->d()V

    .line 249
    .line 250
    .line 251
    :goto_fa
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 252
    .line 253
    .line 254
    move-result v4

    .line 255
    if-eqz v4, :cond_133

    .line 256
    .line 257
    sget-object v4, La3/s;->b:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 258
    .line 259
    invoke-virtual {v0, v4}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 260
    .line 261
    .line 262
    move-result v4

    .line 263
    if-eqz v4, :cond_12e

    .line 264
    .line 265
    if-eq v4, v5, :cond_111

    .line 266
    .line 267
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 268
    .line 269
    .line 270
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 271
    .line 272
    .line 273
    goto :goto_fa

    .line 274
    :cond_111
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 275
    .line 276
    .line 277
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 278
    .line 279
    .line 280
    move-result v4

    .line 281
    if-eqz v4, :cond_120

    .line 282
    .line 283
    invoke-static/range {p0 .. p1}, La3/b;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/k;

    .line 284
    .line 285
    .line 286
    move-result-object v4

    .line 287
    move-object/from16 v30, v4

    .line 288
    .line 289
    :cond_120
    :goto_120
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 290
    .line 291
    .line 292
    move-result v4

    .line 293
    if-eqz v4, :cond_12a

    .line 294
    .line 295
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 296
    .line 297
    .line 298
    goto :goto_120

    .line 299
    :cond_12a
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 300
    .line 301
    .line 302
    goto :goto_fa

    .line 303
    :cond_12e
    invoke-static/range {p0 .. p1}, La3/d;->d(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/j;

    .line 304
    .line 305
    .line 306
    move-result-object v29

    .line 307
    goto :goto_fa

    .line 308
    :cond_133
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 309
    .line 310
    .line 311
    goto/16 :goto_4c

    .line 312
    .line 313
    :pswitch_138
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 314
    .line 315
    .line 316
    :cond_13b
    :goto_13b
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 317
    .line 318
    .line 319
    move-result v4

    .line 320
    if-eqz v4, :cond_14b

    .line 321
    .line 322
    invoke-static/range {p0 .. p1}, La3/g;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lx2/b;

    .line 323
    .line 324
    .line 325
    move-result-object v4

    .line 326
    if-eqz v4, :cond_13b

    .line 327
    .line 328
    invoke-interface {v8, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 329
    .line 330
    .line 331
    goto :goto_13b

    .line 332
    :cond_14b
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 333
    .line 334
    .line 335
    goto/16 :goto_4c

    .line 336
    .line 337
    :pswitch_150
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->c()V

    .line 338
    .line 339
    .line 340
    :goto_153
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 341
    .line 342
    .line 343
    move-result v4

    .line 344
    if-eqz v4, :cond_161

    .line 345
    .line 346
    invoke-static/range {p0 .. p1}, La3/u;->a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lcom/airbnb/lottie/model/content/Mask;

    .line 347
    .line 348
    .line 349
    move-result-object v4

    .line 350
    invoke-interface {v10, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 351
    .line 352
    .line 353
    goto :goto_153

    .line 354
    :cond_161
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 355
    .line 356
    .line 357
    move-result v4

    .line 358
    invoke-virtual {v7, v4}, Lq2/d;->q(I)V

    .line 359
    .line 360
    .line 361
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->e()V

    .line 362
    .line 363
    .line 364
    goto/16 :goto_4c

    .line 365
    .line 366
    :pswitch_16d
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 367
    .line 368
    .line 369
    move-result v4

    .line 370
    invoke-static {}, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->values()[Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    .line 371
    .line 372
    .line 373
    move-result-object v6

    .line 374
    array-length v6, v6

    .line 375
    if-lt v4, v6, :cond_18e

    .line 376
    .line 377
    new-instance v5, Ljava/lang/StringBuilder;

    .line 378
    .line 379
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 380
    .line 381
    .line 382
    const-string v6, "Unsupported matte type: "

    .line 383
    .line 384
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 385
    .line 386
    .line 387
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v4

    .line 394
    invoke-virtual {v7, v4}, Lq2/d;->a(Ljava/lang/String;)V

    .line 395
    .line 396
    .line 397
    goto/16 :goto_4c

    .line 398
    .line 399
    :cond_18e
    invoke-static {}, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->values()[Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    .line 400
    .line 401
    .line 402
    move-result-object v6

    .line 403
    aget-object v31, v6, v4

    .line 404
    .line 405
    sget-object v4, La3/s$a;->a:[I

    .line 406
    .line 407
    invoke-virtual/range {v31 .. v31}, Ljava/lang/Enum;->ordinal()I

    .line 408
    .line 409
    .line 410
    move-result v6

    .line 411
    aget v4, v4, v6

    .line 412
    .line 413
    if-eq v4, v5, :cond_1a8

    .line 414
    .line 415
    const/4 v6, 0x2

    .line 416
    if-eq v4, v6, :cond_1a2

    .line 417
    .line 418
    goto :goto_1ad

    .line 419
    :cond_1a2
    const-string v4, "Unsupported matte type: Luma Inverted"

    .line 420
    .line 421
    invoke-virtual {v7, v4}, Lq2/d;->a(Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    goto :goto_1ad

    .line 425
    :cond_1a8
    const-string v4, "Unsupported matte type: Luma"

    .line 426
    .line 427
    invoke-virtual {v7, v4}, Lq2/d;->a(Ljava/lang/String;)V

    .line 428
    .line 429
    .line 430
    :goto_1ad
    invoke-virtual {v7, v5}, Lq2/d;->q(I)V

    .line 431
    .line 432
    .line 433
    goto/16 :goto_4c

    .line 434
    .line 435
    :pswitch_1b2
    invoke-static/range {p0 .. p1}, La3/c;->g(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/l;

    .line 436
    .line 437
    .line 438
    move-result-object v21

    .line 439
    goto/16 :goto_4c

    .line 440
    .line 441
    :pswitch_1b8
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 442
    .line 443
    .line 444
    move-result-object v4

    .line 445
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 446
    .line 447
    .line 448
    move-result v24

    .line 449
    goto/16 :goto_4c

    .line 450
    .line 451
    :pswitch_1c2
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 452
    .line 453
    .line 454
    move-result v4

    .line 455
    int-to-float v4, v4

    .line 456
    invoke-static {}, Lc3/j;->e()F

    .line 457
    .line 458
    .line 459
    move-result v5

    .line 460
    mul-float v4, v4, v5

    .line 461
    .line 462
    float-to-int v4, v4

    .line 463
    move/from16 v23, v4

    .line 464
    .line 465
    goto/16 :goto_4c

    .line 466
    .line 467
    :pswitch_1d2
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 468
    .line 469
    .line 470
    move-result v4

    .line 471
    int-to-float v4, v4

    .line 472
    invoke-static {}, Lc3/j;->e()F

    .line 473
    .line 474
    .line 475
    move-result v5

    .line 476
    mul-float v4, v4, v5

    .line 477
    .line 478
    float-to-int v4, v4

    .line 479
    move/from16 v22, v4

    .line 480
    .line 481
    goto/16 :goto_4c

    .line 482
    .line 483
    :pswitch_1e2
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 484
    .line 485
    .line 486
    move-result v4

    .line 487
    int-to-long v4, v4

    .line 488
    move-wide/from16 v18, v4

    .line 489
    .line 490
    goto/16 :goto_4c

    .line 491
    .line 492
    :pswitch_1eb
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 493
    .line 494
    .line 495
    move-result v4

    .line 496
    sget-object v17, Lcom/airbnb/lottie/model/layer/Layer$LayerType;->UNKNOWN:Lcom/airbnb/lottie/model/layer/Layer$LayerType;

    .line 497
    .line 498
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Enum;->ordinal()I

    .line 499
    .line 500
    .line 501
    move-result v5

    .line 502
    if-ge v4, v5, :cond_4c

    .line 503
    .line 504
    invoke-static {}, Lcom/airbnb/lottie/model/layer/Layer$LayerType;->values()[Lcom/airbnb/lottie/model/layer/Layer$LayerType;

    .line 505
    .line 506
    .line 507
    move-result-object v5

    .line 508
    aget-object v17, v5, v4

    .line 509
    .line 510
    goto/16 :goto_4c

    .line 511
    .line 512
    :pswitch_1ff
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 513
    .line 514
    .line 515
    move-result-object v20

    .line 516
    goto/16 :goto_4c

    .line 517
    .line 518
    :pswitch_205
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 519
    .line 520
    .line 521
    move-result v4

    .line 522
    int-to-long v4, v4

    .line 523
    move-wide v15, v4

    .line 524
    goto/16 :goto_4c

    .line 525
    .line 526
    :pswitch_20d
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 527
    .line 528
    .line 529
    move-result-object v13

    .line 530
    goto/16 :goto_4c

    .line 531
    .line 532
    :cond_213
    invoke-virtual/range {p0 .. p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->f()V

    .line 533
    .line 534
    .line 535
    div-float v34, v1, v25

    .line 536
    .line 537
    div-float v35, v2, v25

    .line 538
    .line 539
    new-instance v6, Ljava/util/ArrayList;

    .line 540
    .line 541
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 542
    .line 543
    .line 544
    cmpl-float v0, v34, v11

    .line 545
    .line 546
    if-lez v0, :cond_240

    .line 547
    .line 548
    new-instance v5, Ld3/a;

    .line 549
    .line 550
    const/4 v4, 0x0

    .line 551
    const/16 v36, 0x0

    .line 552
    .line 553
    invoke-static/range {v34 .. v34}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 554
    .line 555
    .line 556
    move-result-object v37

    .line 557
    move-object v0, v5

    .line 558
    move-object/from16 v1, p1

    .line 559
    .line 560
    move-object v2, v12

    .line 561
    move-object v3, v12

    .line 562
    move-object v11, v5

    .line 563
    move/from16 v5, v36

    .line 564
    .line 565
    move-object/from16 v36, v10

    .line 566
    .line 567
    move-object v10, v6

    .line 568
    move-object/from16 v6, v37

    .line 569
    .line 570
    invoke-direct/range {v0 .. v6}, Ld3/a;-><init>(Lq2/d;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V

    .line 571
    .line 572
    .line 573
    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 574
    .line 575
    .line 576
    goto :goto_243

    .line 577
    :cond_240
    move-object/from16 v36, v10

    .line 578
    .line 579
    move-object v10, v6

    .line 580
    :goto_243
    const/4 v0, 0x0

    .line 581
    cmpl-float v0, v35, v0

    .line 582
    .line 583
    if-lez v0, :cond_249

    .line 584
    .line 585
    goto :goto_24f

    .line 586
    :cond_249
    invoke-virtual/range {p1 .. p1}, Lq2/d;->f()F

    .line 587
    .line 588
    .line 589
    move-result v0

    .line 590
    move/from16 v35, v0

    .line 591
    .line 592
    :goto_24f
    new-instance v11, Ld3/a;

    .line 593
    .line 594
    const/4 v4, 0x0

    .line 595
    invoke-static/range {v35 .. v35}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 596
    .line 597
    .line 598
    move-result-object v6

    .line 599
    move-object v0, v11

    .line 600
    move-object/from16 v1, p1

    .line 601
    .line 602
    move-object v2, v9

    .line 603
    move-object v3, v9

    .line 604
    move/from16 v5, v34

    .line 605
    .line 606
    invoke-direct/range {v0 .. v6}, Ld3/a;-><init>(Lq2/d;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V

    .line 607
    .line 608
    .line 609
    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 610
    .line 611
    .line 612
    new-instance v9, Ld3/a;

    .line 613
    .line 614
    const v0, 0x7f7fffff    # Float.MAX_VALUE

    .line 615
    .line 616
    .line 617
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 618
    .line 619
    .line 620
    move-result-object v6

    .line 621
    move-object v0, v9

    .line 622
    move-object v2, v12

    .line 623
    move-object v3, v12

    .line 624
    move/from16 v5, v35

    .line 625
    .line 626
    invoke-direct/range {v0 .. v6}, Ld3/a;-><init>(Lq2/d;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/animation/Interpolator;FLjava/lang/Float;)V

    .line 627
    .line 628
    .line 629
    invoke-interface {v10, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 630
    .line 631
    .line 632
    const-string v0, ".ai"

    .line 633
    .line 634
    invoke-virtual {v13, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 635
    .line 636
    .line 637
    move-result v0

    .line 638
    if-nez v0, :cond_287

    .line 639
    .line 640
    const-string v0, "ai"

    .line 641
    .line 642
    invoke-virtual {v0, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 643
    .line 644
    .line 645
    move-result v0

    .line 646
    if-eqz v0, :cond_28c

    .line 647
    .line 648
    :cond_287
    const-string v0, "Convert your Illustrator layers to shape layers."

    .line 649
    .line 650
    invoke-virtual {v7, v0}, Lq2/d;->a(Ljava/lang/String;)V

    .line 651
    .line 652
    .line 653
    :cond_28c
    new-instance v34, Lcom/airbnb/lottie/model/layer/Layer;

    .line 654
    .line 655
    move-object/from16 v0, v34

    .line 656
    .line 657
    move-object v1, v8

    .line 658
    move-object/from16 v2, p1

    .line 659
    .line 660
    move-object v3, v13

    .line 661
    move-wide v4, v15

    .line 662
    move-object/from16 v6, v17

    .line 663
    .line 664
    move-wide/from16 v7, v18

    .line 665
    .line 666
    move-object/from16 v9, v20

    .line 667
    .line 668
    move-object/from16 v35, v10

    .line 669
    .line 670
    move-object/from16 v10, v36

    .line 671
    .line 672
    move-object/from16 v11, v21

    .line 673
    .line 674
    move/from16 v12, v22

    .line 675
    .line 676
    move/from16 v13, v23

    .line 677
    .line 678
    move/from16 v14, v24

    .line 679
    .line 680
    move/from16 v15, v25

    .line 681
    .line 682
    move/from16 v16, v26

    .line 683
    .line 684
    move/from16 v17, v27

    .line 685
    .line 686
    move/from16 v18, v28

    .line 687
    .line 688
    move-object/from16 v19, v29

    .line 689
    .line 690
    move-object/from16 v20, v30

    .line 691
    .line 692
    move-object/from16 v21, v35

    .line 693
    .line 694
    move-object/from16 v22, v31

    .line 695
    .line 696
    move-object/from16 v23, v32

    .line 697
    .line 698
    move/from16 v24, v33

    .line 699
    .line 700
    invoke-direct/range {v0 .. v24}, Lcom/airbnb/lottie/model/layer/Layer;-><init>(Ljava/util/List;Lq2/d;Ljava/lang/String;JLcom/airbnb/lottie/model/layer/Layer$LayerType;JLjava/lang/String;Ljava/util/List;Lw2/l;IIIFFIILw2/j;Lw2/k;Ljava/util/List;Lcom/airbnb/lottie/model/layer/Layer$MatteType;Lw2/b;Z)V

    .line 701
    .line 702
    .line 703
    return-object v34

    .line 704
    nop

    .line 705
    :pswitch_data_2c0
    .packed-switch 0x0
        :pswitch_20d
        :pswitch_205
        :pswitch_1ff
        :pswitch_1eb
        :pswitch_1e2
        :pswitch_1d2
        :pswitch_1c2
        :pswitch_1b8
        :pswitch_1b2
        :pswitch_16d
        :pswitch_150
        :pswitch_138
        :pswitch_f7
        :pswitch_ac
        :pswitch_a4
        :pswitch_9c
        :pswitch_8d
        :pswitch_7e
        :pswitch_78
        :pswitch_72
        :pswitch_6d
        :pswitch_68
        :pswitch_63
    .end packed-switch
.end method

.method public static b(Lq2/d;)Lcom/airbnb/lottie/model/layer/Layer;
    .registers 27

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p0}, Lq2/d;->b()Landroid/graphics/Rect;

    .line 4
    .line 5
    .line 6
    move-result-object v3

    .line 7
    new-instance v25, Lcom/airbnb/lottie/model/layer/Layer;

    .line 8
    .line 9
    move-object/from16 v0, v25

    .line 10
    .line 11
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    sget-object v6, Lcom/airbnb/lottie/model/layer/Layer$LayerType;->PRE_COMP:Lcom/airbnb/lottie/model/layer/Layer$LayerType;

    .line 16
    .line 17
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 18
    .line 19
    .line 20
    move-result-object v10

    .line 21
    new-instance v4, Lw2/l;

    .line 22
    .line 23
    move-object v11, v4

    .line 24
    invoke-direct {v4}, Lw2/l;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v3}, Landroid/graphics/Rect;->width()I

    .line 28
    .line 29
    .line 30
    move-result v17

    .line 31
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 32
    .line 33
    .line 34
    move-result v18

    .line 35
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 36
    .line 37
    .line 38
    move-result-object v21

    .line 39
    sget-object v22, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->NONE:Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    .line 40
    .line 41
    const-string v3, "__container"

    .line 42
    .line 43
    const-wide/16 v4, -0x1

    .line 44
    .line 45
    const-wide/16 v7, -0x1

    .line 46
    .line 47
    const/4 v9, 0x0

    .line 48
    const/4 v12, 0x0

    .line 49
    const/4 v13, 0x0

    .line 50
    const/4 v14, 0x0

    .line 51
    const/4 v15, 0x0

    .line 52
    const/16 v16, 0x0

    .line 53
    .line 54
    const/16 v19, 0x0

    .line 55
    .line 56
    const/16 v20, 0x0

    .line 57
    .line 58
    const/16 v23, 0x0

    .line 59
    .line 60
    const/16 v24, 0x0

    .line 61
    .line 62
    invoke-direct/range {v0 .. v24}, Lcom/airbnb/lottie/model/layer/Layer;-><init>(Ljava/util/List;Lq2/d;Ljava/lang/String;JLcom/airbnb/lottie/model/layer/Layer$LayerType;JLjava/lang/String;Ljava/util/List;Lw2/l;IIIFFIILw2/j;Lw2/k;Ljava/util/List;Lcom/airbnb/lottie/model/layer/Layer$MatteType;Lw2/b;Z)V

    .line 63
    .line 64
    .line 65
    return-object v25
.end method

###### Class a3.s.a (a3.s$a)
.class public synthetic La3/s$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La3/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation


# static fields
.field public static final synthetic a:[I


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    invoke-static {}, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->values()[Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    sput-object v0, La3/s$a;->a:[I

    :try_start_9
    sget-object v1, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->LUMA:Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_12} :catch_12

    :catch_12
    :try_start_12
    sget-object v0, La3/s$a;->a:[I

    sget-object v1, Lcom/airbnb/lottie/model/layer/Layer$MatteType;->LUMA_INVERTED:Lcom/airbnb/lottie/model/layer/Layer$MatteType;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_1d} :catch_1d

    :catch_1d
    return-void
.end method
