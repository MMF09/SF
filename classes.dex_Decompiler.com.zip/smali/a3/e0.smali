###### Class a3.e0 (a3.e0)
.class public La3/e0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;


# direct methods
.method public static constructor <clinit>()V
    .registers 6

    const-string v0, "nm"

    const-string v1, "c"

    const-string v2, "o"

    const-string v3, "fillEnabled"

    const-string v4, "r"

    const-string v5, "hd"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/airbnb/lottie/parser/moshi/JsonReader$a;->a([Ljava/lang/String;)Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    move-result-object v0

    sput-object v0, La3/e0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    return-void
.end method

.method public static a(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lx2/h;
    .registers 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    const/4 v2, 0x0

    .line 4
    move-object v4, v2

    .line 5
    move-object v7, v4

    .line 6
    const/4 v0, 0x1

    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v9, 0x0

    .line 9
    :goto_8
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->g()Z

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    if-eqz v3, :cond_49

    .line 14
    .line 15
    sget-object v3, La3/e0;->a:Lcom/airbnb/lottie/parser/moshi/JsonReader$a;

    .line 16
    .line 17
    invoke-virtual {p0, v3}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->q(Lcom/airbnb/lottie/parser/moshi/JsonReader$a;)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    if-eqz v3, :cond_44

    .line 22
    .line 23
    if-eq v3, v1, :cond_3f

    .line 24
    .line 25
    const/4 v6, 0x2

    .line 26
    if-eq v3, v6, :cond_3a

    .line 27
    .line 28
    const/4 v6, 0x3

    .line 29
    if-eq v3, v6, :cond_35

    .line 30
    .line 31
    const/4 v6, 0x4

    .line 32
    if-eq v3, v6, :cond_30

    .line 33
    .line 34
    const/4 v6, 0x5

    .line 35
    if-eq v3, v6, :cond_2b

    .line 36
    .line 37
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->r()V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->u()V

    .line 41
    .line 42
    .line 43
    goto :goto_8

    .line 44
    :cond_2b
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 45
    .line 46
    .line 47
    move-result v9

    .line 48
    goto :goto_8

    .line 49
    :cond_30
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->j()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    goto :goto_8

    .line 54
    :cond_35
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->h()Z

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    goto :goto_8

    .line 59
    :cond_3a
    invoke-static {p0, p1}, La3/d;->h(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/d;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    goto :goto_8

    .line 64
    :cond_3f
    invoke-static {p0, p1}, La3/d;->c(Lcom/airbnb/lottie/parser/moshi/JsonReader;Lq2/d;)Lw2/a;

    .line 65
    .line 66
    .line 67
    move-result-object v7

    .line 68
    goto :goto_8

    .line 69
    :cond_44
    invoke-virtual {p0}, Lcom/airbnb/lottie/parser/moshi/JsonReader;->l()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    goto :goto_8

    .line 74
    :cond_49
    if-nez v2, :cond_61

    .line 75
    .line 76
    new-instance p0, Lw2/d;

    .line 77
    .line 78
    new-instance p1, Ld3/a;

    .line 79
    .line 80
    const/16 v2, 0x64

    .line 81
    .line 82
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    invoke-direct {p1, v2}, Ld3/a;-><init>(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    invoke-direct {p0, p1}, Lw2/d;-><init>(Ljava/util/List;)V

    .line 94
    .line 95
    .line 96
    move-object v8, p0

    .line 97
    goto :goto_62

    .line 98
    :cond_61
    move-object v8, v2

    .line 99
    :goto_62
    if-ne v0, v1, :cond_67

    .line 100
    .line 101
    sget-object p0, Landroid/graphics/Path$FillType;->WINDING:Landroid/graphics/Path$FillType;

    .line 102
    .line 103
    goto :goto_69

    .line 104
    :cond_67
    sget-object p0, Landroid/graphics/Path$FillType;->EVEN_ODD:Landroid/graphics/Path$FillType;

    .line 105
    .line 106
    :goto_69
    move-object v6, p0

    .line 107
    new-instance p0, Lx2/h;

    .line 108
    .line 109
    move-object v3, p0

    .line 110
    invoke-direct/range {v3 .. v9}, Lx2/h;-><init>(Ljava/lang/String;ZLandroid/graphics/Path$FillType;Lw2/a;Lw2/d;Z)V

    .line 111
    .line 112
    .line 113
    return-object p0
.end method
