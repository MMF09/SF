###### Class t2.f (t2.f)
.class public abstract Lt2/f;
.super Lt2/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lt2/a<",
        "TT;TT;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Ld3/a<",
            "TT;>;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1}, Lt2/a;-><init>(Ljava/util/List;)V

    return-void
.end method
