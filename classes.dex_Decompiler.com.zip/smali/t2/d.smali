###### Class t2.d (t2.d)
.class public Lt2/d;
.super Lt2/f;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lt2/f<",
        "Lx2/c;",
        ">;"
    }
.end annotation


# instance fields
.field public final i:Lx2/c;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ld3/a<",
            "Lx2/c;",
            ">;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1}, Lt2/f;-><init>(Ljava/util/List;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ld3/a;

    .line 10
    .line 11
    iget-object p1, p1, Ld3/a;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p1, Lx2/c;

    .line 14
    .line 15
    if-nez p1, :cond_11

    .line 16
    .line 17
    goto :goto_15

    .line 18
    :cond_11
    invoke-virtual {p1}, Lx2/c;->c()I

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    :goto_15
    new-instance p1, Lx2/c;

    .line 23
    .line 24
    new-array v1, v0, [F

    .line 25
    .line 26
    new-array v0, v0, [I

    .line 27
    .line 28
    invoke-direct {p1, v1, v0}, Lx2/c;-><init>([F[I)V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Lt2/d;->i:Lx2/c;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public bridge synthetic i(Ld3/a;F)Ljava/lang/Object;
    .registers 3

    invoke-virtual {p0, p1, p2}, Lt2/d;->o(Ld3/a;F)Lx2/c;

    move-result-object p1

    return-object p1
.end method

.method public o(Ld3/a;F)Lx2/c;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/a<",
            "Lx2/c;",
            ">;F)",
            "Lx2/c;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lt2/d;->i:Lx2/c;

    .line 2
    .line 3
    iget-object v1, p1, Ld3/a;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lx2/c;

    .line 6
    .line 7
    iget-object p1, p1, Ld3/a;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p1, Lx2/c;

    .line 10
    .line 11
    invoke-virtual {v0, v1, p1, p2}, Lx2/c;->d(Lx2/c;Lx2/c;F)V

    .line 12
    .line 13
    .line 14
    iget-object p1, p0, Lt2/d;->i:Lx2/c;

    .line 15
    .line 16
    return-object p1
.end method
