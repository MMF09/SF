###### Class t2.l (t2.l)
.class public Lt2/l;
.super Lt2/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lt2/a<",
        "Lx2/g;",
        "Landroid/graphics/Path;",
        ">;"
    }
.end annotation


# instance fields
.field public final i:Lx2/g;

.field public final j:Landroid/graphics/Path;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ld3/a<",
            "Lx2/g;",
            ">;>;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1}, Lt2/a;-><init>(Ljava/util/List;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, Lx2/g;

    .line 5
    .line 6
    invoke-direct {p1}, Lx2/g;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lt2/l;->i:Lx2/g;

    .line 10
    .line 11
    new-instance p1, Landroid/graphics/Path;

    .line 12
    .line 13
    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lt2/l;->j:Landroid/graphics/Path;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public bridge synthetic i(Ld3/a;F)Ljava/lang/Object;
    .registers 3

    invoke-virtual {p0, p1, p2}, Lt2/l;->o(Ld3/a;F)Landroid/graphics/Path;

    move-result-object p1

    return-object p1
.end method

.method public o(Ld3/a;F)Landroid/graphics/Path;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/a<",
            "Lx2/g;",
            ">;F)",
            "Landroid/graphics/Path;"
        }
    .end annotation

    .line 1
    iget-object v0, p1, Ld3/a;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lx2/g;

    .line 4
    .line 5
    iget-object p1, p1, Ld3/a;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p1, Lx2/g;

    .line 8
    .line 9
    iget-object v1, p0, Lt2/l;->i:Lx2/g;

    .line 10
    .line 11
    invoke-virtual {v1, v0, p1, p2}, Lx2/g;->c(Lx2/g;Lx2/g;F)V

    .line 12
    .line 13
    .line 14
    iget-object p1, p0, Lt2/l;->i:Lx2/g;

    .line 15
    .line 16
    iget-object p2, p0, Lt2/l;->j:Landroid/graphics/Path;

    .line 17
    .line 18
    invoke-static {p1, p2}, Lc3/i;->i(Lx2/g;Landroid/graphics/Path;)V

    .line 19
    .line 20
    .line 21
    iget-object p1, p0, Lt2/l;->j:Landroid/graphics/Path;

    .line 22
    .line 23
    return-object p1
.end method
