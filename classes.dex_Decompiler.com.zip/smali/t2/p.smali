###### Class t2.p (t2.p)
.class public Lt2/p;
.super Lt2/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "A:",
        "Ljava/lang/Object;",
        ">",
        "Lt2/a<",
        "TK;TA;>;"
    }
.end annotation


# instance fields
.field public final i:Ld3/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ld3/b<",
            "TA;>;"
        }
    .end annotation
.end field

.field public final j:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TA;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ld3/c;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/c<",
            "TA;>;)V"
        }
    .end annotation

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, Lt2/p;-><init>(Ld3/c;Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Ld3/c;Ljava/lang/Object;)V
    .registers 4
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/c<",
            "TA;>;TA;)V"
        }
    .end annotation

    .line 2
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0}, Lt2/a;-><init>(Ljava/util/List;)V

    .line 3
    new-instance v0, Ld3/b;

    invoke-direct {v0}, Ld3/b;-><init>()V

    iput-object v0, p0, Lt2/p;->i:Ld3/b;

    .line 4
    invoke-virtual {p0, p1}, Lt2/a;->m(Ld3/c;)V

    .line 5
    iput-object p2, p0, Lt2/p;->j:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public c()F
    .registers 2

    const/high16 v0, 0x3f800000    # 1.0f

    return v0
.end method

.method public h()Ljava/lang/Object;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TA;"
        }
    .end annotation

    iget-object v0, p0, Lt2/a;->e:Ld3/c;

    iget-object v4, p0, Lt2/p;->j:Ljava/lang/Object;

    invoke-virtual {p0}, Lt2/a;->f()F

    move-result v5

    invoke-virtual {p0}, Lt2/a;->f()F

    move-result v6

    invoke-virtual {p0}, Lt2/a;->f()F

    move-result v7

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object v3, v4

    invoke-virtual/range {v0 .. v7}, Ld3/c;->b(FFLjava/lang/Object;Ljava/lang/Object;FFF)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public i(Ld3/a;F)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ld3/a<",
            "TK;>;F)TA;"
        }
    .end annotation

    invoke-virtual {p0}, Lt2/p;->h()Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public j()V
    .registers 2

    .line 1
    iget-object v0, p0, Lt2/a;->e:Ld3/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-super {p0}, Lt2/a;->j()V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public l(F)V
    .registers 2

    iput p1, p0, Lt2/a;->d:F

    return-void
.end method
