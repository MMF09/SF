###### Class w1.b (w1.b)
.class public final synthetic Lw1/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/print/PrintAttributes$Builder;I)Landroid/print/PrintAttributes$Builder;
    .registers 2

    invoke-virtual {p0, p1}, Landroid/print/PrintAttributes$Builder;->setDuplexMode(I)Landroid/print/PrintAttributes$Builder;

    move-result-object p0

    return-object p0
.end method
