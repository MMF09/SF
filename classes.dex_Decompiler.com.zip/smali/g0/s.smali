###### Class g0.s (g0.s)
.class public final synthetic Lg0/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/camera/core/processing/SurfaceEdge;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/processing/SurfaceEdge;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lg0/s;->a:Landroidx/camera/core/processing/SurfaceEdge;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lg0/s;->a:Landroidx/camera/core/processing/SurfaceEdge;

    invoke-static {v0}, Landroidx/camera/core/processing/SurfaceEdge;->d(Landroidx/camera/core/processing/SurfaceEdge;)V

    return-void
.end method
