###### Class defpackage.MmsDeviceInfoEvent (MmsDeviceInfoEvent)
.class public final LMmsDeviceInfoEvent;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LMmsDeviceInfoEvent$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT_CODEC_INFOS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_IMAGE_CODEC_INFOS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_MEMORY_SIZE:Ljava/lang/Long;

.field private static final serialVersionUID:J


# instance fields
.field public final chip_info:LMMSDeviceChipInfo;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x5
    .end annotation
.end field

.field public final codec_infos:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        messageType = LCodecInfo;
        tag = 0x1
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public final display_info:LMMSDeviceDisplayInfo;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x4
    .end annotation
.end field

.field public final image_codec_infos:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        messageType = LCodecInfo;
        tag = 0x3
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public final memory_size:Ljava/lang/Long;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x2
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT64:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    .line 1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sput-object v0, LMmsDeviceInfoEvent;->DEFAULT_CODEC_INFOS:Ljava/util/List;

    .line 6
    .line 7
    const-wide/16 v0, 0x0

    .line 8
    .line 9
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    sput-object v0, LMmsDeviceInfoEvent;->DEFAULT_MEMORY_SIZE:Ljava/lang/Long;

    .line 14
    .line 15
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, LMmsDeviceInfoEvent;->DEFAULT_IMAGE_CODEC_INFOS:Ljava/util/List;

    .line 20
    .line 21
    return-void
.end method

.method private constructor <init>(LMmsDeviceInfoEvent$Builder;)V
    .registers 8

    .line 8
    iget-object v1, p1, LMmsDeviceInfoEvent$Builder;->codec_infos:Ljava/util/List;

    iget-object v2, p1, LMmsDeviceInfoEvent$Builder;->memory_size:Ljava/lang/Long;

    iget-object v3, p1, LMmsDeviceInfoEvent$Builder;->image_codec_infos:Ljava/util/List;

    iget-object v4, p1, LMmsDeviceInfoEvent$Builder;->display_info:LMMSDeviceDisplayInfo;

    iget-object v5, p1, LMmsDeviceInfoEvent$Builder;->chip_info:LMMSDeviceChipInfo;

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, LMmsDeviceInfoEvent;-><init>(Ljava/util/List;Ljava/lang/Long;Ljava/util/List;LMMSDeviceDisplayInfo;LMMSDeviceChipInfo;)V

    .line 9
    invoke-virtual {p0, p1}, Lcom/squareup/wire/Message;->setBuilder(Lcom/squareup/wire/Message$Builder;)V

    return-void
.end method

.method public synthetic constructor <init>(LMmsDeviceInfoEvent$Builder;LMmsDeviceInfoEvent$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LMmsDeviceInfoEvent;-><init>(LMmsDeviceInfoEvent$Builder;)V

    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/lang/Long;Ljava/util/List;LMMSDeviceDisplayInfo;LMMSDeviceChipInfo;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;",
            "Ljava/lang/Long;",
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;",
            "LMMSDeviceDisplayInfo;",
            "LMMSDeviceChipInfo;",
            ")V"
        }
    .end annotation

    .line 2
    invoke-direct {p0}, Lcom/squareup/wire/Message;-><init>()V

    .line 3
    invoke-static {p1}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMmsDeviceInfoEvent;->codec_infos:Ljava/util/List;

    .line 4
    iput-object p2, p0, LMmsDeviceInfoEvent;->memory_size:Ljava/lang/Long;

    .line 5
    invoke-static {p3}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMmsDeviceInfoEvent;->image_codec_infos:Ljava/util/List;

    .line 6
    iput-object p4, p0, LMmsDeviceInfoEvent;->display_info:LMMSDeviceDisplayInfo;

    .line 7
    iput-object p5, p0, LMmsDeviceInfoEvent;->chip_info:LMMSDeviceChipInfo;

    return-void
.end method

.method public static synthetic access$000(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$100(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LMmsDeviceInfoEvent;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LMmsDeviceInfoEvent;

    .line 12
    .line 13
    iget-object v1, p0, LMmsDeviceInfoEvent;->codec_infos:Ljava/util/List;

    .line 14
    .line 15
    iget-object v3, p1, LMmsDeviceInfoEvent;->codec_infos:Ljava/util/List;

    .line 16
    .line 17
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_3f

    .line 22
    .line 23
    iget-object v1, p0, LMmsDeviceInfoEvent;->memory_size:Ljava/lang/Long;

    .line 24
    .line 25
    iget-object v3, p1, LMmsDeviceInfoEvent;->memory_size:Ljava/lang/Long;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_3f

    .line 32
    .line 33
    iget-object v1, p0, LMmsDeviceInfoEvent;->image_codec_infos:Ljava/util/List;

    .line 34
    .line 35
    iget-object v3, p1, LMmsDeviceInfoEvent;->image_codec_infos:Ljava/util/List;

    .line 36
    .line 37
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_3f

    .line 42
    .line 43
    iget-object v1, p0, LMmsDeviceInfoEvent;->display_info:LMMSDeviceDisplayInfo;

    .line 44
    .line 45
    iget-object v3, p1, LMmsDeviceInfoEvent;->display_info:LMMSDeviceDisplayInfo;

    .line 46
    .line 47
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_3f

    .line 52
    .line 53
    iget-object v1, p0, LMmsDeviceInfoEvent;->chip_info:LMMSDeviceChipInfo;

    .line 54
    .line 55
    iget-object p1, p1, LMmsDeviceInfoEvent;->chip_info:LMMSDeviceChipInfo;

    .line 56
    .line 57
    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    if-eqz p1, :cond_3f

    .line 62
    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    const/4 v0, 0x0

    .line 65
    :goto_40
    return v0
.end method

.method public hashCode()I
    .registers 5

    .line 1
    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 2
    .line 3
    if-nez v0, :cond_42

    .line 4
    .line 5
    iget-object v0, p0, LMmsDeviceInfoEvent;->codec_infos:Ljava/util/List;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x1

    .line 16
    :goto_f
    mul-int/lit8 v0, v0, 0x25

    .line 17
    .line 18
    iget-object v2, p0, LMmsDeviceInfoEvent;->memory_size:Ljava/lang/Long;

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    if-eqz v2, :cond_1b

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/lang/Long;->hashCode()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 v2, 0x0

    .line 29
    :goto_1c
    add-int/2addr v0, v2

    .line 30
    mul-int/lit8 v0, v0, 0x25

    .line 31
    .line 32
    iget-object v2, p0, LMmsDeviceInfoEvent;->image_codec_infos:Ljava/util/List;

    .line 33
    .line 34
    if-eqz v2, :cond_27

    .line 35
    .line 36
    invoke-interface {v2}, Ljava/util/List;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    :cond_27
    add-int/2addr v0, v1

    .line 41
    mul-int/lit8 v0, v0, 0x25

    .line 42
    .line 43
    iget-object v1, p0, LMmsDeviceInfoEvent;->display_info:LMMSDeviceDisplayInfo;

    .line 44
    .line 45
    if-eqz v1, :cond_33

    .line 46
    .line 47
    invoke-virtual {v1}, LMMSDeviceDisplayInfo;->hashCode()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    goto :goto_34

    .line 52
    :cond_33
    const/4 v1, 0x0

    .line 53
    :goto_34
    add-int/2addr v0, v1

    .line 54
    mul-int/lit8 v0, v0, 0x25

    .line 55
    .line 56
    iget-object v1, p0, LMmsDeviceInfoEvent;->chip_info:LMMSDeviceChipInfo;

    .line 57
    .line 58
    if-eqz v1, :cond_3f

    .line 59
    .line 60
    invoke-virtual {v1}, LMMSDeviceChipInfo;->hashCode()I

    .line 61
    .line 62
    .line 63
    move-result v3

    .line 64
    :cond_3f
    add-int/2addr v0, v3

    .line 65
    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 66
    .line 67
    :cond_42
    return v0
.end method

###### Class MmsDeviceInfoEvent.Builder (MmsDeviceInfoEvent$Builder)
.class public final LMmsDeviceInfoEvent$Builder;
.super Lcom/squareup/wire/Message$Builder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMmsDeviceInfoEvent;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/Message$Builder<",
        "LMmsDeviceInfoEvent;",
        ">;"
    }
.end annotation


# instance fields
.field public chip_info:LMMSDeviceChipInfo;

.field public codec_infos:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public display_info:LMMSDeviceDisplayInfo;

.field public image_codec_infos:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;"
        }
    .end annotation
.end field

.field public memory_size:Ljava/lang/Long;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/squareup/wire/Message$Builder;-><init>()V

    return-void
.end method

.method public constructor <init>(LMmsDeviceInfoEvent;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/squareup/wire/Message$Builder;-><init>(Lcom/squareup/wire/Message;)V

    if-nez p1, :cond_6

    return-void

    .line 3
    :cond_6
    iget-object v0, p1, LMmsDeviceInfoEvent;->codec_infos:Ljava/util/List;

    invoke-static {v0}, LMmsDeviceInfoEvent;->access$000(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LMmsDeviceInfoEvent$Builder;->codec_infos:Ljava/util/List;

    .line 4
    iget-object v0, p1, LMmsDeviceInfoEvent;->memory_size:Ljava/lang/Long;

    iput-object v0, p0, LMmsDeviceInfoEvent$Builder;->memory_size:Ljava/lang/Long;

    .line 5
    iget-object v0, p1, LMmsDeviceInfoEvent;->image_codec_infos:Ljava/util/List;

    invoke-static {v0}, LMmsDeviceInfoEvent;->access$100(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LMmsDeviceInfoEvent$Builder;->image_codec_infos:Ljava/util/List;

    .line 6
    iget-object v0, p1, LMmsDeviceInfoEvent;->display_info:LMMSDeviceDisplayInfo;

    iput-object v0, p0, LMmsDeviceInfoEvent$Builder;->display_info:LMMSDeviceDisplayInfo;

    .line 7
    iget-object p1, p1, LMmsDeviceInfoEvent;->chip_info:LMMSDeviceChipInfo;

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->chip_info:LMMSDeviceChipInfo;

    return-void
.end method


# virtual methods
.method public build()LMmsDeviceInfoEvent;
    .registers 3

    .line 2
    new-instance v0, LMmsDeviceInfoEvent;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, LMmsDeviceInfoEvent;-><init>(LMmsDeviceInfoEvent$Builder;LMmsDeviceInfoEvent$a;)V

    return-object v0
.end method

.method public bridge synthetic build()Lcom/squareup/wire/Message;
    .registers 2

    .line 1
    invoke-virtual {p0}, LMmsDeviceInfoEvent$Builder;->build()LMmsDeviceInfoEvent;

    move-result-object v0

    return-object v0
.end method

.method public chip_info(LMMSDeviceChipInfo;)LMmsDeviceInfoEvent$Builder;
    .registers 2

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->chip_info:LMMSDeviceChipInfo;

    return-object p0
.end method

.method public codec_infos(Ljava/util/List;)LMmsDeviceInfoEvent$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;)",
            "LMmsDeviceInfoEvent$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->codec_infos:Ljava/util/List;

    return-object p0
.end method

.method public display_info(LMMSDeviceDisplayInfo;)LMmsDeviceInfoEvent$Builder;
    .registers 2

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->display_info:LMMSDeviceDisplayInfo;

    return-object p0
.end method

.method public image_codec_infos(Ljava/util/List;)LMmsDeviceInfoEvent$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "LCodecInfo;",
            ">;)",
            "LMmsDeviceInfoEvent$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->image_codec_infos:Ljava/util/List;

    return-object p0
.end method

.method public memory_size(Ljava/lang/Long;)LMmsDeviceInfoEvent$Builder;
    .registers 2

    iput-object p1, p0, LMmsDeviceInfoEvent$Builder;->memory_size:Ljava/lang/Long;

    return-object p0
.end method

###### Class MmsDeviceInfoEvent.a (MmsDeviceInfoEvent$a)
.class public synthetic LMmsDeviceInfoEvent$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMmsDeviceInfoEvent;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation
