###### Class f4.b (f4.b)
.class public Lf4/b;
.super Landroid/os/HandlerThread;
.source "SourceFile"

# interfaces
.implements Le4/a;


# instance fields
.field public a:Le4/h;

.field public b:Lf4/a;

.field public final c:Le4/c;

.field public d:Le4/d;

.field public final e:Ljava/util/concurrent/ExecutorService;


# direct methods
.method public constructor <init>(Le4/h;Le4/c;)V
    .registers 4

    .line 1
    const-string v0, "NETWORK_THREAD"

    .line 2
    .line 3
    invoke-direct {p0, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lf4/b;->a:Le4/h;

    .line 7
    .line 8
    iput-object p2, p0, Lf4/b;->c:Le4/c;

    .line 9
    .line 10
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, p0, Lf4/b;->e:Ljava/util/concurrent/ExecutorService;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public a()V
    .registers 4

    .line 1
    iget-object v0, p0, Lf4/b;->a:Le4/h;

    .line 2
    .line 3
    invoke-virtual {v0}, Le4/h;->e()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_14

    .line 8
    .line 9
    iget-object v0, p0, Lf4/b;->d:Le4/d;

    .line 10
    .line 11
    iget-object v1, p0, Lf4/b;->a:Le4/h;

    .line 12
    .line 13
    invoke-virtual {v1}, Le4/h;->c()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    invoke-virtual {v0, v1}, Le4/d;->e(I)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    :try_start_14
    iget-object v0, p0, Lf4/b;->a:Le4/h;

    .line 22
    .line 23
    invoke-virtual {v0}, Le4/h;->a()V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, Lf4/b;->d()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_2b

    .line 31
    .line 32
    iget-object v0, p0, Lf4/b;->d:Le4/d;

    .line 33
    .line 34
    iget-object v1, p0, Lf4/b;->a:Le4/h;

    .line 35
    .line 36
    invoke-virtual {v1}, Le4/h;->c()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {v0, v1}, Le4/d;->e(I)V

    .line 41
    .line 42
    .line 43
    goto :goto_53

    .line 44
    :cond_2b
    invoke-virtual {p0}, Lf4/b;->closeConnection()V
    :try_end_2e
    .catch La4/d; {:try_start_14 .. :try_end_2e} :catch_40
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_14 .. :try_end_2e} :catch_2f

    .line 45
    .line 46
    .line 47
    goto :goto_53

    .line 48
    :catch_2f
    move-exception v0

    .line 49
    invoke-static {v0}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 50
    .line 51
    .line 52
    iget-object v0, p0, Lf4/b;->d:Le4/d;

    .line 53
    .line 54
    iget-object v1, p0, Lf4/b;->a:Le4/h;

    .line 55
    .line 56
    invoke-virtual {v1}, Le4/h;->c()I

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    const/4 v2, 0x3

    .line 61
    invoke-virtual {v0, v1, v2}, Le4/d;->d(II)V

    .line 62
    .line 63
    .line 64
    goto :goto_53

    .line 65
    :catch_40
    move-exception v0

    .line 66
    invoke-static {v0}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 67
    .line 68
    .line 69
    iget-object v1, p0, Lf4/b;->d:Le4/d;

    .line 70
    .line 71
    iget-object v2, p0, Lf4/b;->a:Le4/h;

    .line 72
    .line 73
    invoke-virtual {v2}, Le4/h;->c()I

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    invoke-virtual {v0}, La4/d;->a()I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    invoke-virtual {v1, v2, v0}, Le4/d;->d(II)V

    .line 82
    .line 83
    .line 84
    :goto_53
    return-void
.end method

.method public b(Le4/f;)V
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lf4/b;->a:Le4/h;

    .line 2
    .line 3
    invoke-virtual {v0}, Le4/h;->e()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_12

    .line 8
    .line 9
    iget-object v0, p0, Lf4/b;->a:Le4/h;

    .line 10
    .line 11
    invoke-virtual {p1}, Le4/f;->d()[B

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v0, v1}, Le4/h;->g([B)V

    .line 16
    .line 17
    .line 18
    goto :goto_21

    .line 19
    :cond_12
    iget-object v0, p0, Lf4/b;->d:Le4/d;

    .line 20
    .line 21
    invoke-virtual {v0, p1}, Le4/d;->a(Le4/f;)V
    :try_end_17
    .catch La4/b; {:try_start_0 .. :try_end_17} :catch_18

    .line 22
    .line 23
    .line 24
    goto :goto_21

    .line 25
    :catch_18
    move-exception v0

    .line 26
    invoke-static {v0}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lf4/b;->d:Le4/d;

    .line 30
    .line 31
    invoke-virtual {v0, p1}, Le4/d;->a(Le4/f;)V

    .line 32
    .line 33
    .line 34
    :goto_21
    return-void
.end method

.method public c()Le4/b;
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v1, p0, Lf4/b;->b:Lf4/a;

    .line 6
    .line 7
    if-nez v1, :cond_11

    .line 8
    .line 9
    if-eqz v0, :cond_11

    .line 10
    .line 11
    new-instance v1, Lf4/a;

    .line 12
    .line 13
    invoke-direct {v1, v0, p0}, Lf4/a;-><init>(Landroid/os/Looper;Le4/a;)V

    .line 14
    .line 15
    .line 16
    iput-object v1, p0, Lf4/b;->b:Lf4/a;

    .line 17
    .line 18
    :cond_11
    iget-object v0, p0, Lf4/b;->b:Lf4/a;

    .line 19
    .line 20
    return-object v0
.end method

.method public closeConnection()V
    .registers 2

    iget-object v0, p0, Lf4/b;->a:Le4/h;

    invoke-virtual {v0}, Le4/h;->b()V

    return-void
.end method

.method public final d()Z
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/concurrent/RejectedExecutionException;
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lf4/b;->e:Ljava/util/concurrent/ExecutorService;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_2c

    .line 8
    .line 9
    iget-object v0, p0, Lf4/b;->e:Ljava/util/concurrent/ExecutorService;

    .line 10
    .line 11
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isTerminated()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    goto :goto_2c

    .line 18
    :cond_11
    new-instance v0, Le4/g;

    .line 19
    .line 20
    iget-object v1, p0, Lf4/b;->a:Le4/h;

    .line 21
    .line 22
    invoke-virtual {v1}, Le4/h;->d()Ljava/io/InputStream;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-direct {v0, v1}, Le4/g;-><init>(Ljava/io/InputStream;)V

    .line 27
    .line 28
    .line 29
    new-instance v1, Le4/e;

    .line 30
    .line 31
    iget-object v2, p0, Lf4/b;->a:Le4/h;

    .line 32
    .line 33
    iget-object v3, p0, Lf4/b;->c:Le4/c;

    .line 34
    .line 35
    invoke-direct {v1, v2, v0, v3}, Le4/e;-><init>(Le4/h;Le4/g;Le4/c;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lf4/b;->e:Ljava/util/concurrent/ExecutorService;

    .line 39
    .line 40
    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    .line 41
    .line 42
    .line 43
    const/4 v0, 0x1

    .line 44
    return v0

    .line 45
    :cond_2c
    :goto_2c
    const/4 v0, 0x0

    .line 46
    new-array v1, v0, [Ljava/lang/Object;

    .line 47
    .line 48
    const-string v2, "unable to initPacketReceiver "

    .line 49
    .line 50
    invoke-static {v2, v1}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return v0
.end method

.method public e()V
    .registers 2

    .line 1
    iget-object v0, p0, Lf4/b;->e:Ljava/util/concurrent/ExecutorService;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/os/HandlerThread;->quit()Z

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public onLooperPrepared()V
    .registers 4

    .line 1
    invoke-super {p0}, Landroid/os/HandlerThread;->onLooperPrepared()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Le4/d;

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iget-object v2, p0, Lf4/b;->c:Le4/c;

    .line 11
    .line 12
    invoke-direct {v0, v1, v2}, Le4/d;-><init>(Landroid/os/Looper;Le4/c;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lf4/b;->d:Le4/d;

    .line 16
    .line 17
    return-void
.end method
