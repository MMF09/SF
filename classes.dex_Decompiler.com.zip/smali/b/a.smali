###### Class b.a (b.a)
.class public final Lb/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(I)I
    .registers 1
    .annotation build Landroidx/annotation/FontRes;
    .end annotation

    sget p0, Lf3/e;->a:I

    return p0
.end method
