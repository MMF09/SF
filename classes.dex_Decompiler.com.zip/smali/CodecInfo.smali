###### Class defpackage.CodecInfo (CodecInfo)
.class public final LCodecInfo;
.super Lcom/squareup/wire/Message;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LCodecInfo$Builder;
    }
.end annotation


# static fields
.field public static final DEFAULT_CODEC:Ljava/lang/String; = ""

.field public static final DEFAULT_DECODE:Ljava/lang/Integer;

.field public static final DEFAULT_DECODER_PROFILES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_ENCODE:Ljava/lang/Integer;

.field public static final DEFAULT_ENCODER_PROFILES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_EXTEND_DECODER_CAPABILITIES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_EXTEND_ENCODER_CAPABILITIES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final DEFAULT_MEDIA_TYPE:Ljava/lang/String; = ""

.field private static final serialVersionUID:J


# instance fields
.field public final codec:Ljava/lang/String;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x2
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final decode:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x4
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final decoder_profiles:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        tag = 0x6
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final encode:Ljava/lang/Integer;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x3
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field

.field public final encoder_profiles:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        tag = 0x5
        type = .enum Lcom/squareup/wire/Message$Datatype;->UINT32:Lcom/squareup/wire/Message$Datatype;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final extend_decoder_capabilities:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        tag = 0x8
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final extend_encoder_capabilities:Ljava/util/List;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        label = .enum Lcom/squareup/wire/Message$Label;->REPEATED:Lcom/squareup/wire/Message$Label;
        tag = 0x7
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public final media_type:Ljava/lang/String;
    .annotation runtime Lcom/squareup/wire/ProtoField;
        tag = 0x1
        type = .enum Lcom/squareup/wire/Message$Datatype;->STRING:Lcom/squareup/wire/Message$Datatype;
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    sput-object v0, LCodecInfo;->DEFAULT_ENCODE:Ljava/lang/Integer;

    .line 7
    .line 8
    sput-object v0, LCodecInfo;->DEFAULT_DECODE:Ljava/lang/Integer;

    .line 9
    .line 10
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    sput-object v0, LCodecInfo;->DEFAULT_ENCODER_PROFILES:Ljava/util/List;

    .line 15
    .line 16
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    sput-object v0, LCodecInfo;->DEFAULT_DECODER_PROFILES:Ljava/util/List;

    .line 21
    .line 22
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sput-object v0, LCodecInfo;->DEFAULT_EXTEND_ENCODER_CAPABILITIES:Ljava/util/List;

    .line 27
    .line 28
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    sput-object v0, LCodecInfo;->DEFAULT_EXTEND_DECODER_CAPABILITIES:Ljava/util/List;

    .line 33
    .line 34
    return-void
.end method

.method private constructor <init>(LCodecInfo$Builder;)V
    .registers 11

    .line 11
    iget-object v1, p1, LCodecInfo$Builder;->media_type:Ljava/lang/String;

    iget-object v2, p1, LCodecInfo$Builder;->codec:Ljava/lang/String;

    iget-object v3, p1, LCodecInfo$Builder;->encode:Ljava/lang/Integer;

    iget-object v4, p1, LCodecInfo$Builder;->decode:Ljava/lang/Integer;

    iget-object v5, p1, LCodecInfo$Builder;->encoder_profiles:Ljava/util/List;

    iget-object v6, p1, LCodecInfo$Builder;->decoder_profiles:Ljava/util/List;

    iget-object v7, p1, LCodecInfo$Builder;->extend_encoder_capabilities:Ljava/util/List;

    iget-object v8, p1, LCodecInfo$Builder;->extend_decoder_capabilities:Ljava/util/List;

    move-object v0, p0

    invoke-direct/range {v0 .. v8}, LCodecInfo;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 12
    invoke-virtual {p0, p1}, Lcom/squareup/wire/Message;->setBuilder(Lcom/squareup/wire/Message$Builder;)V

    return-void
.end method

.method public synthetic constructor <init>(LCodecInfo$Builder;LCodecInfo$a;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, LCodecInfo;-><init>(LCodecInfo$Builder;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 2
    invoke-direct {p0}, Lcom/squareup/wire/Message;-><init>()V

    .line 3
    iput-object p1, p0, LCodecInfo;->media_type:Ljava/lang/String;

    .line 4
    iput-object p2, p0, LCodecInfo;->codec:Ljava/lang/String;

    .line 5
    iput-object p3, p0, LCodecInfo;->encode:Ljava/lang/Integer;

    .line 6
    iput-object p4, p0, LCodecInfo;->decode:Ljava/lang/Integer;

    .line 7
    invoke-static {p5}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo;->encoder_profiles:Ljava/util/List;

    .line 8
    invoke-static {p6}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo;->decoder_profiles:Ljava/util/List;

    .line 9
    invoke-static {p7}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo;->extend_encoder_capabilities:Ljava/util/List;

    .line 10
    invoke-static {p8}, Lcom/squareup/wire/Message;->immutableCopyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo;->extend_decoder_capabilities:Ljava/util/List;

    return-void
.end method

.method public static synthetic access$000(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$100(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$200(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$300(Ljava/util/List;)Ljava/util/List;
    .registers 1

    invoke-static {p0}, Lcom/squareup/wire/Message;->copyOf(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, LCodecInfo;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, LCodecInfo;

    .line 12
    .line 13
    iget-object v1, p0, LCodecInfo;->media_type:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v3, p1, LCodecInfo;->media_type:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_5d

    .line 22
    .line 23
    iget-object v1, p0, LCodecInfo;->codec:Ljava/lang/String;

    .line 24
    .line 25
    iget-object v3, p1, LCodecInfo;->codec:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_5d

    .line 32
    .line 33
    iget-object v1, p0, LCodecInfo;->encode:Ljava/lang/Integer;

    .line 34
    .line 35
    iget-object v3, p1, LCodecInfo;->encode:Ljava/lang/Integer;

    .line 36
    .line 37
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    if-eqz v1, :cond_5d

    .line 42
    .line 43
    iget-object v1, p0, LCodecInfo;->decode:Ljava/lang/Integer;

    .line 44
    .line 45
    iget-object v3, p1, LCodecInfo;->decode:Ljava/lang/Integer;

    .line 46
    .line 47
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_5d

    .line 52
    .line 53
    iget-object v1, p0, LCodecInfo;->encoder_profiles:Ljava/util/List;

    .line 54
    .line 55
    iget-object v3, p1, LCodecInfo;->encoder_profiles:Ljava/util/List;

    .line 56
    .line 57
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_5d

    .line 62
    .line 63
    iget-object v1, p0, LCodecInfo;->decoder_profiles:Ljava/util/List;

    .line 64
    .line 65
    iget-object v3, p1, LCodecInfo;->decoder_profiles:Ljava/util/List;

    .line 66
    .line 67
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    if-eqz v1, :cond_5d

    .line 72
    .line 73
    iget-object v1, p0, LCodecInfo;->extend_encoder_capabilities:Ljava/util/List;

    .line 74
    .line 75
    iget-object v3, p1, LCodecInfo;->extend_encoder_capabilities:Ljava/util/List;

    .line 76
    .line 77
    invoke-virtual {p0, v1, v3}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    if-eqz v1, :cond_5d

    .line 82
    .line 83
    iget-object v1, p0, LCodecInfo;->extend_decoder_capabilities:Ljava/util/List;

    .line 84
    .line 85
    iget-object p1, p1, LCodecInfo;->extend_decoder_capabilities:Ljava/util/List;

    .line 86
    .line 87
    invoke-virtual {p0, v1, p1}, Lcom/squareup/wire/Message;->equals(Ljava/util/List;Ljava/util/List;)Z

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    if-eqz p1, :cond_5d

    .line 92
    .line 93
    goto :goto_5e

    .line 94
    :cond_5d
    const/4 v0, 0x0

    .line 95
    :goto_5e
    return v0
.end method

.method public hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 2
    .line 3
    if-nez v0, :cond_69

    .line 4
    .line 5
    iget-object v0, p0, LCodecInfo;->media_type:Ljava/lang/String;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 v0, 0x0

    .line 16
    :goto_f
    mul-int/lit8 v0, v0, 0x25

    .line 17
    .line 18
    iget-object v2, p0, LCodecInfo;->codec:Ljava/lang/String;

    .line 19
    .line 20
    if-eqz v2, :cond_1a

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x0

    .line 28
    :goto_1b
    add-int/2addr v0, v2

    .line 29
    mul-int/lit8 v0, v0, 0x25

    .line 30
    .line 31
    iget-object v2, p0, LCodecInfo;->encode:Ljava/lang/Integer;

    .line 32
    .line 33
    if-eqz v2, :cond_27

    .line 34
    .line 35
    invoke-virtual {v2}, Ljava/lang/Integer;->hashCode()I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    const/4 v2, 0x0

    .line 41
    :goto_28
    add-int/2addr v0, v2

    .line 42
    mul-int/lit8 v0, v0, 0x25

    .line 43
    .line 44
    iget-object v2, p0, LCodecInfo;->decode:Ljava/lang/Integer;

    .line 45
    .line 46
    if-eqz v2, :cond_33

    .line 47
    .line 48
    invoke-virtual {v2}, Ljava/lang/Integer;->hashCode()I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    :cond_33
    add-int/2addr v0, v1

    .line 53
    mul-int/lit8 v0, v0, 0x25

    .line 54
    .line 55
    iget-object v1, p0, LCodecInfo;->encoder_profiles:Ljava/util/List;

    .line 56
    .line 57
    const/4 v2, 0x1

    .line 58
    if-eqz v1, :cond_40

    .line 59
    .line 60
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    goto :goto_41

    .line 65
    :cond_40
    const/4 v1, 0x1

    .line 66
    :goto_41
    add-int/2addr v0, v1

    .line 67
    mul-int/lit8 v0, v0, 0x25

    .line 68
    .line 69
    iget-object v1, p0, LCodecInfo;->decoder_profiles:Ljava/util/List;

    .line 70
    .line 71
    if-eqz v1, :cond_4d

    .line 72
    .line 73
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 74
    .line 75
    .line 76
    move-result v1

    .line 77
    goto :goto_4e

    .line 78
    :cond_4d
    const/4 v1, 0x1

    .line 79
    :goto_4e
    add-int/2addr v0, v1

    .line 80
    mul-int/lit8 v0, v0, 0x25

    .line 81
    .line 82
    iget-object v1, p0, LCodecInfo;->extend_encoder_capabilities:Ljava/util/List;

    .line 83
    .line 84
    if-eqz v1, :cond_5a

    .line 85
    .line 86
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    goto :goto_5b

    .line 91
    :cond_5a
    const/4 v1, 0x1

    .line 92
    :goto_5b
    add-int/2addr v0, v1

    .line 93
    mul-int/lit8 v0, v0, 0x25

    .line 94
    .line 95
    iget-object v1, p0, LCodecInfo;->extend_decoder_capabilities:Ljava/util/List;

    .line 96
    .line 97
    if-eqz v1, :cond_66

    .line 98
    .line 99
    invoke-interface {v1}, Ljava/util/List;->hashCode()I

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    :cond_66
    add-int/2addr v0, v2

    .line 104
    iput v0, p0, Lcom/squareup/wire/Message;->hashCode:I

    .line 105
    .line 106
    :cond_69
    return v0
.end method

###### Class CodecInfo.Builder (CodecInfo$Builder)
.class public final LCodecInfo$Builder;
.super Lcom/squareup/wire/Message$Builder;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCodecInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/squareup/wire/Message$Builder<",
        "LCodecInfo;",
        ">;"
    }
.end annotation


# instance fields
.field public codec:Ljava/lang/String;

.field public decode:Ljava/lang/Integer;

.field public decoder_profiles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public encode:Ljava/lang/Integer;

.field public encoder_profiles:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public extend_decoder_capabilities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public extend_encoder_capabilities:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public media_type:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lcom/squareup/wire/Message$Builder;-><init>()V

    return-void
.end method

.method public constructor <init>(LCodecInfo;)V
    .registers 3

    .line 2
    invoke-direct {p0, p1}, Lcom/squareup/wire/Message$Builder;-><init>(Lcom/squareup/wire/Message;)V

    if-nez p1, :cond_6

    return-void

    .line 3
    :cond_6
    iget-object v0, p1, LCodecInfo;->media_type:Ljava/lang/String;

    iput-object v0, p0, LCodecInfo$Builder;->media_type:Ljava/lang/String;

    .line 4
    iget-object v0, p1, LCodecInfo;->codec:Ljava/lang/String;

    iput-object v0, p0, LCodecInfo$Builder;->codec:Ljava/lang/String;

    .line 5
    iget-object v0, p1, LCodecInfo;->encode:Ljava/lang/Integer;

    iput-object v0, p0, LCodecInfo$Builder;->encode:Ljava/lang/Integer;

    .line 6
    iget-object v0, p1, LCodecInfo;->decode:Ljava/lang/Integer;

    iput-object v0, p0, LCodecInfo$Builder;->decode:Ljava/lang/Integer;

    .line 7
    iget-object v0, p1, LCodecInfo;->encoder_profiles:Ljava/util/List;

    invoke-static {v0}, LCodecInfo;->access$000(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LCodecInfo$Builder;->encoder_profiles:Ljava/util/List;

    .line 8
    iget-object v0, p1, LCodecInfo;->decoder_profiles:Ljava/util/List;

    invoke-static {v0}, LCodecInfo;->access$100(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LCodecInfo$Builder;->decoder_profiles:Ljava/util/List;

    .line 9
    iget-object v0, p1, LCodecInfo;->extend_encoder_capabilities:Ljava/util/List;

    invoke-static {v0}, LCodecInfo;->access$200(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, LCodecInfo$Builder;->extend_encoder_capabilities:Ljava/util/List;

    .line 10
    iget-object p1, p1, LCodecInfo;->extend_decoder_capabilities:Ljava/util/List;

    invoke-static {p1}, LCodecInfo;->access$300(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo$Builder;->extend_decoder_capabilities:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public build()LCodecInfo;
    .registers 3

    .line 2
    new-instance v0, LCodecInfo;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, LCodecInfo;-><init>(LCodecInfo$Builder;LCodecInfo$a;)V

    return-object v0
.end method

.method public bridge synthetic build()Lcom/squareup/wire/Message;
    .registers 2

    .line 1
    invoke-virtual {p0}, LCodecInfo$Builder;->build()LCodecInfo;

    move-result-object v0

    return-object v0
.end method

.method public codec(Ljava/lang/String;)LCodecInfo$Builder;
    .registers 2

    iput-object p1, p0, LCodecInfo$Builder;->codec:Ljava/lang/String;

    return-object p0
.end method

.method public decode(Ljava/lang/Integer;)LCodecInfo$Builder;
    .registers 2

    iput-object p1, p0, LCodecInfo$Builder;->decode:Ljava/lang/Integer;

    return-object p0
.end method

.method public decoder_profiles(Ljava/util/List;)LCodecInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)",
            "LCodecInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo$Builder;->decoder_profiles:Ljava/util/List;

    return-object p0
.end method

.method public encode(Ljava/lang/Integer;)LCodecInfo$Builder;
    .registers 2

    iput-object p1, p0, LCodecInfo$Builder;->encode:Ljava/lang/Integer;

    return-object p0
.end method

.method public encoder_profiles(Ljava/util/List;)LCodecInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)",
            "LCodecInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo$Builder;->encoder_profiles:Ljava/util/List;

    return-object p0
.end method

.method public extend_decoder_capabilities(Ljava/util/List;)LCodecInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "LCodecInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo$Builder;->extend_decoder_capabilities:Ljava/util/List;

    return-object p0
.end method

.method public extend_encoder_capabilities(Ljava/util/List;)LCodecInfo$Builder;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "LCodecInfo$Builder;"
        }
    .end annotation

    invoke-static {p1}, Lcom/squareup/wire/Message$Builder;->checkForNulls(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, LCodecInfo$Builder;->extend_encoder_capabilities:Ljava/util/List;

    return-object p0
.end method

.method public media_type(Ljava/lang/String;)LCodecInfo$Builder;
    .registers 2

    iput-object p1, p0, LCodecInfo$Builder;->media_type:Ljava/lang/String;

    return-object p0
.end method

###### Class CodecInfo.a (CodecInfo$a)
.class public synthetic LCodecInfo$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LCodecInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation
