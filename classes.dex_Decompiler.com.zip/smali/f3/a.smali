###### Class f3.a (f3.a)
.class public final Lf3/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Lkotlin/Metadata;
    bv = {}
    d1 = {
        "\u0000J\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0008\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0008\u0008\u001a3\u0010\u0008\u001a\u00020\u0007\"\u0008\u0008\u0000\u0010\u0001*\u00020\u00002\u0006\u0010\u0002\u001a\u00028\u00002\u0006\u0010\u0004\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0005H\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\t\u001a \u0010\u000e\u001a\u00020\r2\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00052\u0008\u0010\u000c\u001a\u0004\u0018\u00010\u000b\u001a&\u0010\u0014\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0004\u0012\u00020\u00050\u00132\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0012\u001a\u00020\u0011H\u0001\u001a&\u0010\u0018\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0004\u0012\u00020\u00050\u00132\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0005H\u0002\u001a\u0010\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u0015H\u0003\u001a1\u0010\u001c\u001a\u00020\u0007\"\u0008\u0008\u0000\u0010\u0001*\u00020\u00002\u0006\u0010\u0002\u001a\u00028\u00002\u0006\u0010\u001a\u001a\u00020\u00032\u0006\u0010\u001b\u001a\u00020\u0003H\u0002\u00a2\u0006\u0004\u0008\u001c\u0010\u001d\u001a)\u0010 \u001a\u00020\u0007\"\u0008\u0008\u0000\u0010\u0001*\u00020\u00002\u0006\u0010\u0002\u001a\u00028\u00002\u0006\u0010\u001f\u001a\u00020\u001eH\u0000\u00a2\u0006\u0004\u0008 \u0010!\u001a)\u0010\"\u001a\u00020\u0007\"\u0008\u0008\u0000\u0010\u0001*\u00020\u00002\u0006\u0010\u0002\u001a\u00028\u00002\u0006\u0010\u001f\u001a\u00020\u001eH\u0000\u00a2\u0006\u0004\u0008\"\u0010!\"\u0014\u0010#\u001a\u00020\u00058\u0002X\u0082T\u00a2\u0006\u0006\n\u0004\u0008#\u0010$\"\u0014\u0010%\u001a\u00020\u00058\u0000X\u0080T\u00a2\u0006\u0006\n\u0004\u0008%\u0010$\u00a8\u0006&"
    }
    d2 = {
        "",
        "T",
        "invoker",
        "",
        "landingUrl",
        "",
        "requestCode",
        "",
        "d",
        "(Ljava/lang/Object;Ljava/lang/String;I)V",
        "resultCode",
        "Landroid/content/Intent;",
        "data",
        "Lm3/a;",
        "e",
        "Landroid/app/Activity;",
        "activity",
        "",
        "isForLinking",
        "Lkotlin/Pair;",
        "c",
        "Landroid/content/pm/PackageManager;",
        "pm",
        "airPayVersion",
        "findLinkingGateway",
        "getAirPayAppVersion",
        "merchantId",
        "userId",
        "link",
        "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V",
        "Lcom/airpay/sdk/v2/data/PaymentRequest;",
        "request",
        "payInAirPay",
        "(Ljava/lang/Object;Lcom/airpay/sdk/v2/data/PaymentRequest;)V",
        "payInAirPayDirectly",
        "INVALID_AIRPAY_VERSION",
        "I",
        "SDK_REQUEST_CODE",
        "sdk_merchantVnRelease"
    }
    k = 0x2
    mv = {
        0x1,
        0x4,
        0x0
    }
.end annotation

.annotation build Lkotlin/jvm/JvmName;
    name = "AirPaySdk"
.end annotation


# direct methods
.method public static final a(Landroid/content/pm/PackageManager;)I
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PackageManagerGetSignatures",
            "WrongConstant"
        }
    .end annotation

    .line 1
    const-string v0, "com.beeasy.toppay"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p0, v0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    iget v2, v2, Landroid/content/pm/PackageInfo;->versionCode:I

    .line 9
    .line 10
    const/16 v3, 0x40

    .line 11
    .line 12
    invoke-virtual {p0, v0, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 17
    .line 18
    const-string v0, "pm.getPackageInfo(PACKAG\u2026ET_SIGNATURES).signatures"

    .line 19
    .line 20
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkExpressionValueIsNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    array-length v0, p0

    .line 24
    :goto_17
    if-ge v1, v0, :cond_28

    .line 25
    .line 26
    aget-object v3, p0, v1

    .line 27
    .line 28
    invoke-virtual {v3}, Landroid/content/pm/Signature;->hashCode()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    const v4, 0x39e3e6a1

    .line 33
    .line 34
    .line 35
    if-ne v3, v4, :cond_25

    .line 36
    .line 37
    return v2

    .line 38
    :cond_25
    add-int/lit8 v1, v1, 0x1

    .line 39
    .line 40
    goto :goto_17

    .line 41
    :cond_28
    const p0, 0xffff

    .line 42
    .line 43
    .line 44
    return p0
.end method

.method public static final b(Landroid/content/pm/PackageManager;I)Lkotlin/Pair;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/pm/PackageManager;",
            "I)",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance p1, Landroid/content/Intent;

    .line 2
    .line 3
    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v0, "airpay.app.gateway.ACTION.LINKING"

    .line 7
    .line 8
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 9
    .line 10
    .line 11
    const/high16 v0, 0x10000

    .line 12
    .line 13
    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    if-eqz p0, :cond_4a

    .line 18
    .line 19
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    if-nez p1, :cond_19

    .line 24
    .line 25
    goto :goto_4a

    .line 26
    :cond_19
    sget-object v0, Lk3/a;->c:Lk3/a;

    .line 27
    .line 28
    const/4 p1, 0x0

    .line 29
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, Landroid/content/pm/ResolveInfo;

    .line 34
    .line 35
    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    .line 36
    .line 37
    iget-object v4, v1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    const/4 v2, 0x0

    .line 41
    const/4 v3, 0x0

    .line 42
    const/4 v5, 0x0

    .line 43
    const/16 v6, 0x17

    .line 44
    .line 45
    const/4 v7, 0x0

    .line 46
    invoke-static/range {v0 .. v7}, Lk3/a;->e(Lk3/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    sget-object v0, Lk3/c;->a:Lk3/c$a;

    .line 50
    .line 51
    const-string v1, "AirPaySdk.findLinkingGateway() - RESULT_SUCCESS"

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    check-cast p0, Landroid/content/pm/ResolveInfo;

    .line 61
    .line 62
    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    .line 63
    .line 64
    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-static {p0, p1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    goto :goto_5b

    .line 75
    :cond_4a
    :goto_4a
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 76
    .line 77
    const-string p1, "AirPaySdk.findLinkingGateway() - ERROR_AIRPAY_APP_VERSION_TOO_LOW"

    .line 78
    .line 79
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    const/4 p0, 0x3

    .line 83
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    const/4 p1, 0x0

    .line 88
    invoke-static {p1, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    :goto_5b
    return-object p0
.end method

.method public static final c(Landroid/app/Activity;Z)Lkotlin/Pair;
    .registers 5
    .param p0    # Landroid/app/Activity;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PackageManagerGetSignatures"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "Z)",
            "Lkotlin/Pair<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    const-string v0, "activity.applicationContext"

    .line 6
    .line 7
    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkExpressionValueIsNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    const/4 v0, 0x0

    .line 15
    :try_start_e
    const-string v1, "pm"

    .line 16
    .line 17
    invoke-static {p0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkExpressionValueIsNotNull(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-static {p0}, Lf3/a;->a(Landroid/content/pm/PackageManager;)I

    .line 21
    .line 22
    .line 23
    move-result v1
    :try_end_17
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_e .. :try_end_17} :catch_45

    .line 24
    const v2, 0xffff

    .line 25
    .line 26
    .line 27
    if-ne v1, v2, :cond_2d

    .line 28
    .line 29
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 30
    .line 31
    const-string p1, "AirPaySdk.findAirPayApp() - ERROR_AIRPAY_SIGNATURE_INVALID"

    .line 32
    .line 33
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const/4 p0, 0x6

    .line 37
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-static {v0, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :cond_2d
    if-eqz p1, :cond_34

    .line 47
    .line 48
    invoke-static {p0, v1}, Lf3/a;->b(Landroid/content/pm/PackageManager;I)Lkotlin/Pair;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :cond_34
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 54
    .line 55
    const-string p1, "AirPaySdk.findAirPayApp() - RESULT_SUCCESS"

    .line 56
    .line 57
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    const/4 p0, 0x0

    .line 61
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    invoke-static {v0, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    return-object p0

    .line 70
    :catch_45
    move-exception p0

    .line 71
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 72
    .line 73
    .line 74
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 75
    .line 76
    const-string p1, "AirPaySdk.findAirPayApp() - ERROR_AIRPAY_APP_NOT_INSTALLED"

    .line 77
    .line 78
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    const/4 p0, 0x2

    .line 82
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    invoke-static {v0, p0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0
.end method

.method public static final d(Ljava/lang/Object;Ljava/lang/String;I)V
    .registers 22
    .param p0    # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .annotation build Lkotlin/jvm/JvmOverloads;
    .end annotation

    .line 1
    invoke-static/range {p0 .. p0}, Lk3/b;->a(Ljava/lang/Object;)Landroid/app/Activity;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lk3/a;->c:Lk3/a;

    .line 6
    .line 7
    if-nez v0, :cond_b

    .line 8
    .line 9
    invoke-static {}, Lkotlin/jvm/internal/Intrinsics;->throwNpe()V

    .line 10
    .line 11
    .line 12
    :cond_b
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    const/4 v3, 0x0

    .line 21
    const/4 v4, 0x0

    .line 22
    const/4 v5, 0x0

    .line 23
    const/16 v7, 0xe

    .line 24
    .line 25
    const/4 v8, 0x0

    .line 26
    invoke-static/range {v1 .. v8}, Lk3/a;->e(Lk3/a;Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;ILjava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    new-instance v0, Lg3/f;

    .line 30
    .line 31
    const/4 v11, 0x0

    .line 32
    const/4 v12, 0x0

    .line 33
    const/4 v13, 0x0

    .line 34
    const/4 v14, 0x0

    .line 35
    const/4 v15, 0x0

    .line 36
    const/16 v16, 0x0

    .line 37
    .line 38
    const/16 v17, 0x7e

    .line 39
    .line 40
    const/16 v18, 0x0

    .line 41
    .line 42
    move-object v9, v0

    .line 43
    move-object/from16 v10, p1

    .line 44
    .line 45
    invoke-direct/range {v9 .. v18}, Lg3/f;-><init>(Ljava/lang/String;Ljava/lang/String;ILl3/a;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 46
    .line 47
    .line 48
    move-object/from16 v1, p0

    .line 49
    .line 50
    invoke-static {v1, v0}, Lf3/a;->g(Ljava/lang/Object;Lg3/f;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public static final e(IILandroid/content/Intent;)Lm3/a;
    .registers 7
    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Lk3/a;->c:Lk3/a;

    .line 2
    .line 3
    invoke-virtual {v0}, Lk3/a;->i()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x5

    .line 9
    if-eq p0, v1, :cond_1b

    .line 10
    .line 11
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 12
    .line 13
    const-string p1, "parsePaymentResult(): ERROR_NOT_AN_AIRPAY_REQUEST"

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    new-instance p0, Lm3/a;

    .line 19
    .line 20
    invoke-virtual {v0, v3}, Lk3/a;->g(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-direct {p0, v3, v2, p1}, Lm3/a;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_1b
    if-eqz p2, :cond_49

    .line 29
    .line 30
    const-string p0, "order_staus"

    .line 31
    .line 32
    invoke-virtual {p2, p0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_49

    .line 37
    .line 38
    const/4 v1, -0x1

    .line 39
    if-eq p1, v1, :cond_29

    .line 40
    .line 41
    goto :goto_49

    .line 42
    :cond_29
    invoke-virtual {p2, p0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    const-string p1, "air_pay_merchant_order_id"

    .line 47
    .line 48
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    const-string v1, "error_msg"

    .line 53
    .line 54
    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_43

    .line 63
    .line 64
    invoke-virtual {v0, p0}, Lk3/a;->g(I)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    :cond_43
    new-instance v0, Lm3/a;

    .line 69
    .line 70
    invoke-direct {v0, p0, p1, p2}, Lm3/a;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    return-object v0

    .line 74
    :cond_49
    :goto_49
    sget-object p0, Lk3/c;->a:Lk3/c$a;

    .line 75
    .line 76
    const-string p1, "parsePaymentResult(): BAD INTENT"

    .line 77
    .line 78
    invoke-virtual {p0, p1}, Lk3/c$a;->a(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    new-instance p0, Lm3/a;

    .line 82
    .line 83
    invoke-virtual {v0, v3}, Lk3/a;->g(I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-direct {p0, v3, v2, p1}, Lm3/a;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    return-object p0
.end method

.method public static final f(Ljava/lang/Object;Lg3/f;)V
    .registers 14
    .param p0    # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # Lg3/f;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lg3/f;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lk3/b;->a(Ljava/lang/Object;)Landroid/app/Activity;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_9

    .line 6
    .line 7
    invoke-static {}, Lkotlin/jvm/internal/Intrinsics;->throwNpe()V

    .line 8
    .line 9
    .line 10
    :cond_9
    const/4 v1, 0x1

    .line 11
    invoke-static {v0, v1}, Lf3/a;->c(Landroid/app/Activity;Z)Lkotlin/Pair;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v1}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ljava/lang/Number;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_55

    .line 26
    .line 27
    const/4 v0, 0x2

    .line 28
    if-eq v1, v0, :cond_3b

    .line 29
    .line 30
    const/4 v0, 0x3

    .line 31
    if-eq v1, v0, :cond_21

    .line 32
    .line 33
    goto :goto_5a

    .line 34
    :cond_21
    new-instance v0, Lg3/f;

    .line 35
    .line 36
    invoke-virtual {p1}, Lg3/f;->c()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    const/4 v4, 0x0

    .line 41
    const/4 v5, 0x0

    .line 42
    const/4 v6, 0x0

    .line 43
    const/4 v7, 0x0

    .line 44
    const/4 v8, 0x0

    .line 45
    const/16 v9, 0x1002

    .line 46
    .line 47
    const/16 v10, 0x3e

    .line 48
    .line 49
    const/4 v11, 0x0

    .line 50
    move-object v2, v0

    .line 51
    invoke-direct/range {v2 .. v11}, Lg3/f;-><init>(Ljava/lang/String;Ljava/lang/String;ILl3/a;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 52
    .line 53
    .line 54
    sget-object p1, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity;->n:Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;

    .line 55
    .line 56
    invoke-virtual {p1, p0, v0}, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;->a(Ljava/lang/Object;Lg3/h;)V

    .line 57
    .line 58
    .line 59
    goto :goto_5a

    .line 60
    :cond_3b
    new-instance v0, Lg3/f;

    .line 61
    .line 62
    invoke-virtual {p1}, Lg3/f;->c()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    const/4 v3, 0x0

    .line 67
    const/4 v4, 0x0

    .line 68
    const/4 v5, 0x0

    .line 69
    const/4 v6, 0x0

    .line 70
    const/4 v7, 0x0

    .line 71
    const/16 v8, 0x1001

    .line 72
    .line 73
    const/16 v9, 0x3e

    .line 74
    .line 75
    const/4 v10, 0x0

    .line 76
    move-object v1, v0

    .line 77
    invoke-direct/range {v1 .. v10}, Lg3/f;-><init>(Ljava/lang/String;Ljava/lang/String;ILl3/a;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 78
    .line 79
    .line 80
    sget-object p1, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity;->n:Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;

    .line 81
    .line 82
    invoke-virtual {p1, p0, v0}, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;->a(Ljava/lang/Object;Lg3/h;)V

    .line 83
    .line 84
    .line 85
    goto :goto_5a

    .line 86
    :cond_55
    sget-object p0, Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity;->c:Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity$a;

    .line 87
    .line 88
    invoke-virtual {p0, v0, p1}, Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity$a;->a(Landroid/app/Activity;Lg3/h;)V

    .line 89
    .line 90
    .line 91
    :goto_5a
    return-void
.end method

.method public static final g(Ljava/lang/Object;Lg3/f;)V
    .registers 14
    .param p0    # Ljava/lang/Object;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .param p1    # Lg3/f;
        .annotation build Lorg/jetbrains/annotations/NotNull;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lg3/f;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lk3/b;->a(Ljava/lang/Object;)Landroid/app/Activity;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_9

    .line 6
    .line 7
    invoke-static {}, Lkotlin/jvm/internal/Intrinsics;->throwNpe()V

    .line 8
    .line 9
    .line 10
    :cond_9
    const/4 v1, 0x1

    .line 11
    invoke-static {v0, v1}, Lf3/a;->c(Landroid/app/Activity;Z)Lkotlin/Pair;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Ljava/lang/Number;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_55

    .line 26
    .line 27
    const/4 v1, 0x2

    .line 28
    if-eq v0, v1, :cond_3b

    .line 29
    .line 30
    const/4 v1, 0x3

    .line 31
    if-eq v0, v1, :cond_21

    .line 32
    .line 33
    goto :goto_5a

    .line 34
    :cond_21
    new-instance v0, Lg3/f;

    .line 35
    .line 36
    invoke-virtual {p1}, Lg3/f;->c()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    const/4 v4, 0x0

    .line 41
    const/4 v5, 0x0

    .line 42
    const/4 v6, 0x0

    .line 43
    const/4 v7, 0x0

    .line 44
    const/4 v8, 0x0

    .line 45
    const/16 v9, 0x1002

    .line 46
    .line 47
    const/16 v10, 0x3e

    .line 48
    .line 49
    const/4 v11, 0x0

    .line 50
    move-object v2, v0

    .line 51
    invoke-direct/range {v2 .. v11}, Lg3/f;-><init>(Ljava/lang/String;Ljava/lang/String;ILl3/a;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 52
    .line 53
    .line 54
    sget-object p1, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity;->n:Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;

    .line 55
    .line 56
    invoke-virtual {p1, p0, v0}, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;->b(Ljava/lang/Object;Lg3/h;)V

    .line 57
    .line 58
    .line 59
    goto :goto_5a

    .line 60
    :cond_3b
    new-instance v0, Lg3/f;

    .line 61
    .line 62
    invoke-virtual {p1}, Lg3/f;->c()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    const/4 v3, 0x0

    .line 67
    const/4 v4, 0x0

    .line 68
    const/4 v5, 0x0

    .line 69
    const/4 v6, 0x0

    .line 70
    const/4 v7, 0x0

    .line 71
    const/16 v8, 0x1001

    .line 72
    .line 73
    const/16 v9, 0x3e

    .line 74
    .line 75
    const/4 v10, 0x0

    .line 76
    move-object v1, v0

    .line 77
    invoke-direct/range {v1 .. v10}, Lg3/f;-><init>(Ljava/lang/String;Ljava/lang/String;ILl3/a;Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 78
    .line 79
    .line 80
    sget-object p1, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity;->n:Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;

    .line 81
    .line 82
    invoke-virtual {p1, p0, v0}, Lcom/airpay/sdk/v2/activity/AirPayInstallationActivity$b;->b(Ljava/lang/Object;Lg3/h;)V

    .line 83
    .line 84
    .line 85
    goto :goto_5a

    .line 86
    :cond_55
    sget-object v0, Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity;->c:Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity$a;

    .line 87
    .line 88
    invoke-virtual {v0, p0, p1}, Lcom/airpay/sdk/v2/activity/MerchantGatewayActivity$a;->b(Ljava/lang/Object;Lg3/h;)V

    .line 89
    .line 90
    .line 91
    :goto_5a
    return-void
.end method
