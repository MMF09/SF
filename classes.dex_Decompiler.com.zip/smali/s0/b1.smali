###### Class s0.b1 (s0.b1)
.class public final synthetic Ls0/b1;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;)Landroid/widget/RemoteViews;
    .registers 1

    invoke-virtual {p0}, Landroid/app/Notification$Builder;->createBigContentView()Landroid/widget/RemoteViews;

    move-result-object p0

    return-object p0
.end method
