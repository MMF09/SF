###### Class s0.x0 (s0.x0)
.class public final synthetic Ls0/x0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$BigPictureStyle;Z)Landroid/app/Notification$BigPictureStyle;
    .registers 2

    invoke-virtual {p0, p1}, Landroid/app/Notification$BigPictureStyle;->showBigPictureWhenCollapsed(Z)Landroid/app/Notification$BigPictureStyle;

    move-result-object p0

    return-object p0
.end method
