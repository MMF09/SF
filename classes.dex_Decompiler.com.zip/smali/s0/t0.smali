###### Class s0.t0 (s0.t0)
.class public final synthetic Ls0/t0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteInput;)I
    .registers 1

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getEditChoicesBeforeSending()I

    move-result p0

    return p0
.end method
