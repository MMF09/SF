###### Class s0.o2 (s0.o2)
.class public final synthetic Ls0/o2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/os/PersistableBundle;Ljava/lang/String;)Z
    .registers 2

    invoke-virtual {p0, p1}, Landroid/os/PersistableBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method
