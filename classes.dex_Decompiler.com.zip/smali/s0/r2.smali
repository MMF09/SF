###### Class s0.r2 (s0.r2)
.class public final synthetic Ls0/r2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteInput;Landroid/content/Intent;Ljava/util/Map;)V
    .registers 3

    invoke-static {p0, p1, p2}, Landroid/app/RemoteInput;->addDataResultToIntent(Landroid/app/RemoteInput;Landroid/content/Intent;Ljava/util/Map;)V

    return-void
.end method
