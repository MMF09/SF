###### Class s0.g (s0.g)
.class public final synthetic Ls0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/content/ContextWrapper;)Landroid/view/Display;
    .registers 1

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getDisplay()Landroid/view/Display;

    move-result-object p0

    return-object p0
.end method
