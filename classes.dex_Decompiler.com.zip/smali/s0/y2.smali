###### Class s0.y2 (s0.y2)
.class public final synthetic Ls0/y2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/Service;I)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/app/Service;->stopForeground(I)V

    return-void
.end method
