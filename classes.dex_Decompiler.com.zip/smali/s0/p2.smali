###### Class s0.p2 (s0.p2)
.class public final synthetic Ls0/p2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteAction;)Z
    .registers 1

    invoke-virtual {p0}, Landroid/app/RemoteAction;->shouldShowIcon()Z

    move-result p0

    return p0
.end method
