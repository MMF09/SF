###### Class s0.v (s0.v)
.class public final synthetic Ls0/v;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/view/Window;Landroid/view/Window$OnFrameMetricsAvailableListener;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/view/Window;->removeOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;)V

    return-void
.end method
