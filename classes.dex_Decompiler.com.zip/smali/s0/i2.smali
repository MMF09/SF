###### Class s0.i2 (s0.i2)
.class public final synthetic Ls0/i2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationManager;Landroid/app/NotificationChannelGroup;)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/app/NotificationManager;->createNotificationChannelGroup(Landroid/app/NotificationChannelGroup;)V

    return-void
.end method
