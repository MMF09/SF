###### Class s0.p0 (s0.p0)
.class public final synthetic Ls0/p0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)Landroid/app/Notification$BubbleMetadata;
    .registers 1

    invoke-virtual {p0}, Landroid/app/Notification;->getBubbleMetadata()Landroid/app/Notification$BubbleMetadata;

    move-result-object p0

    return-object p0
.end method
