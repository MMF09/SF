###### Class s0.a1 (s0.a1)
.class public final synthetic Ls0/a1;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$BubbleMetadata;)Ljava/lang/String;
    .registers 1

    invoke-virtual {p0}, Landroid/app/Notification$BubbleMetadata;->getShortcutId()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
