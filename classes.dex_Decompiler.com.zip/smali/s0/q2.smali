###### Class s0.q2 (s0.q2)
.class public final synthetic Ls0/q2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteAction;Z)V
    .registers 2

    invoke-virtual {p0, p1}, Landroid/app/RemoteAction;->setShouldShowIcon(Z)V

    return-void
.end method
