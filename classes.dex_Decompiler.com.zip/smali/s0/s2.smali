###### Class s0.s2 (s0.s2)
.class public final synthetic Ls0/s2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteInput;)Ljava/util/Set;
    .registers 1

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getAllowedDataTypes()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method
