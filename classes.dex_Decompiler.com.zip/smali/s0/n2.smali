###### Class s0.n2 (s0.n2)
.class public final synthetic Ls0/n2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/os/PersistableBundle;Ljava/lang/String;Z)V
    .registers 3

    invoke-virtual {p0, p1, p2}, Landroid/os/PersistableBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method
