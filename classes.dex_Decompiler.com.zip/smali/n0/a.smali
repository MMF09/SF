###### Class n0.a (n0.a)
.class public final synthetic Ln0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroidx/camera/video/internal/compat/quirk/VideoQualityQuirk;)Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method
