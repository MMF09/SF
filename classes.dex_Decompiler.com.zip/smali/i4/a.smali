###### Class i4.a (i4.a)
.class public final Li4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lm4/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lm4/g<",
        "Ljava/nio/ByteBuffer;",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# instance fields
.field public final a:Lq4/d;


# direct methods
.method public constructor <init>(Lq4/d;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Lk5/k;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    check-cast p1, Lq4/d;

    .line 9
    .line 10
    iput-object p1, p0, Li4/a;->a:Lq4/d;

    .line 11
    .line 12
    sget p1, Lh4/d;->m:I

    .line 13
    .line 14
    if-lez p1, :cond_2d

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    :try_start_10
    invoke-static {v0, p1}, Lorg/aomedia/avif/android/AvifDecoder;->decodeThreadPriority(ZI)V
    :try_end_13
    .catchall {:try_start_10 .. :try_end_13} :catchall_14

    .line 18
    .line 19
    .line 20
    goto :goto_2d

    .line 21
    :catchall_14
    move-exception v0

    .line 22
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 25
    .line 26
    .line 27
    const-string v2, "[AVIF Thread] setThreadPriority Exception:"

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    :cond_2d
    :goto_2d
    new-instance v0, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 49
    .line 50
    .line 51
    const-string v1, "[AVIF Thread] setThreadPriority:"

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-static {p1}, Lh4/d;->a(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;IILm4/f;)Lp4/l;
    .registers 5
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p1, Ljava/nio/ByteBuffer;

    invoke-virtual {p0, p1, p2, p3, p4}, Li4/a;->c(Ljava/nio/ByteBuffer;IILm4/f;)Lp4/l;

    move-result-object p1

    return-object p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;Lm4/f;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    check-cast p1, Ljava/nio/ByteBuffer;

    invoke-virtual {p0, p1, p2}, Li4/a;->d(Ljava/nio/ByteBuffer;Lm4/f;)Z

    move-result p1

    return p1
.end method

.method public c(Ljava/nio/ByteBuffer;IILm4/f;)Lp4/l;
    .registers 32
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/nio/ByteBuffer;",
            "II",
            "Lm4/f;",
            ")",
            "Lp4/l<",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v10, p2

    .line 4
    .line 5
    move/from16 v11, p3

    .line 6
    .line 7
    move-object/from16 v0, p4

    .line 8
    .line 9
    const-string v12, ""

    .line 10
    .line 11
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 12
    .line 13
    .line 14
    move-result-wide v13

    .line 15
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    invoke-virtual {v2}, Lh4/l;->b()Lm4/e;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-virtual {v0, v2}, Lm4/f;->a(Lm4/e;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    move-object v15, v2

    .line 28
    check-cast v15, Ljava/lang/String;

    .line 29
    .line 30
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-virtual {v2}, Lh4/l;->a()Lm4/e;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v0, v2}, Lm4/f;->a(Lm4/e;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    move-object/from16 v16, v2

    .line 43
    .line 44
    check-cast v16, Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {v2}, Lh4/l;->d()Lb90/b;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-interface {v2}, Lb90/b;->l()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    check-cast v2, Lm4/e;

    .line 59
    .line 60
    invoke-virtual {v0, v2}, Lm4/f;->a(Lm4/e;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v9

    .line 64
    new-instance v0, Ljava/lang/StringBuilder;

    .line 65
    .line 66
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 67
    .line 68
    .line 69
    const-string v2, "[Decode] AvifByteBufferBitmapDecoder decode: Begin"

    .line 70
    .line 71
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 75
    .line 76
    .line 77
    move-result-wide v2

    .line 78
    sub-long/2addr v2, v13

    .line 79
    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const-string v2, "ms inputSize:"

    .line 83
    .line 84
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    const-string v8, "-"

    .line 91
    .line 92
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual/range {p0 .. p1}, Li4/a;->e(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    new-instance v7, Lorg/aomedia/avif/android/AvifDecoder$Info;

    .line 110
    .line 111
    invoke-direct {v7}, Lorg/aomedia/avif/android/AvifDecoder$Info;-><init>()V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    .line 115
    .line 116
    .line 117
    move-result v3

    .line 118
    invoke-static {v0, v3, v7}, Lorg/aomedia/avif/android/AvifDecoder;->getInfo(Ljava/nio/ByteBuffer;ILorg/aomedia/avif/android/AvifDecoder$Info;)Z

    .line 119
    .line 120
    .line 121
    move-result v3

    .line 122
    const/16 v17, 0x0

    .line 123
    .line 124
    if-nez v3, :cond_b8

    .line 125
    .line 126
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-virtual {v0}, Lh4/l;->d()Lb90/b;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    const/4 v6, 0x0

    .line 135
    const/4 v7, 0x0

    .line 136
    const/4 v0, 0x1

    .line 137
    const-string v9, "decodeEnd failed, Requested to decode byte buffer which cannot be handled by AvifDecoder"

    .line 138
    .line 139
    move-object v4, v15

    .line 140
    move-object/from16 v5, v16

    .line 141
    .line 142
    move-object v12, v8

    .line 143
    move v8, v0

    .line 144
    invoke-interface/range {v3 .. v9}, Lb90/b;->i(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;Ljava/lang/Object;ZLjava/lang/String;)V

    .line 145
    .line 146
    .line 147
    new-instance v0, Ljava/lang/StringBuilder;

    .line 148
    .line 149
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 150
    .line 151
    .line 152
    const-string v3, "[Decode] AvifByteBufferBitmapDecoder decode: decodeEnd failed, Requested to decode byte buffer which cannot be handled by AvifDecoder"

    .line 153
    .line 154
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 158
    .line 159
    .line 160
    move-result-wide v3

    .line 161
    sub-long/2addr v3, v13

    .line 162
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object v0

    .line 181
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    return-object v17

    .line 185
    :cond_b8
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 186
    .line 187
    .line 188
    move-result-object v3

    .line 189
    invoke-virtual {v3}, Lh4/l;->d()Lb90/b;

    .line 190
    .line 191
    .line 192
    move-result-object v3

    .line 193
    iget v6, v7, Lorg/aomedia/avif/android/AvifDecoder$Info;->a:I

    .line 194
    .line 195
    iget v5, v7, Lorg/aomedia/avif/android/AvifDecoder$Info;->b:I

    .line 196
    .line 197
    const-string v4, "avif"

    .line 198
    .line 199
    move-object/from16 v18, v12

    .line 200
    .line 201
    move-object v12, v2

    .line 202
    move-object v2, v3

    .line 203
    move-object v3, v15

    .line 204
    move/from16 v19, v5

    .line 205
    .line 206
    move/from16 v5, p2

    .line 207
    .line 208
    move/from16 v20, v6

    .line 209
    .line 210
    move/from16 v6, p3

    .line 211
    .line 212
    move-object v11, v7

    .line 213
    move/from16 v7, v20

    .line 214
    .line 215
    move-object/from16 v21, v8

    .line 216
    .line 217
    move/from16 v8, v19

    .line 218
    .line 219
    invoke-interface/range {v2 .. v9}, Lb90/b;->c(Ljava/lang/String;Ljava/lang/String;IIIILjava/lang/Object;)V

    .line 220
    .line 221
    .line 222
    sget v2, Lh4/d;->l:I

    .line 223
    .line 224
    if-lez v2, :cond_129

    .line 225
    .line 226
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 227
    .line 228
    .line 229
    move-result-wide v2

    .line 230
    :try_start_e5
    sget v4, Lh4/d;->l:I

    .line 231
    .line 232
    int-to-long v4, v4

    .line 233
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V

    .line 234
    .line 235
    .line 236
    new-instance v4, Ljava/lang/StringBuilder;

    .line 237
    .line 238
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 239
    .line 240
    .line 241
    const-string v5, "[AVIF Sleep]:"

    .line 242
    .line 243
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 244
    .line 245
    .line 246
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 247
    .line 248
    .line 249
    move-result-wide v5

    .line 250
    sub-long/2addr v5, v2

    .line 251
    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 252
    .line 253
    .line 254
    const-string v2, "ms"

    .line 255
    .line 256
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 257
    .line 258
    .line 259
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 260
    .line 261
    .line 262
    move-result-object v2

    .line 263
    invoke-static {v2}, Lh4/d;->a(Ljava/lang/String;)V
    :try_end_109
    .catch Ljava/lang/InterruptedException; {:try_start_e5 .. :try_end_109} :catch_10a

    .line 264
    .line 265
    .line 266
    goto :goto_129

    .line 267
    :catch_10a
    move-exception v0

    .line 268
    new-instance v2, Ljava/lang/StringBuilder;

    .line 269
    .line 270
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 271
    .line 272
    .line 273
    const-string v3, "[AVIF Sleep] Exception:"

    .line 274
    .line 275
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 283
    .line 284
    .line 285
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 286
    .line 287
    .line 288
    move-result-object v2

    .line 289
    invoke-static {v2}, Lh4/d;->a(Ljava/lang/String;)V

    .line 290
    .line 291
    .line 292
    new-instance v2, Ljava/lang/RuntimeException;

    .line 293
    .line 294
    invoke-direct {v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 295
    .line 296
    .line 297
    throw v2

    .line 298
    :cond_129
    :goto_129
    sget-boolean v2, Lh4/d;->j:Z

    .line 299
    .line 300
    if-eqz v2, :cond_137

    .line 301
    .line 302
    iget-boolean v2, v11, Lorg/aomedia/avif/android/AvifDecoder$Info;->d:Z

    .line 303
    .line 304
    if-eqz v2, :cond_134

    .line 305
    .line 306
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 307
    .line 308
    goto :goto_142

    .line 309
    :cond_134
    sget-object v2, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    .line 310
    .line 311
    goto :goto_142

    .line 312
    :cond_137
    iget v2, v11, Lorg/aomedia/avif/android/AvifDecoder$Info;->c:I

    .line 313
    .line 314
    const/16 v3, 0x8

    .line 315
    .line 316
    if-ne v2, v3, :cond_140

    .line 317
    .line 318
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 319
    .line 320
    goto :goto_142

    .line 321
    :cond_140
    sget-object v2, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    .line 322
    .line 323
    :goto_142
    iget-object v3, v1, Li4/a;->a:Lq4/d;

    .line 324
    .line 325
    iget v4, v11, Lorg/aomedia/avif/android/AvifDecoder$Info;->a:I

    .line 326
    .line 327
    iget v5, v11, Lorg/aomedia/avif/android/AvifDecoder$Info;->b:I

    .line 328
    .line 329
    invoke-interface {v3, v4, v5, v2}, Lq4/d;->c(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 330
    .line 331
    .line 332
    move-result-object v9

    .line 333
    invoke-virtual {v0}, Ljava/nio/Buffer;->remaining()I

    .line 334
    .line 335
    .line 336
    move-result v3

    .line 337
    const/4 v4, 0x1

    .line 338
    invoke-static {v0, v3, v9, v4}, Lorg/aomedia/avif/android/AvifDecoder;->decode(Ljava/nio/ByteBuffer;ILandroid/graphics/Bitmap;I)Z

    .line 339
    .line 340
    .line 341
    move-result v0

    .line 342
    const-string v8, " bitmapConfig:"

    .line 343
    .line 344
    const-string v7, " alpha:"

    .line 345
    .line 346
    const-string v6, " depth:"

    .line 347
    .line 348
    if-nez v0, :cond_1cc

    .line 349
    .line 350
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    invoke-virtual {v0}, Lh4/l;->d()Lb90/b;

    .line 355
    .line 356
    .line 357
    move-result-object v3

    .line 358
    const/4 v0, 0x0

    .line 359
    const/16 v18, 0x0

    .line 360
    .line 361
    const/16 v19, 0x1

    .line 362
    .line 363
    const-string v20, "decodeEnd failed, Failed to decode ByteBuffer as Avif."

    .line 364
    .line 365
    move-object v4, v15

    .line 366
    move-object/from16 v5, v16

    .line 367
    .line 368
    move-object v15, v6

    .line 369
    move-object v6, v0

    .line 370
    move-object/from16 v22, v7

    .line 371
    .line 372
    move-object/from16 v7, v18

    .line 373
    .line 374
    move-object/from16 v23, v8

    .line 375
    .line 376
    move/from16 v8, v19

    .line 377
    .line 378
    move-object/from16 v19, v11

    .line 379
    .line 380
    move-object v11, v9

    .line 381
    move-object/from16 v9, v20

    .line 382
    .line 383
    invoke-interface/range {v3 .. v9}, Lb90/b;->i(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;Ljava/lang/Object;ZLjava/lang/String;)V

    .line 384
    .line 385
    .line 386
    new-instance v0, Ljava/lang/StringBuilder;

    .line 387
    .line 388
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 389
    .line 390
    .line 391
    const-string v3, "[Decode] AvifByteBufferBitmapDecoder decode: decodeEnd failed, Failed to decode ByteBuffer as Avif."

    .line 392
    .line 393
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 394
    .line 395
    .line 396
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 397
    .line 398
    .line 399
    move-result-wide v3

    .line 400
    sub-long/2addr v3, v13

    .line 401
    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 402
    .line 403
    .line 404
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 405
    .line 406
    .line 407
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 408
    .line 409
    .line 410
    move-object/from16 v3, v21

    .line 411
    .line 412
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 413
    .line 414
    .line 415
    move/from16 v4, p3

    .line 416
    .line 417
    move-object/from16 v5, v19

    .line 418
    .line 419
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 420
    .line 421
    .line 422
    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 423
    .line 424
    .line 425
    iget v3, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->c:I

    .line 426
    .line 427
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 428
    .line 429
    .line 430
    move-object/from16 v6, v22

    .line 431
    .line 432
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 433
    .line 434
    .line 435
    iget-boolean v3, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->d:Z

    .line 436
    .line 437
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    move-object/from16 v7, v23

    .line 441
    .line 442
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 443
    .line 444
    .line 445
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 446
    .line 447
    .line 448
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 453
    .line 454
    .line 455
    iget-object v0, v1, Li4/a;->a:Lq4/d;

    .line 456
    .line 457
    invoke-interface {v0, v11}, Lq4/d;->b(Landroid/graphics/Bitmap;)V

    .line 458
    .line 459
    .line 460
    return-object v17

    .line 461
    :cond_1cc
    move/from16 v4, p3

    .line 462
    .line 463
    move-object v5, v11

    .line 464
    move-object/from16 v3, v21

    .line 465
    .line 466
    move-object v11, v9

    .line 467
    move-object/from16 v26, v8

    .line 468
    .line 469
    move-object v8, v6

    .line 470
    move-object v6, v7

    .line 471
    move-object/from16 v7, v26

    .line 472
    .line 473
    sget-object v0, Lh4/d;->c:Ljava/lang/Boolean;

    .line 474
    .line 475
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 476
    .line 477
    .line 478
    move-result v0

    .line 479
    if-eqz v0, :cond_28f

    .line 480
    .line 481
    if-lez v10, :cond_28f

    .line 482
    .line 483
    iget v0, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->a:I

    .line 484
    .line 485
    if-ge v10, v0, :cond_28f

    .line 486
    .line 487
    if-lez v4, :cond_28f

    .line 488
    .line 489
    iget v9, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->b:I

    .line 490
    .line 491
    if-ge v4, v9, :cond_28f

    .line 492
    .line 493
    move-object/from16 v22, v6

    .line 494
    .line 495
    move-object/from16 v23, v7

    .line 496
    .line 497
    int-to-double v6, v0

    .line 498
    const-wide/high16 v19, 0x3ff0000000000000L    # 1.0

    .line 499
    .line 500
    mul-double v6, v6, v19

    .line 501
    .line 502
    move-wide/from16 v24, v13

    .line 503
    .line 504
    move-object v14, v12

    .line 505
    int-to-double v12, v10

    .line 506
    div-double/2addr v6, v12

    .line 507
    int-to-double v12, v9

    .line 508
    mul-double v12, v12, v19

    .line 509
    .line 510
    move-object/from16 p1, v14

    .line 511
    .line 512
    move-object v9, v15

    .line 513
    int-to-double v14, v4

    .line 514
    div-double/2addr v12, v14

    .line 515
    invoke-static {v6, v7, v12, v13}, Ljava/lang/Math;->min(DD)D

    .line 516
    .line 517
    .line 518
    move-result-wide v6

    .line 519
    new-instance v0, Ljava/lang/StringBuilder;

    .line 520
    .line 521
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 522
    .line 523
    .line 524
    const-string v12, "[Decode] AvifByteBufferBitmapDecoder avifOptimizeDecode. scale:"

    .line 525
    .line 526
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 527
    .line 528
    .line 529
    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 530
    .line 531
    .line 532
    const-string v12, " Info:"

    .line 533
    .line 534
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 535
    .line 536
    .line 537
    iget v12, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->a:I

    .line 538
    .line 539
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 540
    .line 541
    .line 542
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 543
    .line 544
    .line 545
    iget v12, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->b:I

    .line 546
    .line 547
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 548
    .line 549
    .line 550
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 551
    .line 552
    .line 553
    move-result-object v0

    .line 554
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 555
    .line 556
    .line 557
    cmpl-double v0, v6, v19

    .line 558
    .line 559
    if-lez v0, :cond_298

    .line 560
    .line 561
    :try_start_230
    new-instance v0, Ljava/lang/StringBuilder;

    .line 562
    .line 563
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 564
    .line 565
    .line 566
    move-object/from16 v12, v18

    .line 567
    .line 568
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 569
    .line 570
    .line 571
    iget v13, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->a:I

    .line 572
    .line 573
    int-to-double v13, v13

    .line 574
    mul-double v13, v13, v19

    .line 575
    .line 576
    div-double/2addr v13, v6

    .line 577
    invoke-virtual {v0, v13, v14}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 578
    .line 579
    .line 580
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 581
    .line 582
    .line 583
    move-result-object v0

    .line 584
    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 585
    .line 586
    .line 587
    move-result-wide v13

    .line 588
    double-to-int v0, v13

    .line 589
    new-instance v13, Ljava/lang/StringBuilder;

    .line 590
    .line 591
    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 592
    .line 593
    .line 594
    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 595
    .line 596
    .line 597
    iget v12, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->b:I

    .line 598
    .line 599
    int-to-double v14, v12

    .line 600
    mul-double v14, v14, v19

    .line 601
    .line 602
    div-double/2addr v14, v6

    .line 603
    invoke-virtual {v13, v14, v15}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 604
    .line 605
    .line 606
    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 607
    .line 608
    .line 609
    move-result-object v6

    .line 610
    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    .line 611
    .line 612
    .line 613
    move-result-wide v6

    .line 614
    double-to-int v6, v6

    .line 615
    const/4 v7, 0x0

    .line 616
    invoke-static {v11, v0, v6, v7}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    .line 617
    .line 618
    .line 619
    move-result-object v6
    :try_end_26b
    .catch Ljava/lang/Exception; {:try_start_230 .. :try_end_26b} :catch_275

    .line 620
    :try_start_26b
    iget-object v0, v1, Li4/a;->a:Lq4/d;

    .line 621
    .line 622
    invoke-interface {v0, v11}, Lq4/d;->b(Landroid/graphics/Bitmap;)V
    :try_end_270
    .catch Ljava/lang/Exception; {:try_start_26b .. :try_end_270} :catch_272

    .line 623
    .line 624
    .line 625
    move-object v11, v6

    .line 626
    goto :goto_298

    .line 627
    :catch_272
    move-exception v0

    .line 628
    move-object v11, v6

    .line 629
    goto :goto_276

    .line 630
    :catch_275
    move-exception v0

    .line 631
    :goto_276
    new-instance v6, Ljava/lang/StringBuilder;

    .line 632
    .line 633
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 634
    .line 635
    .line 636
    const-string v7, "[Decode] AvifByteBufferBitmapDecoder avifOptimizeDecode. Exception:"

    .line 637
    .line 638
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 639
    .line 640
    .line 641
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 642
    .line 643
    .line 644
    move-result-object v0

    .line 645
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 646
    .line 647
    .line 648
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 649
    .line 650
    .line 651
    move-result-object v0

    .line 652
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 653
    .line 654
    .line 655
    goto :goto_298

    .line 656
    :cond_28f
    move-object/from16 v22, v6

    .line 657
    .line 658
    move-object/from16 v23, v7

    .line 659
    .line 660
    move-object/from16 p1, v12

    .line 661
    .line 662
    move-wide/from16 v24, v13

    .line 663
    .line 664
    move-object v9, v15

    .line 665
    :cond_298
    :goto_298
    new-instance v0, Ljava/lang/StringBuilder;

    .line 666
    .line 667
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 668
    .line 669
    .line 670
    const-string v6, "[Decode] AvifByteBufferBitmapDecoder decode:"

    .line 671
    .line 672
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 673
    .line 674
    .line 675
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 676
    .line 677
    .line 678
    move-result-wide v6

    .line 679
    sub-long v6, v6, v24

    .line 680
    .line 681
    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 682
    .line 683
    .line 684
    move-object/from16 v6, p1

    .line 685
    .line 686
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 687
    .line 688
    .line 689
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 690
    .line 691
    .line 692
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 693
    .line 694
    .line 695
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 696
    .line 697
    .line 698
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 699
    .line 700
    .line 701
    iget v3, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->c:I

    .line 702
    .line 703
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 704
    .line 705
    .line 706
    move-object/from16 v3, v22

    .line 707
    .line 708
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 709
    .line 710
    .line 711
    iget-boolean v3, v5, Lorg/aomedia/avif/android/AvifDecoder$Info;->d:Z

    .line 712
    .line 713
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 714
    .line 715
    .line 716
    move-object/from16 v3, v23

    .line 717
    .line 718
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 719
    .line 720
    .line 721
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 722
    .line 723
    .line 724
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 725
    .line 726
    .line 727
    move-result-object v0

    .line 728
    invoke-static {v0}, Lh4/d;->a(Ljava/lang/String;)V

    .line 729
    .line 730
    .line 731
    invoke-static {}, Lh4/l;->c()Lh4/l;

    .line 732
    .line 733
    .line 734
    move-result-object v0

    .line 735
    invoke-virtual {v0}, Lh4/l;->d()Lb90/b;

    .line 736
    .line 737
    .line 738
    move-result-object v3

    .line 739
    const/4 v7, 0x0

    .line 740
    const/4 v8, 0x0

    .line 741
    const/4 v0, 0x0

    .line 742
    move-object v4, v9

    .line 743
    move-object/from16 v5, v16

    .line 744
    .line 745
    move-object v6, v11

    .line 746
    move-object v9, v0

    .line 747
    invoke-interface/range {v3 .. v9}, Lb90/b;->i(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;Ljava/lang/Object;ZLjava/lang/String;)V

    .line 748
    .line 749
    .line 750
    iget-object v0, v1, Li4/a;->a:Lq4/d;

    .line 751
    .line 752
    invoke-static {v11, v0}, Lw4/e;->c(Landroid/graphics/Bitmap;Lq4/d;)Lw4/e;

    .line 753
    .line 754
    .line 755
    move-result-object v0

    .line 756
    return-object v0
.end method

.method public d(Ljava/nio/ByteBuffer;Lm4/f;)Z
    .registers 3

    invoke-virtual {p0, p1}, Li4/a;->e(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    move-result-object p1

    invoke-static {p1}, Lorg/aomedia/avif/android/AvifDecoder;->a(Ljava/nio/ByteBuffer;)Z

    move-result p1

    return p1
.end method

.method public final e(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->isDirect()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    return-object p1

    .line 8
    :cond_7
    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 20
    .line 21
    .line 22
    return-object v0
.end method
