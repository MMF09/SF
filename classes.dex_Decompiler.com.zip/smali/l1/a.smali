###### Class l1.a (l1.a)
.class public final synthetic Ll1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;
    .registers 1

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->getButtonDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method
