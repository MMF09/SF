###### Class x0.v (x0.v)
.class public final synthetic Lx0/v;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Color;)Landroid/graphics/ColorSpace$Model;
    .registers 1

    invoke-virtual {p0}, Landroid/graphics/Color;->getModel()Landroid/graphics/ColorSpace$Model;

    move-result-object p0

    return-object p0
.end method
