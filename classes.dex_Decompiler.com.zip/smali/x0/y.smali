###### Class x0.y (x0.y)
.class public final synthetic Lx0/y;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Color;)Landroid/graphics/ColorSpace;
    .registers 1

    invoke-virtual {p0}, Landroid/graphics/Color;->getColorSpace()Landroid/graphics/ColorSpace;

    move-result-object p0

    return-object p0
.end method
