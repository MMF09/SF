###### Class x0.d (x0.d)
.class public final synthetic Lx0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Bitmap;)Landroid/hardware/HardwareBuffer;
    .registers 1

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHardwareBuffer()Landroid/hardware/HardwareBuffer;

    move-result-object p0

    return-object p0
.end method
