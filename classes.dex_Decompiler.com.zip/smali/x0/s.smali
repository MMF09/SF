###### Class x0.s (x0.s)
.class public final synthetic Lx0/s;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(JLandroid/graphics/ColorSpace;)J
    .registers 3

    invoke-static {p0, p1, p2}, Landroid/graphics/Color;->convert(JLandroid/graphics/ColorSpace;)J

    move-result-wide p0

    return-wide p0
.end method
