###### Class x0.b0 (x0.b0)
.class public final synthetic Lx0/b0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Paint;Ljava/lang/String;)Z
    .registers 2

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->hasGlyph(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method
