###### Class x0.w (x0.w)
.class public final synthetic Lx0/w;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Color;)F
    .registers 1

    invoke-virtual {p0}, Landroid/graphics/Color;->alpha()F

    move-result p0

    return p0
.end method
