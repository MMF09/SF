###### Class b4.g (b4.g)
.class public interface abstract Lb4/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method
