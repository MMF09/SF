###### Class b4.f (b4.f)
.class public Lb4/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/a;
.implements Le4/c;


# static fields
.field public static j:Lcom/squareup/wire/Wire;


# instance fields
.field public a:I

.field public b:Lb4/h;

.field public c:Le4/b;

.field public d:I

.field public e:Lc4/c;

.field public i:Lb4/j;


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/squareup/wire/Wire;

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Class;

    invoke-direct {v0, v1}, Lcom/squareup/wire/Wire;-><init>([Ljava/lang/Class;)V

    sput-object v0, Lb4/f;->j:Lcom/squareup/wire/Wire;

    return-void
.end method

.method public constructor <init>(Lb4/h;Lc4/c;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x8

    .line 5
    .line 6
    iput v0, p0, Lb4/f;->a:I

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput v0, p0, Lb4/f;->d:I

    .line 10
    .line 11
    iput-object p1, p0, Lb4/f;->b:Lb4/h;

    .line 12
    .line 13
    iput-object p2, p0, Lb4/f;->e:Lc4/c;

    .line 14
    .line 15
    invoke-static {}, Lc4/a;->a()Lc4/a;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p1, p0}, Lc4/a;->b(Lb4/a;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public a(Le4/f;)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-virtual {p1}, Le4/f;->b()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v1, 0x0

    .line 13
    aput-object p1, v0, v1

    .line 14
    .line 15
    const-string p1, "send packet failed %d"

    .line 16
    .line 17
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lb4/f;->h()V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public b(Le4/f;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    new-array p1, p1, [Ljava/lang/Object;

    .line 7
    .line 8
    const-string v0, "response cmd %d ignored - no pending tasks"

    .line 9
    .line 10
    invoke-static {v0, p1}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    :try_start_d
    invoke-virtual {p1}, Le4/f;->b()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v1, 0x2

    .line 19
    if-eq v0, v1, :cond_53

    .line 20
    .line 21
    const/4 v1, 0x4

    .line 22
    if-eq v0, v1, :cond_2d

    .line 23
    .line 24
    const/4 v1, 0x5

    .line 25
    if-eq v0, v1, :cond_1b

    .line 26
    .line 27
    goto :goto_71

    .line 28
    :cond_1b
    sget-object v0, Lb4/f;->j:Lcom/squareup/wire/Wire;

    .line 29
    .line 30
    invoke-virtual {p1}, Le4/f;->c()[B

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    const-class v1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;

    .line 35
    .line 36
    invoke-virtual {v0, p1, v1}, Lcom/squareup/wire/Wire;->parseFrom([BLjava/lang/Class;)Lcom/squareup/wire/Message;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;

    .line 41
    .line 42
    invoke-virtual {p0, p1}, Lb4/f;->k(Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;)V

    .line 43
    .line 44
    .line 45
    goto :goto_71

    .line 46
    :cond_2d
    sget-object v0, Lb4/f;->j:Lcom/squareup/wire/Wire;

    .line 47
    .line 48
    invoke-virtual {p1}, Le4/f;->c()[B

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    const-class v1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPartAck;

    .line 53
    .line 54
    invoke-virtual {v0, p1, v1}, Lcom/squareup/wire/Wire;->parseFrom([BLjava/lang/Class;)Lcom/squareup/wire/Message;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    check-cast p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPartAck;

    .line 59
    .line 60
    iget-object v0, p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPartAck;->RequestId:Ljava/lang/String;

    .line 61
    .line 62
    iget-object v1, p0, Lb4/f;->i:Lb4/j;

    .line 63
    .line 64
    iget-object v1, v1, Lb4/j;->a:Ljava/lang/String;

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_71

    .line 71
    .line 72
    iget-object p1, p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPartAck;->PartId:Ljava/lang/Integer;

    .line 73
    .line 74
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    add-int/lit8 p1, p1, 0x1

    .line 79
    .line 80
    invoke-virtual {p0, p1}, Lb4/f;->i(I)V

    .line 81
    .line 82
    .line 83
    goto :goto_71

    .line 84
    :cond_53
    sget-object v0, Lb4/f;->j:Lcom/squareup/wire/Wire;

    .line 85
    .line 86
    invoke-virtual {p1}, Le4/f;->c()[B

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    const-class v1, Lcom/beetalklib/network/file/protocol/FSGeneralError;

    .line 91
    .line 92
    invoke-virtual {v0, p1, v1}, Lcom/squareup/wire/Wire;->parseFrom([BLjava/lang/Class;)Lcom/squareup/wire/Message;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    check-cast p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;

    .line 97
    .line 98
    iget-object v0, p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;->ErrorCode:Ljava/lang/Integer;

    .line 99
    .line 100
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 101
    .line 102
    .line 103
    move-result v0

    .line 104
    iget-object p1, p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;->RequestId:Ljava/lang/String;

    .line 105
    .line 106
    invoke-virtual {p0, v0, p1}, Lb4/f;->g(ILjava/lang/String;)V
    :try_end_6c
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_6c} :catch_6d

    .line 107
    .line 108
    .line 109
    goto :goto_71

    .line 110
    :catch_6d
    move-exception p1

    .line 111
    invoke-static {p1}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 112
    .line 113
    .line 114
    :cond_71
    :goto_71
    return-void
.end method

.method public c(I)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v1, 0x0

    .line 9
    aput-object p1, v0, v1

    .line 10
    .line 11
    const-string p1, "connection dropped %d"

    .line 12
    .line 13
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Lb4/f;->h()V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public d(II)V
    .registers 5

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v1, 0x0

    .line 9
    aput-object p1, v0, v1

    .line 10
    .line 11
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const/4 p2, 0x1

    .line 16
    aput-object p1, v0, p2

    .line 17
    .line 18
    const-string p1, "unable to connect %d error %d"

    .line 19
    .line 20
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Lb4/f;->h()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public e(I)V
    .registers 5

    .line 1
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    if-nez p1, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    invoke-virtual {p1}, Lb4/j;->g()I

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    const/4 v0, -0x1

    .line 11
    if-ne p1, v0, :cond_10

    .line 12
    .line 13
    invoke-virtual {p0}, Lb4/f;->j()V

    .line 14
    .line 15
    .line 16
    goto :goto_29

    .line 17
    :cond_10
    const/4 p1, 0x1

    .line 18
    new-array v0, p1, [Ljava/lang/Object;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    iget-object v2, p0, Lb4/f;->i:Lb4/j;

    .line 22
    .line 23
    iget-object v2, v2, Lb4/j;->a:Ljava/lang/String;

    .line 24
    .line 25
    aput-object v2, v0, v1

    .line 26
    .line 27
    const-string v1, "resume the upload session %s"

    .line 28
    .line 29
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 33
    .line 34
    invoke-virtual {v0}, Lb4/j;->g()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    add-int/2addr v0, p1

    .line 39
    invoke-virtual {p0, v0}, Lb4/f;->i(I)V

    .line 40
    .line 41
    .line 42
    :goto_29
    return-void
.end method

.method public final f(Z)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    if-eqz p1, :cond_8

    .line 5
    .line 6
    const-string v1, "ok"

    .line 7
    .line 8
    goto :goto_a

    .line 9
    :cond_8
    const-string v1, "failed"

    .line 10
    .line 11
    :goto_a
    const/4 v2, 0x0

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const-string v1, "fileUpload completed %s"

    .line 15
    .line 16
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 21
    .line 22
    invoke-static {}, Lc4/a;->a()Lc4/a;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0, p0}, Lc4/a;->c(Lb4/a;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lb4/f;->b:Lb4/h;

    .line 30
    .line 31
    invoke-virtual {v0}, Lb4/h;->h()V

    .line 32
    .line 33
    .line 34
    iget-object v0, p0, Lb4/f;->e:Lc4/c;

    .line 35
    .line 36
    invoke-interface {v0, p1}, Lc4/c;->a(Z)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public g(ILjava/lang/String;)V
    .registers 8

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v3, 0x0

    .line 9
    aput-object v2, v1, v3

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object p2, v1, v2

    .line 13
    .line 14
    const-string v4, "general error %d %s"

    .line 15
    .line 16
    invoke-static {v4, v1}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lb4/f;->i:Lb4/j;

    .line 20
    .line 21
    if-eqz v1, :cond_6f

    .line 22
    .line 23
    iget-object v1, v1, Lb4/j;->a:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-nez v1, :cond_1f

    .line 30
    .line 31
    goto :goto_6f

    .line 32
    :cond_1f
    if-eq p1, v2, :cond_66

    .line 33
    .line 34
    const/16 v1, 0x10

    .line 35
    .line 36
    if-eq p1, v1, :cond_5d

    .line 37
    .line 38
    const/16 v1, 0x81

    .line 39
    .line 40
    if-eq p1, v1, :cond_54

    .line 41
    .line 42
    const/16 v1, 0x82

    .line 43
    .line 44
    if-eq p1, v1, :cond_50

    .line 45
    .line 46
    const/4 v1, 0x3

    .line 47
    new-array v1, v1, [Ljava/lang/Object;

    .line 48
    .line 49
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    aput-object p1, v1, v3

    .line 54
    .line 55
    aput-object p2, v1, v2

    .line 56
    .line 57
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 58
    .line 59
    invoke-virtual {p1}, Lb4/j;->d()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    aput-object p1, v1, v0

    .line 64
    .line 65
    const-string p1, "unknown error %d %s %s"

    .line 66
    .line 67
    invoke-static {p1, v1}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 71
    .line 72
    const/16 p2, 0x110

    .line 73
    .line 74
    invoke-virtual {p1, p2}, Lb4/j;->i(I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p0, v3}, Lb4/f;->f(Z)V

    .line 78
    .line 79
    .line 80
    goto :goto_6e

    .line 81
    :cond_50
    invoke-virtual {p0}, Lb4/f;->j()V

    .line 82
    .line 83
    .line 84
    goto :goto_6e

    .line 85
    :cond_54
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 86
    .line 87
    invoke-virtual {p1, v1}, Lb4/j;->i(I)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p0, v3}, Lb4/f;->f(Z)V

    .line 91
    .line 92
    .line 93
    goto :goto_6e

    .line 94
    :cond_5d
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 95
    .line 96
    invoke-virtual {p1, v1}, Lb4/j;->i(I)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0, v3}, Lb4/f;->f(Z)V

    .line 100
    .line 101
    .line 102
    goto :goto_6e

    .line 103
    :cond_66
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 104
    .line 105
    invoke-virtual {p1, v2}, Lb4/j;->i(I)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0, v3}, Lb4/f;->f(Z)V

    .line 109
    .line 110
    .line 111
    :goto_6e
    return-void

    .line 112
    :cond_6f
    :goto_6f
    new-array v0, v0, [Ljava/lang/Object;

    .line 113
    .line 114
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 115
    .line 116
    .line 117
    move-result-object p1

    .line 118
    aput-object p1, v0, v3

    .line 119
    .line 120
    aput-object p2, v0, v2

    .line 121
    .line 122
    const-string p1, "ignore error %d %s"

    .line 123
    .line 124
    invoke-static {p1, v0}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    return-void
.end method

.method public final h()V
    .registers 6

    .line 1
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iget v1, p0, Lb4/f;->d:I

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    add-int/2addr v1, v2

    .line 10
    iput v1, p0, Lb4/f;->d:I

    .line 11
    .line 12
    iget v3, p0, Lb4/f;->a:I

    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    if-gt v3, v1, :cond_19

    .line 16
    .line 17
    const/16 v1, 0x22

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Lb4/j;->i(I)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v4}, Lb4/f;->f(Z)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_19
    new-array v0, v2, [Ljava/lang/Object;

    .line 27
    .line 28
    const-wide/16 v1, 0x2

    .line 29
    .line 30
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    aput-object v1, v0, v4

    .line 35
    .line 36
    const-string v1, "resume connection %d seconds later"

    .line 37
    .line 38
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    iget-object v0, p0, Lb4/f;->c:Le4/b;

    .line 42
    .line 43
    const-wide/16 v1, 0x7d0

    .line 44
    .line 45
    invoke-interface {v0, v1, v2}, Le4/b;->c(J)V

    .line 46
    .line 47
    .line 48
    return-void
.end method

.method public final i(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lb4/j;->e(I)Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    if-eqz p1, :cond_18

    .line 8
    .line 9
    new-instance v0, Le4/f;

    .line 10
    .line 11
    const/4 v1, 0x4

    .line 12
    invoke-virtual {p1}, Lcom/squareup/wire/Message;->toByteArray()[B

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    invoke-direct {v0, v1, p1}, Le4/f;-><init>(I[B)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, Lb4/f;->c:Le4/b;

    .line 20
    .line 21
    invoke-interface {p1, v0}, Le4/b;->b(Le4/f;)V

    .line 22
    .line 23
    .line 24
    goto :goto_24

    .line 25
    :cond_18
    const/4 p1, 0x1

    .line 26
    invoke-virtual {p0, p1}, Lb4/f;->f(Z)V

    .line 27
    .line 28
    .line 29
    const/4 p1, 0x0

    .line 30
    new-array p1, p1, [Ljava/lang/Object;

    .line 31
    .line 32
    const-string v0, "null the current task"

    .line 33
    .line 34
    invoke-static {v0, p1}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    :goto_24
    return-void
.end method

.method public final j()V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    invoke-virtual {v0}, Lb4/j;->c()Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Le4/f;

    .line 8
    .line 9
    invoke-virtual {v0}, Lcom/squareup/wire/Message;->toByteArray()[B

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v2, 0x3

    .line 14
    invoke-direct {v1, v2, v0}, Le4/f;-><init>(I[B)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lb4/f;->c:Le4/b;

    .line 18
    .line 19
    invoke-interface {v0, v1}, Le4/b;->b(Le4/f;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final k(Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;)V
    .registers 4

    .line 1
    iget-object v0, p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;->Exists:Ljava/lang/Boolean;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_15

    .line 8
    .line 9
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 10
    .line 11
    const v0, 0x7fffffff

    .line 12
    .line 13
    .line 14
    invoke-virtual {p1, v0}, Lb4/j;->e(I)Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart;

    .line 15
    .line 16
    .line 17
    const/4 p1, 0x1

    .line 18
    invoke-virtual {p0, p1}, Lb4/f;->f(Z)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 23
    .line 24
    iget-object v0, v0, Lb4/j;->a:Ljava/lang/String;

    .line 25
    .line 26
    iget-object p1, p1, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeaderAck;->Name:Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    if-eqz p1, :cond_37

    .line 33
    .line 34
    iget-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 35
    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-virtual {p1, v0}, Lb4/j;->e(I)Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    new-instance v0, Le4/f;

    .line 42
    .line 43
    const/4 v1, 0x4

    .line 44
    invoke-virtual {p1}, Lcom/squareup/wire/Message;->toByteArray()[B

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-direct {v0, v1, p1}, Le4/f;-><init>(I[B)V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Lb4/f;->c:Le4/b;

    .line 52
    .line 53
    invoke-interface {p1, v0}, Le4/b;->b(Le4/f;)V

    .line 54
    .line 55
    .line 56
    :cond_37
    return-void
.end method

.method public l(Lb4/j;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lb4/f;->i:Lb4/j;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    new-array v0, v0, [Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v1, p1, Lb4/j;->a:Ljava/lang/String;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const-string v1, "new task join %s"

    .line 15
    .line 16
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Lb4/j;->b()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/16 v1, 0xa

    .line 24
    .line 25
    if-le v0, v1, :cond_1d

    .line 26
    .line 27
    const/16 v0, 0x8

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    const/4 v0, 0x6

    .line 31
    :goto_1e
    iput v0, p0, Lb4/f;->a:I

    .line 32
    .line 33
    iput-object p1, p0, Lb4/f;->i:Lb4/j;

    .line 34
    .line 35
    iput v2, p0, Lb4/f;->d:I

    .line 36
    .line 37
    iget-object p1, p0, Lb4/f;->b:Lb4/h;

    .line 38
    .line 39
    invoke-virtual {p1, p0}, Lb4/h;->f(Le4/c;)Le4/b;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    iput-object p1, p0, Lb4/f;->c:Le4/b;

    .line 44
    .line 45
    invoke-interface {p1}, Le4/b;->a()V

    .line 46
    .line 47
    .line 48
    return-void
.end method
