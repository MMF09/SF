###### Class b4.d (b4.d)
.class public Lb4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/g;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:I

.field public e:Lb4/c;

.field public f:Z


# virtual methods
.method public a()I
    .registers 2

    const/4 v0, 0x2

    return v0
.end method

.method public declared-synchronized b([B)V
    .registers 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lb4/d;->e:Lb4/c;

    .line 3
    .line 4
    invoke-interface {v0, p1}, Lb4/c;->a([B)V

    .line 5
    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    iput-boolean p1, p0, Lb4/d;->f:Z
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_b

    .line 9
    .line 10
    monitor-exit p0

    .line 11
    return-void

    .line 12
    :catchall_b
    move-exception p1

    .line 13
    monitor-exit p0

    .line 14
    throw p1
.end method

.method public c()Lcom/beetalklib/network/file/protocol/ImageDownloadRequest;
    .registers 3

    .line 1
    new-instance v0, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lb4/d;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;->Name:Ljava/lang/String;

    .line 9
    .line 10
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;->RequestId:Ljava/lang/String;

    .line 11
    .line 12
    iget-object v1, p0, Lb4/d;->b:Ljava/lang/String;

    .line 13
    .line 14
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;->Token:Ljava/lang/String;

    .line 15
    .line 16
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;->Thumb(Ljava/lang/Boolean;)Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Lcom/beetalklib/network/file/protocol/ImageDownloadRequest$Builder;->build()Lcom/beetalklib/network/file/protocol/ImageDownloadRequest;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0
.end method

.method public d()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lb4/d;->c:Ljava/lang/String;

    return-object v0
.end method

.method public e()I
    .registers 2

    iget v0, p0, Lb4/d;->d:I

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    instance-of v0, p1, Lb4/d;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2c

    .line 5
    .line 6
    check-cast p1, Lb4/d;

    .line 7
    .line 8
    iget-object v0, p1, Lb4/d;->c:Ljava/lang/String;

    .line 9
    .line 10
    iget-object v2, p0, Lb4/d;->c:Ljava/lang/String;

    .line 11
    .line 12
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_2c

    .line 17
    .line 18
    iget v0, p1, Lb4/d;->d:I

    .line 19
    .line 20
    iget v2, p0, Lb4/d;->d:I

    .line 21
    .line 22
    if-ne v0, v2, :cond_2c

    .line 23
    .line 24
    iget-object v0, p0, Lb4/d;->e:Lb4/c;

    .line 25
    .line 26
    iget-object v2, p1, Lb4/d;->e:Lb4/c;

    .line 27
    .line 28
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_2c

    .line 33
    .line 34
    iget-object v0, p0, Lb4/d;->a:Ljava/lang/String;

    .line 35
    .line 36
    iget-object p1, p1, Lb4/d;->a:Ljava/lang/String;

    .line 37
    .line 38
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_2c

    .line 43
    .line 44
    const/4 v1, 0x1

    .line 45
    :cond_2c
    return v1
.end method

.method public declared-synchronized f()Z
    .registers 2

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lb4/d;->f:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_5

    monitor-exit p0

    return v0

    :catchall_5
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public g(I)V
    .registers 3

    iget-object v0, p0, Lb4/d;->e:Lb4/c;

    invoke-interface {v0, p1}, Lb4/c;->onError(I)V

    return-void
.end method
