###### Class b4.i (b4.i)
.class public interface abstract Lb4/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(II)V
.end method

.method public abstract onError(I)V
.end method

.method public abstract onFinish()V
.end method
