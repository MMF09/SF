###### Class b4.h (b4.h)
.class public Lb4/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le4/c;


# instance fields
.field public a:Le4/h;

.field public b:Lf4/b;

.field public c:Le4/c;

.field public d:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Le4/h;

    .line 5
    .line 6
    invoke-direct {v0, p1, p2}, Le4/h;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lb4/h;->a:Le4/h;

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, p0, Lb4/h;->d:Z

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public a(Le4/f;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h;->c:Le4/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-interface {v0, p1}, Le4/c;->a(Le4/f;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public b(Le4/f;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h;->c:Le4/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-interface {v0, p1}, Le4/c;->b(Le4/f;)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public c(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h;->c:Le4/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-interface {v0, p1}, Le4/c;->c(I)V

    .line 6
    .line 7
    .line 8
    :cond_7
    iget-boolean p1, p0, Lb4/h;->d:Z

    .line 9
    .line 10
    if-nez p1, :cond_18

    .line 11
    .line 12
    iget-object p1, p0, Lb4/h;->b:Lf4/b;

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, Lb4/h;->b:Lf4/b;

    .line 18
    .line 19
    invoke-virtual {p1}, Lf4/b;->e()V

    .line 20
    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    iput-object p1, p0, Lb4/h;->a:Le4/h;

    .line 24
    .line 25
    :cond_18
    return-void
.end method

.method public d(II)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/h;->c:Le4/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-interface {v0, p1, p2}, Le4/c;->d(II)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public e(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lb4/h;->c:Le4/c;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-interface {v0, p1}, Le4/c;->e(I)V

    .line 6
    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public declared-synchronized f(Le4/c;)Le4/b;
    .registers 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 3
    .line 4
    if-eqz v0, :cond_b

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_17

    .line 11
    .line 12
    :cond_b
    new-instance v0, Lf4/b;

    .line 13
    .line 14
    iget-object v1, p0, Lb4/h;->a:Le4/h;

    .line 15
    .line 16
    invoke-direct {v0, v1, p0}, Lf4/b;-><init>(Le4/h;Le4/c;)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 22
    .line 23
    .line 24
    :cond_17
    iput-object p1, p0, Lb4/h;->c:Le4/c;

    .line 25
    .line 26
    iget-object p1, p0, Lb4/h;->b:Lf4/b;

    .line 27
    .line 28
    invoke-virtual {p1}, Lf4/b;->c()Le4/b;

    .line 29
    .line 30
    .line 31
    move-result-object p1
    :try_end_1f
    .catchall {:try_start_1 .. :try_end_1f} :catchall_21

    .line 32
    monitor-exit p0

    .line 33
    return-object p1

    .line 34
    :catchall_21
    move-exception p1

    .line 35
    monitor-exit p0

    .line 36
    throw p1
.end method

.method public g()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lb4/h;->d:Z

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, Lb4/h;->d:Z

    .line 8
    .line 9
    iget-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 10
    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    iget-object v0, p0, Lb4/h;->a:Le4/h;

    .line 15
    .line 16
    invoke-virtual {v0}, Le4/h;->e()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_20

    .line 21
    .line 22
    iget-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 28
    .line 29
    invoke-virtual {v0}, Lf4/b;->e()V

    .line 30
    .line 31
    .line 32
    goto :goto_2b

    .line 33
    :cond_20
    iget-object v0, p0, Lb4/h;->b:Lf4/b;

    .line 34
    .line 35
    if-eqz v0, :cond_2b

    .line 36
    .line 37
    invoke-virtual {v0}, Lf4/b;->c()Le4/b;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {v0}, Le4/b;->closeConnection()V

    .line 42
    .line 43
    .line 44
    :cond_2b
    :goto_2b
    return-void
.end method

.method public h()V
    .registers 2

    const/4 v0, 0x0

    iput-object v0, p0, Lb4/h;->c:Le4/c;

    return-void
.end method

.method public i()Z
    .registers 2

    iget-object v0, p0, Lb4/h;->c:Le4/c;

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public j(Ljava/lang/String;I)Z
    .registers 4

    iget-object v0, p0, Lb4/h;->a:Le4/h;

    if-eqz v0, :cond_c

    invoke-virtual {v0, p1, p2}, Le4/h;->f(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_c

    const/4 p1, 0x1

    goto :goto_d

    :cond_c
    const/4 p1, 0x0

    :goto_d
    return p1
.end method
