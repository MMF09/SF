###### Class b4.e (b4.e)
.class public Lb4/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/a;
.implements Le4/c;


# instance fields
.field public a:Lcom/squareup/wire/Wire;

.field public b:Le4/b;

.field public c:I

.field public d:Lc4/c;

.field public e:Lb4/d;

.field public i:Lb4/h;


# direct methods
.method public constructor <init>(Lb4/h;Lc4/c;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lcom/squareup/wire/Wire;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    new-array v2, v1, [Ljava/lang/Class;

    .line 8
    .line 9
    invoke-direct {v0, v2}, Lcom/squareup/wire/Wire;-><init>([Ljava/lang/Class;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lb4/e;->a:Lcom/squareup/wire/Wire;

    .line 13
    .line 14
    iput v1, p0, Lb4/e;->c:I

    .line 15
    .line 16
    iput-object p1, p0, Lb4/e;->i:Lb4/h;

    .line 17
    .line 18
    iput-object p2, p0, Lb4/e;->d:Lc4/c;

    .line 19
    .line 20
    invoke-static {}, Lc4/a;->a()Lc4/a;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-virtual {p1, p0}, Lc4/a;->b(Lb4/a;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public a(Le4/f;)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-virtual {p1}, Le4/f;->b()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 v1, 0x0

    .line 13
    aput-object p1, v0, v1

    .line 14
    .line 15
    const-string p1, "send packet failed %d"

    .line 16
    .line 17
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lb4/e;->j()V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public b(Le4/f;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    new-array p1, p1, [Ljava/lang/Object;

    .line 7
    .line 8
    const-string v0, "response cmd %d ignored - no pending tasks"

    .line 9
    .line 10
    invoke-static {v0, p1}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    :try_start_d
    invoke-virtual {p1}, Le4/f;->b()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v1, 0x2

    .line 19
    if-eq v0, v1, :cond_32

    .line 20
    .line 21
    const/4 v1, 0x3

    .line 22
    if-eq v0, v1, :cond_18

    .line 23
    .line 24
    goto :goto_50

    .line 25
    :cond_18
    iget-object v0, p0, Lb4/e;->a:Lcom/squareup/wire/Wire;

    .line 26
    .line 27
    invoke-virtual {p1}, Le4/f;->c()[B

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    const-class v1, Lcom/beetalklib/network/file/protocol/ImageDownloadResult;

    .line 32
    .line 33
    invoke-virtual {v0, p1, v1}, Lcom/squareup/wire/Wire;->parseFrom([BLjava/lang/Class;)Lcom/squareup/wire/Message;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    check-cast p1, Lcom/beetalklib/network/file/protocol/ImageDownloadResult;

    .line 38
    .line 39
    iget-object v0, p1, Lcom/beetalklib/network/file/protocol/ImageDownloadResult;->Content:Lokio/ByteString;

    .line 40
    .line 41
    invoke-virtual {v0}, Lokio/ByteString;->toByteArray()[B

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    iget-object p1, p1, Lcom/beetalklib/network/file/protocol/ImageDownloadResult;->RequestId:Ljava/lang/String;

    .line 46
    .line 47
    invoke-virtual {p0, v0, p1}, Lb4/e;->f([BLjava/lang/String;)V

    .line 48
    .line 49
    .line 50
    goto :goto_50

    .line 51
    :cond_32
    iget-object v0, p0, Lb4/e;->a:Lcom/squareup/wire/Wire;

    .line 52
    .line 53
    invoke-virtual {p1}, Le4/f;->c()[B

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    const-class v1, Lcom/beetalklib/network/file/protocol/FSGeneralError;

    .line 58
    .line 59
    invoke-virtual {v0, p1, v1}, Lcom/squareup/wire/Wire;->parseFrom([BLjava/lang/Class;)Lcom/squareup/wire/Message;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    check-cast p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;

    .line 64
    .line 65
    iget-object v0, p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;->ErrorCode:Ljava/lang/Integer;

    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    iget-object p1, p1, Lcom/beetalklib/network/file/protocol/FSGeneralError;->RequestId:Ljava/lang/String;

    .line 72
    .line 73
    invoke-virtual {p0, v0, p1}, Lb4/e;->i(ILjava/lang/String;)V
    :try_end_4b
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_4b} :catch_4c

    .line 74
    .line 75
    .line 76
    goto :goto_50

    .line 77
    :catch_4c
    move-exception p1

    .line 78
    invoke-static {p1}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 79
    .line 80
    .line 81
    :goto_50
    return-void
.end method

.method public c(I)V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v1, 0x0

    .line 9
    aput-object p1, v0, v1

    .line 10
    .line 11
    const-string p1, "connection dropped %d"

    .line 12
    .line 13
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Lb4/e;->j()V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public d(II)V
    .registers 5

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    const/4 v1, 0x0

    .line 9
    aput-object p1, v0, v1

    .line 10
    .line 11
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const/4 p2, 0x1

    .line 16
    aput-object p1, v0, p2

    .line 17
    .line 18
    const-string p1, "unable to connect %d error %d"

    .line 19
    .line 20
    invoke-static {p1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Lb4/e;->j()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public e(I)V
    .registers 2

    .line 1
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    if-nez p1, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    invoke-virtual {p1}, Lb4/d;->f()Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    if-nez p1, :cond_e

    .line 11
    .line 12
    invoke-virtual {p0}, Lb4/e;->k()V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public final f([BLjava/lang/String;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    if-eqz v0, :cond_11

    .line 4
    .line 5
    iget-object v0, v0, Lb4/d;->a:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_11

    .line 12
    .line 13
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Lb4/d;->b([B)V

    .line 16
    .line 17
    .line 18
    :cond_11
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 19
    .line 20
    if-eqz p1, :cond_1d

    .line 21
    .line 22
    iget-object p1, p1, Lb4/d;->a:Ljava/lang/String;

    .line 23
    .line 24
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    if-eqz p1, :cond_21

    .line 29
    .line 30
    :cond_1d
    const/4 p1, 0x1

    .line 31
    invoke-virtual {p0, p1}, Lb4/e;->g(Z)V

    .line 32
    .line 33
    .line 34
    :cond_21
    return-void
.end method

.method public final g(Z)V
    .registers 5

    .line 1
    const/4 v0, 0x1

    .line 2
    new-array v0, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    if-eqz p1, :cond_8

    .line 5
    .line 6
    const-string v1, "ok"

    .line 7
    .line 8
    goto :goto_a

    .line 9
    :cond_8
    const-string v1, "failed"

    .line 10
    .line 11
    :goto_a
    const/4 v2, 0x0

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const-string v1, "fileUpload completed %s"

    .line 15
    .line 16
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 21
    .line 22
    invoke-static {}, Lc4/a;->a()Lc4/a;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0, p0}, Lc4/a;->c(Lb4/a;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lb4/e;->i:Lb4/h;

    .line 30
    .line 31
    invoke-virtual {v0}, Lb4/h;->h()V

    .line 32
    .line 33
    .line 34
    iget-object v0, p0, Lb4/e;->d:Lc4/c;

    .line 35
    .line 36
    invoke-interface {v0, p1}, Lc4/c;->a(Z)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public h(Lb4/d;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    new-array v0, v0, [Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v1, p1, Lb4/d;->a:Ljava/lang/String;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    aput-object v1, v0, v2

    .line 13
    .line 14
    const-string v1, "new task join download queue %s"

    .line 15
    .line 16
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 20
    .line 21
    iput v2, p0, Lb4/e;->c:I

    .line 22
    .line 23
    iget-object p1, p0, Lb4/e;->i:Lb4/h;

    .line 24
    .line 25
    invoke-virtual {p1, p0}, Lb4/h;->f(Le4/c;)Le4/b;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    iput-object p1, p0, Lb4/e;->b:Le4/b;

    .line 30
    .line 31
    invoke-interface {p1}, Le4/b;->a()V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public i(ILjava/lang/String;)V
    .registers 8

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 5
    .line 6
    .line 7
    move-result-object v2

    .line 8
    const/4 v3, 0x0

    .line 9
    aput-object v2, v1, v3

    .line 10
    .line 11
    const/4 v2, 0x1

    .line 12
    aput-object p2, v1, v2

    .line 13
    .line 14
    const-string v4, "general error %d %s"

    .line 15
    .line 16
    invoke-static {v4, v1}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Lb4/e;->e:Lb4/d;

    .line 20
    .line 21
    if-eqz v1, :cond_5a

    .line 22
    .line 23
    iget-object v1, v1, Lb4/d;->a:Ljava/lang/String;

    .line 24
    .line 25
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-nez v1, :cond_1f

    .line 30
    .line 31
    goto :goto_5a

    .line 32
    :cond_1f
    if-eq p1, v2, :cond_51

    .line 33
    .line 34
    const/16 v1, 0x10

    .line 35
    .line 36
    if-eq p1, v1, :cond_48

    .line 37
    .line 38
    const/4 v1, 0x3

    .line 39
    new-array v1, v1, [Ljava/lang/Object;

    .line 40
    .line 41
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    aput-object p1, v1, v3

    .line 46
    .line 47
    aput-object p2, v1, v2

    .line 48
    .line 49
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 50
    .line 51
    invoke-virtual {p1}, Lb4/d;->d()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    aput-object p1, v1, v0

    .line 56
    .line 57
    const-string p1, "unknown error %d %s %s"

    .line 58
    .line 59
    invoke-static {p1, v1}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 63
    .line 64
    const/16 p2, 0x110

    .line 65
    .line 66
    invoke-virtual {p1, p2}, Lb4/d;->g(I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p0, v3}, Lb4/e;->g(Z)V

    .line 70
    .line 71
    .line 72
    goto :goto_59

    .line 73
    :cond_48
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 74
    .line 75
    invoke-virtual {p1, v1}, Lb4/d;->g(I)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, v3}, Lb4/e;->g(Z)V

    .line 79
    .line 80
    .line 81
    goto :goto_59

    .line 82
    :cond_51
    iget-object p1, p0, Lb4/e;->e:Lb4/d;

    .line 83
    .line 84
    invoke-virtual {p1, v2}, Lb4/d;->g(I)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0, v3}, Lb4/e;->g(Z)V

    .line 88
    .line 89
    .line 90
    :goto_59
    return-void

    .line 91
    :cond_5a
    :goto_5a
    new-array v0, v0, [Ljava/lang/Object;

    .line 92
    .line 93
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    aput-object p1, v0, v3

    .line 98
    .line 99
    aput-object p2, v0, v2

    .line 100
    .line 101
    const-string p1, "ignore error %d %s"

    .line 102
    .line 103
    invoke-static {p1, v0}, Ld4/a;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    return-void
.end method

.method public final j()V
    .registers 6

    .line 1
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iget v1, p0, Lb4/e;->c:I

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    add-int/2addr v1, v2

    .line 10
    iput v1, p0, Lb4/e;->c:I

    .line 11
    .line 12
    const/4 v3, 0x3

    .line 13
    const/4 v4, 0x0

    .line 14
    if-gt v3, v1, :cond_18

    .line 15
    .line 16
    const/16 v1, 0x22

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lb4/d;->g(I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v4}, Lb4/e;->g(Z)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    new-array v0, v2, [Ljava/lang/Object;

    .line 26
    .line 27
    const-wide/16 v1, 0x2

    .line 28
    .line 29
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    aput-object v1, v0, v4

    .line 34
    .line 35
    const-string v1, "resume connection %d seconds later"

    .line 36
    .line 37
    invoke-static {v1, v0}, Ld4/a;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iget-object v0, p0, Lb4/e;->b:Le4/b;

    .line 41
    .line 42
    const-wide/16 v1, 0x7d0

    .line 43
    .line 44
    invoke-interface {v0, v1, v2}, Le4/b;->c(J)V

    .line 45
    .line 46
    .line 47
    return-void
.end method

.method public final k()V
    .registers 4

    .line 1
    iget-object v0, p0, Lb4/e;->e:Lb4/d;

    .line 2
    .line 3
    invoke-virtual {v0}, Lb4/d;->c()Lcom/beetalklib/network/file/protocol/ImageDownloadRequest;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Le4/f;

    .line 8
    .line 9
    invoke-virtual {v0}, Lcom/squareup/wire/Message;->toByteArray()[B

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const/4 v2, 0x2

    .line 14
    invoke-direct {v1, v2, v0}, Le4/f;-><init>(I[B)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Lb4/e;->b:Le4/b;

    .line 18
    .line 19
    invoke-interface {v0, v1}, Le4/b;->b(Le4/f;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
