###### Class b4.j (b4.j)
.class public Lb4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/g;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:I

.field public f:[B

.field public g:Lb4/i;

.field public h:I

.field public i:I

.field public j:I


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILb4/i;)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lb4/j;->f:[B

    .line 6
    .line 7
    const/16 v0, 0x1000

    .line 8
    .line 9
    iput v0, p0, Lb4/j;->h:I

    .line 10
    .line 11
    iput-object p4, p0, Lb4/j;->d:Ljava/lang/String;

    .line 12
    .line 13
    if-lez p6, :cond_10

    .line 14
    .line 15
    iput p6, p0, Lb4/j;->h:I

    .line 16
    .line 17
    :cond_10
    move-object v0, p0

    .line 18
    move-object v1, p1

    .line 19
    move v2, p2

    .line 20
    move-object v3, p3

    .line 21
    move-object v4, p5

    .line 22
    move-object v5, p7

    .line 23
    invoke-virtual/range {v0 .. v5}, Lb4/j;->h(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lb4/i;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public a()I
    .registers 2

    const/4 v0, 0x1

    return v0
.end method

.method public b()I
    .registers 2

    iget v0, p0, Lb4/j;->i:I

    return v0
.end method

.method public c()Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader;
    .registers 3

    .line 1
    new-instance v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lb4/j;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->Name:Ljava/lang/String;

    .line 9
    .line 10
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->RequestId:Ljava/lang/String;

    .line 11
    .line 12
    const/16 v1, 0x3e8

    .line 13
    .line 14
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->Timeout:Ljava/lang/Integer;

    .line 19
    .line 20
    iget-object v1, p0, Lb4/j;->b:Ljava/lang/String;

    .line 21
    .line 22
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->Token:Ljava/lang/String;

    .line 23
    .line 24
    iget v1, p0, Lb4/j;->i:I

    .line 25
    .line 26
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->TotalBlock:Ljava/lang/Integer;

    .line 31
    .line 32
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->Thumb(Ljava/lang/Boolean;)Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;

    .line 35
    .line 36
    .line 37
    const-string v1, "f"

    .line 38
    .line 39
    iput-object v1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->Type:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v0}, Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader$Builder;->build()Lcom/beetalklib/network/file/protocol/ImageUploadRequestHeader;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    return-object v0
.end method

.method public d()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lb4/j;->c:Ljava/lang/String;

    return-object v0
.end method

.method public e(I)Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart;
    .registers 7

    .line 1
    add-int/lit8 v0, p1, -0x1

    .line 2
    .line 3
    iput v0, p0, Lb4/j;->j:I

    .line 4
    .line 5
    iget v0, p0, Lb4/j;->h:I

    .line 6
    .line 7
    mul-int v0, v0, p1

    .line 8
    .line 9
    iget v1, p0, Lb4/j;->i:I

    .line 10
    .line 11
    if-lt p1, v1, :cond_1c

    .line 12
    .line 13
    iget-object p1, p0, Lb4/j;->g:Lb4/i;

    .line 14
    .line 15
    iget-object v0, p0, Lb4/j;->f:[B

    .line 16
    .line 17
    array-length v1, v0

    .line 18
    array-length v0, v0

    .line 19
    invoke-interface {p1, v1, v0}, Lb4/i;->a(II)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p0, Lb4/j;->g:Lb4/i;

    .line 23
    .line 24
    invoke-interface {p1}, Lb4/i;->onFinish()V

    .line 25
    .line 26
    .line 27
    const/4 p1, 0x0

    .line 28
    return-object p1

    .line 29
    :cond_1c
    iget-object v1, p0, Lb4/j;->g:Lb4/i;

    .line 30
    .line 31
    iget-object v2, p0, Lb4/j;->f:[B

    .line 32
    .line 33
    array-length v2, v2

    .line 34
    invoke-interface {v1, v2, v0}, Lb4/i;->a(II)V

    .line 35
    .line 36
    .line 37
    iget-object v1, p0, Lb4/j;->f:[B

    .line 38
    .line 39
    array-length v2, v1

    .line 40
    iget v3, p0, Lb4/j;->h:I

    .line 41
    .line 42
    add-int v4, v0, v3

    .line 43
    .line 44
    if-lt v2, v4, :cond_2f

    .line 45
    .line 46
    add-int/2addr v3, v0

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    array-length v3, v1

    .line 49
    :goto_30
    sub-int/2addr v3, v0

    .line 50
    new-array v2, v3, [B

    .line 51
    .line 52
    const/4 v4, 0x0

    .line 53
    invoke-static {v1, v0, v2, v4, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 54
    .line 55
    .line 56
    new-instance v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;

    .line 57
    .line 58
    invoke-direct {v0}, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;-><init>()V

    .line 59
    .line 60
    .line 61
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iput-object p1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;->PartId:Ljava/lang/Integer;

    .line 66
    .line 67
    invoke-static {v2}, Lokio/ByteString;->of([B)Lokio/ByteString;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iput-object p1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;->Content:Lokio/ByteString;

    .line 72
    .line 73
    iget-object p1, p0, Lb4/j;->a:Ljava/lang/String;

    .line 74
    .line 75
    iput-object p1, v0, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;->RequestId:Ljava/lang/String;

    .line 76
    .line 77
    invoke-virtual {v0}, Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart$Builder;->build()Lcom/beetalklib/network/file/protocol/ImageUploadRequestPart;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    instance-of v0, p1, Lb4/j;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2e

    .line 5
    .line 6
    check-cast p1, Lb4/j;

    .line 7
    .line 8
    invoke-virtual {p1}, Lb4/j;->d()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    iget-object v2, p0, Lb4/j;->c:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_2e

    .line 19
    .line 20
    iget v0, p1, Lb4/j;->e:I

    .line 21
    .line 22
    iget v2, p0, Lb4/j;->e:I

    .line 23
    .line 24
    if-ne v0, v2, :cond_2e

    .line 25
    .line 26
    iget-object v0, p0, Lb4/j;->g:Lb4/i;

    .line 27
    .line 28
    iget-object v2, p1, Lb4/j;->g:Lb4/i;

    .line 29
    .line 30
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_2e

    .line 35
    .line 36
    iget-object v0, p0, Lb4/j;->a:Ljava/lang/String;

    .line 37
    .line 38
    iget-object p1, p1, Lb4/j;->a:Ljava/lang/String;

    .line 39
    .line 40
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result p1

    .line 44
    if-eqz p1, :cond_2e

    .line 45
    .line 46
    const/4 v1, 0x1

    .line 47
    :cond_2e
    return v1
.end method

.method public f()I
    .registers 2

    iget v0, p0, Lb4/j;->e:I

    return v0
.end method

.method public g()I
    .registers 2

    iget v0, p0, Lb4/j;->j:I

    return v0
.end method

.method public final h(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lb4/i;)V
    .registers 6

    .line 1
    iput-object p3, p0, Lb4/j;->a:Ljava/lang/String;

    .line 2
    .line 3
    iput-object p4, p0, Lb4/j;->b:Ljava/lang/String;

    .line 4
    .line 5
    iput-object p5, p0, Lb4/j;->g:Lb4/i;

    .line 6
    .line 7
    iput-object p1, p0, Lb4/j;->c:Ljava/lang/String;

    .line 8
    .line 9
    iput p2, p0, Lb4/j;->e:I

    .line 10
    .line 11
    const/4 p1, -0x1

    .line 12
    iput p1, p0, Lb4/j;->j:I

    .line 13
    .line 14
    return-void
.end method

.method public i(I)V
    .registers 3

    iget-object v0, p0, Lb4/j;->g:Lb4/i;

    invoke-interface {v0, p1}, Lb4/i;->onError(I)V

    return-void
.end method

.method public j()Z
    .registers 7

    .line 1
    iget-object v0, p0, Lb4/j;->f:[B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_76

    .line 5
    .line 6
    iget-object v0, p0, Lb4/j;->d:Ljava/lang/String;

    .line 7
    .line 8
    if-nez v0, :cond_b

    .line 9
    .line 10
    goto/16 :goto_76

    .line 11
    .line 12
    :cond_b
    new-instance v0, Ljava/io/File;

    .line 13
    .line 14
    iget-object v2, p0, Lb4/j;->d:Ljava/lang/String;

    .line 15
    .line 16
    invoke-direct {v0, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-nez v2, :cond_19

    .line 24
    .line 25
    return v1

    .line 26
    :cond_19
    const/4 v2, 0x0

    .line 27
    :try_start_1a
    new-instance v3, Ljava/io/FileInputStream;

    .line 28
    .line 29
    invoke-direct {v3, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_1f
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_1f} :catch_5c
    .catchall {:try_start_1a .. :try_end_1f} :catchall_5a

    .line 30
    .line 31
    .line 32
    const/16 v0, 0x1000

    .line 33
    .line 34
    :try_start_21
    new-array v0, v0, [B

    .line 35
    .line 36
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    .line 37
    .line 38
    invoke-direct {v2}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 39
    .line 40
    .line 41
    :goto_28
    invoke-virtual {v3, v0}, Ljava/io/FileInputStream;->read([B)I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    const/4 v5, -0x1

    .line 46
    if-eq v4, v5, :cond_33

    .line 47
    .line 48
    invoke-virtual {v2, v0, v1, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    .line 49
    .line 50
    .line 51
    goto :goto_28

    .line 52
    :cond_33
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    iput-object v0, p0, Lb4/j;->f:[B

    .line 57
    .line 58
    array-length v0, v0

    .line 59
    int-to-float v0, v0

    .line 60
    iget v2, p0, Lb4/j;->h:I

    .line 61
    .line 62
    int-to-float v2, v2

    .line 63
    div-float/2addr v0, v2

    .line 64
    float-to-double v4, v0

    .line 65
    invoke-static {v4, v5}, Ljava/lang/Math;->ceil(D)D

    .line 66
    .line 67
    .line 68
    move-result-wide v4

    .line 69
    double-to-int v0, v4

    .line 70
    iput v0, p0, Lb4/j;->i:I

    .line 71
    .line 72
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V
    :try_end_4a
    .catch Ljava/io/IOException; {:try_start_21 .. :try_end_4a} :catch_57
    .catchall {:try_start_21 .. :try_end_4a} :catchall_54

    .line 73
    .line 74
    .line 75
    const/4 v0, 0x1

    .line 76
    :try_start_4b
    invoke-virtual {v3}, Ljava/io/FileInputStream;->close()V
    :try_end_4e
    .catch Ljava/io/IOException; {:try_start_4b .. :try_end_4e} :catch_4f

    .line 77
    .line 78
    .line 79
    goto :goto_53

    .line 80
    :catch_4f
    move-exception v1

    .line 81
    invoke-static {v1}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 82
    .line 83
    .line 84
    :goto_53
    return v0

    .line 85
    :catchall_54
    move-exception v0

    .line 86
    move-object v2, v3

    .line 87
    goto :goto_6b

    .line 88
    :catch_57
    move-exception v0

    .line 89
    move-object v2, v3

    .line 90
    goto :goto_5d

    .line 91
    :catchall_5a
    move-exception v0

    .line 92
    goto :goto_6b

    .line 93
    :catch_5c
    move-exception v0

    .line 94
    :goto_5d
    :try_start_5d
    invoke-static {v0}, Ld4/a;->a(Ljava/lang/Exception;)V
    :try_end_60
    .catchall {:try_start_5d .. :try_end_60} :catchall_5a

    .line 95
    .line 96
    .line 97
    if-eqz v2, :cond_6a

    .line 98
    .line 99
    :try_start_62
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_65
    .catch Ljava/io/IOException; {:try_start_62 .. :try_end_65} :catch_66

    .line 100
    .line 101
    .line 102
    goto :goto_6a

    .line 103
    :catch_66
    move-exception v0

    .line 104
    invoke-static {v0}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 105
    .line 106
    .line 107
    :cond_6a
    :goto_6a
    return v1

    .line 108
    :goto_6b
    if-eqz v2, :cond_75

    .line 109
    .line 110
    :try_start_6d
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_70
    .catch Ljava/io/IOException; {:try_start_6d .. :try_end_70} :catch_71

    .line 111
    .line 112
    .line 113
    goto :goto_75

    .line 114
    :catch_71
    move-exception v1

    .line 115
    invoke-static {v1}, Ld4/a;->a(Ljava/lang/Exception;)V

    .line 116
    .line 117
    .line 118
    :cond_75
    :goto_75
    throw v0

    .line 119
    :cond_76
    :goto_76
    return v1
.end method
