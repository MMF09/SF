###### Class b4.c (b4.c)
.class public interface abstract Lb4/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a([B)V
.end method

.method public abstract onError(I)V
.end method
