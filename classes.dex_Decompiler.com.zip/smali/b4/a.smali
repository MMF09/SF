###### Class b4.a (b4.a)
.class public interface abstract Lb4/a;
.super Ljava/lang/Object;
.source "SourceFile"
