###### Class v3.b (v3.b)
.class public Lv3/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lu3/f;


# instance fields
.field public final a:Lv3/g;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public final b:Lv3/a;

.field public final c:Lv3/c;


# direct methods
.method public constructor <init>(Lv3/a;)V
    .registers 4

    .line 1
    new-instance v0, Lv3/c;

    const/16 v1, 0x1000

    invoke-direct {v0, v1}, Lv3/c;-><init>(I)V

    invoke-direct {p0, p1, v0}, Lv3/b;-><init>(Lv3/a;Lv3/c;)V

    return-void
.end method

.method public constructor <init>(Lv3/a;Lv3/c;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lv3/b;->b:Lv3/a;

    .line 4
    iput-object p1, p0, Lv3/b;->a:Lv3/g;

    .line 5
    iput-object p2, p0, Lv3/b;->c:Lv3/c;

    return-void
.end method


# virtual methods
.method public a(Lcom/android/volley/Request;)Lu3/h;
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/volley/Request<",
            "*>;)",
            "Lu3/h;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lu3/p;
        }
    .end annotation

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v8, p1

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 6
    .line 7
    .line 8
    move-result-wide v9

    .line 9
    :goto_8
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    :try_start_c
    invoke-virtual/range {p1 .. p1}, Lcom/android/volley/Request;->getCacheEntry()Lcom/android/volley/a$a;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    invoke-static {v0}, Lv3/e;->c(Lcom/android/volley/a$a;)Ljava/util/Map;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v3, v1, Lv3/b;->b:Lv3/a;

    .line 22
    .line 23
    invoke-virtual {v3, v8, v0}, Lv3/a;->a(Lcom/android/volley/Request;Ljava/util/Map;)Lv3/f;

    .line 24
    .line 25
    .line 26
    move-result-object v3
    :try_end_1a
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_1a} :catch_70

    .line 27
    :try_start_1a
    invoke-virtual {v3}, Lv3/f;->d()I

    .line 28
    .line 29
    .line 30
    move-result v12

    .line 31
    invoke-virtual {v3}, Lv3/f;->c()Ljava/util/List;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    const/16 v4, 0x130

    .line 36
    .line 37
    if-ne v12, v4, :cond_30

    .line 38
    .line 39
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 40
    .line 41
    .line 42
    move-result-wide v4

    .line 43
    sub-long/2addr v4, v9

    .line 44
    invoke-static {v8, v4, v5, v0}, Lv3/l;->b(Lcom/android/volley/Request;JLjava/util/List;)Lu3/h;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0

    .line 49
    :cond_30
    invoke-virtual {v3}, Lv3/f;->a()Ljava/io/InputStream;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    if-eqz v4, :cond_41

    .line 54
    .line 55
    invoke-virtual {v3}, Lv3/f;->b()I

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    iget-object v6, v1, Lv3/b;->c:Lv3/c;

    .line 60
    .line 61
    invoke-static {v4, v5, v6}, Lv3/l;->c(Ljava/io/InputStream;ILv3/c;)[B

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    goto :goto_44

    .line 66
    :cond_41
    const/4 v4, 0x0

    .line 67
    new-array v2, v4, [B

    .line 68
    .line 69
    :goto_44
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 70
    .line 71
    .line 72
    move-result-wide v4

    .line 73
    sub-long/2addr v4, v9

    .line 74
    invoke-static {v4, v5, v8, v2, v12}, Lv3/l;->d(JLcom/android/volley/Request;[BI)V

    .line 75
    .line 76
    .line 77
    const/16 v4, 0xc8

    .line 78
    .line 79
    if-lt v12, v4, :cond_65

    .line 80
    .line 81
    const/16 v4, 0x12b

    .line 82
    .line 83
    if-gt v12, v4, :cond_65

    .line 84
    .line 85
    new-instance v4, Lu3/h;

    .line 86
    .line 87
    const/4 v14, 0x0

    .line 88
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 89
    .line 90
    .line 91
    move-result-wide v5

    .line 92
    sub-long v15, v5, v9

    .line 93
    .line 94
    move-object v11, v4

    .line 95
    move-object v13, v2

    .line 96
    move-object/from16 v17, v0

    .line 97
    .line 98
    invoke-direct/range {v11 .. v17}, Lu3/h;-><init>(I[BZJLjava/util/List;)V

    .line 99
    .line 100
    .line 101
    return-object v4

    .line 102
    :cond_65
    new-instance v0, Ljava/io/IOException;

    .line 103
    .line 104
    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    .line 105
    .line 106
    .line 107
    throw v0
    :try_end_6b
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_6b} :catch_6b

    .line 108
    :catch_6b
    move-exception v0

    .line 109
    move-object v7, v2

    .line 110
    move-object v6, v3

    .line 111
    move-object v3, v0

    .line 112
    goto :goto_74

    .line 113
    :catch_70
    move-exception v0

    .line 114
    move-object v3, v0

    .line 115
    move-object v6, v2

    .line 116
    move-object v7, v6

    .line 117
    :goto_74
    move-object/from16 v2, p1

    .line 118
    .line 119
    move-wide v4, v9

    .line 120
    invoke-static/range {v2 .. v7}, Lv3/l;->e(Lcom/android/volley/Request;Ljava/io/IOException;JLv3/f;[B)Lv3/l$b;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    invoke-static {v8, v0}, Lv3/l;->a(Lcom/android/volley/Request;Lv3/l$b;)V

    .line 125
    .line 126
    .line 127
    goto :goto_8
.end method
