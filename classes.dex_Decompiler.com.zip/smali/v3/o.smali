###### Class v3.o (v3.o)
.class public Lv3/o;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/content/Context;)Lu3/k;
    .registers 2
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lv3/o;->c(Landroid/content/Context;Lv3/a;)Lu3/k;

    move-result-object p0

    return-object p0
.end method

.method public static b(Landroid/content/Context;Lu3/f;)Lu3/k;
    .registers 4
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    new-instance v0, Lv3/o$a;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Lv3/o$a;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    new-instance p0, Lu3/k;

    .line 11
    .line 12
    new-instance v1, Lv3/d;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Lv3/d;-><init>(Lv3/d$c;)V

    .line 15
    .line 16
    .line 17
    invoke-direct {p0, v1, p1}, Lu3/k;-><init>(Lcom/android/volley/a;Lu3/f;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lu3/k;->g()V

    .line 21
    .line 22
    .line 23
    return-object p0
.end method

.method public static c(Landroid/content/Context;Lv3/a;)Lu3/k;
    .registers 3
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    .line 1
    if-nez p1, :cond_d

    .line 2
    .line 3
    new-instance p1, Lv3/b;

    .line 4
    .line 5
    new-instance v0, Lv3/h;

    .line 6
    .line 7
    invoke-direct {v0}, Lv3/h;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-direct {p1, v0}, Lv3/b;-><init>(Lv3/a;)V

    .line 11
    .line 12
    .line 13
    goto :goto_13

    .line 14
    :cond_d
    new-instance v0, Lv3/b;

    .line 15
    .line 16
    invoke-direct {v0, p1}, Lv3/b;-><init>(Lv3/a;)V

    .line 17
    .line 18
    .line 19
    move-object p1, v0

    .line 20
    :goto_13
    invoke-static {p0, p1}, Lv3/o;->b(Landroid/content/Context;Lu3/f;)Lu3/k;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

###### Class v3.o.a (v3.o$a)
.class public Lv3/o$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv3/d$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lv3/o;->b(Landroid/content/Context;Lu3/f;)Lu3/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Ljava/io/File;

.field public final synthetic b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lv3/o$a;->b:Landroid/content/Context;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, Lv3/o$a;->a:Ljava/io/File;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public get()Ljava/io/File;
    .registers 4

    .line 1
    iget-object v0, p0, Lv3/o$a;->a:Ljava/io/File;

    .line 2
    .line 3
    if-nez v0, :cond_13

    .line 4
    .line 5
    new-instance v0, Ljava/io/File;

    .line 6
    .line 7
    iget-object v1, p0, Lv3/o$a;->b:Landroid/content/Context;

    .line 8
    .line 9
    invoke-virtual {v1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const-string v2, "volley"

    .line 14
    .line 15
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lv3/o$a;->a:Ljava/io/File;

    .line 19
    .line 20
    :cond_13
    iget-object v0, p0, Lv3/o$a;->a:Ljava/io/File;

    .line 21
    .line 22
    return-object v0
.end method
