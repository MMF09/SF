###### Class v3.d (v3.d)
.class public Lv3/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/android/volley/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lv3/d$b;,
        Lv3/d$a;,
        Lv3/d$c;
    }
.end annotation


# instance fields
.field public final a:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lv3/d$a;",
            ">;"
        }
    .end annotation
.end field

.field public b:J

.field public final c:Lv3/d$c;

.field public final d:I


# direct methods
.method public constructor <init>(Lv3/d$c;)V
    .registers 3

    const/high16 v0, 0x500000

    .line 6
    invoke-direct {p0, p1, v0}, Lv3/d;-><init>(Lv3/d$c;I)V

    return-void
.end method

.method public constructor <init>(Lv3/d$c;I)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Ljava/util/LinkedHashMap;

    const/16 v1, 0x10

    const/high16 v2, 0x3f400000    # 0.75f

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2, v3}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    const-wide/16 v0, 0x0

    .line 3
    iput-wide v0, p0, Lv3/d;->b:J

    .line 4
    iput-object p1, p0, Lv3/d;->c:Lv3/d$c;

    .line 5
    iput p2, p0, Lv3/d;->d:I

    return-void
.end method

.method public static j(Ljava/io/InputStream;)I
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 v0, -0x1

    .line 6
    if-eq p0, v0, :cond_8

    .line 7
    .line 8
    return p0

    .line 9
    :cond_8
    new-instance p0, Ljava/io/EOFException;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/io/EOFException;-><init>()V

    .line 12
    .line 13
    .line 14
    throw p0
.end method

.method public static k(Lv3/d$b;)Ljava/util/List;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lv3/d$b;",
            ")",
            "Ljava/util/List<",
            "Lu3/e;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lv3/d;->l(Ljava/io/InputStream;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-ltz v0, :cond_31

    .line 6
    .line 7
    if-nez v0, :cond_d

    .line 8
    .line 9
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    goto :goto_12

    .line 14
    :cond_d
    new-instance v1, Ljava/util/ArrayList;

    .line 15
    .line 16
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 17
    .line 18
    .line 19
    :goto_12
    const/4 v2, 0x0

    .line 20
    :goto_13
    if-ge v2, v0, :cond_30

    .line 21
    .line 22
    invoke-static {p0}, Lv3/d;->n(Lv3/d$b;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-virtual {v3}, Ljava/lang/String;->intern()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    invoke-static {p0}, Lv3/d;->n(Lv3/d$b;)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    invoke-virtual {v4}, Ljava/lang/String;->intern()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v4

    .line 38
    new-instance v5, Lu3/e;

    .line 39
    .line 40
    invoke-direct {v5, v3, v4}, Lu3/e;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    invoke-interface {v1, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    add-int/lit8 v2, v2, 0x1

    .line 47
    .line 48
    goto :goto_13

    .line 49
    :cond_30
    return-object v1

    .line 50
    :cond_31
    new-instance p0, Ljava/io/IOException;

    .line 51
    .line 52
    new-instance v1, Ljava/lang/StringBuilder;

    .line 53
    .line 54
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 55
    .line 56
    .line 57
    const-string v2, "readHeaderList size="

    .line 58
    .line 59
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw p0
.end method

.method public static l(Ljava/io/InputStream;)I
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    shl-int/lit8 v0, v0, 0x0

    .line 6
    .line 7
    or-int/lit8 v0, v0, 0x0

    .line 8
    .line 9
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    shl-int/lit8 v1, v1, 0x8

    .line 14
    .line 15
    or-int/2addr v0, v1

    .line 16
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    shl-int/lit8 v1, v1, 0x10

    .line 21
    .line 22
    or-int/2addr v0, v1

    .line 23
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    shl-int/lit8 p0, p0, 0x18

    .line 28
    .line 29
    or-int/2addr p0, v0

    .line 30
    return p0
.end method

.method public static m(Ljava/io/InputStream;)J
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    int-to-long v0, v0

    .line 6
    const-wide/16 v2, 0xff

    .line 7
    .line 8
    and-long/2addr v0, v2

    .line 9
    const/4 v4, 0x0

    .line 10
    shl-long/2addr v0, v4

    .line 11
    const-wide/16 v4, 0x0

    .line 12
    .line 13
    or-long/2addr v0, v4

    .line 14
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    int-to-long v4, v4

    .line 19
    and-long/2addr v4, v2

    .line 20
    const/16 v6, 0x8

    .line 21
    .line 22
    shl-long/2addr v4, v6

    .line 23
    or-long/2addr v0, v4

    .line 24
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    int-to-long v4, v4

    .line 29
    and-long/2addr v4, v2

    .line 30
    const/16 v6, 0x10

    .line 31
    .line 32
    shl-long/2addr v4, v6

    .line 33
    or-long/2addr v0, v4

    .line 34
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    int-to-long v4, v4

    .line 39
    and-long/2addr v4, v2

    .line 40
    const/16 v6, 0x18

    .line 41
    .line 42
    shl-long/2addr v4, v6

    .line 43
    or-long/2addr v0, v4

    .line 44
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 45
    .line 46
    .line 47
    move-result v4

    .line 48
    int-to-long v4, v4

    .line 49
    and-long/2addr v4, v2

    .line 50
    const/16 v6, 0x20

    .line 51
    .line 52
    shl-long/2addr v4, v6

    .line 53
    or-long/2addr v0, v4

    .line 54
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    int-to-long v4, v4

    .line 59
    and-long/2addr v4, v2

    .line 60
    const/16 v6, 0x28

    .line 61
    .line 62
    shl-long/2addr v4, v6

    .line 63
    or-long/2addr v0, v4

    .line 64
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    int-to-long v4, v4

    .line 69
    and-long/2addr v4, v2

    .line 70
    const/16 v6, 0x30

    .line 71
    .line 72
    shl-long/2addr v4, v6

    .line 73
    or-long/2addr v0, v4

    .line 74
    invoke-static {p0}, Lv3/d;->j(Ljava/io/InputStream;)I

    .line 75
    .line 76
    .line 77
    move-result p0

    .line 78
    int-to-long v4, p0

    .line 79
    and-long/2addr v2, v4

    .line 80
    const/16 p0, 0x38

    .line 81
    .line 82
    shl-long/2addr v2, p0

    .line 83
    or-long/2addr v0, v2

    .line 84
    return-wide v0
.end method

.method public static n(Lv3/d$b;)Ljava/lang/String;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lv3/d;->m(Ljava/io/InputStream;)J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    invoke-static {p0, v0, v1}, Lv3/d;->q(Lv3/d$b;J)[B

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    new-instance v0, Ljava/lang/String;

    .line 10
    .line 11
    const-string v1, "UTF-8"

    .line 12
    .line 13
    invoke-direct {v0, p0, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public static q(Lv3/d$b;J)[B
    .registers 9
    .annotation build Landroidx/annotation/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lv3/d$b;->b()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    const-wide/16 v2, 0x0

    .line 6
    .line 7
    cmp-long v4, p1, v2

    .line 8
    .line 9
    if-ltz v4, :cond_1f

    .line 10
    .line 11
    cmp-long v2, p1, v0

    .line 12
    .line 13
    if-gtz v2, :cond_1f

    .line 14
    .line 15
    long-to-int v2, p1

    .line 16
    int-to-long v3, v2

    .line 17
    cmp-long v5, v3, p1

    .line 18
    .line 19
    if-nez v5, :cond_1f

    .line 20
    .line 21
    new-array p1, v2, [B

    .line 22
    .line 23
    new-instance p2, Ljava/io/DataInputStream;

    .line 24
    .line 25
    invoke-direct {p2, p0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p2, p1}, Ljava/io/DataInputStream;->readFully([B)V

    .line 29
    .line 30
    .line 31
    return-object p1

    .line 32
    :cond_1f
    new-instance p0, Ljava/io/IOException;

    .line 33
    .line 34
    new-instance v2, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 37
    .line 38
    .line 39
    const-string v3, "streamToBytes length="

    .line 40
    .line 41
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string p1, ", maxLength="

    .line 48
    .line 49
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    throw p0
.end method

.method public static r(Ljava/util/List;Ljava/io/OutputStream;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lu3/e;",
            ">;",
            "Ljava/io/OutputStream;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    if-eqz p0, :cond_28

    .line 2
    .line 3
    invoke-interface {p0}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-static {p1, v0}, Lv3/d;->s(Ljava/io/OutputStream;I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    :goto_d
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_2c

    .line 19
    .line 20
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    check-cast v0, Lu3/e;

    .line 25
    .line 26
    invoke-virtual {v0}, Lu3/e;->a()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    invoke-static {p1, v1}, Lv3/d;->u(Ljava/io/OutputStream;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, Lu3/e;->b()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {p1, v0}, Lv3/d;->u(Ljava/io/OutputStream;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    goto :goto_d

    .line 41
    :cond_28
    const/4 p0, 0x0

    .line 42
    invoke-static {p1, p0}, Lv3/d;->s(Ljava/io/OutputStream;I)V

    .line 43
    .line 44
    .line 45
    :cond_2c
    return-void
.end method

.method public static s(Ljava/io/OutputStream;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    shr-int/lit8 v0, p1, 0x0

    .line 2
    .line 3
    and-int/lit16 v0, v0, 0xff

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 6
    .line 7
    .line 8
    shr-int/lit8 v0, p1, 0x8

    .line 9
    .line 10
    and-int/lit16 v0, v0, 0xff

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 13
    .line 14
    .line 15
    shr-int/lit8 v0, p1, 0x10

    .line 16
    .line 17
    and-int/lit16 v0, v0, 0xff

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 20
    .line 21
    .line 22
    shr-int/lit8 p1, p1, 0x18

    .line 23
    .line 24
    and-int/lit16 p1, p1, 0xff

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Ljava/io/OutputStream;->write(I)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static t(Ljava/io/OutputStream;J)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    ushr-long v0, p1, v0

    .line 3
    .line 4
    long-to-int v1, v0

    .line 5
    int-to-byte v0, v1

    .line 6
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 7
    .line 8
    .line 9
    const/16 v0, 0x8

    .line 10
    .line 11
    ushr-long v0, p1, v0

    .line 12
    .line 13
    long-to-int v1, v0

    .line 14
    int-to-byte v0, v1

    .line 15
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 16
    .line 17
    .line 18
    const/16 v0, 0x10

    .line 19
    .line 20
    ushr-long v0, p1, v0

    .line 21
    .line 22
    long-to-int v1, v0

    .line 23
    int-to-byte v0, v1

    .line 24
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 25
    .line 26
    .line 27
    const/16 v0, 0x18

    .line 28
    .line 29
    ushr-long v0, p1, v0

    .line 30
    .line 31
    long-to-int v1, v0

    .line 32
    int-to-byte v0, v1

    .line 33
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 34
    .line 35
    .line 36
    const/16 v0, 0x20

    .line 37
    .line 38
    ushr-long v0, p1, v0

    .line 39
    .line 40
    long-to-int v1, v0

    .line 41
    int-to-byte v0, v1

    .line 42
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 43
    .line 44
    .line 45
    const/16 v0, 0x28

    .line 46
    .line 47
    ushr-long v0, p1, v0

    .line 48
    .line 49
    long-to-int v1, v0

    .line 50
    int-to-byte v0, v1

    .line 51
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 52
    .line 53
    .line 54
    const/16 v0, 0x30

    .line 55
    .line 56
    ushr-long v0, p1, v0

    .line 57
    .line 58
    long-to-int v1, v0

    .line 59
    int-to-byte v0, v1

    .line 60
    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write(I)V

    .line 61
    .line 62
    .line 63
    const/16 v0, 0x38

    .line 64
    .line 65
    ushr-long/2addr p1, v0

    .line 66
    long-to-int p2, p1

    .line 67
    int-to-byte p1, p2

    .line 68
    invoke-virtual {p0, p1}, Ljava/io/OutputStream;->write(I)V

    .line 69
    .line 70
    .line 71
    return-void
.end method

.method public static u(Ljava/io/OutputStream;Ljava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const-string v0, "UTF-8"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    array-length v0, p1

    .line 8
    int-to-long v0, v0

    .line 9
    invoke-static {p0, v0, v1}, Lv3/d;->t(Ljava/io/OutputStream;J)V

    .line 10
    .line 11
    .line 12
    array-length v0, p1

    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-virtual {p0, p1, v1, v0}, Ljava/io/OutputStream;->write([BII)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public declared-synchronized a(Ljava/lang/String;Z)V
    .registers 6

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0, p1}, Lv3/d;->get(Ljava/lang/String;)Lcom/android/volley/a$a;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    if-eqz v0, :cond_12

    .line 7
    .line 8
    const-wide/16 v1, 0x0

    .line 9
    .line 10
    iput-wide v1, v0, Lcom/android/volley/a$a;->f:J

    .line 11
    .line 12
    if-eqz p2, :cond_f

    .line 13
    .line 14
    iput-wide v1, v0, Lcom/android/volley/a$a;->e:J

    .line 15
    .line 16
    :cond_f
    invoke-virtual {p0, p1, v0}, Lv3/d;->b(Ljava/lang/String;Lcom/android/volley/a$a;)V
    :try_end_12
    .catchall {:try_start_1 .. :try_end_12} :catchall_14

    .line 17
    .line 18
    .line 19
    :cond_12
    monitor-exit p0

    .line 20
    return-void

    .line 21
    :catchall_14
    move-exception p1

    .line 22
    monitor-exit p0

    .line 23
    throw p1
.end method

.method public declared-synchronized b(Ljava/lang/String;Lcom/android/volley/a$a;)V
    .registers 10

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-wide v0, p0, Lv3/d;->b:J

    .line 3
    .line 4
    iget-object v2, p2, Lcom/android/volley/a$a;->a:[B

    .line 5
    .line 6
    array-length v3, v2

    .line 7
    int-to-long v3, v3

    .line 8
    add-long/2addr v0, v3

    .line 9
    iget v3, p0, Lv3/d;->d:I

    .line 10
    .line 11
    int-to-long v4, v3

    .line 12
    cmp-long v6, v0, v4

    .line 13
    .line 14
    if-lez v6, :cond_1d

    .line 15
    .line 16
    array-length v0, v2
    :try_end_10
    .catchall {:try_start_1 .. :try_end_10} :catchall_7a

    .line 17
    int-to-float v0, v0

    .line 18
    int-to-float v1, v3

    .line 19
    const v2, 0x3f666666    # 0.9f

    .line 20
    .line 21
    .line 22
    mul-float v1, v1, v2

    .line 23
    .line 24
    cmpl-float v0, v0, v1

    .line 25
    .line 26
    if-lez v0, :cond_1d

    .line 27
    .line 28
    monitor-exit p0

    .line 29
    return-void

    .line 30
    :cond_1d
    :try_start_1d
    invoke-virtual {p0, p1}, Lv3/d;->e(Ljava/lang/String;)Ljava/io/File;

    .line 31
    .line 32
    .line 33
    move-result-object v0
    :try_end_21
    .catchall {:try_start_1d .. :try_end_21} :catchall_7a

    .line 34
    const/4 v1, 0x0

    .line 35
    const/4 v2, 0x1

    .line 36
    :try_start_23
    new-instance v3, Ljava/io/BufferedOutputStream;

    .line 37
    .line 38
    invoke-virtual {p0, v0}, Lv3/d;->d(Ljava/io/File;)Ljava/io/OutputStream;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    invoke-direct {v3, v4}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 43
    .line 44
    .line 45
    new-instance v4, Lv3/d$a;

    .line 46
    .line 47
    invoke-direct {v4, p1, p2}, Lv3/d$a;-><init>(Ljava/lang/String;Lcom/android/volley/a$a;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v4, v3}, Lv3/d$a;->d(Ljava/io/OutputStream;)Z

    .line 51
    .line 52
    .line 53
    move-result v5

    .line 54
    if-eqz v5, :cond_4c

    .line 55
    .line 56
    iget-object p2, p2, Lcom/android/volley/a$a;->a:[B

    .line 57
    .line 58
    invoke-virtual {v3, p2}, Ljava/io/OutputStream;->write([B)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/io/File;->length()J

    .line 65
    .line 66
    .line 67
    move-result-wide v5

    .line 68
    iput-wide v5, v4, Lv3/d$a;->a:J

    .line 69
    .line 70
    invoke-virtual {p0, p1, v4}, Lv3/d;->i(Ljava/lang/String;Lv3/d$a;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {p0}, Lv3/d;->h()V

    .line 74
    .line 75
    .line 76
    goto :goto_78

    .line 77
    :cond_4c
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 78
    .line 79
    .line 80
    const-string p1, "Failed to write header for %s"

    .line 81
    .line 82
    new-array p2, v2, [Ljava/lang/Object;

    .line 83
    .line 84
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    aput-object v3, p2, v1

    .line 89
    .line 90
    invoke-static {p1, p2}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    new-instance p1, Ljava/io/IOException;

    .line 94
    .line 95
    invoke-direct {p1}, Ljava/io/IOException;-><init>()V

    .line 96
    .line 97
    .line 98
    throw p1
    :try_end_62
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_62} :catch_62
    .catchall {:try_start_23 .. :try_end_62} :catchall_7a

    .line 99
    :catch_62
    :try_start_62
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 100
    .line 101
    .line 102
    move-result p1

    .line 103
    if-nez p1, :cond_75

    .line 104
    .line 105
    const-string p1, "Could not clean up file %s"

    .line 106
    .line 107
    new-array p2, v2, [Ljava/lang/Object;

    .line 108
    .line 109
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    aput-object v0, p2, v1

    .line 114
    .line 115
    invoke-static {p1, p2}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :cond_75
    invoke-virtual {p0}, Lv3/d;->g()V
    :try_end_78
    .catchall {:try_start_62 .. :try_end_78} :catchall_7a

    .line 119
    .line 120
    .line 121
    :goto_78
    monitor-exit p0

    .line 122
    return-void

    .line 123
    :catchall_7a
    move-exception p1

    .line 124
    monitor-exit p0

    .line 125
    throw p1
.end method

.method public c(Ljava/io/File;)Ljava/io/InputStream;
    .registers 3
    .annotation build Landroidx/annotation/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    new-instance v0, Ljava/io/FileInputStream;

    invoke-direct {v0, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    return-object v0
.end method

.method public d(Ljava/io/File;)Ljava/io/OutputStream;
    .registers 3
    .annotation build Landroidx/annotation/VisibleForTesting;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    return-object v0
.end method

.method public e(Ljava/lang/String;)Ljava/io/File;
    .registers 4

    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lv3/d;->c:Lv3/d$c;

    invoke-interface {v1}, Lv3/d$c;->get()Ljava/io/File;

    move-result-object v1

    invoke-virtual {p0, p1}, Lv3/d;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public final f(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    div-int/lit8 v0, v0, 0x2

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    new-instance v2, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    return-object p1
.end method

.method public final g()V
    .registers 3

    .line 1
    iget-object v0, p0, Lv3/d;->c:Lv3/d$c;

    .line 2
    .line 3
    invoke-interface {v0}, Lv3/d$c;->get()Ljava/io/File;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_20

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    new-array v0, v0, [Ljava/lang/Object;

    .line 15
    .line 16
    const-string v1, "Re-initializing cache after external clearing."

    .line 17
    .line 18
    invoke-static {v1, v0}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 22
    .line 23
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 24
    .line 25
    .line 26
    const-wide/16 v0, 0x0

    .line 27
    .line 28
    iput-wide v0, p0, Lv3/d;->b:J

    .line 29
    .line 30
    invoke-virtual {p0}, Lv3/d;->initialize()V

    .line 31
    .line 32
    .line 33
    :cond_20
    return-void
.end method

.method public declared-synchronized get(Ljava/lang/String;)Lcom/android/volley/a$a;
    .registers 12

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 3
    .line 4
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lv3/d$a;
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_7e

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-nez v0, :cond_e

    .line 12
    .line 13
    monitor-exit p0

    .line 14
    return-object v1

    .line 15
    :cond_e
    :try_start_e
    invoke-virtual {p0, p1}, Lv3/d;->e(Ljava/lang/String;)Ljava/io/File;

    .line 16
    .line 17
    .line 18
    move-result-object v2
    :try_end_12
    .catchall {:try_start_e .. :try_end_12} :catchall_7e

    .line 19
    const/4 v3, 0x1

    .line 20
    const/4 v4, 0x0

    .line 21
    const/4 v5, 0x2

    .line 22
    :try_start_15
    new-instance v6, Lv3/d$b;

    .line 23
    .line 24
    new-instance v7, Ljava/io/BufferedInputStream;

    .line 25
    .line 26
    invoke-virtual {p0, v2}, Lv3/d;->c(Ljava/io/File;)Ljava/io/InputStream;

    .line 27
    .line 28
    .line 29
    move-result-object v8

    .line 30
    invoke-direct {v7, v8}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 34
    .line 35
    .line 36
    move-result-wide v8

    .line 37
    invoke-direct {v6, v7, v8, v9}, Lv3/d$b;-><init>(Ljava/io/InputStream;J)V
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_15 .. :try_end_27} :catch_65
    .catchall {:try_start_15 .. :try_end_27} :catchall_7e

    .line 38
    .line 39
    .line 40
    :try_start_27
    invoke-static {v6}, Lv3/d$a;->b(Lv3/d$b;)Lv3/d$a;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    iget-object v8, v7, Lv3/d$a;->b:Ljava/lang/String;

    .line 45
    .line 46
    invoke-static {p1, v8}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 47
    .line 48
    .line 49
    move-result v8

    .line 50
    if-nez v8, :cond_4f

    .line 51
    .line 52
    const-string v0, "%s: key=%s, found=%s"

    .line 53
    .line 54
    const/4 v8, 0x3

    .line 55
    new-array v8, v8, [Ljava/lang/Object;

    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    aput-object v9, v8, v4

    .line 62
    .line 63
    aput-object p1, v8, v3

    .line 64
    .line 65
    iget-object v7, v7, Lv3/d$a;->b:Ljava/lang/String;

    .line 66
    .line 67
    aput-object v7, v8, v5

    .line 68
    .line 69
    invoke-static {v0, v8}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p0, p1}, Lv3/d;->p(Ljava/lang/String;)V
    :try_end_4a
    .catchall {:try_start_27 .. :try_end_4a} :catchall_60

    .line 73
    .line 74
    .line 75
    :try_start_4a
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V
    :try_end_4d
    .catch Ljava/io/IOException; {:try_start_4a .. :try_end_4d} :catch_65
    .catchall {:try_start_4a .. :try_end_4d} :catchall_7e

    .line 76
    .line 77
    .line 78
    monitor-exit p0

    .line 79
    return-object v1

    .line 80
    :cond_4f
    :try_start_4f
    invoke-virtual {v6}, Lv3/d$b;->b()J

    .line 81
    .line 82
    .line 83
    move-result-wide v7

    .line 84
    invoke-static {v6, v7, v8}, Lv3/d;->q(Lv3/d$b;J)[B

    .line 85
    .line 86
    .line 87
    move-result-object v7

    .line 88
    invoke-virtual {v0, v7}, Lv3/d$a;->c([B)Lcom/android/volley/a$a;

    .line 89
    .line 90
    .line 91
    move-result-object v0
    :try_end_5b
    .catchall {:try_start_4f .. :try_end_5b} :catchall_60

    .line 92
    :try_start_5b
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V
    :try_end_5e
    .catch Ljava/io/IOException; {:try_start_5b .. :try_end_5e} :catch_65
    .catchall {:try_start_5b .. :try_end_5e} :catchall_7e

    .line 93
    .line 94
    .line 95
    monitor-exit p0

    .line 96
    return-object v0

    .line 97
    :catchall_60
    move-exception v0

    .line 98
    :try_start_61
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    .line 99
    .line 100
    .line 101
    throw v0
    :try_end_65
    .catch Ljava/io/IOException; {:try_start_61 .. :try_end_65} :catch_65
    .catchall {:try_start_61 .. :try_end_65} :catchall_7e

    .line 102
    :catch_65
    move-exception v0

    .line 103
    :try_start_66
    const-string v6, "%s: %s"

    .line 104
    .line 105
    new-array v5, v5, [Ljava/lang/Object;

    .line 106
    .line 107
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v2

    .line 111
    aput-object v2, v5, v4

    .line 112
    .line 113
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    aput-object v0, v5, v3

    .line 118
    .line 119
    invoke-static {v6, v5}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0, p1}, Lv3/d;->o(Ljava/lang/String;)V
    :try_end_7c
    .catchall {:try_start_66 .. :try_end_7c} :catchall_7e

    .line 123
    .line 124
    .line 125
    monitor-exit p0

    .line 126
    return-object v1

    .line 127
    :catchall_7e
    move-exception p1

    .line 128
    monitor-exit p0

    .line 129
    throw p1
.end method

.method public final h()V
    .registers 15

    .line 1
    iget-wide v0, p0, Lv3/d;->b:J

    .line 2
    .line 3
    iget v2, p0, Lv3/d;->d:I

    .line 4
    .line 5
    int-to-long v2, v2

    .line 6
    cmp-long v4, v0, v2

    .line 7
    .line 8
    if-gez v4, :cond_a

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    sget-boolean v0, Lcom/android/volley/e;->b:Z

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    if-eqz v0, :cond_16

    .line 15
    .line 16
    new-array v0, v1, [Ljava/lang/Object;

    .line 17
    .line 18
    const-string v2, "Pruning old cache entries."

    .line 19
    .line 20
    invoke-static {v2, v0}, Lcom/android/volley/e;->e(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    :cond_16
    iget-wide v2, p0, Lv3/d;->b:J

    .line 24
    .line 25
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 26
    .line 27
    .line 28
    move-result-wide v4

    .line 29
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    const/4 v6, 0x0

    .line 40
    :cond_27
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 41
    .line 42
    .line 43
    move-result v7

    .line 44
    const/4 v8, 0x2

    .line 45
    const/4 v9, 0x1

    .line 46
    if-eqz v7, :cond_74

    .line 47
    .line 48
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v7

    .line 52
    check-cast v7, Ljava/util/Map$Entry;

    .line 53
    .line 54
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v7

    .line 58
    check-cast v7, Lv3/d$a;

    .line 59
    .line 60
    iget-object v10, v7, Lv3/d$a;->b:Ljava/lang/String;

    .line 61
    .line 62
    invoke-virtual {p0, v10}, Lv3/d;->e(Ljava/lang/String;)Ljava/io/File;

    .line 63
    .line 64
    .line 65
    move-result-object v10

    .line 66
    invoke-virtual {v10}, Ljava/io/File;->delete()Z

    .line 67
    .line 68
    .line 69
    move-result v10

    .line 70
    if-eqz v10, :cond_4f

    .line 71
    .line 72
    iget-wide v10, p0, Lv3/d;->b:J

    .line 73
    .line 74
    iget-wide v12, v7, Lv3/d$a;->a:J

    .line 75
    .line 76
    sub-long/2addr v10, v12

    .line 77
    iput-wide v10, p0, Lv3/d;->b:J

    .line 78
    .line 79
    goto :goto_60

    .line 80
    :cond_4f
    new-array v10, v8, [Ljava/lang/Object;

    .line 81
    .line 82
    iget-object v7, v7, Lv3/d$a;->b:Ljava/lang/String;

    .line 83
    .line 84
    aput-object v7, v10, v1

    .line 85
    .line 86
    invoke-virtual {p0, v7}, Lv3/d;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    aput-object v7, v10, v9

    .line 91
    .line 92
    const-string v7, "Could not delete cache entry for key=%s, filename=%s"

    .line 93
    .line 94
    invoke-static {v7, v10}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    :goto_60
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    .line 98
    .line 99
    .line 100
    add-int/lit8 v6, v6, 0x1

    .line 101
    .line 102
    iget-wide v10, p0, Lv3/d;->b:J

    .line 103
    .line 104
    long-to-float v7, v10

    .line 105
    iget v10, p0, Lv3/d;->d:I

    .line 106
    .line 107
    int-to-float v10, v10

    .line 108
    const v11, 0x3f666666    # 0.9f

    .line 109
    .line 110
    .line 111
    mul-float v10, v10, v11

    .line 112
    .line 113
    cmpg-float v7, v7, v10

    .line 114
    .line 115
    if-gez v7, :cond_27

    .line 116
    .line 117
    :cond_74
    sget-boolean v0, Lcom/android/volley/e;->b:Z

    .line 118
    .line 119
    if-eqz v0, :cond_9a

    .line 120
    .line 121
    const/4 v0, 0x3

    .line 122
    new-array v0, v0, [Ljava/lang/Object;

    .line 123
    .line 124
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 125
    .line 126
    .line 127
    move-result-object v6

    .line 128
    aput-object v6, v0, v1

    .line 129
    .line 130
    iget-wide v6, p0, Lv3/d;->b:J

    .line 131
    .line 132
    sub-long/2addr v6, v2

    .line 133
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    aput-object v1, v0, v9

    .line 138
    .line 139
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 140
    .line 141
    .line 142
    move-result-wide v1

    .line 143
    sub-long/2addr v1, v4

    .line 144
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    aput-object v1, v0, v8

    .line 149
    .line 150
    const-string v1, "pruned %d files, %d bytes, %d ms"

    .line 151
    .line 152
    invoke-static {v1, v0}, Lcom/android/volley/e;->e(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    :cond_9a
    return-void
.end method

.method public final i(Ljava/lang/String;Lv3/d$a;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_10

    .line 8
    .line 9
    iget-wide v0, p0, Lv3/d;->b:J

    .line 10
    .line 11
    iget-wide v2, p2, Lv3/d$a;->a:J

    .line 12
    .line 13
    add-long/2addr v0, v2

    .line 14
    iput-wide v0, p0, Lv3/d;->b:J

    .line 15
    .line 16
    goto :goto_22

    .line 17
    :cond_10
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 18
    .line 19
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    check-cast v0, Lv3/d$a;

    .line 24
    .line 25
    iget-wide v1, p0, Lv3/d;->b:J

    .line 26
    .line 27
    iget-wide v3, p2, Lv3/d$a;->a:J

    .line 28
    .line 29
    iget-wide v5, v0, Lv3/d$a;->a:J

    .line 30
    .line 31
    sub-long/2addr v3, v5

    .line 32
    add-long/2addr v1, v3

    .line 33
    iput-wide v1, p0, Lv3/d;->b:J

    .line 34
    .line 35
    :goto_22
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 36
    .line 37
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public declared-synchronized initialize()V
    .registers 10

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    iget-object v0, p0, Lv3/d;->c:Lv3/d$c;

    .line 3
    .line 4
    invoke-interface {v0}, Lv3/d$c;->get()Ljava/io/File;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v2, 0x0

    .line 13
    if-nez v1, :cond_24

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_22

    .line 20
    .line 21
    const-string v1, "Unable to create cache dir %s"

    .line 22
    .line 23
    const/4 v3, 0x1

    .line 24
    new-array v3, v3, [Ljava/lang/Object;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    aput-object v0, v3, v2

    .line 31
    .line 32
    invoke-static {v1, v3}, Lcom/android/volley/e;->c(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_22
    .catchall {:try_start_1 .. :try_end_22} :catchall_5f

    .line 33
    .line 34
    .line 35
    :cond_22
    monitor-exit p0

    .line 36
    return-void

    .line 37
    :cond_24
    :try_start_24
    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 38
    .line 39
    .line 40
    move-result-object v0
    :try_end_28
    .catchall {:try_start_24 .. :try_end_28} :catchall_5f

    .line 41
    if-nez v0, :cond_2c

    .line 42
    .line 43
    monitor-exit p0

    .line 44
    return-void

    .line 45
    :cond_2c
    :try_start_2c
    array-length v1, v0

    .line 46
    :goto_2d
    if-ge v2, v1, :cond_5d

    .line 47
    .line 48
    aget-object v3, v0, v2
    :try_end_31
    .catchall {:try_start_2c .. :try_end_31} :catchall_5f

    .line 49
    .line 50
    :try_start_31
    invoke-virtual {v3}, Ljava/io/File;->length()J

    .line 51
    .line 52
    .line 53
    move-result-wide v4

    .line 54
    new-instance v6, Lv3/d$b;

    .line 55
    .line 56
    new-instance v7, Ljava/io/BufferedInputStream;

    .line 57
    .line 58
    invoke-virtual {p0, v3}, Lv3/d;->c(Ljava/io/File;)Ljava/io/InputStream;

    .line 59
    .line 60
    .line 61
    move-result-object v8

    .line 62
    invoke-direct {v7, v8}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    .line 63
    .line 64
    .line 65
    invoke-direct {v6, v7, v4, v5}, Lv3/d$b;-><init>(Ljava/io/InputStream;J)V
    :try_end_43
    .catch Ljava/io/IOException; {:try_start_31 .. :try_end_43} :catch_57
    .catchall {:try_start_31 .. :try_end_43} :catchall_5f

    .line 66
    .line 67
    .line 68
    :try_start_43
    invoke-static {v6}, Lv3/d$a;->b(Lv3/d$b;)Lv3/d$a;

    .line 69
    .line 70
    .line 71
    move-result-object v7

    .line 72
    iput-wide v4, v7, Lv3/d$a;->a:J

    .line 73
    .line 74
    iget-object v4, v7, Lv3/d$a;->b:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {p0, v4, v7}, Lv3/d;->i(Ljava/lang/String;Lv3/d$a;)V
    :try_end_4e
    .catchall {:try_start_43 .. :try_end_4e} :catchall_52

    .line 77
    .line 78
    .line 79
    :try_start_4e
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    .line 80
    .line 81
    .line 82
    goto :goto_5a

    .line 83
    :catchall_52
    move-exception v4

    .line 84
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V

    .line 85
    .line 86
    .line 87
    throw v4
    :try_end_57
    .catch Ljava/io/IOException; {:try_start_4e .. :try_end_57} :catch_57
    .catchall {:try_start_4e .. :try_end_57} :catchall_5f

    .line 88
    :catch_57
    :try_start_57
    invoke-virtual {v3}, Ljava/io/File;->delete()Z
    :try_end_5a
    .catchall {:try_start_57 .. :try_end_5a} :catchall_5f

    .line 89
    .line 90
    .line 91
    :goto_5a
    add-int/lit8 v2, v2, 0x1

    .line 92
    .line 93
    goto :goto_2d

    .line 94
    :cond_5d
    monitor-exit p0

    .line 95
    return-void

    .line 96
    :catchall_5f
    move-exception v0

    .line 97
    monitor-exit p0

    .line 98
    throw v0
.end method

.method public declared-synchronized o(Ljava/lang/String;)V
    .registers 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_1
    invoke-virtual {p0, p1}, Lv3/d;->e(Ljava/lang/String;)Ljava/io/File;

    .line 3
    .line 4
    .line 5
    move-result-object v0

    .line 6
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    invoke-virtual {p0, p1}, Lv3/d;->p(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    if-nez v0, :cond_20

    .line 14
    .line 15
    const-string v0, "Could not delete cache entry for key=%s, filename=%s"

    .line 16
    .line 17
    const/4 v1, 0x2

    .line 18
    new-array v1, v1, [Ljava/lang/Object;

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    aput-object p1, v1, v2

    .line 22
    .line 23
    const/4 v2, 0x1

    .line 24
    invoke-virtual {p0, p1}, Lv3/d;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    aput-object p1, v1, v2

    .line 29
    .line 30
    invoke-static {v0, v1}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_22

    .line 31
    .line 32
    .line 33
    :cond_20
    monitor-exit p0

    .line 34
    return-void

    .line 35
    :catchall_22
    move-exception p1

    .line 36
    monitor-exit p0

    .line 37
    throw p1
.end method

.method public final p(Ljava/lang/String;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lv3/d;->a:Ljava/util/Map;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Lv3/d$a;

    .line 8
    .line 9
    if-eqz p1, :cond_11

    .line 10
    .line 11
    iget-wide v0, p0, Lv3/d;->b:J

    .line 12
    .line 13
    iget-wide v2, p1, Lv3/d$a;->a:J

    .line 14
    .line 15
    sub-long/2addr v0, v2

    .line 16
    iput-wide v0, p0, Lv3/d;->b:J

    .line 17
    .line 18
    :cond_11
    return-void
.end method

###### Class v3.d.a (v3.d$a)
.class public Lv3/d$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation build Landroidx/annotation/VisibleForTesting;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv3/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:J

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:J

.field public final e:J

.field public final f:J

.field public final g:J

.field public final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lu3/e;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/android/volley/a$a;)V
    .registers 15

    .line 9
    iget-object v2, p2, Lcom/android/volley/a$a;->b:Ljava/lang/String;

    iget-wide v3, p2, Lcom/android/volley/a$a;->c:J

    iget-wide v5, p2, Lcom/android/volley/a$a;->d:J

    iget-wide v7, p2, Lcom/android/volley/a$a;->e:J

    iget-wide v9, p2, Lcom/android/volley/a$a;->f:J

    .line 10
    invoke-static {p2}, Lv3/d$a;->a(Lcom/android/volley/a$a;)Ljava/util/List;

    move-result-object v11

    move-object v0, p0

    move-object v1, p1

    .line 11
    invoke-direct/range {v0 .. v11}, Lv3/d$a;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJLjava/util/List;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;JJJJLjava/util/List;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "JJJJ",
            "Ljava/util/List<",
            "Lu3/e;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lv3/d$a;->b:Ljava/lang/String;

    const-string p1, ""

    .line 3
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_e

    const/4 p2, 0x0

    :cond_e
    iput-object p2, p0, Lv3/d$a;->c:Ljava/lang/String;

    .line 4
    iput-wide p3, p0, Lv3/d$a;->d:J

    .line 5
    iput-wide p5, p0, Lv3/d$a;->e:J

    .line 6
    iput-wide p7, p0, Lv3/d$a;->f:J

    .line 7
    iput-wide p9, p0, Lv3/d$a;->g:J

    .line 8
    iput-object p11, p0, Lv3/d$a;->h:Ljava/util/List;

    return-void
.end method

.method public static a(Lcom/android/volley/a$a;)Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/volley/a$a;",
            ")",
            "Ljava/util/List<",
            "Lu3/e;",
            ">;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcom/android/volley/a$a;->h:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    iget-object p0, p0, Lcom/android/volley/a$a;->g:Ljava/util/Map;

    .line 7
    .line 8
    invoke-static {p0}, Lv3/e;->h(Ljava/util/Map;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public static b(Lv3/d$b;)Lv3/d$a;
    .registers 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-static {p0}, Lv3/d;->l(Ljava/io/InputStream;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, 0x20150306

    .line 6
    .line 7
    .line 8
    if-ne v0, v1, :cond_2c

    .line 9
    .line 10
    invoke-static {p0}, Lv3/d;->n(Lv3/d$b;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    invoke-static {p0}, Lv3/d;->n(Lv3/d$b;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    invoke-static {p0}, Lv3/d;->m(Ljava/io/InputStream;)J

    .line 19
    .line 20
    .line 21
    move-result-wide v5

    .line 22
    invoke-static {p0}, Lv3/d;->m(Ljava/io/InputStream;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v7

    .line 26
    invoke-static {p0}, Lv3/d;->m(Ljava/io/InputStream;)J

    .line 27
    .line 28
    .line 29
    move-result-wide v9

    .line 30
    invoke-static {p0}, Lv3/d;->m(Ljava/io/InputStream;)J

    .line 31
    .line 32
    .line 33
    move-result-wide v11

    .line 34
    invoke-static {p0}, Lv3/d;->k(Lv3/d$b;)Ljava/util/List;

    .line 35
    .line 36
    .line 37
    move-result-object v13

    .line 38
    new-instance p0, Lv3/d$a;

    .line 39
    .line 40
    move-object v2, p0

    .line 41
    invoke-direct/range {v2 .. v13}, Lv3/d$a;-><init>(Ljava/lang/String;Ljava/lang/String;JJJJLjava/util/List;)V

    .line 42
    .line 43
    .line 44
    return-object p0

    .line 45
    :cond_2c
    new-instance p0, Ljava/io/IOException;

    .line 46
    .line 47
    invoke-direct {p0}, Ljava/io/IOException;-><init>()V

    .line 48
    .line 49
    .line 50
    throw p0
.end method


# virtual methods
.method public c([B)Lcom/android/volley/a$a;
    .registers 5

    .line 1
    new-instance v0, Lcom/android/volley/a$a;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/android/volley/a$a;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, v0, Lcom/android/volley/a$a;->a:[B

    .line 7
    .line 8
    iget-object p1, p0, Lv3/d$a;->c:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p1, v0, Lcom/android/volley/a$a;->b:Ljava/lang/String;

    .line 11
    .line 12
    iget-wide v1, p0, Lv3/d$a;->d:J

    .line 13
    .line 14
    iput-wide v1, v0, Lcom/android/volley/a$a;->c:J

    .line 15
    .line 16
    iget-wide v1, p0, Lv3/d$a;->e:J

    .line 17
    .line 18
    iput-wide v1, v0, Lcom/android/volley/a$a;->d:J

    .line 19
    .line 20
    iget-wide v1, p0, Lv3/d$a;->f:J

    .line 21
    .line 22
    iput-wide v1, v0, Lcom/android/volley/a$a;->e:J

    .line 23
    .line 24
    iget-wide v1, p0, Lv3/d$a;->g:J

    .line 25
    .line 26
    iput-wide v1, v0, Lcom/android/volley/a$a;->f:J

    .line 27
    .line 28
    iget-object p1, p0, Lv3/d$a;->h:Ljava/util/List;

    .line 29
    .line 30
    invoke-static {p1}, Lv3/e;->i(Ljava/util/List;)Ljava/util/Map;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    iput-object p1, v0, Lcom/android/volley/a$a;->g:Ljava/util/Map;

    .line 35
    .line 36
    iget-object p1, p0, Lv3/d$a;->h:Ljava/util/List;

    .line 37
    .line 38
    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    iput-object p1, v0, Lcom/android/volley/a$a;->h:Ljava/util/List;

    .line 43
    .line 44
    return-object v0
.end method

.method public d(Ljava/io/OutputStream;)Z
    .registers 6

    .line 1
    const v0, 0x20150306

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_4
    invoke-static {p1, v0}, Lv3/d;->s(Ljava/io/OutputStream;I)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lv3/d$a;->b:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {p1, v0}, Lv3/d;->u(Ljava/io/OutputStream;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lv3/d$a;->c:Ljava/lang/String;

    .line 14
    .line 15
    if-nez v0, :cond_12

    .line 16
    .line 17
    const-string v0, ""

    .line 18
    .line 19
    :cond_12
    invoke-static {p1, v0}, Lv3/d;->u(Ljava/io/OutputStream;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-wide v2, p0, Lv3/d$a;->d:J

    .line 23
    .line 24
    invoke-static {p1, v2, v3}, Lv3/d;->t(Ljava/io/OutputStream;J)V

    .line 25
    .line 26
    .line 27
    iget-wide v2, p0, Lv3/d$a;->e:J

    .line 28
    .line 29
    invoke-static {p1, v2, v3}, Lv3/d;->t(Ljava/io/OutputStream;J)V

    .line 30
    .line 31
    .line 32
    iget-wide v2, p0, Lv3/d$a;->f:J

    .line 33
    .line 34
    invoke-static {p1, v2, v3}, Lv3/d;->t(Ljava/io/OutputStream;J)V

    .line 35
    .line 36
    .line 37
    iget-wide v2, p0, Lv3/d$a;->g:J

    .line 38
    .line 39
    invoke-static {p1, v2, v3}, Lv3/d;->t(Ljava/io/OutputStream;J)V

    .line 40
    .line 41
    .line 42
    iget-object v0, p0, Lv3/d$a;->h:Ljava/util/List;

    .line 43
    .line 44
    invoke-static {v0, p1}, Lv3/d;->r(Ljava/util/List;Ljava/io/OutputStream;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1}, Ljava/io/OutputStream;->flush()V
    :try_end_31
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_31} :catch_32

    .line 48
    .line 49
    .line 50
    return v1

    .line 51
    :catch_32
    move-exception p1

    .line 52
    new-array v0, v1, [Ljava/lang/Object;

    .line 53
    .line 54
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    const/4 v1, 0x0

    .line 59
    aput-object p1, v0, v1

    .line 60
    .line 61
    const-string p1, "%s"

    .line 62
    .line 63
    invoke-static {p1, v0}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    return v1
.end method

###### Class v3.d.b (v3.d$b)
.class public Lv3/d$b;
.super Ljava/io/FilterInputStream;
.source "SourceFile"


# annotations
.annotation build Landroidx/annotation/VisibleForTesting;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv3/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:J

.field public b:J


# direct methods
.method public constructor <init>(Ljava/io/InputStream;J)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    .line 2
    .line 3
    .line 4
    iput-wide p2, p0, Lv3/d$b;->a:J

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public b()J
    .registers 5

    iget-wide v0, p0, Lv3/d$b;->a:J

    iget-wide v2, p0, Lv3/d$b;->b:J

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public read()I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    invoke-super {p0}, Ljava/io/FilterInputStream;->read()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_e

    .line 2
    iget-wide v1, p0, Lv3/d$b;->b:J

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    iput-wide v1, p0, Lv3/d$b;->b:J

    :cond_e
    return v0
.end method

.method public read([BII)I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 3
    invoke-super {p0, p1, p2, p3}, Ljava/io/FilterInputStream;->read([BII)I

    move-result p1

    const/4 p2, -0x1

    if-eq p1, p2, :cond_d

    .line 4
    iget-wide p2, p0, Lv3/d$b;->b:J

    int-to-long v0, p1

    add-long/2addr p2, v0

    iput-wide p2, p0, Lv3/d$b;->b:J

    :cond_d
    return p1
.end method

###### Class v3.d.c (v3.d$c)
.class public interface abstract Lv3/d$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv3/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation


# virtual methods
.method public abstract get()Ljava/io/File;
.end method
