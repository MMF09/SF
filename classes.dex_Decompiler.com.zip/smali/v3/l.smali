###### Class v3.l (v3.l)
.class public final Lv3/l;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lv3/l$b;
    }
.end annotation


# direct methods
.method public static a(Lcom/android/volley/Request;Lv3/l$b;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/volley/Request<",
            "*>;",
            "Lv3/l$b;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lu3/p;
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lcom/android/volley/Request;->getRetryPolicy()Lu3/m;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Lcom/android/volley/Request;->getTimeoutMs()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x1

    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x2

    .line 12
    :try_start_b
    invoke-static {p1}, Lv3/l$b;->a(Lv3/l$b;)Lu3/p;

    .line 13
    .line 14
    .line 15
    move-result-object v5

    .line 16
    invoke-interface {v0, v5}, Lu3/m;->b(Lu3/p;)V
    :try_end_12
    .catch Lu3/p; {:try_start_b .. :try_end_12} :catch_2a

    .line 17
    .line 18
    .line 19
    new-array v0, v4, [Ljava/lang/Object;

    .line 20
    .line 21
    invoke-static {p1}, Lv3/l$b;->b(Lv3/l$b;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    aput-object p1, v0, v3

    .line 26
    .line 27
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    aput-object p1, v0, v2

    .line 32
    .line 33
    const-string p1, "%s-retry [timeout=%s]"

    .line 34
    .line 35
    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-virtual {p0, p1}, Lcom/android/volley/Request;->addMarker(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :catch_2a
    move-exception v0

    .line 44
    new-array v4, v4, [Ljava/lang/Object;

    .line 45
    .line 46
    invoke-static {p1}, Lv3/l$b;->b(Lv3/l$b;)Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    aput-object p1, v4, v3

    .line 51
    .line 52
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    aput-object p1, v4, v2

    .line 57
    .line 58
    const-string p1, "%s-timeout-giveup [timeout=%s]"

    .line 59
    .line 60
    invoke-static {p1, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-virtual {p0, p1}, Lcom/android/volley/Request;->addMarker(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    throw v0
.end method

.method public static b(Lcom/android/volley/Request;JLjava/util/List;)Lu3/h;
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/volley/Request<",
            "*>;J",
            "Ljava/util/List<",
            "Lu3/e;",
            ">;)",
            "Lu3/h;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lcom/android/volley/Request;->getCacheEntry()Lcom/android/volley/a$a;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-nez p0, :cond_13

    .line 6
    .line 7
    new-instance p0, Lu3/h;

    .line 8
    .line 9
    const/16 v1, 0x130

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    const/4 v3, 0x1

    .line 13
    move-object v0, p0

    .line 14
    move-wide v4, p1

    .line 15
    move-object v6, p3

    .line 16
    invoke-direct/range {v0 .. v6}, Lu3/h;-><init>(I[BZJLjava/util/List;)V

    .line 17
    .line 18
    .line 19
    return-object p0

    .line 20
    :cond_13
    invoke-static {p3, p0}, Lv3/e;->a(Ljava/util/List;Lcom/android/volley/a$a;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object v10

    .line 24
    new-instance p3, Lu3/h;

    .line 25
    .line 26
    const/16 v5, 0x130

    .line 27
    .line 28
    iget-object v6, p0, Lcom/android/volley/a$a;->a:[B

    .line 29
    .line 30
    const/4 v7, 0x1

    .line 31
    move-object v4, p3

    .line 32
    move-wide v8, p1

    .line 33
    invoke-direct/range {v4 .. v10}, Lu3/h;-><init>(I[BZJLjava/util/List;)V

    .line 34
    .line 35
    .line 36
    return-object p3
.end method

.method public static c(Ljava/io/InputStream;ILv3/c;)[B
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 1
    const-string v0, "Error occurred when closing InputStream"

    .line 2
    .line 3
    new-instance v1, Lv3/m;

    .line 4
    .line 5
    invoke-direct {v1, p2, p1}, Lv3/m;-><init>(Lv3/c;I)V

    .line 6
    .line 7
    .line 8
    const/16 p1, 0x400

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    :try_start_a
    invoke-virtual {p2, p1}, Lv3/c;->a(I)[B

    .line 12
    .line 13
    .line 14
    move-result-object p1
    :try_end_e
    .catchall {:try_start_a .. :try_end_e} :catchall_2f

    .line 15
    :goto_e
    :try_start_e
    invoke-virtual {p0, p1}, Ljava/io/InputStream;->read([B)I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    const/4 v4, -0x1

    .line 20
    if-eq v3, v4, :cond_19

    .line 21
    .line 22
    invoke-virtual {v1, p1, v2, v3}, Lv3/m;->write([BII)V

    .line 23
    .line 24
    .line 25
    goto :goto_e

    .line 26
    :cond_19
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 27
    .line 28
    .line 29
    move-result-object v3
    :try_end_1d
    .catchall {:try_start_e .. :try_end_1d} :catchall_2d

    .line 30
    :try_start_1d
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_20
    .catch Ljava/io/IOException; {:try_start_1d .. :try_end_20} :catch_21

    .line 31
    .line 32
    .line 33
    goto :goto_26

    .line 34
    :catch_21
    new-array p0, v2, [Ljava/lang/Object;

    .line 35
    .line 36
    invoke-static {v0, p0}, Lcom/android/volley/e;->e(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    :goto_26
    invoke-virtual {p2, p1}, Lv3/c;->b([B)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1}, Lv3/m;->close()V

    .line 43
    .line 44
    .line 45
    return-object v3

    .line 46
    :catchall_2d
    move-exception v3

    .line 47
    goto :goto_31

    .line 48
    :catchall_2f
    move-exception v3

    .line 49
    const/4 p1, 0x0

    .line 50
    :goto_31
    if-eqz p0, :cond_3c

    .line 51
    .line 52
    :try_start_33
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_36
    .catch Ljava/io/IOException; {:try_start_33 .. :try_end_36} :catch_37

    .line 53
    .line 54
    .line 55
    goto :goto_3c

    .line 56
    :catch_37
    new-array p0, v2, [Ljava/lang/Object;

    .line 57
    .line 58
    invoke-static {v0, p0}, Lcom/android/volley/e;->e(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :cond_3c
    :goto_3c
    invoke-virtual {p2, p1}, Lv3/c;->b([B)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v1}, Lv3/m;->close()V

    .line 65
    .line 66
    .line 67
    throw v3
.end method

.method public static d(JLcom/android/volley/Request;[BI)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lcom/android/volley/Request<",
            "*>;[BI)V"
        }
    .end annotation

    .line 1
    sget-boolean v0, Lcom/android/volley/e;->b:Z

    .line 2
    .line 3
    if-nez v0, :cond_a

    .line 4
    .line 5
    const-wide/16 v0, 0xbb8

    .line 6
    .line 7
    cmp-long v2, p0, v0

    .line 8
    .line 9
    if-lez v2, :cond_3f

    .line 10
    .line 11
    :cond_a
    const/4 v0, 0x5

    .line 12
    new-array v0, v0, [Ljava/lang/Object;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    aput-object p2, v0, v1

    .line 16
    .line 17
    const/4 v1, 0x1

    .line 18
    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    aput-object p0, v0, v1

    .line 23
    .line 24
    const/4 p0, 0x2

    .line 25
    if-eqz p3, :cond_20

    .line 26
    .line 27
    array-length p1, p3

    .line 28
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    goto :goto_22

    .line 33
    :cond_20
    const-string p1, "null"

    .line 34
    .line 35
    :goto_22
    aput-object p1, v0, p0

    .line 36
    .line 37
    const/4 p0, 0x3

    .line 38
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    aput-object p1, v0, p0

    .line 43
    .line 44
    const/4 p0, 0x4

    .line 45
    invoke-virtual {p2}, Lcom/android/volley/Request;->getRetryPolicy()Lu3/m;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-interface {p1}, Lu3/m;->a()I

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    aput-object p1, v0, p0

    .line 58
    .line 59
    const-string p0, "HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]"

    .line 60
    .line 61
    invoke-static {p0, v0}, Lcom/android/volley/e;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    :cond_3f
    return-void
.end method

.method public static e(Lcom/android/volley/Request;Ljava/io/IOException;JLv3/f;[B)Lv3/l$b;
    .registers 15
    .param p4    # Lv3/f;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .param p5    # [B
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/android/volley/Request<",
            "*>;",
            "Ljava/io/IOException;",
            "J",
            "Lv3/f;",
            "[B)",
            "Lv3/l$b;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lu3/p;
        }
    .end annotation

    .line 1
    instance-of v0, p1, Ljava/net/SocketTimeoutException;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_12

    .line 5
    .line 6
    new-instance p0, Lv3/l$b;

    .line 7
    .line 8
    new-instance p1, Lu3/o;

    .line 9
    .line 10
    invoke-direct {p1}, Lu3/o;-><init>()V

    .line 11
    .line 12
    .line 13
    const-string p2, "socket"

    .line 14
    .line 15
    invoke-direct {p0, p2, p1, v1}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V

    .line 16
    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_12
    instance-of v0, p1, Ljava/net/MalformedURLException;

    .line 20
    .line 21
    if-nez v0, :cond_b3

    .line 22
    .line 23
    if-eqz p4, :cond_9a

    .line 24
    .line 25
    invoke-virtual {p4}, Lv3/f;->d()I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    const/4 v0, 0x2

    .line 30
    new-array v0, v0, [Ljava/lang/Object;

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    aput-object v3, v0, v2

    .line 38
    .line 39
    const/4 v2, 0x1

    .line 40
    invoke-virtual {p0}, Lcom/android/volley/Request;->getUrl()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    aput-object v3, v0, v2

    .line 45
    .line 46
    const-string v2, "Unexpected response code %d for %s"

    .line 47
    .line 48
    invoke-static {v2, v0}, Lcom/android/volley/e;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    if-eqz p5, :cond_8d

    .line 52
    .line 53
    invoke-virtual {p4}, Lv3/f;->c()Ljava/util/List;

    .line 54
    .line 55
    .line 56
    move-result-object v8

    .line 57
    new-instance p4, Lu3/h;

    .line 58
    .line 59
    const/4 v5, 0x0

    .line 60
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 61
    .line 62
    .line 63
    move-result-wide v2

    .line 64
    sub-long v6, v2, p2

    .line 65
    .line 66
    move-object v2, p4

    .line 67
    move v3, p1

    .line 68
    move-object v4, p5

    .line 69
    invoke-direct/range {v2 .. v8}, Lu3/h;-><init>(I[BZJLjava/util/List;)V

    .line 70
    .line 71
    .line 72
    const/16 p2, 0x191

    .line 73
    .line 74
    if-eq p1, p2, :cond_80

    .line 75
    .line 76
    const/16 p2, 0x193

    .line 77
    .line 78
    if-ne p1, p2, :cond_50

    .line 79
    .line 80
    goto :goto_80

    .line 81
    :cond_50
    const/16 p2, 0x190

    .line 82
    .line 83
    if-lt p1, p2, :cond_5f

    .line 84
    .line 85
    const/16 p2, 0x1f3

    .line 86
    .line 87
    if-le p1, p2, :cond_59

    .line 88
    .line 89
    goto :goto_5f

    .line 90
    :cond_59
    new-instance p0, Lu3/b;

    .line 91
    .line 92
    invoke-direct {p0, p4}, Lu3/b;-><init>(Lu3/h;)V

    .line 93
    .line 94
    .line 95
    throw p0

    .line 96
    :cond_5f
    :goto_5f
    const/16 p2, 0x1f4

    .line 97
    .line 98
    if-lt p1, p2, :cond_7a

    .line 99
    .line 100
    const/16 p2, 0x257

    .line 101
    .line 102
    if-gt p1, p2, :cond_7a

    .line 103
    .line 104
    invoke-virtual {p0}, Lcom/android/volley/Request;->shouldRetryServerErrors()Z

    .line 105
    .line 106
    .line 107
    move-result p0

    .line 108
    if-eqz p0, :cond_7a

    .line 109
    .line 110
    new-instance p0, Lv3/l$b;

    .line 111
    .line 112
    new-instance p1, Lu3/n;

    .line 113
    .line 114
    invoke-direct {p1, p4}, Lu3/n;-><init>(Lu3/h;)V

    .line 115
    .line 116
    .line 117
    const-string p2, "server"

    .line 118
    .line 119
    invoke-direct {p0, p2, p1, v1}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V

    .line 120
    .line 121
    .line 122
    return-object p0

    .line 123
    :cond_7a
    new-instance p0, Lu3/n;

    .line 124
    .line 125
    invoke-direct {p0, p4}, Lu3/n;-><init>(Lu3/h;)V

    .line 126
    .line 127
    .line 128
    throw p0

    .line 129
    :cond_80
    :goto_80
    new-instance p0, Lv3/l$b;

    .line 130
    .line 131
    new-instance p1, Lu3/a;

    .line 132
    .line 133
    invoke-direct {p1, p4}, Lu3/a;-><init>(Lu3/h;)V

    .line 134
    .line 135
    .line 136
    const-string p2, "auth"

    .line 137
    .line 138
    invoke-direct {p0, p2, p1, v1}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V

    .line 139
    .line 140
    .line 141
    return-object p0

    .line 142
    :cond_8d
    new-instance p0, Lv3/l$b;

    .line 143
    .line 144
    new-instance p1, Lu3/g;

    .line 145
    .line 146
    invoke-direct {p1}, Lu3/g;-><init>()V

    .line 147
    .line 148
    .line 149
    const-string p2, "network"

    .line 150
    .line 151
    invoke-direct {p0, p2, p1, v1}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V

    .line 152
    .line 153
    .line 154
    return-object p0

    .line 155
    :cond_9a
    invoke-virtual {p0}, Lcom/android/volley/Request;->shouldRetryConnectionErrors()Z

    .line 156
    .line 157
    .line 158
    move-result p0

    .line 159
    if-eqz p0, :cond_ad

    .line 160
    .line 161
    new-instance p0, Lv3/l$b;

    .line 162
    .line 163
    new-instance p1, Lu3/i;

    .line 164
    .line 165
    invoke-direct {p1}, Lu3/i;-><init>()V

    .line 166
    .line 167
    .line 168
    const-string p2, "connection"

    .line 169
    .line 170
    invoke-direct {p0, p2, p1, v1}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V

    .line 171
    .line 172
    .line 173
    return-object p0

    .line 174
    :cond_ad
    new-instance p0, Lu3/i;

    .line 175
    .line 176
    invoke-direct {p0, p1}, Lu3/i;-><init>(Ljava/lang/Throwable;)V

    .line 177
    .line 178
    .line 179
    throw p0

    .line 180
    :cond_b3
    new-instance p2, Ljava/lang/RuntimeException;

    .line 181
    .line 182
    new-instance p3, Ljava/lang/StringBuilder;

    .line 183
    .line 184
    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    .line 185
    .line 186
    .line 187
    const-string p4, "Bad URL "

    .line 188
    .line 189
    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 190
    .line 191
    .line 192
    invoke-virtual {p0}, Lcom/android/volley/Request;->getUrl()Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object p0

    .line 196
    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object p0

    .line 203
    invoke-direct {p2, p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 204
    .line 205
    .line 206
    throw p2
.end method

###### Class v3.l.a (v3.l$a)
.class public synthetic Lv3/l$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv3/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1009
    name = null
.end annotation

###### Class v3.l.b (v3.l$b)
.class public Lv3/l$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lv3/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lu3/p;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lu3/p;)V
    .registers 3

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lv3/l$b;->a:Ljava/lang/String;

    .line 4
    iput-object p2, p0, Lv3/l$b;->b:Lu3/p;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lu3/p;Lv3/l$a;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1, p2}, Lv3/l$b;-><init>(Ljava/lang/String;Lu3/p;)V

    return-void
.end method

.method public static synthetic a(Lv3/l$b;)Lu3/p;
    .registers 1

    iget-object p0, p0, Lv3/l$b;->b:Lu3/p;

    return-object p0
.end method

.method public static synthetic b(Lv3/l$b;)Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lv3/l$b;->a:Ljava/lang/String;

    return-object p0
.end method
