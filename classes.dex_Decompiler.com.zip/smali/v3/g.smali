###### Class v3.g (v3.g)
.class public interface abstract Lv3/g;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation
