###### Class i1.w (i1.w)
.class public final synthetic Li1/w;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroidx/core/view/MenuProvider;Landroid/view/Menu;)V
    .registers 2
    .param p1    # Landroid/view/Menu;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    return-void
.end method

.method public static b(Landroidx/core/view/MenuProvider;Landroid/view/Menu;)V
    .registers 2
    .param p1    # Landroid/view/Menu;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    return-void
.end method
