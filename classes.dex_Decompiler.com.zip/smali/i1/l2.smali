###### Class i1.l2 (i1.l2)
.class public final synthetic Li1/l2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/view/Window;)Landroid/view/WindowInsetsController;
    .registers 1

    invoke-virtual {p0}, Landroid/view/Window;->getInsetsController()Landroid/view/WindowInsetsController;

    move-result-object p0

    return-object p0
.end method
