###### Class i1.b2 (i1.b2)
.class public final synthetic Li1/b2;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/view/WindowInsets$Builder;IZ)Landroid/view/WindowInsets$Builder;
    .registers 3

    invoke-virtual {p0, p1, p2}, Landroid/view/WindowInsets$Builder;->setVisible(IZ)Landroid/view/WindowInsets$Builder;

    move-result-object p0

    return-object p0
.end method
