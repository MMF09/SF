###### Class i1.o (i1.o)
.class public final synthetic Li1/o;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/view/MenuItem;)Ljava/lang/CharSequence;
    .registers 1

    invoke-interface {p0}, Landroid/view/MenuItem;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method
